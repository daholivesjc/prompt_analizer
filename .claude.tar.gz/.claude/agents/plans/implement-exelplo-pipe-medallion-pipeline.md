# Feature: exelplo-pipe — Phase 1: Foundation

The following plan covers **Phase 1 only** (Weeks 1-2) from the PRD.
Validate every task against `.claude/PRD/prd.md` sections 6, 7, 8, 9 before implementing.
Phase 2 (Silver/Gold/BQ/full template) is intentionally out of scope here.

---

## Feature Description

Establish the project skeleton, shared PySpark utilities, env-aware config system,
Terraform infrastructure (GCS, BQ datasets, IAM, Metastore, Scheduler), the Bronze ingest job
for the `events` entity, a minimal single-step Workflow Template, and a Makefile that ties
everything together. At the end of Phase 1 a data engineer can run
`make setup && make deploy && make run DATE=2024-01-01` and see a Bronze partition in GCS.

## User Story

As a data engineer,
I want a working project scaffold with one functional Bronze ingest stage,
So that I can verify the infrastructure and patterns before building Silver/Gold layers.

## Problem Statement

The project directory is empty. No code, no infrastructure, no config. Phase 1 must lay
every shared foundation that all future phases depend on — without over-building anything
that belongs to Phase 2.

## Solution Statement

Create the minimum viable set of files to satisfy the Phase 1 validation criterion:
`make run DATE=2024-01-01` triggers a Dataproc Workflow Template that spins up an ephemeral
cluster, runs `ingest_events.py`, writes Bronze Parquet to GCS, and auto-deletes the cluster.

## Feature Metadata

**Feature Type**: New Capability (Greenfield — Phase 1 only)
**Estimated Complexity**: Medium
**Primary Systems Affected**: jobs/common/, jobs/bronze/, config/, terraform/, templates/, scripts/
**Out of Scope**: Silver, Gold, BQ Load jobs, Cloud Functions trigger, maintenance job,
full 4-stage Workflow Template, Spot/Preemptible secondaries (Phase 2), monitoring alerts (Phase 2)

---

## CONTEXT REFERENCES

### Relevant Codebase Files — READ BEFORE IMPLEMENTING

- `.claude/PRD/prd.md` lines 219–270 — Canonical directory structure to follow exactly
- `.claude/PRD/prd.md` lines 548–561 — Phase 1 deliverables and validation command
- `.claude/PRD/prd.md` lines 284–295 — F-01 Bronze Ingest Job specification
- `.claude/PRD/prd.md` lines 342–347 — F-07 Environment Config System specification
- `.claude/PRD/prd.md` lines 406–427 — Security: SA model and Secret Manager pattern
- `.claude/PRD/prd.md` lines 362–402 — Technology stack versions

### New Files to Create (Phase 1 only)

```
exelplo-pipe/
├── pyproject.toml
├── requirements.txt
├── Makefile
├── .gitignore
├── jobs/
│   ├── common/
│   │   ├── __init__.py
│   │   ├── config.py           # env-aware config loader (GCS + Secret Manager)
│   │   ├── spark_session.py    # SparkSession factory (Iceberg + BQ pre-configured)
│   │   └── logging_utils.py    # structured Cloud Logging helpers
│   └── bronze/
│       └── ingest_events.py    # Bronze ingest job — events entity
├── config/
│   ├── base.yaml
│   ├── dev.yaml
│   ├── staging.yaml
│   └── prod.yaml
├── setup/
│   └── create_iceberg_tables.py   # DDL for silver.events + gold.daily_revenue
├── templates/
│   └── daily-pipeline.yaml        # MINIMAL: single Bronze step, managed cluster
├── terraform/
│   ├── main.tf
│   ├── variables.tf
│   ├── outputs.tf
│   ├── gcs.tf
│   ├── bigquery.tf
│   ├── iam.tf
│   ├── metastore.tf
│   └── scheduler.tf
├── tests/
│   └── unit/
│       ├── conftest.py
│       └── test_bronze_ingest.py
└── scripts/
    ├── deploy.sh
    └── run_pipeline.sh
```

### Relevant Documentation

- Iceberg Spark config: https://iceberg.apache.org/docs/latest/spark-configuration/
  - Why: Catalog setup keys for `spark.sql.catalog.*`
- Dataproc Workflow Templates: https://cloud.google.com/dataproc/docs/concepts/workflows/overview
  - Section: Managed cluster, parameters, YAML import via gcloud
- Dataproc Metastore connect: https://cloud.google.com/dataproc-metastore/docs/connect-dataproc
  - Why: `metastoreConfig.dataprocMetastoreService` field format
- Terraform google_dataproc_metastore_service: https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/dataproc_metastore_service
- Terraform google_storage_bucket lifecycle: https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket#lifecycle_rule

---

## PATTERNS TO FOLLOW

### Structured Logging (all jobs must follow this)

```python
# jobs/common/logging_utils.py
import json
from datetime import datetime, timezone

def _emit(severity: str, message: str, **extra):
    print(json.dumps({
        "severity": severity,
        "message": message,
        "job": _JOB_NAME,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        **extra,
    }), flush=True)
```

Dataproc YARN captures stdout and forwards it to Cloud Logging automatically.
Always include `run_date` and `rows_written` in the final log entry of each job.

### Config Loading from GCS

```python
# Jobs fetch config/ from GCS — NOT from local filesystem
# Config files are uploaded by scripts/deploy.sh before any run

def load_config(env: str, scripts_bucket: str) -> dict:
    client = storage.Client()
    bucket = client.bucket(scripts_bucket)
    base   = yaml.safe_load(bucket.blob("config/base.yaml").download_as_text())
    overrides = yaml.safe_load(bucket.blob(f"config/{env}.yaml").download_as_text())
    return _deep_merge(base, overrides)
```

**Gotcha**: `scripts_bucket` is the bucket name only — no `gs://` prefix.

### SparkSession — Iceberg + BQ configured, AQE on

```python
SparkSession.builder
    .config("spark.sql.extensions",
            "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
    .config("spark.sql.catalog.hive_prod", "org.apache.iceberg.spark.SparkCatalog")
    .config("spark.sql.catalog.hive_prod.type", "hive")
    .config("spark.sql.catalog.hive_prod.uri", "thrift://localhost:9083")
    .config("spark.sql.catalog.hive_prod.warehouse", config["storage"]["warehouse_uri"])
    .config("spark.sql.adaptive.enabled", "true")
    .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
    .enableHiveSupport()
    .getOrCreate()
```

On Dataproc with `metastoreConfig` set in the cluster spec, the Thrift URI
`thrift://localhost:9083` is injected automatically. Config provides it as override
for local test compatibility.

### Job CLI Args — every job must accept these four

```python
p.add_argument("--run_date",       required=True)
p.add_argument("--env",            required=True, choices=["dev", "staging", "prod"])
p.add_argument("--scripts_bucket", required=True)  # bucket name, no gs://
# Bronze only also needs:
p.add_argument("--source_path",    required=True)  # full gs:// URI
```

### Bronze Write Pattern — append-only Parquet

```python
df_out.repartition(n_partitions).write \
    .mode("append") \
    .format("parquet") \
    .option("compression", "snappy") \
    .save(bronze_path)
```

Bronze path: `gs://{data_lake_bucket}/bronze/events/ingested_date={run_date}/`

### Minimal Workflow Template — single Bronze step

```yaml
jobs:
  - stepId: bronze-ingest
    pysparkJob:
      mainPythonFileUri: "gs://SCRIPTS_BUCKET/jobs/bronze/ingest_events.py"
      args: ["--run_date=${run_date}", "--env=${env}",
             "--source_path=${source_path}", "--scripts_bucket=SCRIPTS_BUCKET"]
      jarFileUris:
        - "gs://spark-lib/bigquery/spark-bigquery-with-dependencies_2.12-0.44.0.jar"
        - "gs://spark-lib/iceberg/iceberg-spark-runtime-3.3_2.12-1.4.3.jar"
      pythonFileUris:
        - "gs://SCRIPTS_BUCKET/jobs/common/__init__.py"
        - "gs://SCRIPTS_BUCKET/jobs/common/config.py"
        - "gs://SCRIPTS_BUCKET/jobs/common/spark_session.py"
        - "gs://SCRIPTS_BUCKET/jobs/common/logging_utils.py"
```

**Gotcha**: `pythonFileUris` makes common modules available on all executors.
Without this, `from jobs.common import ...` fails at runtime.

---

## STEP-BY-STEP TASKS

---

### CREATE pyproject.toml

- **IMPLEMENT**: Python 3.10 project. `pyspark` goes in `[dev]` extras only — the cluster provides it at runtime.
- **VALIDATE**: `pip install -e ".[dev]" --dry-run`

```toml
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.backends.legacy:build"

[project]
name = "exelplo-pipe"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = [
    "pyyaml>=6.0",
    "google-cloud-storage>=2.14",
    "google-cloud-secret-manager>=2.16",
    "google-cloud-dataproc>=5.0",
]

[project.optional-dependencies]
dev = [
    "pyspark==3.3.4",
    "pytest>=7.4",
    "pytest-cov>=4.0",
]

[tool.pytest.ini_options]
testpaths = ["tests"]
python_files = ["test_*.py"]
```

---

### CREATE requirements.txt

- **IMPLEMENT**: Pip-format for Dataproc init actions (if needed) and Cloud Functions

```
pyyaml>=6.0
google-cloud-storage>=2.14
google-cloud-secret-manager>=2.16
google-cloud-dataproc>=5.0
```

- **VALIDATE**: `pip install -r requirements.txt --dry-run`

---

### CREATE .gitignore

```gitignore
__pycache__/
*.py[cod]
.venv/
*.egg-info/
.env
.terraform/
*.tfstate
*.tfstate.backup
.terraform.lock.hcl
*.tfvars
!example.tfvars
.pytest_cache/
.coverage
htmlcov/
/tmp/
```

---

### CREATE Makefile

- **IMPLEMENT**: Targets: `setup`, `deploy`, `test`, `run`, `terraform-init`, `terraform-plan`, `terraform-apply`
- **GOTCHA**: `GCP_PROJECT_ID` and `SCRIPTS_BUCKET` must be set in the shell or passed as make vars

```makefile
ENV            ?= dev
GCP_PROJECT_ID ?= $(shell gcloud config get-value project 2>/dev/null)
GCP_REGION     ?= us-central1
SCRIPTS_BUCKET ?= $(GCP_PROJECT_ID)-$(ENV)-pipe-scripts
RUN_DATE       ?= $(shell date -u --date='yesterday' '+%Y-%m-%d')
SOURCE_PATH    ?= gs://$(GCP_PROJECT_ID)-$(ENV)-data-lake/raw/events/$(RUN_DATE)/

.PHONY: setup deploy test run terraform-init terraform-plan terraform-apply

setup:
	pip install -e ".[dev]"

deploy:
	GCP_PROJECT_ID=$(GCP_PROJECT_ID) GCP_REGION=$(GCP_REGION) \
	METASTORE_SERVICE=exelplo-pipe-metastore-$(ENV) SUBNET=default \
	bash scripts/deploy.sh $(SCRIPTS_BUCKET)

test:
	pytest tests/unit/ -v --cov=jobs --cov-report=term-missing

run:
	bash scripts/run_pipeline.sh $(GCP_PROJECT_ID) $(GCP_REGION) $(ENV) $(RUN_DATE) $(SOURCE_PATH)

terraform-init:
	cd terraform && terraform init

terraform-plan:
	cd terraform && terraform plan \
	  -var="project_id=$(GCP_PROJECT_ID)" \
	  -var="region=$(GCP_REGION)" \
	  -var="env=$(ENV)"

terraform-apply:
	cd terraform && terraform apply \
	  -var="project_id=$(GCP_PROJECT_ID)" \
	  -var="region=$(GCP_REGION)" \
	  -var="env=$(ENV)"
```

- **VALIDATE**: `make --dry-run test`

---

### CREATE jobs/common/__init__.py

- **IMPLEMENT**: Empty file (makes `common` a Python package)
- **VALIDATE**: `python -c "import jobs.common"`

---

### CREATE jobs/common/logging_utils.py

- **IMPLEMENT**: Three public functions `info()`, `warn()`, `error()` emitting JSON to stdout
- **IMPLEMENT**: `configure(job_name)` sets the job label included in every entry

```python
import json
from datetime import datetime, timezone

_JOB_NAME: str = "unknown"


def configure(job_name: str) -> None:
    global _JOB_NAME
    _JOB_NAME = job_name


def _emit(severity: str, message: str, **extra) -> None:
    print(json.dumps({
        "severity": severity,
        "message": message,
        "job": _JOB_NAME,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        **extra,
    }), flush=True)


def info(message: str, **kw) -> None:  _emit("INFO",    message, **kw)
def warn(message: str, **kw) -> None:  _emit("WARNING", message, **kw)
def error(message: str, **kw) -> None: _emit("ERROR",   message, **kw)
```

- **VALIDATE**: `python -c "from jobs.common.logging_utils import info; info('ok', run_date='2024-01-01')"`

---

### CREATE jobs/common/config.py

- **IMPLEMENT**: `load_config(env, scripts_bucket)` — fetches `config/base.yaml` and `config/{env}.yaml` from GCS, deep-merges
- **IMPLEMENT**: `get_secret(project_id, secret_name)` — Secret Manager latest version accessor
- **IMPLEMENT**: `_deep_merge(base, override)` — recursive dict merge
- **IMPORTS**: `google.cloud.storage`, `google.cloud.secretmanager`, `yaml`

```python
import yaml
from google.cloud import storage, secretmanager


def load_config(env: str, scripts_bucket: str) -> dict:
    """Fetch base.yaml + {env}.yaml from GCS and deep-merge."""
    client = storage.Client()
    bucket = client.bucket(scripts_bucket)

    def _read(blob_name: str) -> dict:
        return yaml.safe_load(bucket.blob(blob_name).download_as_text())

    return _deep_merge(_read("config/base.yaml"), _read(f"config/{env}.yaml"))


def get_secret(project_id: str, secret_name: str) -> str:
    """Return latest version of a Secret Manager secret as a string."""
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
    return client.access_secret_version(name=name).payload.data.decode("UTF-8")


def _deep_merge(base: dict, override: dict) -> dict:
    result = base.copy()
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result
```

- **VALIDATE**: `python -c "from jobs.common.config import _deep_merge; assert _deep_merge({'a':{'b':1}},{'a':{'c':2}}) == {'a':{'b':1,'c':2}}"`

---

### CREATE jobs/common/spark_session.py

- **IMPLEMENT**: `get_spark_session(app_name, config)` — production session with Iceberg + AQE
- **IMPLEMENT**: `get_local_spark_session(app_name)` — unit-test session (local mode, no Hive)
- **GOTCHA**: `enableHiveSupport()` requires Hive jars (present on Dataproc 2.1, absent locally). Only call it in the production factory.

```python
from pyspark.sql import SparkSession


def get_spark_session(app_name: str, config: dict) -> SparkSession:
    """Production SparkSession: Iceberg catalog + AQE configured."""
    return (
        SparkSession.builder
        .appName(app_name)
        .config("spark.sql.extensions",
                "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
        .config("spark.sql.catalog.hive_prod", "org.apache.iceberg.spark.SparkCatalog")
        .config("spark.sql.catalog.hive_prod.type", "hive")
        .config("spark.sql.catalog.hive_prod.uri",
                config.get("metastore", {}).get("thrift_uri", "thrift://localhost:9083"))
        .config("spark.sql.catalog.hive_prod.warehouse",
                config["storage"]["warehouse_uri"])
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
        .enableHiveSupport()
        .getOrCreate()
    )


def get_local_spark_session(app_name: str) -> SparkSession:
    """Local SparkSession for unit tests — no Hive, no Iceberg catalog."""
    return (
        SparkSession.builder
        .appName(app_name)
        .master("local[2]")
        .config("spark.sql.shuffle.partitions", "4")
        .getOrCreate()
    )
```

- **VALIDATE**: `python -c "from jobs.common.spark_session import get_local_spark_session; s=get_local_spark_session('t'); s.stop()"`

---

### CREATE config/base.yaml

- **IMPLEMENT**: Shared defaults. All `REPLACE_*` values must be overridden in env files.
- **GOTCHA**: Jobs read this from GCS — it must be valid YAML parseable by `yaml.safe_load()`

```yaml
# Shared defaults across all environments.
# Override specific keys in config/{env}.yaml.

project:
  id: "REPLACE_WITH_GCP_PROJECT_ID"
  region: "us-central1"

metastore:
  # Injected automatically by Dataproc when metastoreConfig is set in cluster spec.
  # Override here only for local testing.
  thrift_uri: "thrift://localhost:9083"

storage:
  warehouse_uri: "gs://REPLACE_DATA_LAKE_BUCKET/warehouse/"
  bronze_prefix: "bronze"
  scripts_bucket: "REPLACE_SCRIPTS_BUCKET"
  staging_bucket: "REPLACE_BQ_STAGING_BUCKET"   # no gs:// prefix — BQ connector requirement

iceberg:
  catalog: "hive_prod"
  silver_db: "silver"
  gold_db: "gold"

bigquery:
  project: "REPLACE_WITH_GCP_PROJECT_ID"
  gold_dataset: "gold"
  silver_ext_dataset: "silver_ext"

pipeline:
  null_key_threshold: 0.01   # fail if > 1% of rows have null primary key
```

- **VALIDATE**: `python -c "import yaml; yaml.safe_load(open('config/base.yaml'))"`

---

### CREATE config/dev.yaml

```yaml
project:
  id: "my-project-dev"

storage:
  warehouse_uri: "gs://my-project-dev-data-lake/warehouse/"
  scripts_bucket: "my-project-dev-pipe-scripts"
  staging_bucket: "my-project-dev-bq-staging"

bigquery:
  project: "my-project-dev"
  gold_dataset: "gold_dev"
  silver_ext_dataset: "silver_ext_dev"
```

---

### CREATE config/staging.yaml

```yaml
project:
  id: "my-project-staging"

storage:
  warehouse_uri: "gs://my-project-staging-data-lake/warehouse/"
  scripts_bucket: "my-project-staging-pipe-scripts"
  staging_bucket: "my-project-staging-bq-staging"

bigquery:
  project: "my-project-staging"
  gold_dataset: "gold_staging"
  silver_ext_dataset: "silver_ext_staging"
```

---

### CREATE config/prod.yaml

```yaml
project:
  id: "my-project-prod"

storage:
  warehouse_uri: "gs://my-project-prod-data-lake/warehouse/"
  scripts_bucket: "my-project-prod-pipe-scripts"
  staging_bucket: "my-project-prod-bq-staging"

bigquery:
  project: "my-project-prod"
  gold_dataset: "gold_prod"
  silver_ext_dataset: "silver_ext_prod"
```

---

### CREATE jobs/bronze/ingest_events.py

- **IMPLEMENT**: Read raw files from `--source_path` → add metadata columns → append-only Parquet write to `bronze/events/ingested_date={run_date}/`
- **IMPLEMENT**: Detect file format from path suffix (parquet/csv/json/avro); default parquet
- **IMPLEMENT**: `mergeSchema=true` to tolerate upstream schema drift (F-01 spec)
- **IMPLEMENT**: Repartition to target ~128MB files before write (approx. 1 partition per 500k rows)
- **IMPLEMENT**: Log input row count, output path, and completion at INFO level
- **PATTERN**: Use `get_spark_session()` from `jobs.common.spark_session`
- **GOTCHA**: Bronze is APPEND-ONLY — never use `mode("overwrite")` here

```python
"""Bronze Ingest Job — events entity.

Reads raw files from source GCS path, adds ingested_date and ingested_at
metadata columns, and appends Parquet files to the Bronze GCS layer.
Never modifies or deduplicates source data.
"""
import argparse
from pyspark.sql import functions as F

from jobs.common import logging_utils
from jobs.common.config import load_config
from jobs.common.spark_session import get_spark_session

_FORMAT_MAP = {"csv": "csv", "json": "json", "avro": "avro", "parquet": "parquet"}


def _detect_format(source_path: str) -> str:
    for ext, fmt in _FORMAT_MAP.items():
        if source_path.lower().endswith(f".{ext}") or f"/{ext}/" in source_path.lower():
            return fmt
    return "parquet"


def parse_args():
    p = argparse.ArgumentParser(description="Bronze Ingest — events")
    p.add_argument("--run_date",       required=True, help="YYYY-MM-DD")
    p.add_argument("--env",            required=True, choices=["dev", "staging", "prod"])
    p.add_argument("--source_path",    required=True, help="gs:// URI to raw source files")
    p.add_argument("--scripts_bucket", required=True, help="GCS bucket holding config/ dir")
    return p.parse_args()


def main():
    args = parse_args()
    logging_utils.configure("bronze-ingest-events")
    logging_utils.info("Starting Bronze ingest", run_date=args.run_date, env=args.env,
                       source_path=args.source_path)

    config = load_config(args.env, args.scripts_bucket)
    spark = get_spark_session("bronze-ingest-events", config)

    fmt = _detect_format(args.source_path)
    logging_utils.info("Detected source format", format=fmt)

    df = (spark.read
          .option("mergeSchema", "true")
          .option("header", "true")       # CSV only; ignored by other formats
          .format(fmt)
          .load(args.source_path))

    df_out = df.withColumns({
        "ingested_date": F.lit(args.run_date).cast("date"),
        "ingested_at":   F.current_timestamp(),
    })

    row_count = df_out.count()
    n_partitions = max(1, row_count // 500_000)

    # Bronze path derived from config + run_date
    data_lake_bucket = config["storage"]["warehouse_uri"].split("/")[2]
    bronze_prefix    = config["storage"]["bronze_prefix"]
    bronze_path = f"gs://{data_lake_bucket}/{bronze_prefix}/events/ingested_date={args.run_date}/"

    (df_out
     .repartition(n_partitions)
     .write
     .mode("append")
     .format("parquet")
     .option("compression", "snappy")
     .save(bronze_path))

    logging_utils.info("Bronze ingest complete",
                       run_date=args.run_date,
                       rows_written=row_count,
                       partitions=n_partitions,
                       output_path=bronze_path)
    spark.stop()


if __name__ == "__main__":
    main()
```

- **VALIDATE**: `python -m py_compile jobs/bronze/ingest_events.py`

---

### CREATE setup/create_iceberg_tables.py

- **IMPLEMENT**: One-time DDL script. Creates Silver and Gold Iceberg tables via SparkSession.
- **IMPLEMENT**: `CREATE DATABASE IF NOT EXISTS` for both `silver` and `gold` namespaces.
- **IMPLEMENT**: `CREATE TABLE IF NOT EXISTS` — idempotent, safe to re-run.
- **GOTCHA**: Must be run once per environment BEFORE the pipeline runs, on a Dataproc cluster with Metastore access. Not run locally.

```python
"""One-time DDL: create Silver and Gold Iceberg tables in Dataproc Metastore."""
import argparse

from jobs.common import logging_utils
from jobs.common.config import load_config
from jobs.common.spark_session import get_spark_session

SILVER_EVENTS_DDL = """
CREATE TABLE IF NOT EXISTS {catalog}.silver.events (
    event_id        STRING        COMMENT 'Primary key',
    user_id         STRING,
    event_type      STRING,
    event_timestamp TIMESTAMP,
    revenue         DECIMAL(18,2),
    event_date      DATE          COMMENT 'Partition column'
)
USING iceberg
PARTITIONED BY (days(event_date))
TBLPROPERTIES (
    'write.target-file-size-bytes'       = '134217728',
    'write.parquet.compression-codec'    = 'snappy',
    'write.metadata.compression-codec'   = 'gzip',
    'history.expire.max-snapshot-age-ms' = '604800000'
)
"""

GOLD_DAILY_REVENUE_DDL = """
CREATE TABLE IF NOT EXISTS {catalog}.gold.daily_revenue (
    revenue_date  DATE          COMMENT 'Partition column',
    event_type    STRING,
    total_revenue DECIMAL(18,2),
    event_count   BIGINT,
    unique_users  BIGINT,
    avg_revenue   DECIMAL(18,6)
)
USING iceberg
PARTITIONED BY (days(revenue_date))
TBLPROPERTIES (
    'write.target-file-size-bytes'     = '134217728',
    'write.parquet.compression-codec'  = 'snappy',
    'write.metadata.compression-codec' = 'gzip'
)
"""


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--env",            required=True, choices=["dev", "staging", "prod"])
    p.add_argument("--scripts_bucket", required=True)
    return p.parse_args()


def main():
    args = parse_args()
    logging_utils.configure("setup-iceberg-tables")
    config  = load_config(args.env, args.scripts_bucket)
    spark   = get_spark_session("setup-iceberg-tables", config)
    catalog = config["iceberg"]["catalog"]

    statements = [
        f"CREATE DATABASE IF NOT EXISTS {catalog}.silver",
        f"CREATE DATABASE IF NOT EXISTS {catalog}.gold",
        SILVER_EVENTS_DDL.format(catalog=catalog),
        GOLD_DAILY_REVENUE_DDL.format(catalog=catalog),
    ]

    for sql in statements:
        logging_utils.info("Executing DDL", preview=sql.strip()[:80])
        spark.sql(sql)

    logging_utils.info("Iceberg table setup complete")
    spark.stop()


if __name__ == "__main__":
    main()
```

- **VALIDATE**: `python -m py_compile setup/create_iceberg_tables.py`

---

### CREATE templates/daily-pipeline.yaml

- **IMPLEMENT**: Minimal single-step Workflow Template (Bronze only). Phase 2 adds Silver/Gold/BQ steps.
- **IMPLEMENT**: Managed cluster (auto-create + auto-delete) — no Spot workers yet (Phase 2)
- **IMPLEMENT**: Metastore linked via `metastoreConfig` (required even for Bronze job so SparkSession config is consistent)
- **IMPLEMENT**: `autoDeleteTtl: 14400s` (4-hour safety net)
- **IMPLEMENT**: `internalIpOnly: true` for VPC-native cluster (no public IPs)
- **IMPLEMENT**: 3 template parameters: `run_date`, `env`, `source_path`
- **GOTCHA**: `parameters[].fields` paths are zero-indexed into the `args` array and must match the stepId exactly
- **GOTCHA**: `SCRIPTS_BUCKET`, `PROJECT`, `REGION`, `METASTORE_SERVICE`, `SUBNET` are shell placeholders replaced by `deploy.sh` via `sed` before importing

```yaml
# templates/daily-pipeline.yaml
# Phase 1: Bronze ingest only. Silver/Gold/BQ steps added in Phase 2.
# Placeholders (ALL_CAPS) are replaced by scripts/deploy.sh before gcloud import.

id: daily-pipeline
placement:
  managedCluster:
    clusterName: exelplo-pipe-daily
    config:
      masterConfig:
        numInstances: 1
        machineTypeUri: n2-standard-4
        diskConfig:
          bootDiskSizeGb: 100
      workerConfig:
        numInstances: 2
        machineTypeUri: n2-highmem-8
        diskConfig:
          bootDiskSizeGb: 200
      softwareConfig:
        imageVersion: "2.1-debian11"
        properties:
          "spark:spark.sql.adaptive.enabled": "true"
          "spark:spark.sql.adaptive.coalescePartitions.enabled": "true"
      metastoreConfig:
        dataprocMetastoreService: "projects/PROJECT/locations/REGION/services/METASTORE_SERVICE"
      gceClusterConfig:
        serviceAccount: "sa-dataproc-worker-ENV@PROJECT.iam.gserviceaccount.com"
        subnetworkUri: "projects/PROJECT/regions/REGION/subnetworks/SUBNET"
        internalIpOnly: true
        tags:
          - dataproc-cluster
          - exelplo-pipe
      lifecycleConfig:
        autoDeleteTtl: 14400s

jobs:
  - stepId: bronze-ingest
    pysparkJob:
      mainPythonFileUri: "gs://SCRIPTS_BUCKET/jobs/bronze/ingest_events.py"
      args:
        - "--run_date=${run_date}"
        - "--env=${env}"
        - "--source_path=${source_path}"
        - "--scripts_bucket=SCRIPTS_BUCKET"
      jarFileUris:
        - "gs://spark-lib/bigquery/spark-bigquery-with-dependencies_2.12-0.44.0.jar"
        - "gs://spark-lib/iceberg/iceberg-spark-runtime-3.3_2.12-1.4.3.jar"
      pythonFileUris:
        - "gs://SCRIPTS_BUCKET/jobs/common/__init__.py"
        - "gs://SCRIPTS_BUCKET/jobs/common/config.py"
        - "gs://SCRIPTS_BUCKET/jobs/common/spark_session.py"
        - "gs://SCRIPTS_BUCKET/jobs/common/logging_utils.py"

parameters:
  - name: run_date
    fields:
      - "jobs['bronze-ingest'].pysparkJob.args[0]"
    description: "Processing date — YYYY-MM-DD"
    validation:
      regex:
        regexes:
          - "^[0-9]{4}-[0-9]{2}-[0-9]{2}$"
  - name: env
    fields:
      - "jobs['bronze-ingest'].pysparkJob.args[1]"
    description: "Target environment"
    validation:
      values:
        values: [dev, staging, prod]
  - name: source_path
    fields:
      - "jobs['bronze-ingest'].pysparkJob.args[2]"
    description: "GCS URI to raw source files (gs://...)"
```

---

### CREATE terraform/variables.tf

```hcl
variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "region" {
  description = "GCP region"
  type        = string
  default     = "us-central1"
}

variable "env" {
  description = "Environment: dev, staging, or prod"
  type        = string
  validation {
    condition     = contains(["dev", "staging", "prod"], var.env)
    error_message = "env must be dev, staging, or prod."
  }
}

variable "subnet_name" {
  description = "VPC subnetwork name for Dataproc clusters"
  type        = string
  default     = "default"
}
```

---

### CREATE terraform/main.tf

- **IMPLEMENT**: Provider block, required_version, enable all required GCP APIs as a set
- **GOTCHA**: API enablement can take 1-2 minutes. Other resources should `depends_on = [google_project_service.apis]`

```hcl
terraform {
  required_version = ">= 1.5"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

resource "google_project_service" "apis" {
  for_each = toset([
    "dataproc.googleapis.com",
    "metastore.googleapis.com",
    "bigquery.googleapis.com",
    "storage.googleapis.com",
    "secretmanager.googleapis.com",
    "cloudscheduler.googleapis.com",
    "monitoring.googleapis.com",
    "logging.googleapis.com",
    "iam.googleapis.com",
  ])
  project            = var.project_id
  service            = each.key
  disable_on_destroy = false
}
```

---

### CREATE terraform/gcs.tf

- **IMPLEMENT**: 3 buckets — data lake (bronze/silver/gold prefixes), scripts, bq-staging
- **IMPLEMENT**: Lifecycle on data lake: Standard → Nearline at 30 days for `bronze/` prefix; Coldline at 90 days
- **IMPLEMENT**: BQ staging bucket auto-deletes objects after 7 days (cleanup of INDIRECT write temp files)
- **GOTCHA**: `matches_prefix` takes `["bronze/"]` — no leading slash

```hcl
locals {
  data_lake_bucket = "${var.project_id}-${var.env}-data-lake"
  scripts_bucket   = "${var.project_id}-${var.env}-pipe-scripts"
  staging_bucket   = "${var.project_id}-${var.env}-bq-staging"
}

resource "google_storage_bucket" "data_lake" {
  name          = local.data_lake_bucket
  location      = var.region
  storage_class = "STANDARD"
  force_destroy = var.env != "prod"
  uniform_bucket_level_access = true

  lifecycle_rule {
    condition {
      age            = 30
      matches_prefix = ["bronze/"]
    }
    action { type = "SetStorageClass"; storage_class = "NEARLINE" }
  }
  lifecycle_rule {
    condition {
      age            = 90
      matches_prefix = ["bronze/"]
    }
    action { type = "SetStorageClass"; storage_class = "COLDLINE" }
  }

  labels = { env = var.env, cost-center = "exelplo-pipe", managed-by = "terraform" }
  depends_on = [google_project_service.apis]
}

resource "google_storage_bucket" "scripts" {
  name     = local.scripts_bucket
  location = var.region
  uniform_bucket_level_access = true
  labels   = { env = var.env, managed-by = "terraform" }
  depends_on = [google_project_service.apis]
}

resource "google_storage_bucket" "bq_staging" {
  name     = local.staging_bucket
  location = var.region
  uniform_bucket_level_access = true
  lifecycle_rule {
    condition { age = 7 }
    action    { type = "Delete" }
  }
  labels = { env = var.env, managed-by = "terraform" }
  depends_on = [google_project_service.apis]
}
```

---

### CREATE terraform/iam.tf

- **IMPLEMENT**: 2 SAs for Phase 1: `sa-dataproc-worker-{env}` and `sa-pipeline-orchestrator-{env}`
- **IMPLEMENT**: Worker SA needs: `roles/dataproc.worker`, `roles/bigquery.dataEditor`, `roles/bigquery.jobUser`, `roles/metastore.editor`, `roles/secretmanager.secretAccessor`, `roles/logging.logWriter`, `roles/storage.objectAdmin` on all 3 buckets
- **IMPLEMENT**: Orchestrator SA needs: `roles/dataproc.editor` (to instantiate templates)
- **GOTCHA**: `roles/dataproc.worker` must be bound at the project level — not bucket-level

```hcl
resource "google_service_account" "dataproc_worker" {
  account_id   = "sa-dataproc-worker-${var.env}"
  display_name = "Dataproc Worker SA (${var.env})"
  project      = var.project_id
  depends_on   = [google_project_service.apis]
}

resource "google_service_account" "orchestrator" {
  account_id   = "sa-pipeline-orchestrator-${var.env}"
  display_name = "Pipeline Orchestrator SA (${var.env})"
  project      = var.project_id
  depends_on   = [google_project_service.apis]
}

locals {
  worker_sa = "serviceAccount:${google_service_account.dataproc_worker.email}"
}

resource "google_project_iam_member" "worker_project_roles" {
  for_each = toset([
    "roles/dataproc.worker",
    "roles/bigquery.dataEditor",
    "roles/bigquery.jobUser",
    "roles/metastore.editor",
    "roles/secretmanager.secretAccessor",
    "roles/logging.logWriter",
    "roles/monitoring.metricWriter",
  ])
  project = var.project_id
  role    = each.key
  member  = local.worker_sa
}

resource "google_storage_bucket_iam_member" "worker_storage" {
  for_each = {
    lake    = google_storage_bucket.data_lake.name
    scripts = google_storage_bucket.scripts.name
    staging = google_storage_bucket.bq_staging.name
  }
  bucket = each.value
  role   = "roles/storage.objectAdmin"
  member = local.worker_sa
}

resource "google_project_iam_member" "orchestrator_editor" {
  project = var.project_id
  role    = "roles/dataproc.editor"
  member  = "serviceAccount:${google_service_account.orchestrator.email}"
}
```

---

### CREATE terraform/metastore.tf

- **IMPLEMENT**: Dataproc Metastore service — DEVELOPER tier for dev, ENTERPRISE for prod
- **IMPLEMENT**: Hive version 3.1.2
- **IMPLEMENT**: `deletion_protection = true` for prod only
- **GOTCHA**: ENTERPRISE tier takes ~10-15 min to provision. DEVELOPER takes ~2-3 min. Plan around this.

```hcl
resource "google_dataproc_metastore_service" "main" {
  service_id = "exelplo-pipe-metastore-${var.env}"
  location   = var.region
  project    = var.project_id
  tier       = var.env == "prod" ? "ENTERPRISE" : "DEVELOPER"

  hive_metastore_config {
    version = "3.1.2"
  }

  deletion_protection = var.env == "prod"
  labels = { env = var.env, managed-by = "terraform" }
  depends_on = [google_project_service.apis]
}
```

---

### CREATE terraform/bigquery.tf

- **IMPLEMENT**: 2 datasets — `gold_{env}` (native tables from Spark) and `silver_ext_{env}` (external table placeholder)
- **NOTE**: Gold native table is created automatically on first BQ load job write (Phase 2). Silver external table is defined via `bq mk` CLI command documented below — Terraform only creates the dataset.

```hcl
resource "google_bigquery_dataset" "gold" {
  dataset_id = "gold_${var.env}"
  location   = var.region
  project    = var.project_id
  labels     = { env = var.env, managed-by = "terraform" }
  depends_on = [google_project_service.apis]
}

resource "google_bigquery_dataset" "silver_ext" {
  dataset_id = "silver_ext_${var.env}"
  location   = var.region
  project    = var.project_id
  labels     = { env = var.env, managed-by = "terraform" }
  depends_on = [google_project_service.apis]
}
```

---

### CREATE terraform/scheduler.tf

- **IMPLEMENT**: Cloud Scheduler job that triggers a Cloud Function (Phase 1: stub — just documents the target)
- **NOTE**: In Phase 1, Cloud Scheduler is configured but calls `run_pipeline.sh` manually via `make run`. Automated scheduling (Scheduler → Cloud Functions → Dataproc) is completed in Phase 3.
- **IMPLEMENT**: Create the scheduler SA with minimal permissions

```hcl
resource "google_service_account" "scheduler" {
  account_id   = "sa-scheduler-${var.env}"
  display_name = "Cloud Scheduler SA (${var.env})"
  project      = var.project_id
  depends_on   = [google_project_service.apis]
}

# Scheduler SA can impersonate orchestrator SA
resource "google_service_account_iam_member" "scheduler_impersonate" {
  service_account_id = google_service_account.orchestrator.name
  role               = "roles/iam.serviceAccountTokenCreator"
  member             = "serviceAccount:${google_service_account.scheduler.email}"
}

# Full Cloud Scheduler job wired to Dataproc API will be added in Phase 3
# (requires Cloud Functions intermediary to compute run_date dynamically)
```

---

### CREATE terraform/outputs.tf

```hcl
output "data_lake_bucket"    { value = google_storage_bucket.data_lake.name }
output "scripts_bucket"      { value = google_storage_bucket.scripts.name }
output "staging_bucket"      { value = google_storage_bucket.bq_staging.name }
output "metastore_service"   { value = google_dataproc_metastore_service.main.name }
output "worker_sa_email"     { value = google_service_account.dataproc_worker.email }
output "orchestrator_sa_email" { value = google_service_account.orchestrator.email }
output "gold_dataset"        { value = google_bigquery_dataset.gold.dataset_id }
output "silver_ext_dataset"  { value = google_bigquery_dataset.silver_ext.dataset_id }
```

---

### CREATE scripts/deploy.sh

- **IMPLEMENT**: Upload `jobs/` and `config/` to GCS scripts bucket; substitute placeholders in template YAML; import Workflow Template via `gcloud`
- **IMPLEMENT**: Derive `METASTORE_SERVICE` from naming convention if not set
- **IMPLEMENT**: Print each step for visibility
- **GOTCHA**: `sed` substitution order matters — replace longer strings before shorter ones to avoid partial replacements

```bash
#!/usr/bin/env bash
set -euo pipefail

SCRIPTS_BUCKET="${1:?Usage: deploy.sh SCRIPTS_BUCKET}"
PROJECT="${GCP_PROJECT_ID:?'GCP_PROJECT_ID env var required'}"
REGION="${GCP_REGION:-us-central1}"
ENV="${PIPELINE_ENV:-dev}"
METASTORE_SERVICE="${METASTORE_SERVICE:-exelplo-pipe-metastore-${ENV}}"
SUBNET="${SUBNET:-default}"

echo "==> Deploying to gs://${SCRIPTS_BUCKET} (env=${ENV})"

echo "  Syncing jobs/ ..."
gsutil -m rsync -r jobs/ "gs://${SCRIPTS_BUCKET}/jobs/"

echo "  Syncing config/ ..."
gsutil -m rsync -r config/ "gs://${SCRIPTS_BUCKET}/config/"

echo "  Rendering daily-pipeline.yaml ..."
sed \
    -e "s|SCRIPTS_BUCKET|${SCRIPTS_BUCKET}|g" \
    -e "s|METASTORE_SERVICE|${METASTORE_SERVICE}|g" \
    -e "s|PROJECT|${PROJECT}|g" \
    -e "s|REGION|${REGION}|g" \
    -e "s|SUBNET|${SUBNET}|g" \
    -e "s|ENV|${ENV}|g" \
    templates/daily-pipeline.yaml > /tmp/daily-pipeline-rendered.yaml

echo "  Importing Workflow Template ..."
gcloud dataproc workflow-templates import daily-pipeline \
    --source=/tmp/daily-pipeline-rendered.yaml \
    --region="${REGION}" \
    --project="${PROJECT}"

echo "==> Deploy complete."
echo "    Run: make run DATE=YYYY-MM-DD ENV=${ENV}"
```

- **VALIDATE**: `bash -n scripts/deploy.sh`

---

### CREATE scripts/run_pipeline.sh

- **IMPLEMENT**: One-command manual trigger for ad-hoc and backfill runs

```bash
#!/usr/bin/env bash
set -euo pipefail

PROJECT="${1:?Usage: run_pipeline.sh PROJECT REGION ENV RUN_DATE SOURCE_PATH}"
REGION="${2:?REGION required}"
ENV="${3:?ENV required (dev|staging|prod)}"
RUN_DATE="${4:?RUN_DATE required (YYYY-MM-DD)}"
SOURCE_PATH="${5:?SOURCE_PATH required (gs://...)}"

echo "Triggering daily-pipeline: project=${PROJECT} env=${ENV} date=${RUN_DATE}"
echo "Source: ${SOURCE_PATH}"

gcloud dataproc workflow-templates instantiate daily-pipeline \
    --region="${REGION}" \
    --project="${PROJECT}" \
    --parameters="run_date=${RUN_DATE},env=${ENV},source_path=${SOURCE_PATH}"

echo "Pipeline instantiated."
echo "Monitor: https://console.cloud.google.com/dataproc/workflows?project=${PROJECT}"
```

- **VALIDATE**: `bash -n scripts/run_pipeline.sh`

---

### CREATE tests/unit/conftest.py

- **IMPLEMENT**: Session-scoped local SparkSession fixture for all unit tests
- **GOTCHA**: `scope="session"` means one SparkSession per test run — avoids slow restarts

```python
import pytest
from jobs.common.spark_session import get_local_spark_session


@pytest.fixture(scope="session")
def spark():
    session = get_local_spark_session("test-suite")
    yield session
    session.stop()
```

---

### CREATE tests/unit/test_bronze_ingest.py

- **IMPLEMENT**: Test metadata columns are added correctly
- **IMPLEMENT**: Test Bronze is append-only (no dedup — verify all rows preserved)
- **IMPLEMENT**: Test format detection helper
- **PATTERN**: Use `spark.createDataFrame()` for test data; test pure functions directly

```python
from datetime import date
from pyspark.sql import functions as F
from jobs.bronze.ingest_events import _detect_format


def test_bronze_adds_ingested_date(spark):
    df = spark.createDataFrame(
        [("evt_001", "user_1", "purchase", 99.99)],
        ["event_id", "user_id", "event_type", "revenue"]
    )
    run_date = "2024-01-15"
    df_out = df.withColumns({
        "ingested_date": F.lit(run_date).cast("date"),
        "ingested_at":   F.current_timestamp(),
    })
    assert "ingested_date" in df_out.columns
    assert "ingested_at"   in df_out.columns
    assert df_out.first()["ingested_date"] == date(2024, 1, 15)


def test_bronze_does_not_deduplicate(spark):
    """Bronze must preserve duplicates — dedup is Silver's responsibility."""
    df = spark.createDataFrame(
        [("evt_001",), ("evt_001",), ("evt_002",)],
        ["event_id"]
    )
    assert df.count() == 3


def test_detect_format_parquet_default():
    assert _detect_format("gs://bucket/raw/events/") == "parquet"


def test_detect_format_csv():
    assert _detect_format("gs://bucket/raw/events/file.csv") == "csv"


def test_detect_format_json():
    assert _detect_format("gs://bucket/raw/events/json/file") == "json"


def test_detect_format_avro():
    assert _detect_format("gs://bucket/raw/events/file.avro") == "avro"
```

- **VALIDATE**: `pytest tests/unit/test_bronze_ingest.py -v`

---

## TESTING STRATEGY

### Unit Tests (Phase 1 scope)

Run fully locally — no GCP credentials required.

| File | What is tested |
|---|---|
| `test_bronze_ingest.py` | Metadata column addition, no-dedup invariant, format detection |
| `conftest.py` | Local SparkSession fixture |

**Run:** `make test`
**Expected:** All tests green, coverage report emitted for `jobs/`

### Integration Tests (not in Phase 1)

Integration tests against a live dev GCP environment are Phase 2 scope.
The `tests/integration/` directory is NOT created in Phase 1.

---

## VALIDATION COMMANDS

### Level 1: Syntax

```bash
# All job Python files
python -m py_compile jobs/common/__init__.py
python -m py_compile jobs/common/logging_utils.py
python -m py_compile jobs/common/config.py
python -m py_compile jobs/common/spark_session.py
python -m py_compile jobs/bronze/ingest_events.py
python -m py_compile setup/create_iceberg_tables.py

# YAML configs
python -c "
import yaml, glob
for f in glob.glob('config/*.yaml'):
    yaml.safe_load(open(f))
    print(f'OK: {f}')
"

# Shell scripts
bash -n scripts/deploy.sh
bash -n scripts/run_pipeline.sh

# Terraform
cd terraform && terraform fmt -check && terraform validate
```

### Level 2: Unit Tests

```bash
make test
# All tests must pass. Coverage for jobs/ reported.
```

### Level 3: Terraform Plan

```bash
export GCP_PROJECT_ID=my-project-dev
make terraform-init
make terraform-plan ENV=dev
# Must show: N resources to add, 0 to change, 0 to destroy
```

### Level 4: End-to-End (dev GCP environment)

```bash
# 1. Provision infrastructure
make terraform-apply ENV=dev

# 2. Deploy scripts and import Workflow Template
export GCP_PROJECT_ID=my-project-dev
export GCP_REGION=us-central1
export PIPELINE_ENV=dev
export METASTORE_SERVICE=exelplo-pipe-metastore-dev
make deploy ENV=dev

# 3. Run one-time DDL setup (on a Dataproc cluster with Metastore access)
#    Submit as a Dataproc job or use run_pipeline.sh with setup script

# 4. Trigger Bronze ingest for a test date
make run DATE=2024-01-01 \
  SOURCE_PATH=gs://my-project-dev-data-lake/raw/events/2024-01-01/

# 5. Verify Bronze partition written
gsutil ls gs://my-project-dev-data-lake/bronze/events/ingested_date=2024-01-01/
# Expected: one or more .parquet files

# 6. Verify cluster auto-deleted
gcloud dataproc clusters list --region=us-central1 --project=my-project-dev
# Expected: no cluster named exelplo-pipe-daily
```

---

## ACCEPTANCE CRITERIA

- [ ] `python -m py_compile` passes on all Phase 1 job files
- [ ] `terraform validate` passes
- [ ] `make test` passes — all bronze unit tests green
- [ ] `make deploy` syncs files to GCS and imports the Workflow Template without error
- [ ] `make run DATE=2024-01-01 SOURCE_PATH=...` triggers Dataproc Workflow Template
- [ ] Bronze Parquet partition appears at `gs://.../bronze/events/ingested_date=2024-01-01/`
- [ ] Cluster auto-deletes after successful run (confirmed via `gcloud dataproc clusters list`)
- [ ] Cloud Logging shows structured JSON entries from the job (visible in Log Explorer)
- [ ] Terraform provisions all resources cleanly on a fresh GCP project

---

## NOTES

### Phase 1 Boundaries — What NOT to Build

| Item | Phase |
|---|---|
| Silver transform job | Phase 2 |
| Gold aggregation job | Phase 2 |
| BigQuery load job | Phase 2 |
| Full 4-step Workflow Template | Phase 2 |
| Spot/Preemptible secondary workers | Phase 2 |
| Cloud Monitoring alert policies | Phase 2 |
| Iceberg maintenance job | Phase 3 |
| Cloud Functions GCS trigger | Phase 3 |
| Automated Cloud Scheduler → Dataproc | Phase 3 |
| BQ Silver external table (bq mk) | Phase 2 |

### Critical Gotchas

1. **`pythonFileUris` in Workflow Template** — Without listing each `jobs/common/*.py` file under `pythonFileUris`, the `from jobs.common import ...` imports fail silently at executor startup with `ModuleNotFoundError`.

2. **`sed` placeholder order in deploy.sh** — Replace `SCRIPTS_BUCKET` before `BUCKET` (if present) to avoid partial matches. Use `|` as delimiter in sed to avoid conflicts with `/` in GCS paths.

3. **Metastore DEVELOPER tier** — Only valid in select regions. Confirm `us-central1` availability before applying. Use `gcloud metastore services list --location=us-central1` to verify.

4. **`autoDeleteTtl` format** — Must be a duration string like `"14400s"` (not `14400`). Incorrect format causes template import to fail with a cryptic API error.

5. **`internalIpOnly: true`** — Requires the subnet to have Private Google Access enabled. If it does not, GCS/BQ calls from workers will fail. Enable via: `gcloud compute networks subnets update SUBNET --enable-private-ip-google-access --region=REGION`.

6. **Config files fetched from GCS** — `config.py` calls `storage.Client()` at job startup. If the worker SA lacks `roles/storage.objectViewer` on the scripts bucket, the job fails immediately. The `google_storage_bucket_iam_member` Terraform resource handles this — apply Terraform before `make deploy`.

7. **`pyspark` in dev deps only** — `pyspark==3.3.4` must be in `[dev]` extras, not in `dependencies`. Installing it on a Dataproc cluster via an init action would conflict with the pre-installed Spark version.
