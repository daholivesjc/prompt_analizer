# Validate Prompt Command

> Structured prompt validation using CASTROFF framework, 6-step debug protocol, security audit, and production readiness check.

## Usage

```bash
# Inline (paste prompt when asked)
/validate-prompt
/validate-prompt --audit
/validate-prompt --debug
/validate-prompt --security
/validate-prompt --production
/validate-prompt --compare
/validate-prompt --quick

# File input (pass a .txt, .md, or .py file)
/validate-prompt prompts/extraction.txt
/validate-prompt --audit prompts/extraction.txt
/validate-prompt --debug prompts/classifier.md
/validate-prompt --security prompts/user_facing.txt
/validate-prompt --production prompts/invoice_extractor.txt
/validate-prompt --compare prompts/v1.txt prompts/v2.txt
/validate-prompt --quick prompts/draft.txt
```

---

## Overview

This command invokes the **prompt-validator** agent to audit, score, and report on prompt quality across all relevant dimensions.

```text
┌─────────────────────────────────────────────────────────────────┐
│                   PROMPT VALIDATION PIPELINE                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  INPUT          AUDIT                SCORE          OUTPUT      │
│                                                                 │
│  ┌──────┐   ┌──────────┐   ┌──────────────────┐   ┌────────┐  │
│  │Prompt│──▶│ CASTROFF │──▶│ Dimension scores │──▶│ Report │  │
│  └──────┘   │ 8 checks │   │ + Grade A/B/C/D  │   └────────┘  │
│             └──────────┘   └──────────────────┘                │
│                 │                                               │
│            ┌────┴──────────────────────────────┐               │
│            │ Debug  │ Security  │ Production    │               │
│            │ Proto. │  Audit    │  Readiness    │               │
│            └────────────────────────────────────┘              │
└─────────────────────────────────────────────────────────────────┘
```

| Mode | Agent Capability | Best For |
|------|-----------------|----------|
| Full | All 5 capabilities | Pre-deploy review |
| `--audit` | CASTROFF only | Quick quality check |
| `--debug` | 6-step debug protocol | Inconsistent outputs |
| `--security` | Security + attack taxonomy | Prompts with external input |
| `--production` | Production readiness | Deployment gate |
| `--compare` | Comparative scoring | Choosing between variants |
| `--quick` | CASTROFF score only | Fast feedback during iteration |

---

## Process

### Step 1: Collect Input

**If a file path is provided as argument**, read it directly:

```text
Supported formats: .txt, .md, .py, .json
Single file:  /validate-prompt prompts/extraction.txt
Two files:    /validate-prompt --compare prompts/v1.txt prompts/v2.txt
```

Resolution order:
1. File path in args → read file with Read tool
2. No args → ask user to paste the prompt inline

**Required context (collect if missing):**
- Target task (extraction, classification, generation, reasoning, etc.)
- Target LLM model (if known — affects chat template checks)
- Whether external user input is processed (routes security audit)

**If `--compare`:** accept two file paths (`v1.txt v2.txt`) or ask for each variant inline.

### Step 2: Route to Validation Mode

```text
/validate-prompt              → Full: CASTROFF + Debug (if issues) + Security + Production
/validate-prompt --audit      → CASTROFF audit only
/validate-prompt --debug      → 6-step debug protocol
/validate-prompt --security   → Security & injection audit
/validate-prompt --production → Production readiness check
/validate-prompt --compare    → Comparative scoring of two variants
/validate-prompt --quick      → CASTROFF score + top 3 issues only
```

### Step 3: Invoke prompt-validator Agent

Delegate to `.claude/agents/ai-ml/prompt-validator.md` with the collected context and selected mode.

**KB files the agent will load:**

| Mode | KB References |
|------|--------------|
| Full | `index.md`, `castroff-framework.md`, `evaluation-metrics.md`, `advanced-security.md`, `prompt-production-management.md` |
| `--audit` | `index.md`, `castroff-framework.md` |
| `--debug` | `prompt-debug-protocol.md`, `castroff-framework.md` |
| `--security` | `advanced-security.md`, `specs/attack-taxonomy.yaml` |
| `--production` | `prompt-production-management.md`, `evaluation-metrics.md` |
| `--compare` | `castroff-framework.md`, `evaluation-metrics.md` |
| `--quick` | `castroff-framework.md` |

### Step 4: Deliver Report

Return the structured validation report from the agent.

---

## Output Format

### Full Validation

```markdown
# Prompt Validation Report
**Date:** {date}
**Prompt ID:** {id or description}
**Task Type:** {extraction | classification | generation | reasoning | other}

---

## Summary

| Check             | Result                          |
|-------------------|---------------------------------|
| CASTROFF Score    | {X}/16 ({%}) — Grade {A/B/C/D} |
| Security          | {PASS / WARN / FAIL}            |
| Production Ready  | {YES / PARTIAL / NO}            |
| Robustness        | {PASS / FAIL}                   |
| Overall Verdict   | {APPROVED / CONDITIONAL / BLOCKED} |

---

## CASTROFF Audit

| Dimension    | Score (0–2) | Finding                         |
|--------------|-------------|----------------------------------|
| Constraints  | {0/1/2}     | {finding}                        |
| Audience     | {0/1/2}     | {finding}                        |
| Structure    | {0/1/2}     | {finding}                        |
| Tone         | {0/1/2}     | {finding}                        |
| Role         | {0/1/2}     | {finding}                        |
| Output Format| {0/1/2}     | {finding}                        |
| Focus        | {0/1/2}     | {finding}                        |
| Function     | {0/1/2}     | {finding}                        |

## Priority Repair Plan

| Priority | Dimension | Action | Impact |
|----------|-----------|--------|--------|
| P0       | {dim}     | {fix}  | HIGH   |
| P1       | {dim}     | {fix}  | MED    |

## Repaired Prompt (if repairs applied)
{repaired prompt text}
```

### Quick Mode (`--quick`)

```markdown
**CASTROFF Score:** {X}/16 ({%}) — Grade {A/B/C/D}

**Top 3 Issues:**
1. {dimension}: {finding}
2. {dimension}: {finding}
3. {dimension}: {finding}
```

---

## CASTROFF Scoring Reference

| Score | Grade | Meaning |
|-------|-------|---------|
| 88–100% | A | Production-ready |
| 75–87% | B | Minor repairs needed |
| 62–74% | C | Significant repairs needed |
| < 62% | D | Rebuild recommended |

**Dimension scoring:** 0 = absent · 1 = partial · 2 = complete

---

## Error Handling

### File Not Found

```text
IF file path provided but file does not exist:
  1. Show: "File not found: {path}"
  2. Suggest: Check path relative to working directory
  3. Fallback: Ask user to paste the prompt inline
```

### Unsupported File Format

```text
IF file extension is not .txt / .md / .py / .json:
  1. Warn: "Format {ext} not tested — reading as plain text."
  2. Attempt read anyway
  3. If unreadable: ask user to paste inline
```

### No Prompt Provided

```text
IF no file path in args and nothing pasted:
  1. Ask: "Please paste the prompt or provide a file path (.txt, .md, .py)."
  2. Also ask: "What task is this prompt designed to accomplish?"
  3. Proceed after input received.
```

### Task Type Unknown

```text
IF task type not specified:
  1. Infer from prompt content if possible
  2. If unclear: ask before proceeding
  Note: task type affects which production checks apply.
```

### Security Mode Without Context

```text
IF --security and external input handling unknown:
  1. Ask: "Does this prompt process external user input (e.g., user queries, uploaded docs)?"
  2. YES → full injection audit
  3. NO → skip injection vectors, audit instruction hierarchy only
```

---

## Examples

### Example 1: Full Validation from File

```bash
/validate-prompt prompts/invoice_extractor.txt

# Reads file, asks for task type if not inferrable
# Output:
# Prompt Validation Report
# CASTROFF Score: 12/16 (75%) — Grade B
# Security: PASS
# Production Ready: PARTIAL
# Overall Verdict: CONDITIONAL
```

### Example 2: CASTROFF Audit from File

```bash
/validate-prompt --audit prompts/classifier.md

# Output:
# Constraints: 2 — "Max 300 words" present
# Audience:    0 — MISSING
# ...
# Score: 10/16 (62%) — Grade C
# P0 Repair: Add audience definition
```

### Example 3: Debug Inconsistent Prompt from File

```bash
/validate-prompt --debug prompts/sentiment.txt

# Also describe the failure when asked
# Output:
# Reproduced: 4/5 runs failed
# Isolated dimension: Output Format
# Hypothesis: JSON schema not specified — model chooses structure
# Patch: Add explicit JSON schema with field list
# Status: RESOLVED
```

### Example 4: Compare Two Variants from Files

```bash
/validate-prompt --compare prompts/v1.txt prompts/v2.txt

# Output:
# | Dimension    | v1 | v2 | Winner |
# | Constraints  | 2  | 1  | v1     |
# | Audience     | 1  | 2  | v2     |
# ...
# Recommendation: v2 (81%) over v1 (75%)
```

### Example 5: Quick Score (Inline)

```bash
/validate-prompt --quick

# Paste prompt when asked
# Output:
# CASTROFF Score: 10/16 (62%) — Grade C
# Top 3 Issues:
# 1. Audience: MISSING
# 2. Output Format: no schema defined
# 3. Function: communicative purpose not explicit
```

---

## Tips

1. **Always specify the task type** — "extraction", "classification", etc. — it drives which checks apply.
2. **Use `--quick` during iteration** — get a score in seconds, fix, iterate.
3. **Use `--security` for any public-facing prompt** — prompt injection is silent if unchecked.
4. **Grade C or D → rebuild, not patch** — when score < 62%, a rewrite guided by CASTROFF is faster.
5. **Use `--compare` before A/B testing** — confirm the better variant before spending eval budget.

---

## Related

- **Agent:** `.claude/agents/ai-ml/prompt-validator.md`
- **AI Prompt Specialist:** `.claude/agents/ai-ml/ai-prompt-specialist.md`
- **KB:** `.claude/kb/prompt-engineering/index.md`
- **CASTROFF Framework:** `.claude/kb/prompt-engineering/patterns/castroff-framework.md`
- **Debug Protocol:** `.claude/kb/prompt-engineering/patterns/prompt-debug-protocol.md`
- **Security Patterns:** `.claude/kb/prompt-engineering/patterns/advanced-security.md`
