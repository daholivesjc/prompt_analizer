# Retail Questions Command

> Gera perguntas de negócio estruturadas para a área de varejo, com base nas KBs gs1-varejo, analise-negocios-kpis e modelagem-dimensional

## Usage

```bash
/retail-questions <segmento-ou-contexto>
```

## Examples

```bash
# Para um segmento específico
/retail-questions supermercado
/retail-questions moda
/retail-questions farmácia
/retail-questions e-commerce

# Com contexto adicional
/retail-questions "supermercado - foco em estoque e vendas"
/retail-questions "moda feminina - dashboard para diretoria"

# A partir de um arquivo com dados disponíveis
/retail-questions docs/fontes-de-dados.md

# Gerar dados sintéticos para o modelo dimensional
/retail-questions "gerar dados sintéticos - star schema varejo"
/retail-questions "dados sintéticos - supermercado - volume médio - 12 meses"
/retail-questions "gerar CSV para fato_vendas e dimensões"
```

---

## Overview

Este comando gera perguntas de negócio analíticas para o setor de varejo, organizadas por domínio (vendas, estoque, clientes, produtos, cadastro GS1, etc.), com KPIs, dimensões, mapeamento dimensional e priorização.

Integra três bases de conhecimento do projeto:
- **gs1-varejo** — padrões GS1 (GTIN, GLN, SSCC, GPC, CNP), cadastro de produtos, NF-e, rastreabilidade
- **analise-negocios-kpis** — KPIs de vendas, estoque, clientes, financeiro e operações com fórmulas SQL
- **modelagem-dimensional** — star schema, fato/dimensão, granularidade, bus matrix para varejo

---

## What This Command Does

1. **Entende** o segmento de varejo e objetivo do usuário
2. **Seleciona** os domínios de análise relevantes
3. **Gera** perguntas de negócio estruturadas com métricas e dimensões
4. **Prioriza** por impacto, complexidade e disponibilidade de dados
5. **Documenta** em formato padronizado com glossário de KPIs
6. **Gera dados sintéticos** (opcional) — quando solicitado, cria datasets CSV realistas para popular o modelo dimensional

---

## Process

### Step 0: Detectar Modo de Operação

Analisar o argumento do usuário para determinar se é:
- **Modo Perguntas** — gerar perguntas de negócio (padrão)
- **Modo Dados Sintéticos** — gerar datasets CSV para popular modelo dimensional

Palavras-chave que ativam o modo dados sintéticos: "dados sintéticos", "synthetic data", "gerar dados", "popular modelo", "dados de teste", "gerar CSV", "mock data".

Se modo dados sintéticos, pular para **Step 7**.

### Step 1: Coletar Contexto

Usar `AskUserQuestion` para entender (uma pergunta por vez):

1. Qual segmento do varejo? (supermercado, moda, eletrônicos, farmácia, home center, etc.)
2. Quais domínios cobrir? (vendas, estoque, clientes, produtos, lojas, pricing, sazonalidade, operacional)
3. Qual o objetivo? (dashboard, modelagem de dados, análise exploratória, apresentação de resultados)
4. Qual nível? (estratégico/diretoria, tático/gerência, operacional/dia-a-dia)
5. Quais fontes de dados existem? (ERP, CRM, PDV, e-commerce, planilhas)

**Se o argumento já contiver informação suficiente, pular perguntas já respondidas.**

### Step 2: Carregar Base de Conhecimento

```markdown
# Sempre carregar:
Read(.claude/agents/domain/retail-business-questions.md)
Read(.claude/kb/gs1-varejo/reference/glossario-varejo.md)
Read(.claude/kb/analise-negocios-kpis/concepts/kpis-varejo.md)
Read(.claude/kb/analise-negocios-kpis/specs/kpis-varejo-spec.yaml)
Read(.claude/kb/modelagem-dimensional/specs/varejo-star-schema.yaml)

# Carregar conforme domínios selecionados:
# Vendas → kb/analise-negocios-kpis/concepts/analise-vendas.md, patterns/dashboard-vendas-varejo.md
# Estoque → kb/analise-negocios-kpis/concepts/analise-estoque.md, patterns/indicadores-estoque.md
# Clientes → kb/analise-negocios-kpis/concepts/analise-clientes.md, patterns/analise-rfm-clientes.md
# Produtos → kb/gs1-varejo/concepts/gtin.md, concepts/cnp-cadastro-produtos.md, patterns/cadastro-produtos.md
# Lojas → kb/gs1-varejo/concepts/gln.md, kb/analise-negocios-kpis/concepts/metricas-operacionais.md
# Supply Chain → kb/gs1-varejo/patterns/rastreabilidade.md, concepts/sscc.md
# Financeiro → kb/analise-negocios-kpis/concepts/analise-financeira.md
# Cadastro GS1 → kb/gs1-varejo/patterns/validacao-gtin.md, patterns/gestao-gtin.md, patterns/nota-fiscal-eletronica.md
# Modelagem Avancada → kb/modelagem-dimensional/patterns/aggregate-tables.md, patterns/model-review-checklist.md, concepts/schema-evolution.md
# Estrategia → kb/analise-negocios-kpis/concepts/arquetipos-varejo.md, patterns/business-model-canvas-varejo.md
```

Usar os domínios, exemplos, terminologia GS1 e formato definidos no agente e KBs como base.

### Step 3: Gerar Perguntas

Para cada domínio selecionado, gerar no mínimo 5 perguntas seguindo o formato:

| # | Pergunta | Dimensões | KPIs | Granularidade | Nível | Impacto | Complexidade |
|---|----------|-----------|------|---------------|-------|---------|--------------|

**Regras:**
- Perguntas respondíveis com dados (não opinativas)
- Termos precisos conforme glossário de varejo (faturamento bruto vs. líquido, sell-in vs. sell-out, etc.)
- Terminologia GS1: usar GTIN (não "código de barras"), GLN (não "código da loja"), SKU conforme padrão
- KPIs com fórmula conforme `kpis-varejo-spec.yaml`
- Cada pergunta mapeia para tabela fato + dimensões do star schema
- Adaptadas ao segmento informado
- Ordem progressiva: fundamentais antes de avançadas
- Mínimo 5, máximo 10 por domínio
- Total máximo: 50 perguntas

### Step 4: Glossário de KPIs

Incluir tabela com todos os KPIs mencionados:

| KPI | Fórmula | Descrição |
|-----|---------|-----------|

### Step 5: Priorizar e Recomendar

Destacar as **Top 10 perguntas prioritárias** considerando:
- Impacto no negócio
- Viabilidade com dados disponíveis
- Quick wins vs. projetos maiores

### Step 6: Salvar Documento

```markdown
Write(docs/analytics/perguntas-negocio-varejo-{segmento}.md)
```

### Step 7: Gerar Dados Sintéticos (quando solicitado)

Ativado quando o usuário solicita dados sintéticos ou quando o modo dados sintéticos é detectado no Step 0.

#### 7.1 Coletar Parâmetros

Usar `AskUserQuestion` para entender (uma pergunta por vez):

1. **Modelo de referência** — Qual modelagem usar?
   - Star schema varejo padrão (`varejo-star-schema.yaml`) (Recomendado)
   - Arquivo YAML customizado (informar caminho)
   - Apenas tabelas específicas (informar quais)

2. **Volume de dados** — Qual o volume?
   - Pequeno (demo): ~100 registros na fato, 10-20 por dimensão
   - Médio (testes): ~10.000 registros na fato, 50-200 por dimensão (Recomendado)
   - Grande (carga): ~100.000 registros na fato, 500+ por dimensão

3. **Período temporal** — Quantos meses?
   - 3 meses (trimestre)
   - 6 meses (semestre)
   - 12 meses (Recomendado)
   - 24 meses

4. **Formato de saída** — Qual formato?
   - CSV (Recomendado)
   - SQL INSERT statements
   - JSON (newline-delimited)
   - Parquet (requer pandas/pyarrow)

**Se o argumento já contiver informação suficiente, pular perguntas já respondidas.**

#### 7.2 Carregar Especificação

```markdown
Read(.claude/kb/modelagem-dimensional/specs/varejo-star-schema.yaml)
Read(.claude/kb/gs1-varejo/concepts/gtin.md)
Read(.claude/kb/gs1-varejo/concepts/gln.md)
Read(.claude/kb/analise-negocios-kpis/specs/kpis-varejo-spec.yaml)
Read(.claude/kb/analise-negocios-kpis/concepts/analise-vendas.md)
Read(.claude/agents/domain/retail-business-questions.md)
```

#### 7.3 Gerar Script Python

Criar script `data/synthetic/{segmento}/data_generator.py` seguindo as regras detalhadas no agente:

**Dimensões:**
- dim_data: calendário com feriados brasileiros, smart key YYYYMMDD
- dim_produto: GTIN-13 com dígito verificador VÁLIDO (prefixo 789), hierarquia realista, NCM
- dim_loja: GLN com dígito verificador VÁLIDO, tipos de loja com áreas coerentes, cidades reais
- dim_cliente: CPF como SHA-256 (LGPD), linha default sk=-1, faixa etária realista
- dim_promocao: tipos distribuídos, linha default sk=-1, duração 7-30 dias
- dim_forma_pagamento: dinheiro, crédito, débito, pix, vale

**Fato vendas:**
- Grain: 1 item por cupom — NUNCA violar
- Sazonalidade: dezembro +50%, novembro +25%, janeiro -15%
- Dia da semana: sábado +30%, domingo -20%
- 70% vendas sem cliente identificado, 80% sem promoção
- Métricas coerentes: valor_liquido = bruto - desconto, margem 20-40%
- Ticket médio entre R$45-120 dependendo do tipo de loja

**Validações automáticas:**
- Integridade referencial (todas as FKs existem nas dimensões)
- Consistência de métricas (valor_liquido = bruto - desconto)
- Padrões GS1 (GTIN e GLN com dígito verificador válido)
- Realismo (ticket médio, margem bruta, taxa de ruptura dentro das metas)

#### 7.4 Executar e Validar

```bash
# Executar o script gerado
cd data/synthetic/{segmento}
python data_generator.py

# Verificar arquivos gerados
ls -la *.csv
```

#### 7.5 Gerar Documentação

Criar `data/synthetic/{segmento}/README.md` com:
- Descrição do modelo dimensional usado
- Volume por tabela (linhas geradas)
- Período temporal
- Seed utilizada (padrão: 42)
- Resultados da validação
- Comando para regenerar

---

## Output

| Artefato | Local | Modo |
|----------|-------|------|
| **Documento de perguntas** | `docs/analytics/perguntas-negocio-varejo-{segmento}.md` | Perguntas |
| **Script gerador** | `data/synthetic/{segmento}/data_generator.py` | Dados Sintéticos |
| **Arquivos CSV** | `data/synthetic/{segmento}/*.csv` | Dados Sintéticos |
| **Relatório de validação** | `data/synthetic/{segmento}/validation_report.md` | Dados Sintéticos |
| **README do dataset** | `data/synthetic/{segmento}/README.md` | Dados Sintéticos |

---

## Quality Gate

### Para Perguntas de Negócio:

```text
[ ] Contexto do usuário coletado (segmento, objetivo, nível)
[ ] Mínimo 2 domínios cobertos
[ ] Mínimo 5 perguntas por domínio
[ ] Cada pergunta tem: dimensões, KPIs, granularidade, nível, impacto
[ ] Glossário de KPIs incluído
[ ] Top 10 prioritárias destacadas
[ ] Documento salvo em docs/analytics/
[ ] Tudo em português (pt-BR)
```

### Para Dados Sintéticos:

```text
[ ] Modelo de referência identificado (star schema yaml ou customizado)
[ ] Volume e período definidos
[ ] Script Python gerado e executável
[ ] Todas as dimensões com dados coerentes
[ ] GTIN e GLN com dígito verificador válido
[ ] Integridade referencial verificada (FKs → PKs)
[ ] Métricas consistentes (valor_liquido = bruto - desconto)
[ ] Sazonalidade aplicada na fato_vendas
[ ] KPIs resultantes dentro das metas (margem, ticket, ruptura)
[ ] Seed fixa para reprodutibilidade
[ ] README.md do dataset gerado
[ ] Validação automática passou sem erros
```

---

## Domínios Disponíveis

| Domínio | Temas Cobertos | KB Primária |
|---------|----------------|-------------|
| **Vendas e Receita** | Faturamento, ticket médio, conversão, sell-in/sell-out, margens, **GMV**, take rate, crescimento GMV | analise-negocios-kpis |
| **Produtos e Categorias** | Curva ABC, mix, cross-sell, GTIN, GPC, ciclo de vida | gs1-varejo + analise-negocios-kpis |
| **Clientes** | RFM, LTV, churn, retenção, aquisição, NPS, cohort | analise-negocios-kpis |
| **Estoque e Supply Chain** | Giro, ruptura, GMROI, cobertura, SSCC, rastreabilidade | gs1-varejo + analise-negocios-kpis |
| **Lojas e Canais** | Performance por GLN, vendas/m², same-store sales, omnichannel | gs1-varejo + analise-negocios-kpis |
| **Pricing e Promoções** | Elasticidade, ROI promocional, markdown | analise-negocios-kpis |
| **Sazonalidade** | Padrões sazonais, datas comemorativas, tendências | analise-negocios-kpis |
| **Operacional e Financeiro** | CAC, EBITDA, DRE, shrinkage, inadimplência | analise-negocios-kpis |
| **Cadastro e Padrões GS1** | GTIN válido, GPC, CNP, NF-e, GLN, rastreabilidade | gs1-varejo |

---

## Tips

1. **Comece focado** — 2-3 domínios é melhor que cobrir tudo superficialmente
2. **Pense no consumidor** — quem vai usar as respostas? Isso define o nível de detalhe
3. **Dados primeiro** — não adianta perguntas que não podem ser respondidas com os dados disponíveis
4. **Itere** — comece com perguntas fundamentais e refine com o usuário

---

## References

- Agent: `.claude/agents/domain/retail-business-questions.md`
- Output (perguntas): `docs/analytics/perguntas-negocio-varejo-{segmento}.md`
- Output (dados sintéticos): `data/synthetic/{segmento}/`

### Knowledge Bases

| KB | Caminho | Uso |
|----|---------|-----|
| **GS1 Varejo** | `.claude/kb/gs1-varejo/` | Terminologia, GTIN, GLN, SSCC, GPC, CNP, NF-e, rastreabilidade |
| **Análise de Negócios e KPIs** | `.claude/kb/analise-negocios-kpis/` | KPIs com fórmulas, métricas de vendas/estoque/clientes/financeiro |
| **Modelagem Dimensional** | `.claude/kb/modelagem-dimensional/` | Star schema, fato/dimensão, granularidade, bus matrix |
