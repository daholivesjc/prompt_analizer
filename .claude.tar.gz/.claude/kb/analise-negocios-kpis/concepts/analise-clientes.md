# Analise de Clientes

> **Purpose**: RFM, LTV, churn rate, cohort analysis e NPS — segmentacao e valor do cliente no varejo
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

A analise de clientes transforma dados transacionais em inteligencia sobre comportamento de compra.
As tecnicas fundamentais sao: RFM (Recencia, Frequencia, Monetario) para segmentacao, LTV (Lifetime
Value) para valor projetado, Churn Rate para retencao, Cohort Analysis para comportamento temporal
e NPS para satisfacao. Requer dim_cliente com LGPD (dados anonimizados).

## The Pattern

```sql
-- 1. RFM SCORING (Recencia, Frequencia, Monetario)
-- Ref: dim_cliente em modelagem-dimensional/patterns/modelagem-vendas-varejo.md
WITH metricas_cliente AS (
    SELECT
        f.sk_cliente,
        DATE_DIFF(CURRENT_DATE(), MAX(d.data_completa), DAY) AS recencia_dias,
        COUNT(DISTINCT f.nro_cupom_fiscal) AS frequencia,
        SUM(f.valor_liquido) AS monetario
    FROM fato_vendas f
    JOIN dim_data d ON f.sk_data = d.sk_data
    WHERE d.data_completa >= DATE_SUB(CURRENT_DATE(), INTERVAL 12 MONTH)
      AND f.sk_cliente != -1  -- exclui cliente desconhecido
    GROUP BY f.sk_cliente
),
rfm_scores AS (
    SELECT *,
        NTILE(5) OVER (ORDER BY recencia_dias DESC) AS r_score,  -- menor recencia = melhor
        NTILE(5) OVER (ORDER BY frequencia ASC)     AS f_score,
        NTILE(5) OVER (ORDER BY monetario ASC)       AS m_score
    FROM metricas_cliente
)
SELECT *,
    r_score * 100 + f_score * 10 + m_score AS rfm_score,
    CASE
        WHEN r_score >= 4 AND f_score >= 4 AND m_score >= 4 THEN 'Champions'
        WHEN r_score >= 4 AND f_score >= 3 THEN 'Loyal'
        WHEN r_score >= 4 AND f_score <= 2 THEN 'New Customers'
        WHEN r_score <= 2 AND f_score >= 3 THEN 'At Risk'
        WHEN r_score <= 2 AND f_score <= 2 THEN 'Lost'
        ELSE 'Regular'
    END AS segmento
FROM rfm_scores;

-- 2. LTV (Lifetime Value) simplificado
SELECT
    sk_cliente,
    AVG(valor_transacao) AS ticket_medio,
    COUNT(DISTINCT mes_compra) / num_meses_ativo AS frequencia_mensal,
    AVG(valor_transacao) * (COUNT(DISTINCT mes_compra) / num_meses_ativo) * 24
        AS ltv_projetado_24m
FROM resumo_clientes
GROUP BY sk_cliente;

-- 3. CHURN RATE mensal
SELECT
    mes_referencia,
    clientes_inicio,
    clientes_fim,
    clientes_perdidos,
    clientes_perdidos * 100.0 / NULLIF(clientes_inicio, 0) AS churn_rate_pct
FROM (
    SELECT mes_referencia,
        COUNT(DISTINCT CASE WHEN ativo_inicio THEN sk_cliente END) AS clientes_inicio,
        COUNT(DISTINCT CASE WHEN ativo_fim THEN sk_cliente END) AS clientes_fim,
        COUNT(DISTINCT CASE WHEN ativo_inicio AND NOT ativo_fim THEN sk_cliente END)
            AS clientes_perdidos
    FROM base_clientes_mensal
    GROUP BY mes_referencia
) sub;
```

## Quick Reference

| Metrica | O que Mede | Acao |
|---------|-----------|------|
| **Recencia** | Dias desde ultima compra | < 30d = ativo |
| **Frequencia** | Num compras no periodo | > 3x/ano = frequente |
| **Monetario** | Valor total gasto | Top 20% = alto valor |
| **LTV** | Valor futuro projetado | Priorizar retencao |
| **Churn** | % clientes perdidos/mes | Meta: < 5%/mes |
| **NPS** | Satisfacao (-100 a +100) | > 50 = excelente |
| **Cohort** | Retencao por grupo | Acompanhar curva |

## Segmentos RFM Tipicos

| Segmento | RFM Score | Acao Recomendada |
|----------|-----------|------------------|
| Champions | R5 F5 M5 | Programa VIP, early access |
| Loyal | R4+ F3+ | Cross-sell, upsell |
| Promising | R4+ F1-2 | Incentivar frequencia |
| At Risk | R1-2 F3+ | Campanha de reativacao |
| Lost | R1 F1 M1 | Win-back ou descontinuar |

## Common Mistakes

### Wrong

```sql
-- Incluir clientes desconhecidos (sk=-1) na analise RFM
SELECT sk_cliente, COUNT(*) FROM fato_vendas GROUP BY sk_cliente;
```

### Correct

```sql
-- Filtrar apenas clientes identificados
SELECT sk_cliente, COUNT(*) FROM fato_vendas
WHERE sk_cliente != -1
GROUP BY sk_cliente;
```

## Related

- [Analise RFM (pattern)](../patterns/analise-rfm-clientes.md)
- [KPIs Varejo](../concepts/kpis-varejo.md)
- [dim_cliente](../../modelagem-dimensional/patterns/modelagem-vendas-varejo.md)
