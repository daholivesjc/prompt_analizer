# Analise de Estoque

> **Purpose**: Giro, cobertura, ruptura, GMROI e estoque de seguranca — metricas para gestao de inventario
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

A analise de estoque mede a eficiencia do capital investido em inventario. Um estoque saudavel
equilibra disponibilidade (evitar ruptura) com custo (evitar excesso). Os KPIs fundamentais sao
giro de estoque, cobertura em dias, taxa de ruptura e GMROI. Usa-se a tabela fato_estoque_diario
(snapshot periodico) combinada com fato_vendas para calcular indicadores.

## The Pattern

```sql
-- Metricas de estoque calculadas sobre snapshot diario
-- Ref: modelagem-dimensional/concepts/tabelas-fato.md (fato periodica)

-- 1. GIRO DE ESTOQUE (anual)
-- Quantas vezes o estoque e renovado por ano
WITH cmv AS (
    SELECT p.cod_gtin, SUM(f.custo_total) AS custo_mercadoria_vendida
    FROM fato_vendas f
    JOIN dim_produto p ON f.sk_produto = p.sk_produto AND p.flag_corrente = true
    JOIN dim_data d ON f.sk_data = d.sk_data
    WHERE d.ano = 2026
    GROUP BY p.cod_gtin
),
estoque_medio AS (
    SELECT cod_gtin, AVG(valor_estoque) AS estoque_medio_custo
    FROM fato_estoque_diario
    WHERE ano = 2026
    GROUP BY cod_gtin
)
SELECT
    c.cod_gtin,
    c.custo_mercadoria_vendida,
    e.estoque_medio_custo,
    c.custo_mercadoria_vendida / NULLIF(e.estoque_medio_custo, 0) AS giro_estoque
FROM cmv c
JOIN estoque_medio e USING (cod_gtin);

-- 2. COBERTURA EM DIAS
-- Quantos dias o estoque atual dura na velocidade media de venda
SELECT
    cod_gtin,
    estoque_atual_qtd,
    venda_media_diaria,
    estoque_atual_qtd / NULLIF(venda_media_diaria, 0) AS cobertura_dias
FROM (
    SELECT cod_gtin, qtd_em_estoque AS estoque_atual_qtd,
           AVG(qtd_vendida_dia) OVER (PARTITION BY cod_gtin
               ORDER BY data ROWS BETWEEN 29 PRECEDING AND CURRENT ROW)
           AS venda_media_diaria
    FROM estoque_vendas_diario
) sub;

-- 3. TAXA DE RUPTURA (stockout rate)
SELECT
    data_referencia,
    COUNT(CASE WHEN qtd_em_estoque = 0 THEN 1 END) AS skus_ruptura,
    COUNT(*) AS skus_ativos,
    COUNT(CASE WHEN qtd_em_estoque = 0 THEN 1 END) * 100.0
        / COUNT(*) AS taxa_ruptura_pct
FROM fato_estoque_diario
GROUP BY data_referencia;

-- 4. GMROI (Gross Margin Return on Investment)
SELECT
    p.categoria,
    SUM(f.margem_bruta) AS margem_bruta_total,
    AVG(e.valor_estoque) AS estoque_medio_custo,
    SUM(f.margem_bruta) / NULLIF(AVG(e.valor_estoque), 0) AS gmroi
FROM fato_vendas f
JOIN dim_produto p ON f.sk_produto = p.sk_produto
JOIN fato_estoque_diario e ON f.sk_produto = e.sk_produto
GROUP BY p.categoria;
```

## Quick Reference

| Metrica | Formula | Meta Varejo Alimentar | Meta Varejo Moda |
|---------|---------|----------------------|------------------|
| Giro Estoque | CMV / estoque_medio | 8-12x/ano | 4-6x/ano |
| Cobertura | estoque_atual / venda_media_diaria | 15-30 dias | 45-90 dias |
| Ruptura | SKUs_zerados / SKUs_ativos * 100 | < 5% | < 8% |
| GMROI | margem_bruta / estoque_medio | > 2.0 | > 1.5 |
| Shrinkage | (esperado - real) / esperado * 100 | < 2% | < 3% |

## Estoque de Seguranca

```
Estoque_Seguranca = Z * sigma_demanda * SQRT(lead_time)

Onde:
  Z = fator de servico (1.65 para 95%, 2.33 para 99%)
  sigma_demanda = desvio padrao da demanda diaria
  lead_time = prazo de entrega em dias
```

## Common Mistakes

### Wrong

```sql
-- Usar estoque pontual (ultimo dia) para calcular giro
SELECT CMV / estoque_ultimo_dia AS giro FROM ...;
```

### Correct

```sql
-- Usar estoque MEDIO do periodo (media dos snapshots diarios)
SELECT CMV / AVG(estoque_diario) AS giro FROM ...;
```

## Related

- [KPIs Varejo](../concepts/kpis-varejo.md)
- [Indicadores Estoque (pattern)](../patterns/indicadores-estoque.md)
- [Tabelas Fato - Periodica](../../modelagem-dimensional/concepts/tabelas-fato.md)
- [GTIN como chave de produto](../../gs1-varejo/concepts/gtin.md)
