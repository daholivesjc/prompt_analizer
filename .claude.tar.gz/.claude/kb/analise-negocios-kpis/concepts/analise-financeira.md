# Analise Financeira

> **Purpose**: DRE, margens, EBITDA, ponto de equilibrio e ROI — indicadores financeiros para varejo
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

A analise financeira no varejo traduz dados operacionais em indicadores de rentabilidade.
A DRE (Demonstracao do Resultado do Exercicio) e a base, e dela derivam margens bruta,
operacional e liquida. O EBITDA mede geracao de caixa operacional. O ponto de equilibrio
indica o volume minimo de vendas para cobrir custos fixos.

## The Pattern

```sql
-- ESTRUTURA DA DRE NO VAREJO (simplificada)
-- Calculada sobre dados de fato_vendas + custos operacionais

WITH dre AS (
    SELECT
        d.ano, d.mes,
        -- Receita
        SUM(f.valor_bruto)    AS receita_bruta,
        SUM(f.valor_desconto) AS deducoes,
        SUM(f.valor_liquido)  AS receita_liquida,

        -- CMV (Custo Mercadoria Vendida)
        SUM(f.custo_total)    AS cmv,

        -- Margem Bruta
        SUM(f.margem_bruta)   AS lucro_bruto
    FROM fato_vendas f
    JOIN dim_data d ON f.sk_data = d.sk_data
    GROUP BY d.ano, d.mes
)
SELECT
    ano, mes,
    receita_bruta,
    deducoes,
    receita_liquida,
    cmv,
    lucro_bruto,

    -- Margem Bruta %
    lucro_bruto / NULLIF(receita_liquida, 0) * 100 AS margem_bruta_pct,

    -- Despesas operacionais (de outra fonte)
    lucro_bruto - despesas_operacionais AS lucro_operacional,

    -- Margem Operacional %
    (lucro_bruto - despesas_operacionais)
        / NULLIF(receita_liquida, 0) * 100 AS margem_operacional_pct

FROM dre;

-- PONTO DE EQUILIBRIO
-- Volume minimo de vendas para cobrir custos fixos
SELECT
    custos_fixos_mensais,
    margem_contribuicao_media_pct,
    custos_fixos_mensais / (margem_contribuicao_media_pct / 100)
        AS ponto_equilibrio_reais,
    custos_fixos_mensais / margem_contribuicao_unitaria
        AS ponto_equilibrio_unidades
FROM parametros_financeiros;
```

## Quick Reference

| Indicador | Formula | Meta Varejo |
|-----------|---------|-------------|
| Margem Bruta % | (receita - CMV) / receita * 100 | 25-35% |
| Margem Operacional % | EBIT / receita * 100 | 5-10% |
| Margem Liquida % | lucro_liquido / receita * 100 | 2-5% |
| EBITDA | lucro_operacional + depreciacao + amortizacao | Positivo |
| ROI | lucro_liquido / investimento * 100 | > 15% a.a. |
| Margem Contribuicao | receita - custos_variaveis | Positiva |

## Estrutura DRE Varejo

```
  Receita Bruta
- Deducoes (impostos, devolucoes, descontos)
= RECEITA LIQUIDA
- CMV (Custo Mercadoria Vendida)
= LUCRO BRUTO (Margem Bruta)
- Despesas Operacionais (pessoal, aluguel, energia, marketing)
= LUCRO OPERACIONAL (EBIT)
+ Depreciacao/Amortizacao
= EBITDA
- Depreciacao/Amortizacao
- Resultado Financeiro (juros)
= LUCRO ANTES IR (LAIR)
- IR/CSLL
= LUCRO LIQUIDO
```

## Common Mistakes

### Wrong

```sql
-- Calcular margem sobre receita BRUTA (inflaciona resultado)
SELECT (receita_bruta - cmv) / receita_bruta * 100 AS margem;
```

### Correct

```sql
-- Calcular margem sobre receita LIQUIDA (padrao contabil)
SELECT (receita_liquida - cmv) / NULLIF(receita_liquida, 0) * 100
    AS margem_bruta_pct;
```

## Related

- [KPIs Varejo](../concepts/kpis-varejo.md)
- [Dashboard Vendas Varejo](../patterns/dashboard-vendas-varejo.md)
- [Metricas Operacionais](../concepts/metricas-operacionais.md)
- [Tabelas Fato](../../modelagem-dimensional/concepts/tabelas-fato.md)
