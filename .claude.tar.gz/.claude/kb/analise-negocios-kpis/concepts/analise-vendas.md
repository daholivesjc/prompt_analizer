# Analise de Vendas

> **Purpose**: Sell-in vs sell-out, sazonalidade, mix de produtos e metodos de analise de vendas no varejo
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

A analise de vendas no varejo vai alem do faturamento total. Envolve entender o fluxo sell-in
(compra do fornecedor) vs sell-out (venda ao consumidor), identificar padroes de sazonalidade,
analisar o mix de produtos via curva ABC, e medir performance por canal, regiao e periodo.

## The Pattern

```sql
-- SELL-IN vs SELL-OUT: comparar compras vs vendas por produto
-- Sell-in: entrada no estoque (compra do fornecedor)
-- Sell-out: saida do estoque (venda ao consumidor)

WITH sell_out AS (
    SELECT
        p.cod_gtin,  -- ref: gs1-varejo/concepts/gtin.md
        p.nome_produto,
        d.ano, d.mes,
        SUM(f.quantidade)     AS qtd_vendida,
        SUM(f.valor_liquido)  AS receita
    FROM fato_vendas f
    JOIN dim_produto p ON f.sk_produto = p.sk_produto AND p.flag_corrente = true
    JOIN dim_data d ON f.sk_data = d.sk_data
    GROUP BY p.cod_gtin, p.nome_produto, d.ano, d.mes
),
sell_in AS (
    SELECT cod_gtin, ano, mes,
           SUM(qtd_comprada) AS qtd_comprada,
           SUM(valor_compra) AS custo_compra
    FROM fato_compras fc
    JOIN dim_data d ON fc.sk_data = d.sk_data
    GROUP BY cod_gtin, ano, mes
)
SELECT
    so.cod_gtin, so.nome_produto, so.ano, so.mes,
    si.qtd_comprada AS sell_in_qtd,
    so.qtd_vendida  AS sell_out_qtd,
    si.qtd_comprada - so.qtd_vendida AS delta_estoque
FROM sell_out so
LEFT JOIN sell_in si USING (cod_gtin, ano, mes);

-- SAZONALIDADE: indice sazonal por mes
SELECT
    d.mes,
    AVG(vendas_mes) AS media_mes,
    AVG(vendas_mes) / AVG(AVG(vendas_mes)) OVER () AS indice_sazonal
FROM (
    SELECT d.ano, d.mes, SUM(f.valor_liquido) AS vendas_mes
    FROM fato_vendas f
    JOIN dim_data d ON f.sk_data = d.sk_data
    GROUP BY d.ano, d.mes
) sub
GROUP BY d.mes
ORDER BY d.mes;
```

## Quick Reference

| Conceito | Descricao | Aplicacao |
|----------|-----------|-----------|
| **Sell-in** | Compra do fornecedor | Gestao de compras |
| **Sell-out** | Venda ao consumidor | Performance real |
| **Mix de Produtos** | Composicao por categoria | Sortimento |
| **Sazonalidade** | Variacao ciclica nas vendas | Planejamento |
| **Curva ABC** | Pareto 80/20 de produtos | Priorizacao |
| **Venda Cruzada** | Produtos comprados juntos | Promocao |

## Indicadores de Sazonalidade no Varejo Brasileiro

| Periodo | Pico | Segmentos Impactados |
|---------|------|----------------------|
| Jan-Fev | Volta as aulas | Papelaria, vestuario infantil |
| Maio | Dia das Maes | Vestuario, perfumaria, eletro |
| Jun | Dia dos Namorados, Sao Joao | Vestuario, alimentos |
| Ago | Dia dos Pais | Eletronicos, vestuario masc |
| Out | Dia das Criancas | Brinquedos, vestuario infantil |
| Nov | Black Friday | Todos (pico de eletronicos) |
| Dez | Natal | Todos (pico geral do varejo) |

## Common Mistakes

### Wrong

```sql
-- Comparar meses sem ajustar sazonalidade
SELECT mes, SUM(valor_liquido) FROM fato_vendas GROUP BY mes;
```

### Correct

```sql
-- Comparar mesmo mes ano contra ano (YoY)
SELECT d.mes, d.ano, SUM(f.valor_liquido) AS receita,
    LAG(SUM(f.valor_liquido)) OVER (PARTITION BY d.mes ORDER BY d.ano) AS receita_ano_ant,
    (SUM(f.valor_liquido) - LAG(SUM(f.valor_liquido)) OVER (PARTITION BY d.mes ORDER BY d.ano))
    / NULLIF(LAG(SUM(f.valor_liquido)) OVER (PARTITION BY d.mes ORDER BY d.ano), 0) * 100
    AS crescimento_yoy_pct
FROM fato_vendas f
JOIN dim_data d ON f.sk_data = d.sk_data
GROUP BY d.mes, d.ano;
```

## Related

- [KPIs Varejo](../concepts/kpis-varejo.md)
- [Curva ABC Produtos](../patterns/curva-abc-produtos.md)
- [Dashboard Vendas Varejo](../patterns/dashboard-vendas-varejo.md)
- [GTIN como chave de produto](../../gs1-varejo/concepts/gtin.md)
