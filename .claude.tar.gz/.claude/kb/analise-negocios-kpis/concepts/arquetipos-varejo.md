# Arquetipos de Negocio no Varejo

> **Purpose**: Cinco arquetipos de modelos de negocio do varejo moderno e suas implicacoes para analytics
> **Confidence**: 0.90
> **Source**: PwC — "The Future of Retail: Reinventing Business Models for Success" (2024)
> **MCP Validated**: 2026-03-23

## Overview

A PwC identificou cinco arquetipos de negocio que definem o varejo moderno. Cada arquetipo tem
estrategias, KPIs prioritarios e necessidades de dados diferentes. Entender o arquetipo do varejista
e fundamental para definir quais perguntas de negocio e modelos dimensionais sao mais relevantes.

## Os Cinco Arquetipos

### 1. Masters of Scale (Mestres da Escala)

**Exemplos**: Amazon, Walmart, Home Depot

| Aspecto | Descricao |
|---------|-----------|
| **Estrategia** | Escala operacional massiva, logistica como vantagem competitiva |
| **Diferencial** | Rede de distribuicao, volume de clientes, ecossistemas de plataforma |
| **Evolucao** | Crescimento linear → crescimento via plataformas e ecossistemas |
| **KPIs criticos** | GMV, revenue CAGR, EV/Revenue, custo logistico/pedido, market share |
| **Dados prioritarios** | Supply chain, demand forecasting, logistics optimization |

**Implicacoes para modelagem**: fatos de alta volumetria, dimensoes de cadeia de suprimentos,
agregados pre-computados para performance, analise de ecossistema (marketplace 1P/3P).

### 2. Niche Specializers (Especialistas de Nicho)

**Exemplos**: Foot Locker, Chewy, Tractor Supply Company

| Aspecto | Descricao |
|---------|-----------|
| **Estrategia** | Dominio profundo de categoria especifica, comunidade ao redor da marca |
| **Diferencial** | Conhecimento especializado, curadoria de produtos, NPS alto |
| **Evolucao** | Dominancia de categoria → embedded service providers |
| **KPIs criticos** | NPS, LTV, churn rate, penetracao na categoria, wallet share |
| **Dados prioritarios** | CRM profundo, comportamento de compra, satisfacao |

**Implicacoes para modelagem**: dim_cliente detalhada com atributos comportamentais,
analise RFM avancada, factless facts para engajamento, mini-dimensions de perfil.

### 3. Experience Exemplars (Exemplares de Experiencia)

**Exemplos**: Apple, Chanel, Sephora

| Aspecto | Descricao |
|---------|-----------|
| **Estrategia** | Experiencia premium, engajamento emocional, branding forte |
| **Diferencial** | Marca como ativo, pricing premium, lealdade de comunidade |
| **Evolucao** | Experiencia frictionless → relacionamentos profundos (produtos + servicos) |
| **KPIs criticos** | Margem bruta %, brand equity, NPS, receita por servicos, LTV |
| **Dados prioritarios** | Customer journey, omnichannel touchpoints, engagement metrics |

**Implicacoes para modelagem**: fatos de interacao (touchpoints), dimensoes de canal
(role-playing), analise de jornada do cliente (fato acumulada), metricas de brand.

### 4. Innovation Accelerators (Aceleradores de Inovacao)

**Exemplos**: Uniqlo, On Running, Wayfair

| Aspecto | Descricao |
|---------|-----------|
| **Estrategia** | Inovacao em produtos e modelos de negocio, time-to-market rapido |
| **Diferencial** | P&D, parcerias com startups, agilidade, sustentabilidade |
| **Evolucao** | Inovacao de produto → ecosistema interconectado de marca |
| **KPIs criticos** | Time-to-market, % receita de novos produtos, ROI de P&D, sustentabilidade |
| **Dados prioritarios** | Product lifecycle, trend analysis, A/B testing, sustainability metrics |

**Implicacoes para modelagem**: dimensao de ciclo de vida do produto, metricas de inovacao,
SCD Tipo 2 para tracking de mudancas em produtos, analise de tendencias temporais.

### 5. Value Optimizers (Otimizadores de Valor)

**Exemplos**: Dollar Tree, Dollar General, Five Below

| Aspecto | Descricao |
|---------|-----------|
| **Estrategia** | Melhor valor ao menor preco, expansao agressiva de lojas |
| **Diferencial** | Eficiencia de custo, compra oportunistica, localizacao em areas desatendidas |
| **Evolucao** | Escala de lojas fisicas → experiencia do cliente + proposta de valor expandida |
| **KPIs criticos** | Vendas/m2, COGS %, margem operacional, same-store sales, conversao |
| **Dados prioritarios** | Store operations, pricing optimization, assortment planning |

**Implicacoes para modelagem**: foco em metricas operacionais por loja (dim_loja detalhada),
analise de sortimento, pricing analytics, otimizacao de layout.

## Metricas de Classificacao (PwC)

A PwC classificou varejistas usando duas metricas financeiras:

| Metrica | Formula | Uso |
|---------|---------|-----|
| **EV/Revenue** | (market_cap + divida_total - caixa) / receita_anual | Avalia valor relativo da empresa |
| **Revenue CAGR** | ((receita_final / receita_inicial)^(1/n) - 1) * 100 | Taxa de crescimento composto |

**Growth Leaders**: empresas acima do percentil 66 em ambas as metricas.
Tres arquetipos dominam: Masters of Scale, Niche Specializers e Experience Exemplars.

## Estrategias de Reinvencao

| Estrategia | Descricao | Arquetipo Principal |
|------------|-----------|---------------------|
| **XaaS** (Anything as a Service) | Integrar servicos on-demand com varejo | Masters of Scale, Niche |
| **Ecosystems Orchestrator** | Criar plataforma que conecta parceiros | Masters of Scale |
| **Channel Disintermediation** | Venda direta sem intermediarios | Experience, Niche |
| **Connected Products** | IoT, geolocation, personalizacao | Innovation, Experience |
| **Value Chain Shifts** | Expansao para industrias adjacentes | Todos |

## Quick Reference — KPIs por Arquetipo

| KPI | Scale | Niche | Experience | Innovation | Value |
|-----|:-----:|:-----:|:----------:|:----------:|:-----:|
| GMV | X | | | | |
| Revenue CAGR | X | X | X | X | X |
| EV/Revenue | X | | X | | |
| NPS | | X | X | | |
| LTV | | X | X | | |
| Margem Bruta % | | | X | | X |
| Same-Store Sales | X | | | | X |
| Vendas/m2 | | | X | | X |
| Time-to-Market | | | | X | |
| Custo Logistico | X | | | | X |

## Related

- [KPIs Fundamentais do Varejo](kpis-varejo.md)
- [Analise de Vendas](analise-vendas.md)
- [Analise de Clientes](analise-clientes.md)
- [Metricas Operacionais](metricas-operacionais.md)
