# KPIs Fundamentais do Varejo

> **Purpose**: Indicadores-chave de performance para varejo — faturamento, ticket medio, conversao, margem e giro
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

KPIs (Key Performance Indicators) sao metricas quantificaveis que medem o desempenho do negocio.
No varejo, os KPIs fundamentais cobrem vendas, rentabilidade e eficiencia operacional.
A escolha dos KPIs corretos depende do nivel hierarquico (estrategico, tatico, operacional) e do tipo de varejo.

## The Pattern

```sql
-- KPIs fundamentais calculados sobre fato_vendas + dimensoes
-- Ref: modelagem-dimensional/patterns/modelagem-vendas-varejo.md

-- 1. FATURAMENTO (bruto e liquido)
SELECT
    d.ano, d.mes,
    SUM(f.valor_bruto)   AS faturamento_bruto,
    SUM(f.valor_liquido) AS faturamento_liquido,
    SUM(f.valor_desconto) AS total_descontos

-- 2. TICKET MEDIO
    ,SUM(f.valor_liquido) / COUNT(DISTINCT f.nro_cupom_fiscal) AS ticket_medio

-- 3. ITENS POR CUPOM (UPC - Units Per Customer)
    ,COUNT(*) * 1.0 / COUNT(DISTINCT f.nro_cupom_fiscal) AS itens_por_cupom

-- 4. MARGEM BRUTA %
    ,SUM(f.margem_bruta) / NULLIF(SUM(f.valor_liquido), 0) * 100 AS margem_bruta_pct

-- 5. PRECO MEDIO POR ITEM
    ,SUM(f.valor_liquido) / NULLIF(SUM(f.quantidade), 0) AS preco_medio

FROM fato_vendas f
JOIN dim_data d ON f.sk_data = d.sk_data
GROUP BY d.ano, d.mes;
```

## Quick Reference

| KPI | Formula | Tipo | Nivel |
|-----|---------|------|-------|
| Faturamento Bruto | SUM(valor_bruto) | Aditiva | Estrategico |
| Faturamento Liquido | SUM(valor_liquido) | Aditiva | Estrategico |
| Ticket Medio | receita / num_transacoes | Derivada | Tatico |
| Taxa Conversao | compradores / visitantes * 100 | Derivada | Operacional |
| Itens por Cupom | total_itens / num_cupons | Derivada | Operacional |
| Margem Bruta % | margem / receita * 100 | Nao-aditiva | Estrategico |
| Giro Estoque | CMV / estoque_medio | Derivada | Tatico |
| Vendas por m2 | receita / area_venda | Derivada | Operacional |
| Same-Store Sales | (atual - anterior) / anterior * 100 | Derivada | Estrategico |

## Hierarquia de KPIs

| Nivel | KPIs Tipicos | Frequencia |
|-------|-------------|------------|
| **Estrategico** (diretoria) | Faturamento, margem, SSS, EBITDA | Mensal |
| **Tatico** (gerencia) | Ticket medio, giro, mix categoria | Semanal |
| **Operacional** (loja) | Conversao, ruptura, itens/cupom | Diario |

## Common Mistakes

### Wrong

```sql
-- Comparar faturamento BRUTO entre periodos (ignora devolucoes e descontos)
SELECT SUM(valor_bruto) AS receita
FROM fato_vendas
WHERE ano = 2026;
```

### Correct

```sql
-- Usar faturamento LIQUIDO para comparacoes reais
SELECT SUM(valor_liquido) AS receita
FROM fato_vendas f
JOIN dim_data d ON f.sk_data = d.sk_data
WHERE d.ano = 2026;
```

## Related

- [Analise de Vendas](../concepts/analise-vendas.md)
- [Dashboard Vendas Varejo](../patterns/dashboard-vendas-varejo.md)
- [Metricas Operacionais](../concepts/metricas-operacionais.md)
- [Modelo Vendas Varejo](../../modelagem-dimensional/patterns/modelagem-vendas-varejo.md)
