# Metricas Operacionais

> **Purpose**: Shrinkage, produtividade por m2, vendas por funcionario, same-store sales e eficiencia operacional
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

Metricas operacionais medem a eficiencia do dia-a-dia do varejo. Sao indicadores que ligam recursos
fisicos (espaco, pessoas, estoque) ao resultado financeiro. Same-store sales (SSS) isola o crescimento
organico. Shrinkage mede perdas. Produtividade por m2 avalia uso do espaco de venda.

## The Pattern

```sql
-- METRICAS OPERACIONAIS calculadas sobre fato_vendas + dim_loja

-- 1. SAME-STORE SALES (SSS) - crescimento organico
-- Compara vendas apenas de lojas que existiam nos dois periodos
WITH lojas_comparaveis AS (
    SELECT sk_loja FROM dim_loja
    WHERE data_inauguracao < DATE '2025-01-01'  -- aberta antes do periodo anterior
),
vendas_periodo AS (
    SELECT
        d.ano,
        SUM(f.valor_liquido) AS receita
    FROM fato_vendas f
    JOIN dim_data d ON f.sk_data = d.sk_data
    JOIN lojas_comparaveis lc ON f.sk_loja = lc.sk_loja
    WHERE d.ano IN (2025, 2026)
    GROUP BY d.ano
)
SELECT
    (MAX(CASE WHEN ano = 2026 THEN receita END)
   - MAX(CASE WHEN ano = 2025 THEN receita END))
   / MAX(CASE WHEN ano = 2025 THEN receita END) * 100
    AS same_store_sales_pct
FROM vendas_periodo;

-- 2. VENDAS POR M2 (produtividade do espaco)
SELECT
    l.nome_loja,
    l.area_venda_m2,
    SUM(f.valor_liquido) AS receita_anual,
    SUM(f.valor_liquido) / l.area_venda_m2 AS vendas_por_m2
FROM fato_vendas f
JOIN dim_loja l ON f.sk_loja = l.sk_loja
JOIN dim_data d ON f.sk_data = d.sk_data
WHERE d.ano = 2026
GROUP BY l.nome_loja, l.area_venda_m2
ORDER BY vendas_por_m2 DESC;

-- 3. VENDAS POR FUNCIONARIO
SELECT
    l.nome_loja,
    l.num_funcionarios,
    SUM(f.valor_liquido) AS receita_mensal,
    SUM(f.valor_liquido) / l.num_funcionarios AS receita_por_func
FROM fato_vendas f
JOIN dim_loja l ON f.sk_loja = l.sk_loja
JOIN dim_data d ON f.sk_data = d.sk_data
WHERE d.ano = 2026 AND d.mes = 3
GROUP BY l.nome_loja, l.num_funcionarios;

-- 4. SHRINKAGE (perdas/quebras)
SELECT
    p.categoria,
    SUM(e.estoque_sistema - e.estoque_fisico) AS diferenca,
    SUM(e.estoque_sistema - e.estoque_fisico) * 100.0
        / NULLIF(SUM(e.estoque_sistema), 0) AS shrinkage_pct
FROM inventario e
JOIN dim_produto p ON e.sk_produto = p.sk_produto
GROUP BY p.categoria;
```

## Quick Reference

| Metrica | Formula | Meta Tipica |
|---------|---------|-------------|
| Same-Store Sales | (vendas_atual - vendas_ant) / vendas_ant * 100 | > inflacao |
| Vendas por m2 | receita / area_venda_m2 | Varia por formato |
| Vendas por func | receita / num_funcionarios | > custo_func * 3 |
| Shrinkage | (sistema - fisico) / sistema * 100 | < 2% |
| Footfall | visitantes_dia | Tendencia crescente |
| Conversion Rate | transacoes / visitantes * 100 | 20-40% |
| Dwell Time | tempo_medio_na_loja | 15-45 min |

## Benchmarks por Formato de Loja

| Formato | Vendas/m2 (R$/ano) | Giro | Shrinkage |
|---------|-------------------|------|-----------|
| Hipermercado | 8.000-12.000 | 10-14x | 1.5-2.5% |
| Supermercado | 12.000-18.000 | 12-16x | 1.0-2.0% |
| Express/Conveniencia | 20.000-30.000 | 15-20x | 1.5-3.0% |
| Atacarejo | 15.000-25.000 | 14-18x | 0.8-1.5% |

## Common Mistakes

### Wrong

```sql
-- Incluir lojas novas no calculo de Same-Store Sales
SELECT SUM(valor_liquido) FROM fato_vendas WHERE ano = 2026;
```

### Correct

```sql
-- Filtrar apenas lojas abertas ANTES do periodo de comparacao
SELECT SUM(f.valor_liquido)
FROM fato_vendas f
JOIN dim_loja l ON f.sk_loja = l.sk_loja
WHERE l.data_inauguracao < '2025-01-01';
```

## Related

- [KPIs Varejo](../concepts/kpis-varejo.md)
- [Analise Financeira](../concepts/analise-financeira.md)
- [Dashboard Vendas Varejo](../patterns/dashboard-vendas-varejo.md)
- [dim_loja](../../modelagem-dimensional/patterns/modelagem-vendas-varejo.md)
