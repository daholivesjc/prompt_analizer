# Analise de Negocios e KPIs Knowledge Base

> **Purpose**: Metricas, indicadores e analises fundamentais para varejo — KPIs de vendas, estoque, clientes, financeiro e operacoes
> **MCP Validated**: 2026-03-23

## Quick Navigation

### Concepts (< 150 linhas cada)

| Arquivo | Proposito |
|---------|-----------|
| [concepts/kpis-varejo.md](concepts/kpis-varejo.md) | KPIs fundamentais: ticket medio, conversao, faturamento, margem |
| [concepts/analise-vendas.md](concepts/analise-vendas.md) | Sell-in vs sell-out, sazonalidade, mix de produtos, curva ABC |
| [concepts/analise-estoque.md](concepts/analise-estoque.md) | Giro, cobertura, ruptura, GMROI, estoque de seguranca |
| [concepts/analise-clientes.md](concepts/analise-clientes.md) | RFM, LTV, churn rate, cohort analysis, NPS |
| [concepts/analise-financeira.md](concepts/analise-financeira.md) | DRE, margens, EBITDA, ponto de equilibrio, ROI |
| [concepts/metricas-operacionais.md](concepts/metricas-operacionais.md) | Shrinkage, produtividade por m2, vendas/funcionario, same-store sales |
| [concepts/arquetipos-varejo.md](concepts/arquetipos-varejo.md) | 5 arquetipos PwC: Masters of Scale, Niche, Experience, Innovation, Value |

### Patterns (< 200 linhas cada)

| Arquivo | Proposito |
|---------|-----------|
| [patterns/dashboard-vendas-varejo.md](patterns/dashboard-vendas-varejo.md) | Dashboard completo com KPIs, formulas SQL e visualizacoes |
| [patterns/curva-abc-produtos.md](patterns/curva-abc-produtos.md) | Classificacao Pareto (80/20) com SQL e aplicacao pratica |
| [patterns/analise-rfm-clientes.md](patterns/analise-rfm-clientes.md) | Segmentacao RFM com scoring, SQL e casos de uso |
| [patterns/indicadores-estoque.md](patterns/indicadores-estoque.md) | Calculos de giro, cobertura, ruptura com SQL |
| [patterns/business-model-canvas-varejo.md](patterns/business-model-canvas-varejo.md) | BMC aplicado ao varejo com mapeamento para KPIs e modelo dimensional |

### Specs (Machine-Readable)

| Arquivo | Proposito |
|---------|-----------|
| [specs/kpis-varejo-spec.yaml](specs/kpis-varejo-spec.yaml) | Especificacao tecnica dos KPIs (formula, unidade, frequencia, meta) |

---

## Quick Reference

- [quick-reference.md](quick-reference.md) - Tabelas de consulta rapida

---

## Conceitos-Chave

| Conceito | Descricao |
|----------|-----------|
| **Ticket Medio** | Valor medio por transacao (receita / num_transacoes) |
| **Taxa de Conversao** | Percentual de visitantes que compram |
| **Giro de Estoque** | Quantas vezes o estoque e renovado no periodo |
| **GMROI** | Retorno sobre investimento em estoque (margem / custo_medio_estoque) |
| **RFM** | Segmentacao de clientes por Recencia, Frequencia e valor Monetario |
| **Same-Store Sales** | Crescimento de vendas em lojas existentes (exclui novas) |
| **EV/Revenue** | Enterprise Value / Receita — avalia valor relativo da empresa (PwC) |
| **Revenue CAGR** | Taxa de crescimento composto da receita |
| **BMC (Business Model Canvas)** | Framework estrategico de 9 blocos para modelar como a empresa cria e captura valor |
| **Arquetipo de Varejo** | Classificacao do modelo de negocio: Scale, Niche, Experience, Innovation, Value (PwC) |

---

## Trilha de Aprendizado

| Nivel | Arquivos |
|-------|----------|
| **Iniciante** | concepts/kpis-varejo.md, concepts/analise-vendas.md |
| **Intermediario** | concepts/analise-estoque.md, concepts/analise-clientes.md, patterns/dashboard-vendas-varejo.md |
| **Avancado** | concepts/analise-financeira.md, patterns/analise-rfm-clientes.md, patterns/curva-abc-produtos.md |
| **Estrategico** | concepts/arquetipos-varejo.md, patterns/business-model-canvas-varejo.md |

---

## Uso por Agentes

| Agente | Arquivos Primarios | Caso de Uso |
|--------|---------------------|-------------|
| KB Architect | Todos | Referencia sobre metricas de negocio |
| Data Analyst | patterns/dashboard-vendas-varejo.md, specs/ | Criar dashboards e relatorios |
| Data Engineer | patterns/curva-abc-produtos.md, patterns/indicadores-estoque.md | Implementar calculos em pipelines |

---

## Referencias Cruzadas

| KB Relacionada | Conexao |
|----------------|---------|
| [modelagem-dimensional](../modelagem-dimensional/index.md) | fato_vendas, dim_produto, dim_cliente nos exemplos SQL |
| [gs1-varejo](../gs1-varejo/index.md) | GTIN como chave de produto nas analises |
