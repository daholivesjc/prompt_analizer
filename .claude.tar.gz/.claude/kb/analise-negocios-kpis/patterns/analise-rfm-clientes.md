# Analise RFM de Clientes

> **Purpose**: Segmentacao de clientes por Recencia, Frequencia e valor Monetario — com scoring SQL e acoes por segmento
> **MCP Validated**: 2026-03-23

## When to Use

- Segmentar base de clientes para campanhas de marketing direcionadas
- Identificar clientes de alto valor (Champions) para programas de fidelidade
- Detectar clientes em risco de churn para acoes de reativacao
- Priorizar investimento em CRM com base em valor do cliente
- Base para calculo de LTV (Lifetime Value)

## Implementation

```sql
-- ================================================================
-- ANALISE RFM COMPLETA
-- Base: fato_vendas + dim_cliente
-- Ref: modelagem-dimensional (dim_cliente com sk_cliente = -1 para desconhecido)
-- Periodo: ultimos 12 meses
-- ================================================================

-- ETAPA 1: Calcular metricas brutas por cliente
WITH metricas AS (
    SELECT
        c.sk_cliente,
        c.cod_cliente,
        c.nome,
        c.faixa_etaria,
        c.cidade,
        c.estado,
        c.flag_programa_fidelidade,

        -- Recencia: dias desde ultima compra
        DATE_DIFF(CURRENT_DATE(),
            MAX(d.data_completa), DAY) AS recencia_dias,

        -- Frequencia: numero de transacoes distintas
        COUNT(DISTINCT f.nro_cupom_fiscal) AS frequencia,

        -- Monetario: valor total gasto
        SUM(f.valor_liquido) AS monetario,

        -- Metricas auxiliares
        MIN(d.data_completa) AS primeira_compra,
        MAX(d.data_completa) AS ultima_compra,
        SUM(f.valor_liquido) / COUNT(DISTINCT f.nro_cupom_fiscal)
            AS ticket_medio

    FROM fato_vendas f
    JOIN dim_cliente c ON f.sk_cliente = c.sk_cliente AND c.flag_corrente = true
    JOIN dim_data d ON f.sk_data = d.sk_data
    WHERE f.sk_cliente != -1  -- excluir cliente desconhecido
      AND d.data_completa >= DATE_SUB(CURRENT_DATE(), INTERVAL 12 MONTH)
    GROUP BY c.sk_cliente, c.cod_cliente, c.nome, c.faixa_etaria,
             c.cidade, c.estado, c.flag_programa_fidelidade
),

-- ETAPA 2: Atribuir scores 1-5 via quintis (NTILE)
rfm_scores AS (
    SELECT
        *,
        NTILE(5) OVER (ORDER BY recencia_dias DESC) AS r_score,
        NTILE(5) OVER (ORDER BY frequencia ASC) AS f_score,
        NTILE(5) OVER (ORDER BY monetario ASC) AS m_score
    FROM metricas
),

-- ETAPA 3: Classificar em segmentos
rfm_segmentos AS (
    SELECT
        *,
        CONCAT(CAST(r_score AS STRING), CAST(f_score AS STRING),
               CAST(m_score AS STRING)) AS rfm_cell,
        CASE
            WHEN r_score >= 4 AND f_score >= 4 AND m_score >= 4
                THEN 'Champions'
            WHEN r_score >= 3 AND f_score >= 3 AND m_score >= 4
                THEN 'Loyal High Value'
            WHEN r_score >= 4 AND f_score >= 3
                THEN 'Loyal'
            WHEN r_score >= 4 AND f_score <= 2
                THEN 'New Customers'
            WHEN r_score >= 3 AND f_score <= 2 AND m_score >= 3
                THEN 'Promising'
            WHEN r_score <= 2 AND f_score >= 4
                THEN 'Cant Lose Them'
            WHEN r_score <= 2 AND f_score >= 2 AND m_score >= 3
                THEN 'At Risk'
            WHEN r_score <= 2 AND f_score <= 2 AND m_score <= 2
                THEN 'Lost'
            WHEN r_score = 3 AND f_score = 3
                THEN 'Need Attention'
            ELSE 'Regular'
        END AS segmento
    FROM rfm_scores
)
SELECT * FROM rfm_segmentos;

-- ETAPA 4: Resumo por segmento (para dashboard)
SELECT
    segmento,
    COUNT(*) AS num_clientes,
    COUNT(*) * 100.0 / SUM(COUNT(*)) OVER () AS pct_clientes,
    ROUND(AVG(recencia_dias)) AS recencia_media,
    ROUND(AVG(frequencia), 1) AS freq_media,
    ROUND(AVG(monetario), 2) AS monetario_medio,
    ROUND(AVG(ticket_medio), 2) AS ticket_medio,
    SUM(monetario) AS receita_total_segmento
FROM rfm_segmentos
GROUP BY segmento
ORDER BY monetario_medio DESC;
```

## Configuration

| Parametro | Valor | Descricao |
|-----------|-------|-----------|
| Periodo analise | 12 meses | Janela para calcular RFM |
| Num quintis | 5 | Score de 1 a 5 por dimensao |
| Excluir sk_cliente | -1 | Remover cliente desconhecido |
| flag_corrente | true | Usar versao atual do cliente (SCD2) |

## Acoes por Segmento

| Segmento | Acao | Canal |
|----------|------|-------|
| Champions | Early access, programa VIP | Email, app |
| Loyal | Cross-sell, upsell | Email, SMS |
| New Customers | Onboarding, segunda compra | Email welcome |
| Promising | Incentivar frequencia | Cupom desconto |
| At Risk | Reativacao urgente | SMS, push |
| Cant Lose Them | Contato pessoal | Telefone |
| Lost | Win-back ou descontinuar | Email batch |

## Example Usage

```sql
-- Exportar segmento "At Risk" para campanha de reativacao
SELECT cod_cliente, nome, email, recencia_dias, monetario
FROM rfm_segmentos
WHERE segmento = 'At Risk'
ORDER BY monetario DESC;
```

## See Also

- [Analise de Clientes](../concepts/analise-clientes.md)
- [KPIs Varejo](../concepts/kpis-varejo.md)
- [Dashboard Vendas Varejo](../patterns/dashboard-vendas-varejo.md)
- [dim_cliente](../../modelagem-dimensional/patterns/modelagem-vendas-varejo.md)
