# Business Model Canvas — Varejo

> **Purpose**: Framework BMC aplicado ao varejo com mapeamento para KPIs e modelagem dimensional
> **Confidence**: 0.90
> **Source**: Business Model Canvas (Osterwalder), adaptado para varejo
> **MCP Validated**: 2026-03-23

## Overview

O Business Model Canvas (BMC) e um framework estrategico que descreve como uma empresa cria,
entrega e captura valor. No varejo, cada bloco do canvas se conecta diretamente a KPIs mensuráveis
e a tabelas do modelo dimensional. Essa conexao e fundamental para garantir que o data warehouse
cubra todos os aspectos do modelo de negocio.

## Os 9 Blocos do BMC no Varejo

### 1. Key Partners (Parceiros-Chave)

| Parceiro | Papel | Dados Gerados |
|----------|-------|---------------|
| Fabricantes | Fornecem produtos (sell-in) | fato_compras, dim_fornecedor |
| Atacadistas | Distribuicao intermediaria | fato_compras, lead time |
| Locadores | Imoveis das lojas | dim_loja (aluguel, area) |
| Operadores logisticos | Entrega, last-mile | fato_pedido, lead time |
| Plataformas marketplace | Marketplace 3P | fato_vendas (GMV, take rate) |

**KPIs associados**: Lead Time de Reposicao, % Sell-in vs Sell-out, GMROI por fornecedor.

### 2. Key Activities (Atividades-Chave)

| Atividade | Descricao | KPI Principal |
|-----------|-----------|---------------|
| Product Sourcing | Selecao e compra de mercadorias | GMROI, Giro de Estoque |
| Marketing & Branding | Campanhas, fidelizacao, CRM | CAC, ROI de Campanha |
| Store Operations | Gestao de lojas fisicas | Vendas/m2, Shrinkage |
| Merchandise Flow | Logistica de reposicao | Taxa de Ruptura, Cobertura |
| Sales | Execucao da venda | Ticket Medio, Conversao |

### 3. Key Resources (Recursos-Chave)

| Recurso | Modelo Dimensional |
|---------|--------------------|
| Lojas de Varejo | dim_loja (GLN, area, tipo, regiao) |
| Centros de Distribuicao | dim_loja (tipo = CD) |
| Equipe | Metricas operacionais (vendas/funcionario) |
| Estoque | fato_estoque_diario |
| Tecnologia (PDV, ERP) | Fonte de dados para ETL |

### 4. Value Proposition (Proposta de Valor)

| Proposta | Como Medir | Dimensoes |
|----------|------------|-----------|
| Sortimento | Num SKUs ativos, Curva ABC | dim_produto (GTIN, GPC) |
| Conveniencia | Conversao, NPS | dim_loja, dim_cliente |
| Frescor (pereciveis) | Giro, cobertura dias, vencimentos | fato_estoque, dim_produto |
| Preco justo | Margem bruta, elasticidade | dim_produto, dim_promocao |
| Experiencia | NPS, tempo de atendimento | pesquisa_satisfacao |

### 5. Customer Relationships (Relacionamento com Clientes)

| Tipo | KPI | Modelo Dimensional |
|------|-----|--------------------|
| Atendimento (SAC) | TMA, NPS | pesquisa_satisfacao |
| CRM / Fidelidade | LTV, Churn, Retencao | dim_cliente, fato_vendas (RFM) |
| Self-service | Conversao digital | dim_loja (tipo = e-commerce) |
| Comunidade | Engajamento, NPS | Factless fact (interacoes) |

### 6. Channels (Canais)

| Canal | dim_loja.tipo | Metricas Especificas |
|-------|---------------|----------------------|
| Lojas Fisicas | loja_fisica | Vendas/m2, conversao, ticket |
| E-commerce | e_commerce | GMV, taxa de conversao, frete |
| Pop-ups | pop_up | Vendas por evento, ROI |
| Marketplace 3P | marketplace_3p | GMV, take rate, num sellers |
| WhatsApp/Social | social_commerce | Conversao, ticket medio |

### 7. Customer Segments (Segmentos de Clientes)

| Segmento | Criterio | Analise |
|----------|----------|---------|
| Consumidor Final (B2C) | dim_cliente.tipo = 'PF' | RFM, LTV, cohort |
| Mercado de Massa | Todos os clientes | Ticket medio, conversao |
| Nicho | dim_cliente.segmento | LTV, wallet share, NPS |
| Profissional (B2B) | dim_cliente.tipo = 'PJ' | Volume, recorrencia |

### 8. Cost Structure (Estrutura de Custos)

| Custo | KPI | Formula |
|-------|-----|---------|
| COGS (CMV) | Margem Bruta % | (receita - CMV) / receita * 100 |
| Alugueis | % Receita em Aluguel | aluguel / receita * 100 |
| Logistica | Custo Logistico / Pedido | custo_logistica / num_pedidos |
| Funcionarios | Vendas / Funcionario | receita / num_funcionarios |
| Marketing | CAC, ROI Marketing | custo_marketing / novos_clientes |

### 9. Revenue Streams (Fontes de Receita)

| Fonte | Metrica | Modelo Dimensional |
|-------|---------|---------------------|
| Venda de Produtos (1P) | Faturamento Liquido | fato_vendas (valor_liquido) |
| Comissao Marketplace (3P) | Take Rate | fato_vendas (valor_comissao / GMV) |
| Servicos (XaaS) | Receita Recorrente | fato_servicos |
| Publicidade (Retail Media) | Receita de Ads | fato_midia |
| Dados e Insights | Receita de Dados | fato_servicos |

## Mapeamento BMC → Modelo Dimensional

| Bloco BMC | Tabelas Dimensionais | Tabelas Fato |
|-----------|----------------------|--------------|
| Key Partners | dim_fornecedor | fato_compras |
| Key Activities | dim_produto, dim_loja | fato_vendas, fato_estoque |
| Key Resources | dim_loja | fato_vendas, fato_estoque |
| Value Proposition | dim_produto, dim_promocao | fato_vendas |
| Customer Relationships | dim_cliente | fato_vendas (RFM), pesquisa_satisfacao |
| Channels | dim_loja (tipo) | fato_vendas |
| Customer Segments | dim_cliente (segmento) | fato_vendas |
| Cost Structure | — | fato_vendas (CMV), custos operacionais |
| Revenue Streams | dim_loja (tipo canal) | fato_vendas (1P + 3P) |

## Validacao: O Star Schema Cobre o BMC?

Checklist para validar se o modelo dimensional atende todos os blocos:

```text
[ ] Key Partners: dim_fornecedor existe? fato_compras existe?
[ ] Key Activities: metricas de operacao estao na fato?
[ ] Key Resources: dim_loja tem atributos de recursos (area, tipo)?
[ ] Value Proposition: dim_produto tem sortimento? dim_promocao existe?
[ ] Customer Relationships: dim_cliente suporta RFM? LTV calculavel?
[ ] Channels: dim_loja.tipo cobre todos os canais?
[ ] Customer Segments: dim_cliente tem segmentacao?
[ ] Cost Structure: CMV esta na fato? Custos operacionais rastreados?
[ ] Revenue Streams: todas as fontes de receita mapeadas?
```

## Related

- [KPIs Fundamentais do Varejo](../concepts/kpis-varejo.md)
- [Arquetipos de Negocio no Varejo](../concepts/arquetipos-varejo.md)
- [Dashboard Vendas Varejo](dashboard-vendas-varejo.md)
- [Modelo Vendas Varejo](../../modelagem-dimensional/patterns/modelagem-vendas-varejo.md)
