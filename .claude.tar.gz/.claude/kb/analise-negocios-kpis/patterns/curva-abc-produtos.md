# Curva ABC de Produtos

> **Purpose**: Classificacao Pareto (80/20) de produtos por receita, margem ou giro — com SQL pronto para BigQuery/Spark
> **MCP Validated**: 2026-03-23

## When to Use

- Identificar quais 20% dos produtos geram 80% da receita
- Priorizar sortimento, negociacao com fornecedores e alocacao de espaco
- Definir politicas diferenciadas de estoque por classe (A = nunca faltar, C = reduzir)
- Classificar por receita, margem bruta ou giro de estoque

## Implementation

```sql
-- ================================================================
-- CURVA ABC: Classificacao Pareto de Produtos
-- Base: fato_vendas + dim_produto
-- Ref: gs1-varejo (cod_gtin como identificador)
-- ================================================================

-- CURVA ABC POR RECEITA
WITH receita_produto AS (
    SELECT
        p.sk_produto,
        p.cod_gtin,             -- ref: gs1-varejo/concepts/gtin.md
        p.nome_produto,
        p.categoria,
        p.marca,
        SUM(f.valor_liquido)    AS receita,
        SUM(f.margem_bruta)     AS margem,
        SUM(f.quantidade)       AS qtd_vendida
    FROM fato_vendas f
    JOIN dim_produto p ON f.sk_produto = p.sk_produto AND p.flag_corrente = true
    JOIN dim_data d ON f.sk_data = d.sk_data
    WHERE d.ano = 2026
    GROUP BY p.sk_produto, p.cod_gtin, p.nome_produto, p.categoria, p.marca
),
abc_calculo AS (
    SELECT
        *,
        SUM(receita) OVER () AS receita_total,
        SUM(receita) OVER (ORDER BY receita DESC
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS receita_acumulada,
        ROW_NUMBER() OVER (ORDER BY receita DESC) AS ranking,
        COUNT(*) OVER () AS total_produtos
    FROM receita_produto
)
SELECT
    *,
    receita_acumulada / receita_total * 100 AS pct_acumulado,
    CASE
        WHEN receita_acumulada / receita_total <= 0.80 THEN 'A'
        WHEN receita_acumulada / receita_total <= 0.95 THEN 'B'
        ELSE 'C'
    END AS classe_abc,
    ranking * 100.0 / total_produtos AS pct_produtos
FROM abc_calculo
ORDER BY receita DESC;

-- RESUMO POR CLASSE
WITH abc AS (
    -- (usar CTE acima como base)
    SELECT *, CASE
        WHEN pct_acumulado <= 80 THEN 'A'
        WHEN pct_acumulado <= 95 THEN 'B'
        ELSE 'C'
    END AS classe
    FROM curva_abc
)
SELECT
    classe,
    COUNT(*) AS num_produtos,
    COUNT(*) * 100.0 / SUM(COUNT(*)) OVER () AS pct_produtos,
    SUM(receita) AS receita_total,
    SUM(receita) * 100.0 / SUM(SUM(receita)) OVER () AS pct_receita,
    AVG(margem / NULLIF(receita, 0) * 100) AS margem_media_pct
FROM abc
GROUP BY classe
ORDER BY classe;
```

## Configuration

| Parametro | Valor Padrao | Descricao |
|-----------|-------------|-----------|
| Corte A | 80% receita acumulada | Produtos de alta importancia |
| Corte B | 80-95% receita acumulada | Produtos de media importancia |
| Corte C | 95-100% receita acumulada | Produtos de baixa importancia |
| Periodo | 12 meses | Periodo de analise (evitar sazonalidade) |
| Criterio | Receita liquida | Pode ser margem, giro ou qtd |

## Politicas por Classe

| Classe | % Produtos | % Receita | Politica Estoque | Politica Compra |
|--------|-----------|-----------|------------------|-----------------|
| **A** | ~20% | ~80% | Nunca faltar, cobertura 7-15d | Negociar volume, revisao semanal |
| **B** | ~30% | ~15% | Cobertura 15-30d | Revisao quinzenal |
| **C** | ~50% | ~5% | Minimo, cobertura 30-60d | Revisao mensal, avaliar corte |

## Example Usage

```sql
-- ABC cruzada: Receita vs Margem (dupla classificacao)
SELECT
    cod_gtin,
    nome_produto,
    classe_receita,
    classe_margem,
    CASE
        WHEN classe_receita = 'A' AND classe_margem = 'A' THEN 'Estrela'
        WHEN classe_receita = 'A' AND classe_margem = 'C' THEN 'Volume sem Margem'
        WHEN classe_receita = 'C' AND classe_margem = 'A' THEN 'Nicho Rentavel'
        WHEN classe_receita = 'C' AND classe_margem = 'C' THEN 'Candidato a Corte'
        ELSE 'Regular'
    END AS classificacao_estrategica
FROM abc_cruzada;
```

## See Also

- [KPIs Varejo](../concepts/kpis-varejo.md)
- [Analise de Vendas](../concepts/analise-vendas.md)
- [Indicadores Estoque](../patterns/indicadores-estoque.md)
- [dim_produto (GTIN)](../../gs1-varejo/concepts/gtin.md)
- [Modelo Vendas Varejo](../../modelagem-dimensional/patterns/modelagem-vendas-varejo.md)
