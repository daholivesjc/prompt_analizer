# Dashboard de Vendas Varejo

> **Purpose**: Dashboard completo com KPIs essenciais de vendas, formulas SQL prontas e estrutura de visualizacoes
> **MCP Validated**: 2026-03-23

## When to Use

- Criar painel executivo de performance de vendas no varejo
- Montar relatorio diario/semanal para gestao comercial
- Definir quais KPIs exibir e como calcula-los em SQL (BigQuery/Spark SQL)
- Referencia para analistas construirem dashboards em Looker, Power BI ou Data Studio

## Implementation

```sql
-- ================================================================
-- DASHBOARD VENDAS VAREJO: Queries para todos os KPIs
-- Base: fato_vendas + dimensoes (ref: modelagem-dimensional)
-- Compativel com BigQuery e Spark SQL
-- ================================================================

-- BLOCO 1: RESUMO EXECUTIVO (cards de topo)
SELECT
    -- Periodo
    d.ano, d.mes,

    -- Faturamento
    SUM(f.valor_liquido) AS receita_liquida,
    SUM(f.valor_liquido) - LAG(SUM(f.valor_liquido))
        OVER (ORDER BY d.ano, d.mes) AS variacao_receita,

    -- Ticket Medio
    SUM(f.valor_liquido) / COUNT(DISTINCT f.nro_cupom_fiscal) AS ticket_medio,

    -- Numero de Transacoes
    COUNT(DISTINCT f.nro_cupom_fiscal) AS num_transacoes,

    -- Itens por Cupom
    COUNT(*) * 1.0 / COUNT(DISTINCT f.nro_cupom_fiscal) AS itens_por_cupom,

    -- Margem Bruta %
    SUM(f.margem_bruta) / NULLIF(SUM(f.valor_liquido), 0) * 100
        AS margem_bruta_pct,

    -- Desconto Medio %
    SUM(f.valor_desconto) / NULLIF(SUM(f.valor_bruto), 0) * 100
        AS desconto_medio_pct

FROM fato_vendas f
JOIN dim_data d ON f.sk_data = d.sk_data
GROUP BY d.ano, d.mes;

-- BLOCO 2: VENDAS POR CATEGORIA (grafico de barras/treemap)
SELECT
    p.departamento,
    p.categoria,
    SUM(f.valor_liquido) AS receita,
    SUM(f.quantidade) AS qtd_vendida,
    SUM(f.margem_bruta) AS margem,
    SUM(f.valor_liquido) * 100.0 / SUM(SUM(f.valor_liquido)) OVER ()
        AS participacao_pct
FROM fato_vendas f
JOIN dim_produto p ON f.sk_produto = p.sk_produto AND p.flag_corrente = true
JOIN dim_data d ON f.sk_data = d.sk_data
WHERE d.ano = 2026 AND d.mes = 3
GROUP BY p.departamento, p.categoria
ORDER BY receita DESC;

-- BLOCO 3: TENDENCIA DIARIA (grafico de linha)
SELECT
    d.data_completa,
    d.dia_semana,
    d.flag_feriado,
    SUM(f.valor_liquido) AS receita_dia,
    COUNT(DISTINCT f.nro_cupom_fiscal) AS transacoes_dia,
    AVG(SUM(f.valor_liquido)) OVER (
        ORDER BY d.data_completa ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) AS media_movel_7d
FROM fato_vendas f
JOIN dim_data d ON f.sk_data = d.sk_data
WHERE d.ano = 2026 AND d.mes = 3
GROUP BY d.data_completa, d.dia_semana, d.flag_feriado;

-- BLOCO 4: RANKING DE LOJAS (tabela ordenavel)
SELECT
    l.nome_loja,
    l.tipo_loja,
    l.estado,
    SUM(f.valor_liquido) AS receita,
    SUM(f.valor_liquido) / l.area_venda_m2 AS receita_por_m2,
    SUM(f.margem_bruta) / NULLIF(SUM(f.valor_liquido), 0) * 100 AS margem_pct,
    COUNT(DISTINCT f.nro_cupom_fiscal) AS transacoes,
    SUM(f.valor_liquido) / COUNT(DISTINCT f.nro_cupom_fiscal) AS ticket_medio
FROM fato_vendas f
JOIN dim_loja l ON f.sk_loja = l.sk_loja
JOIN dim_data d ON f.sk_data = d.sk_data
WHERE d.ano = 2026 AND d.mes = 3
GROUP BY l.nome_loja, l.tipo_loja, l.estado, l.area_venda_m2
ORDER BY receita DESC;

-- BLOCO 5: FORMA DE PAGAMENTO (grafico de pizza)
SELECT
    fp.tipo AS forma_pagamento,
    fp.bandeira_cartao,
    COUNT(DISTINCT f.nro_cupom_fiscal) AS transacoes,
    SUM(f.valor_liquido) AS receita,
    SUM(f.valor_liquido) * 100.0 / SUM(SUM(f.valor_liquido)) OVER ()
        AS participacao_pct
FROM fato_vendas f
JOIN dim_forma_pagamento fp ON f.sk_forma_pagto = fp.sk_forma_pagto
JOIN dim_data d ON f.sk_data = d.sk_data
WHERE d.ano = 2026 AND d.mes = 3
GROUP BY fp.tipo, fp.bandeira_cartao
ORDER BY receita DESC;
```

## Configuration

| Componente | Tipo Visual | KPIs |
|------------|-------------|------|
| Cards de Topo | Scorecards | Receita, Ticket Medio, Transacoes, Margem % |
| Tendencia | Linha temporal | Receita diaria + media movel 7d |
| Categorias | Treemap/Barras | Receita por departamento/categoria |
| Lojas | Tabela ordenavel | Ranking por receita, margem, receita/m2 |
| Pagamento | Pizza/Donut | Participacao por forma de pagamento |
| Comparativo | Barras agrupadas | Atual vs anterior (MoM, YoY) |

## Example Usage

```sql
-- Comparativo MoM (Month over Month) para card de variacao
SELECT
    mes_atual.receita AS receita_atual,
    mes_anterior.receita AS receita_anterior,
    (mes_atual.receita - mes_anterior.receita)
        / NULLIF(mes_anterior.receita, 0) * 100 AS variacao_mom_pct
FROM
    (SELECT SUM(valor_liquido) AS receita FROM fato_vendas f
     JOIN dim_data d ON f.sk_data = d.sk_data
     WHERE d.ano = 2026 AND d.mes = 3) mes_atual,
    (SELECT SUM(valor_liquido) AS receita FROM fato_vendas f
     JOIN dim_data d ON f.sk_data = d.sk_data
     WHERE d.ano = 2026 AND d.mes = 2) mes_anterior;
```

## See Also

- [KPIs Varejo](../concepts/kpis-varejo.md)
- [Analise de Vendas](../concepts/analise-vendas.md)
- [Curva ABC Produtos](../patterns/curva-abc-produtos.md)
- [Modelo Vendas Varejo](../../modelagem-dimensional/patterns/modelagem-vendas-varejo.md)
- [dim_data, dim_produto, dim_loja](../../modelagem-dimensional/specs/varejo-star-schema.yaml)
