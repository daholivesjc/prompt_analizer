# Indicadores de Estoque

> **Purpose**: Calculos de giro, cobertura, ruptura e GMROI com SQL — monitoramento completo de inventario
> **MCP Validated**: 2026-03-23

## When to Use

- Monitorar saude do estoque e identificar excessos/rupturas
- Calcular retorno sobre investimento em inventario (GMROI)
- Definir niveis de reposicao e estoque de seguranca
- Dashboard operacional de supply chain no varejo
- Combinar com Curva ABC para politicas diferenciadas

## Implementation

```sql
-- ================================================================
-- INDICADORES DE ESTOQUE COMPLETOS
-- Base: fato_estoque_diario (snapshot) + fato_vendas + dim_produto
-- Ref: modelagem-dimensional/concepts/tabelas-fato.md (fato periodica)
-- ================================================================

-- PAINEL COMPLETO DE ESTOQUE POR PRODUTO
WITH vendas_diarias AS (
    SELECT
        p.sk_produto,
        p.cod_gtin,             -- ref: gs1-varejo/concepts/gtin.md
        p.nome_produto,
        p.categoria,
        d.data_completa,
        SUM(f.quantidade)    AS qtd_vendida,
        SUM(f.custo_total)   AS custo_vendido,
        SUM(f.margem_bruta)  AS margem_bruta
    FROM fato_vendas f
    JOIN dim_produto p ON f.sk_produto = p.sk_produto AND p.flag_corrente = true
    JOIN dim_data d ON f.sk_data = d.sk_data
    WHERE d.data_completa >= DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY)
    GROUP BY p.sk_produto, p.cod_gtin, p.nome_produto, p.categoria, d.data_completa
),
metricas_vendas AS (
    SELECT
        sk_produto, cod_gtin, nome_produto, categoria,
        AVG(qtd_vendida) AS venda_media_diaria,
        STDDEV(qtd_vendida) AS desvio_padrao_demanda,
        SUM(custo_vendido) AS cmv_periodo,
        SUM(margem_bruta) AS margem_periodo,
        COUNT(DISTINCT data_completa) AS dias_com_venda
    FROM vendas_diarias
    GROUP BY sk_produto, cod_gtin, nome_produto, categoria
),
estoque_atual AS (
    SELECT
        sk_produto,
        qtd_em_estoque,
        valor_estoque AS custo_estoque
    FROM fato_estoque_diario
    WHERE data_referencia = CURRENT_DATE()
),
estoque_medio AS (
    SELECT
        sk_produto,
        AVG(valor_estoque) AS custo_estoque_medio
    FROM fato_estoque_diario
    WHERE data_referencia >= DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY)
    GROUP BY sk_produto
)
SELECT
    mv.cod_gtin,
    mv.nome_produto,
    mv.categoria,

    -- ESTOQUE ATUAL
    ea.qtd_em_estoque,
    ea.custo_estoque,

    -- VENDA MEDIA DIARIA
    ROUND(mv.venda_media_diaria, 2) AS vmd,

    -- 1. GIRO DE ESTOQUE (anualizado)
    ROUND(mv.cmv_periodo * (365.0 / 90)
        / NULLIF(em.custo_estoque_medio, 0), 2) AS giro_anual,

    -- 2. COBERTURA EM DIAS
    ROUND(ea.qtd_em_estoque
        / NULLIF(mv.venda_media_diaria, 0), 1) AS cobertura_dias,

    -- 3. GMROI (anualizado)
    ROUND(mv.margem_periodo * (365.0 / 90)
        / NULLIF(em.custo_estoque_medio, 0), 2) AS gmroi,

    -- 4. ESTOQUE DE SEGURANCA (nivel servico 95%)
    ROUND(1.65 * mv.desvio_padrao_demanda * SQRT(7), 0)
        AS estoque_seguranca,  -- lead_time = 7 dias

    -- 5. PONTO DE PEDIDO
    ROUND(mv.venda_media_diaria * 7
        + 1.65 * mv.desvio_padrao_demanda * SQRT(7), 0)
        AS ponto_pedido,

    -- 6. STATUS
    CASE
        WHEN ea.qtd_em_estoque = 0 THEN 'RUPTURA'
        WHEN ea.qtd_em_estoque / NULLIF(mv.venda_media_diaria, 0) < 7
            THEN 'CRITICO'
        WHEN ea.qtd_em_estoque / NULLIF(mv.venda_media_diaria, 0) > 60
            THEN 'EXCESSO'
        ELSE 'OK'
    END AS status_estoque

FROM metricas_vendas mv
LEFT JOIN estoque_atual ea ON mv.sk_produto = ea.sk_produto
LEFT JOIN estoque_medio em ON mv.sk_produto = em.sk_produto
ORDER BY gmroi DESC;

-- TAXA DE RUPTURA POR CATEGORIA
SELECT
    p.categoria,
    COUNT(*) AS total_skus,
    COUNT(CASE WHEN e.qtd_em_estoque = 0 THEN 1 END) AS skus_ruptura,
    COUNT(CASE WHEN e.qtd_em_estoque = 0 THEN 1 END) * 100.0
        / COUNT(*) AS taxa_ruptura_pct
FROM fato_estoque_diario e
JOIN dim_produto p ON e.sk_produto = p.sk_produto AND p.flag_corrente = true
WHERE e.data_referencia = CURRENT_DATE()
GROUP BY p.categoria
ORDER BY taxa_ruptura_pct DESC;
```

## Configuration

| Parametro | Valor | Descricao |
|-----------|-------|-----------|
| Periodo CMV | 90 dias | Base para calculo de giro (anualizado) |
| Lead time | 7 dias | Prazo de entrega do fornecedor |
| Nivel servico | 95% (Z=1.65) | Fator para estoque de seguranca |
| Cobertura critica | < 7 dias | Alerta de estoque baixo |
| Cobertura excesso | > 60 dias | Alerta de estoque alto |

## Faixas de Referencia

| Metrica | Critico | Normal | Otimo |
|---------|---------|--------|-------|
| Giro (alimentar) | < 6x | 8-12x | > 14x |
| Cobertura (alimentar) | < 5d ou > 45d | 15-30d | 20-25d |
| Ruptura | > 8% | 3-5% | < 2% |
| GMROI | < 1.0 | 2.0-3.0 | > 4.0 |

## Example Usage

```sql
-- Alerta: produtos classe A (curva ABC) em ruptura
SELECT e.cod_gtin, e.nome_produto, e.categoria
FROM indicadores_estoque e
JOIN curva_abc abc ON e.cod_gtin = abc.cod_gtin
WHERE abc.classe = 'A' AND e.status_estoque = 'RUPTURA';
```

## See Also

- [Analise de Estoque](../concepts/analise-estoque.md)
- [Curva ABC Produtos](../patterns/curva-abc-produtos.md)
- [KPIs Varejo](../concepts/kpis-varejo.md)
- [Tabelas Fato (snapshot periodico)](../../modelagem-dimensional/concepts/tabelas-fato.md)
- [GTIN como identificador](../../gs1-varejo/concepts/gtin.md)
