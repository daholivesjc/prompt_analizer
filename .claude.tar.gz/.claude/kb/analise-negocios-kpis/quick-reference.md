# Analise de Negocios e KPIs Quick Reference

> Tabelas de consulta rapida. Para exemplos de codigo, veja os arquivos linkados.
> **MCP Validated**: 2026-03-23

## KPIs de Vendas

| KPI | Formula | Unidade | Frequencia |
|-----|---------|---------|------------|
| Faturamento Bruto | SUM(valor_bruto) | R$ | Diaria |
| Faturamento Liquido | SUM(valor_liquido) | R$ | Diaria |
| Ticket Medio | receita / num_transacoes | R$ | Diaria |
| Taxa Conversao | compradores / visitantes * 100 | % | Diaria |
| Itens por Cupom | total_itens / num_cupons | un | Semanal |
| Same-Store Sales | (vendas_atual - vendas_anterior) / vendas_anterior * 100 | % | Mensal |

## KPIs de Estoque

| KPI | Formula | Unidade | Meta Tipica |
|-----|---------|---------|-------------|
| Giro de Estoque | CMV / estoque_medio | vezes/ano | 8-12x varejo alimentar |
| Cobertura | estoque_atual / venda_media_diaria | dias | 15-30 dias |
| Ruptura | SKUs_sem_estoque / SKUs_ativos * 100 | % | < 5% |
| GMROI | margem_bruta / custo_medio_estoque | R$/R$ | > 2.0 |

## KPIs de Clientes

| KPI | Formula | Unidade | Frequencia |
|-----|---------|---------|------------|
| LTV | ticket_medio * frequencia * tempo_retencao | R$ | Trimestral |
| Churn Rate | clientes_perdidos / clientes_inicio * 100 | % | Mensal |
| Taxa Recompra | clientes_recorrentes / clientes_total * 100 | % | Mensal |
| NPS | %promotores - %detratores | pontos | Trimestral |

## KPIs Financeiros

| KPI | Formula | Meta Tipica |
|-----|---------|-------------|
| Margem Bruta | (receita - CMV) / receita * 100 | 25-35% varejo |
| Margem Liquida | lucro_liquido / receita * 100 | 2-5% varejo |
| EBITDA | lucro_operacional + depreciacao + amortizacao | Positivo |
| Ponto Equilibrio | custos_fixos / margem_contribuicao_unitaria | un ou R$ |

## Decision Matrix

| Preciso analisar... | Use |
|---------------------|-----|
| Performance de vendas | `concepts/kpis-varejo.md`, `patterns/dashboard-vendas-varejo.md` |
| Quais produtos priorizar | `patterns/curva-abc-produtos.md` |
| Saude do estoque | `concepts/analise-estoque.md`, `patterns/indicadores-estoque.md` |
| Segmentacao de clientes | `concepts/analise-clientes.md`, `patterns/analise-rfm-clientes.md` |
| Rentabilidade do negocio | `concepts/analise-financeira.md` |
| Eficiencia operacional | `concepts/metricas-operacionais.md` |

## Common Pitfalls

| Nao Faca | Faca |
|----------|------|
| Comparar faturamento bruto entre periodos | Use faturamento liquido (desconta devolucoes) |
| Calcular giro com estoque pontual | Use estoque medio do periodo |
| Ignorar sazonalidade em metas | Ajuste metas por mes/estacao |
| Medir conversao sem definir visitante | Defina visitante unico por dia |
| Calcular LTV sem considerar churn | Inclua taxa de retencao na formula |

## Related Documentation

| Topico | Path |
|--------|------|
| KPIs Varejo | `concepts/kpis-varejo.md` |
| Modelo Dimensional Vendas | `../modelagem-dimensional/patterns/modelagem-vendas-varejo.md` |
| GTIN (Produto) | `../gs1-varejo/concepts/gtin.md` |
| Indice | `index.md` |
