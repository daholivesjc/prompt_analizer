# Autenticacao e Seguranca

> **Purpose**: IAM database authentication, Secret Manager para credenciais e SSL/TLS
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-18

## Overview

Cloud SQL PostgreSQL suporta autenticacao via usuario/senha nativo e IAM database authentication. No projeto FDM Dados, as credenciais sao armazenadas no Secret Manager e acessadas em runtime pelo job PySpark. A comunicacao entre Dataproc Serverless e Cloud SQL via Private IP ja e criptografada pela rede interna do Google, mas SSL/TLS pode ser habilitado para camada adicional.

## Metodos de Autenticacao

| Metodo | Uso | Complexidade |
|--------|-----|--------------|
| Usuario/senha nativo | Padrao, compativel com JDBC | Baixa |
| IAM database auth | Service accounts como usuarios | Media |
| IAM group auth | Grupos do Cloud Identity | Media |

## Secret Manager para Credenciais

```python
from google.cloud import secretmanager

def get_secret(project_id: str, secret_name: str) -> str:
    """Obtem o valor mais recente de um segredo do Secret Manager."""
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
    response = client.access_secret_version(name=name)
    return response.payload.data.decode("UTF-8")

# Uso no job de ingestao
db_user = get_secret("my-project", "pg-user")
db_password = get_secret("my-project", "pg-password")
```

## IAM Roles Necessarios

| Service Account | Role | Recurso |
|----------------|------|---------|
| SA Dataproc | `roles/secretmanager.secretAccessor` | Secrets de credenciais |
| SA Dataproc | `roles/cloudsql.client` | Instancia Cloud SQL |
| SA Workflows | `roles/dataproc.editor` | Submeter batches |
| SA Workflows | `roles/iam.serviceAccountUser` | Impersonar SA Dataproc |

## Terraform - Secrets e IAM

```hcl
# Criar secrets
resource "google_secret_manager_secret" "pg_user" {
  secret_id = "pg-user"
  replication { auto {} }
}

resource "google_secret_manager_secret" "pg_password" {
  secret_id = "pg-password"
  replication { auto {} }
}

# Conceder acesso ao SA do Dataproc
resource "google_secret_manager_secret_iam_member" "pg_user_access" {
  secret_id = google_secret_manager_secret.pg_user.id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${var.sa_dataproc_email}"
}

resource "google_secret_manager_secret_iam_member" "pg_pass_access" {
  secret_id = google_secret_manager_secret.pg_password.id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${var.sa_dataproc_email}"
}
```

## SSL/TLS

```text
Cenarios:
  Private IP (mesma VPC)  -> Criptografia do Google automatica, SSL opcional
  Public IP               -> SSL obrigatorio (require_ssl = true)
  Cross-region replicas   -> SSL automatico na replicacao
```

```hcl
# Forcar SSL no Cloud SQL
settings {
  ip_configuration {
    require_ssl = true
    ssl_mode    = "ENCRYPTED_ONLY"
  }
}
```

## Quick Reference

| Input | Output | Notes |
|-------|--------|-------|
| `secret_name` | Valor do segredo | Decodificado UTF-8 |
| `roles/cloudsql.client` | Permissao de conexao | SA do Dataproc |
| `require_ssl = true` | SSL obrigatorio | Recomendado para Public IP |

## Common Mistakes

### Wrong

```python
# Credenciais hardcoded
jdbc_url = "jdbc:postgresql://10.0.0.3:5432/mydb"
user = "admin"
password = "S3cret123!"  # Nunca faca isso!
```

### Correct

```python
# Credenciais do Secret Manager em runtime
user = get_secret(args.project_id, args.secret_user)
password = get_secret(args.project_id, args.secret_password)
```

## Related

- [Credential Management Pattern](../patterns/credential-management.md)
- [Cloud SQL Overview](../concepts/cloud-sql-overview.md)
- [Connectivity](../concepts/connectivity.md)
