# Cloud SQL for PostgreSQL

> **Purpose**: Arquitetura, edicoes e capacidades do Cloud SQL PostgreSQL na GCP
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-18

## Overview

Cloud SQL e o servico de banco de dados relacional gerenciado da Google Cloud. Suporta PostgreSQL, MySQL e SQL Server. Para PostgreSQL, oferece versoes 12 a 16, com patches automaticos, backups, HA e escalabilidade vertical. Elimina a necessidade de gerenciar infraestrutura de banco, mantendo compatibilidade total com o PostgreSQL.

## Edicoes

| Caracteristica | Enterprise | Enterprise Plus |
|----------------|-----------|-----------------|
| SLA (com HA) | 99.95% | 99.99% |
| Armazenamento max | 64 TB | 128 TB |
| Cache de dados | Disco | Disco + cache avancado |
| Manutencao | Janelas configuradas | Near-zero downtime |
| Read replicas | Ate 20 | Ate 20 |
| Versoes PG | 12-16 | 14-16 |

## Arquitetura na GCP

```text
[Cloud SQL Instance]
    |
    +-- Primary (escrita + leitura)
    |       |-- Armazenamento SSD persistente
    |       |-- Backups automaticos (GCS)
    |       +-- Binary logs para PITR
    |
    +-- Standby HA (mesmo regiao, zona diferente)
    |       +-- Replicacao sincrona
    |
    +-- Read Replicas (mesma regiao ou cross-region)
            +-- Replicacao assincrona
```

## Recursos Principais

| Recurso | Descricao |
|---------|-----------|
| **Backups automaticos** | Diarios, retencao configuravel (1-365 dias) |
| **PITR** | Point-in-time recovery via binary logs |
| **HA Regional** | Failover automatico para standby em outra zona |
| **Escalabilidade** | Vertical (CPU/RAM) sem downtime com HA |
| **Manutencao** | Patches automaticos em janelas configuradas |
| **Flags** | Parametros PostgreSQL configurareis via Console/API |
| **Audit logging** | Integrado com Cloud Audit Logs |

## Terraform - Criacao Basica

```hcl
resource "google_sql_database_instance" "postgres" {
  name             = "my-postgres-instance"
  database_version = "POSTGRES_15"
  region           = "us-central1"
  deletion_protection = true

  settings {
    tier              = "db-custom-4-15360"
    edition           = "ENTERPRISE"
    availability_type = "REGIONAL"  # HA

    ip_configuration {
      ipv4_enabled    = false       # Sem IP publico
      private_network = google_compute_network.vpc.id
    }

    backup_configuration {
      enabled                        = true
      point_in_time_recovery_enabled = true
      start_time                     = "03:00"
      transaction_log_retention_days = 7
    }
  }
}
```

## Quick Reference

| Input | Output | Notes |
|-------|--------|-------|
| `database_version` | `POSTGRES_15` | Versao do PostgreSQL |
| `tier` | `db-custom-{cpu}-{ram_mb}` | Machine type personalizado |
| `availability_type` | `REGIONAL` ou `ZONAL` | HA ou single-zone |

## Common Mistakes

### Wrong

```hcl
# IP publico habilitado em producao
ip_configuration {
  ipv4_enabled = true
  authorized_networks { value = "0.0.0.0/0" }
}
```

### Correct

```hcl
# Private IP com VPC dedicada
ip_configuration {
  ipv4_enabled    = false
  private_network = google_compute_network.vpc.id
}
```

## Related

- [Connectivity](../concepts/connectivity.md)
- [High Availability](../concepts/high-availability.md)
- [Cloud SQL Networking](../patterns/cloud-sql-networking.md)
