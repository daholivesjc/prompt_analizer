# Conectividade Cloud SQL

> **Purpose**: Metodos de conexao ao Cloud SQL PostgreSQL — Private IP, VPC Peering, PSA
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-18

## Overview

Cloud SQL suporta conexao via Private IP (recomendado para producao) e Public IP (desenvolvimento). Para Dataproc Serverless, a conexao obrigatoria e via Private IP usando Private Service Access (PSA), que cria um VPC Peering automatico entre a VPC do projeto e a rede interna do Google onde o Cloud SQL reside.

## Metodos de Conexao

```text
[Dataproc Serverless] --VPC Peering--> [Cloud SQL Private IP]
                                         (porta 5432)

[Maquina local] --Cloud SQL Auth Proxy--> [Cloud SQL Public IP]
                                            (porta 3307 local)

[Cloud Run/GKE] --Cloud SQL Connector--> [Cloud SQL via socket]
```

## Private Service Access (PSA)

| Etapa | Recurso | Descricao |
|-------|---------|-----------|
| 1 | `google_compute_global_address` | Reservar range de IPs para o Google |
| 2 | `google_service_networking_connection` | Criar peering com `servicenetworking.googleapis.com` |
| 3 | `google_sql_database_instance` | Criar instancia com `private_network` |
| 4 | `google_compute_firewall` | Liberar TCP 5432 da subnet do Dataproc |

## Terraform - Private Service Access

```hcl
# 1. Reservar range de IPs
resource "google_compute_global_address" "private_ip_range" {
  name          = "cloud-sql-private-range"
  purpose       = "VPC_PEERING"
  address_type  = "INTERNAL"
  prefix_length = 16
  network       = google_compute_network.vpc.id
}

# 2. Criar peering
resource "google_service_networking_connection" "psa" {
  network                 = google_compute_network.vpc.id
  service                 = "servicenetworking.googleapis.com"
  reserved_peering_ranges = [google_compute_global_address.private_ip_range.name]
}

# 3. Cloud SQL usa o peering
resource "google_sql_database_instance" "postgres" {
  depends_on = [google_service_networking_connection.psa]
  # ...
  settings {
    ip_configuration {
      ipv4_enabled    = false
      private_network = google_compute_network.vpc.id
    }
  }
}
```

## Firewall para Dataproc Serverless

```hcl
resource "google_compute_firewall" "dataproc_to_cloudsql" {
  name    = "allow-dataproc-to-cloudsql"
  network = google_compute_network.vpc.name

  allow {
    protocol = "tcp"
    ports    = ["5432"]
  }

  # Range do Dataproc Serverless na subnet
  source_ranges = ["10.0.0.0/16"]
  target_tags   = ["cloudsql"]
}
```

## Cloud SQL Auth Proxy (Desenvolvimento)

```bash
# Baixar o proxy
curl -o cloud-sql-proxy \
  https://storage.googleapis.com/cloud-sql-connectors/cloud-sql-proxy/v2.14.0/cloud-sql-proxy.linux.amd64
chmod +x cloud-sql-proxy

# Conectar via proxy
./cloud-sql-proxy PROJECT:REGION:INSTANCE --port=5432

# Em outro terminal
psql -h 127.0.0.1 -p 5432 -U postgres -d mydb
```

## Quick Reference

| Input | Output | Notes |
|-------|--------|-------|
| Private IP | `10.x.x.x:5432` | Usado pelo Dataproc Serverless |
| Auth Proxy | `127.0.0.1:5432` | Desenvolvimento local |
| Connection name | `project:region:instance` | Identificador unico |

## Common Mistakes

### Wrong

```text
# Usar IP publico para Dataproc Serverless
jdbc:postgresql://35.x.x.x:5432/mydb
# Dataproc Serverless nao suporta saida para IP publico por padrao
```

### Correct

```text
# Usar Private IP via VPC Peering
jdbc:postgresql://10.0.0.3:5432/mydb
# Dataproc Serverless conecta via subnet na mesma VPC
```

## Related

- [Cloud SQL Overview](../concepts/cloud-sql-overview.md)
- [Cloud SQL Networking Pattern](../patterns/cloud-sql-networking.md)
- [Authentication & Security](../concepts/authentication-security.md)
