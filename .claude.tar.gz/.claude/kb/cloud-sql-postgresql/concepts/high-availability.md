# High Availability

> **Purpose**: HA regional, failover automatico e read replicas no Cloud SQL PostgreSQL
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-18

## Overview

Cloud SQL PostgreSQL oferece alta disponibilidade via configuracao regional (primary + standby em zonas diferentes). O failover automatico acontece em caso de falha da zona primaria, com RTO de aproximadamente 30-120 segundos. Read replicas permitem escalar leituras e podem ser criadas na mesma regiao ou cross-region para disaster recovery.

## Arquitetura HA

```text
           Regiao: us-central1
    +-----------+    +-----------+
    | Zona A    |    | Zona B    |
    |           |    |           |
    | [Primary] |--->| [Standby] |
    | R/W       |sync| (quente)  |
    +-----------+    +-----------+
         |
         | async
         v
    +-----------+
    | [Replica] |
    | R/O       |
    +-----------+
```

## Modos de Disponibilidade

| Modo | Zonas | Failover | SLA |
|------|-------|----------|-----|
| `ZONAL` | 1 zona | Manual (restore backup) | 99.95% |
| `REGIONAL` | 2 zonas | Automatico (~60s) | 99.95% (Enterprise) |
| `REGIONAL` + Enterprise Plus | 2 zonas | Automatico (~10s) | 99.99% |

## Read Replicas

| Caracteristica | Valor |
|----------------|-------|
| Max replicas | 20 por instancia |
| Replicacao | Assincrona (streaming replication) |
| Cross-region | Sim (DR e latencia geografica) |
| Promover a primary | Sim (manual ou automatico) |
| Lag tipico | Milissegundos a segundos |

## Terraform - HA Regional

```hcl
resource "google_sql_database_instance" "postgres_ha" {
  name             = "postgres-ha"
  database_version = "POSTGRES_15"
  region           = "us-central1"

  settings {
    tier              = "db-custom-4-15360"
    availability_type = "REGIONAL"  # Habilita HA

    backup_configuration {
      enabled                        = true
      point_in_time_recovery_enabled = true
      start_time                     = "03:00"
      transaction_log_retention_days = 7
    }

    maintenance_window {
      day          = 7  # Domingo
      hour         = 4  # 04:00 UTC
      update_track = "stable"
    }
  }
}
```

## Read Replica

```hcl
resource "google_sql_database_instance" "read_replica" {
  name                 = "postgres-replica-1"
  master_instance_name = google_sql_database_instance.postgres_ha.name
  database_version     = "POSTGRES_15"
  region               = "us-central1"

  replica_configuration {
    failover_target = false
  }

  settings {
    tier              = "db-custom-2-7680"
    availability_type = "ZONAL"
  }
}
```

## Failover - O Que Acontece

| Etapa | Descricao | Tempo |
|-------|-----------|-------|
| 1 | Deteccao de falha na zona primaria | ~10s |
| 2 | Promover standby para primary | ~30-60s |
| 3 | Atualizar DNS interno | Automatico |
| 4 | Conexoes reconectam via Private IP | Transparente |
| 5 | Novo standby provisionado | Minutos |

## Quick Reference

| Input | Output | Notes |
|-------|--------|-------|
| `availability_type = "REGIONAL"` | HA habilitado | Standby automatico |
| `master_instance_name` | Read replica | Replicacao assincrona |
| `failover_target = true` | Replica promovivel | Para DR cross-region |

## Common Mistakes

### Wrong

```hcl
# Producao sem HA
settings {
  availability_type = "ZONAL"  # Single point of failure!
}
```

### Correct

```hcl
# Producao com HA regional
settings {
  availability_type = "REGIONAL"
  backup_configuration {
    enabled                        = true
    point_in_time_recovery_enabled = true
  }
}
```

## Related

- [Cloud SQL Overview](../concepts/cloud-sql-overview.md)
- [Backup Recovery Pattern](../patterns/backup-recovery.md)
- [Cloud SQL Networking](../patterns/cloud-sql-networking.md)
