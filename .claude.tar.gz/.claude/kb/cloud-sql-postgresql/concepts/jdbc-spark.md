# JDBC com Spark

> **Purpose**: Driver JDBC PostgreSQL, connection strings e leitura paralela no Spark
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-18

## Overview

O Spark le dados de bancos relacionais via JDBC usando `spark.read.format("jdbc")`. Para PostgreSQL, e necessario o driver `postgresql-42.7.4.jar` no classpath. A leitura paralela e alcancada via particionamento por coluna numerica, dividindo o range de valores entre executores Spark. Este e o mecanismo usado pelo job `ingest_postgres_to_parquet.py` no projeto.

## Connection String

```text
jdbc:postgresql://HOST:PORT/DATABASE

Exemplos:
  jdbc:postgresql://10.0.0.3:5432/mydb           # Private IP
  jdbc:postgresql://127.0.0.1:5432/mydb           # Via Auth Proxy
  jdbc:postgresql://10.0.0.3:5432/mydb?ssl=true   # Com SSL
```

## Leitura Basica

```python
df = (
    spark.read.format("jdbc")
    .option("url", "jdbc:postgresql://10.0.0.3:5432/mydb")
    .option("dbtable", "public.customers")
    .option("user", db_user)
    .option("password", db_password)
    .option("driver", "org.postgresql.Driver")
    .option("fetchsize", "1000")
    .load()
)
```

## Particionamento para Leitura Paralela

```text
Tabela: 1M linhas, PK id (1 a 1000000), numPartitions=10

Partition 0: SELECT * FROM table WHERE id >= 1      AND id < 100001
Partition 1: SELECT * FROM table WHERE id >= 100001  AND id < 200001
...
Partition 9: SELECT * FROM table WHERE id >= 900001  AND id <= 1000000

Cada partition = 1 conexao JDBC = 1 task Spark
```

```python
df = (
    spark.read.format("jdbc")
    .option("url", jdbc_url)
    .option("dbtable", "public.customers")
    .option("user", user)
    .option("password", password)
    .option("driver", "org.postgresql.Driver")
    .option("fetchsize", "5000")
    .option("partitionColumn", "id")
    .option("lowerBound", "1")
    .option("upperBound", "1000000")
    .option("numPartitions", "10")
    .load()
)
```

## Leitura com Query Customizada

```python
# Query deve ser subquery (alias obrigatorio)
query = "(SELECT id, name, email FROM public.customers WHERE active = true) AS t"
df = (
    spark.read.format("jdbc")
    .option("url", jdbc_url)
    .option("query", query)
    .option("user", user)
    .option("password", password)
    .option("driver", "org.postgresql.Driver")
    .load()
)
```

## Quick Reference

| Parametro | Tipo | Descricao |
|-----------|------|-----------|
| `url` | String | Connection string JDBC |
| `dbtable` | String | schema.tabela (mutuamente exclusivo com query) |
| `query` | String | SQL customizado (mutuamente exclusivo com dbtable) |
| `partitionColumn` | String | Coluna numerica para dividir leitura |
| `lowerBound` | Long | Valor minimo da coluna de particao |
| `upperBound` | Long | Valor maximo da coluna de particao |
| `numPartitions` | Int | Numero de leituras paralelas |
| `fetchsize` | Int | Linhas por roundtrip de rede |

## Common Mistakes

### Wrong

```python
# Sem fetchsize = default JDBC (10 linhas por roundtrip)
spark.read.format("jdbc").option("dbtable", "big_table").load()

# numPartitions sem partitionColumn = ignorado
.option("numPartitions", "10")  # Sem partitionColumn!
```

### Correct

```python
# fetchsize explicito + particionamento completo
spark.read.format("jdbc")
    .option("fetchsize", "5000")
    .option("partitionColumn", "id")
    .option("lowerBound", "1")
    .option("upperBound", "1000000")
    .option("numPartitions", "10")
    .load()
```

## Related

- [Spark JDBC Read Pattern](../patterns/spark-jdbc-read.md)
- [Connection Pooling](../patterns/connection-pooling.md)
- [Cloud SQL Overview](../concepts/cloud-sql-overview.md)
