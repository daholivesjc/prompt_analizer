# Cloud SQL for PostgreSQL Knowledge Base

> **Purpose**: Referencia para Cloud SQL PostgreSQL na GCP, conectividade JDBC com Spark e integracao com Dataproc Serverless
> **MCP Validated**: 2026-03-18

## Quick Navigation

### Concepts (< 150 lines each)

| File | Purpose |
|------|---------|
| [concepts/cloud-sql-overview.md](concepts/cloud-sql-overview.md) | Arquitetura, edicoes e tiers do Cloud SQL PostgreSQL |
| [concepts/connectivity.md](concepts/connectivity.md) | Private IP, VPC Peering, Private Service Access |
| [concepts/jdbc-spark.md](concepts/jdbc-spark.md) | Driver JDBC, connection strings, leitura paralela |
| [concepts/authentication-security.md](concepts/authentication-security.md) | IAM auth, Secret Manager, SSL/TLS |
| [concepts/high-availability.md](concepts/high-availability.md) | HA regional, failover, read replicas |

### Patterns (< 200 lines each)

| File | Purpose |
|------|---------|
| [patterns/spark-jdbc-read.md](patterns/spark-jdbc-read.md) | Leitura JDBC com Spark: particionamento e fetchsize |
| [patterns/cloud-sql-networking.md](patterns/cloud-sql-networking.md) | Rede para Dataproc Serverless acessar Cloud SQL |
| [patterns/credential-management.md](patterns/credential-management.md) | Credenciais seguras com Secret Manager + IAM |
| [patterns/connection-pooling.md](patterns/connection-pooling.md) | Boas praticas de pooling de conexoes JDBC |
| [patterns/backup-recovery.md](patterns/backup-recovery.md) | Backup automatizado e point-in-time recovery |

### Specs (Machine-Readable)

| File | Purpose |
|------|---------|
| [specs/jdbc-config.yaml](specs/jdbc-config.yaml) | Configuracoes JDBC para diferentes cenarios |

---

## Quick Reference

- [quick-reference.md](quick-reference.md) - Tabelas de consulta rapida

---

## Key Concepts

| Concept | Description |
|---------|-------------|
| **Cloud SQL** | Banco relacional gerenciado na GCP com HA, backups e patches automaticos |
| **Private Service Access** | Conectividade privada via VPC Peering com rede interna do Google |
| **JDBC Partitioning** | Leitura paralela dividindo ranges de uma coluna entre executores Spark |
| **Secret Manager** | Armazenamento seguro de credenciais acessadas em runtime pelo job |

---

## Learning Path

| Level | Files |
|-------|-------|
| **Beginner** | concepts/cloud-sql-overview.md, concepts/connectivity.md |
| **Intermediate** | concepts/jdbc-spark.md, patterns/spark-jdbc-read.md |
| **Advanced** | patterns/cloud-sql-networking.md, patterns/credential-management.md |

---

## Agent Usage

| Agent | Primary Files | Use Case |
|-------|---------------|----------|
| kb-architect | patterns/spark-jdbc-read.md | Configurar leitura JDBC otimizada |
| infra-agent | patterns/cloud-sql-networking.md | Configurar VPC e firewall |

---

## Contexto do Projeto

Esta KB suporta o pipeline de ingestao Medallion Lakehouse:

| Componente | Recurso GCP |
|-----------|-------------|
| Job PySpark | `jobs/raw/ingest_postgres_to_parquet.py` |
| Workflow | `workflows/wf_ingest_postgres.yaml` |
| Terraform | `terraform/envs/jobs/ingest-postgres/` |
| Driver JDBC | `postgresql-42.7.4.jar` (GCS) |
| Credenciais | Secret Manager (user + password) |
