# Backup & Recovery Pattern

> **Purpose**: Estrategias de backup automatizado e point-in-time recovery no Cloud SQL PostgreSQL
> **MCP Validated**: 2026-03-18

## When to Use

- Proteger dados contra perda acidental ou corrupcao
- Compliance que exige retencao de dados por periodos especificos
- Disaster recovery com RTO e RPO definidos
- Restaurar estado do banco em um ponto especifico no tempo

## Implementation

```hcl
# Terraform - Configuracao completa de backup

resource "google_sql_database_instance" "postgres" {
  name             = "fdm-postgres"
  database_version = "POSTGRES_15"
  region           = "us-central1"

  settings {
    tier              = "db-custom-4-15360"
    availability_type = "REGIONAL"

    backup_configuration {
      # Backup automatico diario
      enabled                        = true
      start_time                     = "03:00"  # UTC

      # Point-in-time recovery (binary logs)
      point_in_time_recovery_enabled = true
      transaction_log_retention_days = 7

      # Retencao de backups
      backup_retention_settings {
        retained_backups = 30        # Manter 30 backups
        retention_unit   = "COUNT"
      }
    }
  }
}
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `enabled` | `false` | Habilitar backups automaticos |
| `start_time` | - | Hora UTC para backup diario (janela de 4h) |
| `point_in_time_recovery_enabled` | `false` | Habilitar PITR via WAL |
| `transaction_log_retention_days` | `7` | Retencao de WAL (1-7 dias) |
| `retained_backups` | `7` | Numero de backups mantidos |

## Tipos de Backup

| Tipo | Frequencia | RPO | Automacao |
|------|-----------|-----|-----------|
| Automatico | Diario | 24h | Cloud SQL nativo |
| On-demand | Manual | 0 | gcloud/API |
| PITR | Continuo | ~segundos | WAL streaming |
| Export SQL | Sob demanda | Variavel | gcloud sql export |

## Operacoes via gcloud

```bash
# Listar backups
gcloud sql backups list --instance=fdm-postgres

# Criar backup on-demand
gcloud sql backups create --instance=fdm-postgres \
  --description="Backup pre-migracao"

# Restaurar backup especifico
gcloud sql backups restore BACKUP_ID \
  --restore-instance=fdm-postgres

# Point-in-time recovery (PITR)
gcloud sql instances clone fdm-postgres fdm-postgres-restored \
  --point-in-time="2026-03-18T10:30:00.000Z"

# Exportar para GCS (SQL dump)
gcloud sql export sql fdm-postgres \
  gs://fdm-backups/postgres/dump-2026-03-18.sql \
  --database=mydb

# Importar de GCS
gcloud sql import sql fdm-postgres \
  gs://fdm-backups/postgres/dump-2026-03-18.sql \
  --database=mydb
```

## Estrategia de DR

```text
RPO e RTO por cenario:

| Cenario            | Mecanismo          | RPO        | RTO        |
|--------------------|--------------------|------------|------------|
| Falha de zona      | HA failover        | 0          | ~60s       |
| Erro humano (DROP) | PITR clone         | ~segundos  | ~10-30min  |
| Corrupcao de dados | Backup restore     | ~24h       | ~30-60min  |
| Falha de regiao    | Cross-region clone | ~minutos   | ~1-2h      |
```

## Cross-Region Backup

```hcl
# Replica cross-region para DR
resource "google_sql_database_instance" "dr_replica" {
  name                 = "fdm-postgres-dr"
  master_instance_name = google_sql_database_instance.postgres.name
  database_version     = "POSTGRES_15"
  region               = "southamerica-east1"  # Sao Paulo

  replica_configuration {
    failover_target = true  # Pode ser promovida
  }

  settings {
    tier              = "db-custom-4-15360"
    availability_type = "ZONAL"

    backup_configuration {
      enabled = true  # Backup independente na regiao DR
    }
  }
}
```

## Monitoramento de Backups

```bash
# Verificar ultimo backup bem-sucedido
gcloud sql backups list --instance=fdm-postgres \
  --filter="status=SUCCESSFUL" \
  --sort-by=~startTime \
  --limit=1

# Alertas via Cloud Monitoring
# Metrica: cloudsql.googleapis.com/database/backup/age
# Condicao: > 48 horas (2 backups perdidos)
```

## Validacao de Restore

```text
Procedimento trimestral de validacao:
1. Criar clone via PITR para timestamp aleatorio
2. Conectar ao clone e verificar integridade dos dados
3. Executar queries de validacao (contagem, checksums)
4. Deletar clone apos validacao
5. Documentar resultado no runbook
```

## Example Usage

```bash
# Cenario: usuario executou DELETE sem WHERE
# Solucao: PITR para 1 minuto antes do incidente

# 1. Identificar timestamp do incidente nos logs
gcloud logging read \
  'resource.type="cloudsql_database" AND textPayload:"DELETE FROM"' \
  --limit=5

# 2. Clonar instancia para timestamp anterior
gcloud sql instances clone fdm-postgres fdm-postgres-recovery \
  --point-in-time="2026-03-18T14:29:00.000Z"

# 3. Exportar dados recuperados
gcloud sql export sql fdm-postgres-recovery \
  gs://fdm-backups/recovery/customers-recovery.sql \
  --database=mydb --table=customers

# 4. Importar na instancia principal
gcloud sql import sql fdm-postgres \
  gs://fdm-backups/recovery/customers-recovery.sql

# 5. Limpar clone
gcloud sql instances delete fdm-postgres-recovery --quiet
```

## See Also

- [High Availability](../concepts/high-availability.md)
- [Cloud SQL Overview](../concepts/cloud-sql-overview.md)
- [Cloud SQL Networking](../patterns/cloud-sql-networking.md)
