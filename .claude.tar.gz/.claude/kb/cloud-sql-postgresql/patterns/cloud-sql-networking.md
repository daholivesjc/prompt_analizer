# Cloud SQL Networking Pattern

> **Purpose**: Configuracao de rede para Dataproc Serverless acessar Cloud SQL via Private IP
> **MCP Validated**: 2026-03-18

## When to Use

- Dataproc Serverless precisa conectar ao Cloud SQL PostgreSQL
- Infraestrutura com Private IP (sem IP publico)
- VPC compartilhada entre Dataproc e Cloud SQL via PSA
- Terraform como IaC para provisionar toda a rede

## Implementation

```hcl
# ============================================================
# Networking completo: VPC + PSA + Cloud SQL + Firewall
# ============================================================

# 1. VPC e Subnet dedicada
resource "google_compute_network" "vpc" {
  name                    = "fdm-dados-vpc"
  auto_create_subnetworks = false
}

resource "google_compute_subnetwork" "dataproc_subnet" {
  name          = "dataproc-subnet"
  ip_cidr_range = "10.0.0.0/20"
  region        = "us-central1"
  network       = google_compute_network.vpc.id

  private_ip_google_access = true  # Obrigatorio para Dataproc Serverless
}

# 2. Private Service Access (PSA)
resource "google_compute_global_address" "psa_range" {
  name          = "cloud-sql-psa-range"
  purpose       = "VPC_PEERING"
  address_type  = "INTERNAL"
  prefix_length = 16
  network       = google_compute_network.vpc.id
}

resource "google_service_networking_connection" "psa" {
  network                 = google_compute_network.vpc.id
  service                 = "servicenetworking.googleapis.com"
  reserved_peering_ranges = [google_compute_global_address.psa_range.name]
}

# 3. Cloud SQL com Private IP
resource "google_sql_database_instance" "postgres" {
  name             = "fdm-postgres"
  database_version = "POSTGRES_15"
  region           = "us-central1"

  depends_on = [google_service_networking_connection.psa]

  settings {
    tier              = "db-custom-4-15360"
    availability_type = "REGIONAL"

    ip_configuration {
      ipv4_enabled    = false
      private_network = google_compute_network.vpc.id
    }
  }
}

# 4. Firewall: Dataproc Serverless -> Cloud SQL (porta 5432)
resource "google_compute_firewall" "dataproc_to_cloudsql" {
  name    = "allow-dataproc-to-cloudsql-pg"
  network = google_compute_network.vpc.name

  allow {
    protocol = "tcp"
    ports    = ["5432"]
  }

  source_ranges = [
    google_compute_subnetwork.dataproc_subnet.ip_cidr_range
  ]

  direction = "INGRESS"
}

# 5. Firewall: comunicacao interna Dataproc Serverless
resource "google_compute_firewall" "dataproc_internal" {
  name    = "allow-dataproc-internal"
  network = google_compute_network.vpc.name

  allow {
    protocol = "tcp"
    ports    = ["0-65535"]
  }
  allow {
    protocol = "udp"
    ports    = ["0-65535"]
  }
  allow {
    protocol = "icmp"
  }

  source_ranges = [
    google_compute_subnetwork.dataproc_subnet.ip_cidr_range
  ]
}
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `ip_cidr_range` (subnet) | `10.0.0.0/20` | Range para Dataproc (4096 IPs) |
| `prefix_length` (PSA) | `16` | Range reservado para Google (65536 IPs) |
| `private_ip_google_access` | `true` | Obrigatorio para Dataproc Serverless |
| Porta Cloud SQL | `5432` | PostgreSQL padrao |

## Diagrama de Rede

```text
   Projeto GCP
   +-----------------------------------------------+
   |  VPC: fdm-dados-vpc                            |
   |                                                |
   |  +------------------+   +------------------+  |
   |  | Subnet:          |   | PSA Range:       |  |
   |  | 10.0.0.0/20      |   | 10.x.0.0/16     |  |
   |  |                  |   |                  |  |
   |  | [Dataproc        |   | [Cloud SQL       |  |
   |  |  Serverless]     |-->|  PostgreSQL]     |  |
   |  |                  | FW|  10.x.y.z:5432  |  |
   |  +------------------+ 5432 +-----------------+|
   +-----------------------------------------------+
```

## Verificacao de Conectividade

```bash
# Verificar IP privado do Cloud SQL
gcloud sql instances describe fdm-postgres \
  --format="value(ipAddresses[0].ipAddress)"

# Verificar peering ativo
gcloud compute networks peerings list \
  --network=fdm-dados-vpc

# Verificar regras de firewall
gcloud compute firewall-rules list \
  --filter="network=fdm-dados-vpc" \
  --format="table(name, direction, allowed)"
```

## Troubleshooting

| Sintoma | Causa Provavel | Solucao |
|---------|----------------|---------|
| Connection timeout | Firewall sem regra 5432 | Adicionar regra ingress TCP 5432 |
| No route to host | PSA nao configurado | Criar `google_service_networking_connection` |
| Connection refused | Cloud SQL sem Private IP | Habilitar `ipv4_enabled = false` + `private_network` |
| Dataproc batch falha ao iniciar | `private_ip_google_access = false` | Habilitar na subnet |

## See Also

- [Connectivity](../concepts/connectivity.md)
- [Cloud SQL Overview](../concepts/cloud-sql-overview.md)
- [Credential Management](../patterns/credential-management.md)
