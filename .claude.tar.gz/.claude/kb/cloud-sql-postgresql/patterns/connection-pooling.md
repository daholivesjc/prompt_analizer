# Connection Pooling Pattern

> **Purpose**: Boas praticas de pooling e gerenciamento de conexoes JDBC com Spark
> **MCP Validated**: 2026-03-18

## When to Use

- Leitura paralela com multiplas partitions (numPartitions > 1)
- Evitar sobrecarga do Cloud SQL com muitas conexoes simultaneas
- Jobs que executam em paralelo no mesmo banco
- Tabelas grandes com numPartitions alto (>10)

## Implementation

```python
"""Configuracao otimizada de conexoes JDBC para Spark."""

from pyspark.sql import SparkSession


def configure_jdbc_connection(
    spark: SparkSession,
    jdbc_url: str,
    user: str,
    password: str,
    dbtable: str,
    num_partitions: int = 8,
    fetch_size: int = 5000,
    partition_column: str = "id",
    lower_bound: int = 1,
    upper_bound: int = 1000000,
):
    """Le tabela com configuracoes otimizadas de conexao.

    Cada partition do Spark cria 1 conexao JDBC.
    Total de conexoes simultaneas = numPartitions.

    Regras de dimensionamento:
    - Cloud SQL max_connections padrao: 100-500 (depende do tier)
    - Reservar conexoes para app + admin: ~20%
    - numPartitions <= 80% max_connections
    """
    return (
        spark.read.format("jdbc")
        .option("url", jdbc_url)
        .option("user", user)
        .option("password", password)
        .option("driver", "org.postgresql.Driver")
        .option("dbtable", dbtable)
        # Controle de conexoes
        .option("numPartitions", str(num_partitions))
        .option("partitionColumn", partition_column)
        .option("lowerBound", str(lower_bound))
        .option("upperBound", str(upper_bound))
        # Otimizacao de rede
        .option("fetchsize", str(fetch_size))
        # Timeout de conexao (ms)
        .option("connectionTimeout", "30000")
        # Socket timeout (ms) - para queries lentas
        .option("socketTimeout", "300000")
        .load()
    )
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `numPartitions` | 1 | Conexoes simultaneas ao banco |
| `fetchsize` | 10 (JDBC) | Linhas por roundtrip de rede |
| `connectionTimeout` | 0 (infinito) | Timeout de conexao em ms |
| `socketTimeout` | 0 (infinito) | Timeout de socket em ms |

## Cloud SQL - max_connections por Tier

| Tier | vCPUs | RAM | max_connections |
|------|-------|-----|-----------------|
| `db-f1-micro` | shared | 0.6 GB | 25 |
| `db-custom-1-3840` | 1 | 3.75 GB | 50 |
| `db-custom-2-7680` | 2 | 7.5 GB | 100 |
| `db-custom-4-15360` | 4 | 15 GB | 200 |
| `db-custom-8-30720` | 8 | 30 GB | 400 |
| `db-custom-16-61440` | 16 | 60 GB | 500 |

## Regras de Dimensionamento

```text
max_connections do tier:              200
Reserva para admin/monitoramento:     -20 (10%)
Disponivel para jobs:                 180
Jobs simultaneos:                     3
numPartitions por job:                60 (180/3)
```

## Properties JDBC no PostgreSQL

```python
# Via URL JDBC
url = (
    "jdbc:postgresql://10.0.0.3:5432/mydb"
    "?ApplicationName=spark-ingest"      # Identificar no pg_stat_activity
    "&loginTimeout=30"                   # Timeout de login (s)
    "&socketTimeout=300"                 # Timeout de socket (s)
    "&tcpKeepAlive=true"                 # Manter conexao ativa
    "&prepareThreshold=0"               # Desabilitar prepared statements
)
```

## Monitoramento de Conexoes

```sql
-- Ver conexoes ativas no PostgreSQL
SELECT
    application_name,
    client_addr,
    state,
    query_start,
    COUNT(*) OVER () AS total_connections
FROM pg_stat_activity
WHERE datname = 'mydb'
ORDER BY query_start DESC;

-- Ver limites
SHOW max_connections;
SELECT COUNT(*) AS active FROM pg_stat_activity;
```

## Example Usage

```python
# Tabela media (500K linhas) - 8 conexoes paralelas
df = configure_jdbc_connection(
    spark=spark,
    jdbc_url="jdbc:postgresql://10.0.0.3:5432/mydb",
    user=db_user,
    password=db_password,
    dbtable="public.orders",
    num_partitions=8,
    fetch_size=5000,
    partition_column="order_id",
    lower_bound=1,
    upper_bound=500000,
)
```

## See Also

- [Spark JDBC Read](../patterns/spark-jdbc-read.md)
- [JDBC com Spark](../concepts/jdbc-spark.md)
- [Cloud SQL Overview](../concepts/cloud-sql-overview.md)
