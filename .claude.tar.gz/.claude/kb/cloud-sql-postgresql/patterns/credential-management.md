# Credential Management Pattern

> **Purpose**: Gerenciamento seguro de credenciais PostgreSQL com Secret Manager e IAM
> **MCP Validated**: 2026-03-18

## When to Use

- Jobs PySpark precisam de credenciais para conectar ao Cloud SQL
- Credenciais nao devem ser hardcoded no codigo ou em variaveis de ambiente
- Rotacao de credenciais sem redesploy do job
- Auditoria de acesso a credenciais via Cloud Audit Logs

## Implementation

```python
"""Gerenciamento seguro de credenciais para jobs JDBC."""

import logging
from google.cloud import secretmanager

logger = logging.getLogger(__name__)


def get_secret(project_id: str, secret_name: str, version: str = "latest") -> str:
    """Obtem o valor de um segredo do Secret Manager.

    Args:
        project_id: ID do projeto GCP
        secret_name: Nome do segredo (ex: pg-user, pg-password)
        version: Versao do segredo (default: latest)

    Returns:
        Valor do segredo decodificado em UTF-8
    """
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{project_id}/secrets/{secret_name}/versions/{version}"

    try:
        response = client.access_secret_version(name=name)
        logger.info("Segredo '%s' obtido com sucesso.", secret_name)
        return response.payload.data.decode("UTF-8")
    except Exception as e:
        logger.error("Falha ao obter segredo '%s': %s", secret_name, e)
        raise


def get_jdbc_credentials(project_id: str, secret_user: str, secret_password: str):
    """Obtem par de credenciais JDBC do Secret Manager.

    Returns:
        Tupla (user, password)
    """
    user = get_secret(project_id, secret_user)
    password = get_secret(project_id, secret_password)
    return user, password


# Uso no job de ingestao
def run(args):
    db_user, db_password = get_jdbc_credentials(
        project_id=args.project_id,
        secret_user=args.secret_user,
        secret_password=args.secret_password,
    )
    # Usar credenciais na leitura JDBC...
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `secret_user` | - | Nome do segredo com username do banco |
| `secret_password` | - | Nome do segredo com senha do banco |
| `version` | `latest` | Versao do segredo (para rollback) |
| `project_id` | - | Projeto GCP onde estao os segredos |

## Terraform - Provisionamento Completo

```hcl
# Segredos
resource "google_secret_manager_secret" "pg_user" {
  secret_id = "pg-user"
  replication { auto {} }
}

resource "google_secret_manager_secret" "pg_password" {
  secret_id = "pg-password"
  replication { auto {} }
}

# Valores iniciais (gerenciar fora do Terraform em producao)
resource "google_secret_manager_secret_version" "pg_user_v1" {
  secret      = google_secret_manager_secret.pg_user.id
  secret_data = "postgres_app_user"
}

resource "google_secret_manager_secret_version" "pg_password_v1" {
  secret      = google_secret_manager_secret.pg_password.id
  secret_data = var.pg_initial_password  # Variavel sensivel
}

# IAM - SA do Dataproc acessa os segredos
resource "google_secret_manager_secret_iam_member" "user_access" {
  secret_id = google_secret_manager_secret.pg_user.id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${var.sa_dataproc_email}"
}

resource "google_secret_manager_secret_iam_member" "pass_access" {
  secret_id = google_secret_manager_secret.pg_password.id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${var.sa_dataproc_email}"
}
```

## Rotacao de Credenciais

```bash
# 1. Criar novo usuario no PostgreSQL
psql -h 10.0.0.3 -U admin -d mydb \
  -c "CREATE ROLE new_app_user LOGIN PASSWORD 'NewSecurePass123!';"

# 2. Adicionar nova versao do segredo
echo -n "new_app_user" | \
  gcloud secrets versions add pg-user --data-file=-
echo -n "NewSecurePass123!" | \
  gcloud secrets versions add pg-password --data-file=-

# 3. Proximo job automaticamente usa "latest"

# 4. Apos validacao, desabilitar versao antiga
gcloud secrets versions disable pg-user --version=1
gcloud secrets versions disable pg-password --version=1
```

## Argumentos CLI do Job

```bash
# Passados via Workflow/Scheduler
--project-id my-gcp-project \
--secret-user pg-user \
--secret-password pg-password
```

## Example Usage

```python
# No job ingest_postgres_to_parquet.py
args = parse_args()

# Credenciais nunca aparecem em logs
logger.info("Iniciando com args: %s", {
    k: v for k, v in vars(args).items()
    if k not in ("secret_user", "secret_password")
})

# Obter credenciais em runtime
db_user = get_secret(args.project_id, args.secret_user)
db_password = get_secret(args.project_id, args.secret_password)
```

## See Also

- [Authentication & Security](../concepts/authentication-security.md)
- [Spark JDBC Read](../patterns/spark-jdbc-read.md)
- [Cloud SQL Networking](../patterns/cloud-sql-networking.md)
