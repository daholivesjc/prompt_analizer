# Spark JDBC Read Pattern

> **Purpose**: Leitura JDBC otimizada com Spark — particionamento, predicados e fetchsize
> **MCP Validated**: 2026-03-18

## When to Use

- Ingestao de tabelas PostgreSQL para a camada raw (Parquet)
- Tabelas com mais de 100K linhas que precisam de leitura paralela
- Extracao completa ou incremental de dados relacionais
- Job `ingest_postgres_to_parquet.py` do projeto FDM Dados

## Implementation

```python
"""Pattern de leitura JDBC com Spark para PostgreSQL."""

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import StructType


def read_jdbc_table(
    spark: SparkSession,
    jdbc_url: str,
    user: str,
    password: str,
    dbtable: str | None = None,
    query: str | None = None,
    partition_column: str | None = None,
    lower_bound: int | None = None,
    upper_bound: int | None = None,
    num_partitions: int = 1,
    fetch_size: int = 1000,
    schema: StructType | None = None,
) -> DataFrame:
    """Le dados de PostgreSQL via JDBC com suporte a leitura paralela.

    Args:
        spark: SparkSession ativa
        jdbc_url: Connection string (jdbc:postgresql://host:port/db)
        user: Usuario do banco (obtido do Secret Manager)
        password: Senha do banco (obtida do Secret Manager)
        dbtable: Nome da tabela (schema.table). Mutuamente exclusivo com query.
        query: SQL customizado. Mutuamente exclusivo com dbtable.
        partition_column: Coluna numerica para dividir leitura entre executores
        lower_bound: Valor minimo do range de particao
        upper_bound: Valor maximo do range de particao
        num_partitions: Numero de conexoes/tasks paralelas
        fetch_size: Linhas por roundtrip de rede
        schema: Schema explicito (StructType) para sobrescrever inferencia

    Returns:
        DataFrame com os dados lidos
    """
    if not dbtable and not query:
        raise ValueError("Informe --dbtable ou --query.")
    if dbtable and query:
        raise ValueError("Informe apenas --dbtable ou --query, nao ambos.")

    jdbc_properties = {
        "user": user,
        "password": password,
        "driver": "org.postgresql.Driver",
        "fetchsize": str(fetch_size),
    }

    reader = spark.read.format("jdbc").options(url=jdbc_url, **jdbc_properties)

    if dbtable:
        reader = reader.option("dbtable", dbtable)
    else:
        reader = reader.option("query", query)

    # Particionamento para leitura paralela
    if partition_column and lower_bound is not None and upper_bound is not None:
        reader = (
            reader
            .option("partitionColumn", partition_column)
            .option("lowerBound", str(lower_bound))
            .option("upperBound", str(upper_bound))
            .option("numPartitions", str(num_partitions))
        )

    if schema is not None:
        reader = reader.schema(schema)

    return reader.load()
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `fetchsize` | `1000` | Linhas por roundtrip. Aumentar para tabelas grandes (5000-10000) |
| `numPartitions` | `1` | Conexoes paralelas. Regra: 2x num cores dos executores |
| `partitionColumn` | `None` | PK numerica ou coluna com distribuicao uniforme |
| `lowerBound` | `None` | `SELECT MIN(col) FROM table` |
| `upperBound` | `None` | `SELECT MAX(col) FROM table` |
| `driver` | `org.postgresql.Driver` | Driver PostgreSQL JDBC |

## Dimensionamento

| Tamanho Tabela | numPartitions | fetchsize | executor_memory |
|----------------|---------------|-----------|-----------------|
| < 100K linhas | 1 | 1000 | 4g |
| 100K - 1M | 4-8 | 5000 | 8g |
| 1M - 10M | 8-16 | 10000 | 8g |
| > 10M | 16-32 | 10000 | 16g |

## Submissao via Dataproc Serverless

```bash
gcloud dataproc batches submit pyspark \
    gs://BUCKET/landing/scripts_pyspark/ingest_postgres_to_parquet.py \
    --region=us-central1 \
    --version=2.2 \
    --jars=gs://BUCKET/landing/jars/postgresql-42.7.4.jar \
    --service-account=SA@PROJECT.iam.gserviceaccount.com \
    --properties=spark.executor.cores=4,spark.executor.memory=8g \
    --subnet=projects/PROJECT/regions/REGION/subnetworks/SUBNET \
    -- \
    --jdbc-url jdbc:postgresql://10.0.0.3:5432/mydb \
    --project-id my-project \
    --secret-user pg-user \
    --secret-password pg-password \
    --dbtable public.customers \
    --destination gs://BUCKET/raw/postgres/customers \
    --partition-column id \
    --lower-bound 1 \
    --upper-bound 1000000 \
    --num-partitions 10 \
    --fetch-size 5000
```

## Example Usage

```python
# Leitura simples (tabela pequena)
df = read_jdbc_table(
    spark=spark,
    jdbc_url="jdbc:postgresql://10.0.0.3:5432/mydb",
    user=db_user,
    password=db_password,
    dbtable="public.dim_products",
    fetch_size=1000,
)

# Leitura paralela (tabela grande)
df = read_jdbc_table(
    spark=spark,
    jdbc_url="jdbc:postgresql://10.0.0.3:5432/mydb",
    user=db_user,
    password=db_password,
    dbtable="public.fact_orders",
    partition_column="order_id",
    lower_bound=1,
    upper_bound=5000000,
    num_partitions=16,
    fetch_size=10000,
)
```

## See Also

- [JDBC com Spark](../concepts/jdbc-spark.md)
- [Connection Pooling](../patterns/connection-pooling.md)
- [Credential Management](../patterns/credential-management.md)
