# Cloud SQL PostgreSQL Quick Reference

> Tabelas de consulta rapida. Para exemplos de codigo, veja os arquivos linkados.
> **MCP Validated**: 2026-03-18

## Selecao de Edicao

| Edicao | Uso | SLA | Armazenamento Max |
|--------|-----|-----|-------------------|
| Enterprise | Cargas padrao, dev/staging | 99.95% (HA) | 64 TB |
| Enterprise Plus | Missao critica, latencia minima | 99.99% (HA) | 128 TB |

## Conectividade

| Metodo | Quando Usar | Latencia |
|--------|-------------|----------|
| Private IP (PSA) | Dataproc Serverless, producao | Baixa |
| Public IP + Auth Proxy | Desenvolvimento local | Media |
| Cloud SQL Connector | Apps Python/Java diretos | Baixa |
| VPC Peering | Servicos na mesma VPC | Baixa |

## JDBC Spark - Parametros Chave

| Parametro | Default | Recomendado | Descricao |
|-----------|---------|-------------|-----------|
| `fetchsize` | 10 (JDBC) | 1000-10000 | Linhas por roundtrip |
| `numPartitions` | 1 | 4-20 | Leituras paralelas |
| `partitionColumn` | - | PK numerica | Coluna para dividir ranges |
| `lowerBound` | - | MIN(col) | Inicio do range |
| `upperBound` | - | MAX(col) | Fim do range |

## IAM Roles Necessarios

| Tarefa | Role |
|--------|------|
| Conectar ao Cloud SQL | `roles/cloudsql.client` |
| Acessar Secret Manager | `roles/secretmanager.secretAccessor` |
| Executar Dataproc batch | `roles/dataproc.editor` |
| Acessar subrede | `roles/compute.networkUser` |

## Machine Types Comuns

| Tier | vCPUs | RAM | Uso |
|------|-------|-----|-----|
| `db-f1-micro` | Shared | 0.6 GB | Dev/teste |
| `db-custom-2-7680` | 2 | 7.5 GB | Cargas leves |
| `db-custom-4-15360` | 4 | 15 GB | Producao media |
| `db-custom-8-30720` | 8 | 30 GB | Producao pesada |

## Decision Matrix

| Cenario | Escolha |
|---------|---------|
| Dataproc Serverless -> Cloud SQL | Private IP + VPC Peering + Firewall 5432 |
| Credenciais do banco | Secret Manager (nunca hardcode) |
| Tabela grande (>1M linhas) | Particionamento JDBC por PK |
| Tabela pequena (<100K linhas) | Leitura single-partition |
| Alta disponibilidade | HA regional + read replicas |

## Erros Comuns

| Evite | Faca |
|-------|------|
| Public IP em producao | Use Private IP com PSA |
| `fetchsize` default (10) | Configure 1000+ |
| `numPartitions` = 1 para tabelas grandes | Use 4-20 partitions |
| Senha hardcoded no codigo | Use Secret Manager |
| Firewall sem regra porta 5432 | Libere ingress TCP 5432 |
| Sem backup automatizado | Habilite backups diarios |

## Documentacao Relacionada

| Topico | Path |
|--------|------|
| Visao geral Cloud SQL | `concepts/cloud-sql-overview.md` |
| Pattern JDBC Spark | `patterns/spark-jdbc-read.md` |
| Indice completo | `index.md` |
