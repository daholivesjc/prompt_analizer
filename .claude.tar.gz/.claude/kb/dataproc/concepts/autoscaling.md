# Autoscaling

> **Purpose**: Automatically adjust worker VM count based on YARN metrics
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-03

## Overview

Dataproc autoscaling dynamically adjusts worker VM count (horizontal scaling only) based on YARN resource metrics. The algorithm evaluates pending, allocated, and available resources during a cooldown period, then applies scale factors to determine node additions or removals. Best practice is to fix primary workers and scale only secondary (preemptible) workers.

## The Pattern

```yaml
# autoscaling-policy.yaml
workerConfig:
  minInstances: 4
  maxInstances: 4        # Fixed primary workers
  weight: 1
secondaryWorkerConfig:
  minInstances: 0
  maxInstances: 50       # Scale secondary workers
  weight: 1
basicAlgorithm:
  cooldownPeriod: 4m
  yarnConfig:
    scaleUpFactor: 0.05
    scaleDownFactor: 1.0
    scaleUpMinWorkerFraction: 0.0
    scaleDownMinWorkerFraction: 0.0
    gracefulDecommissionTimeout: 1h
```

## Quick Reference

| Parameter | Default | Purpose |
|-----------|---------|---------|
| `scaleUpFactor` | -- | Fraction of pending resources triggering scale-up |
| `scaleDownFactor` | -- | Fraction of available resources triggering scale-down |
| `cooldownPeriod` | 2m | Minimum time between scaling actions |
| `gracefulDecommissionTimeout` | -- | Max wait for running tasks before node removal |
| `scaleUpMinWorkerFraction` | 0.0 | Minimum fractional increase to trigger scale-up |
| `scaleDownMinWorkerFraction` | 0.0 | Minimum fractional decrease to trigger scale-down |

## Scaling Algorithm

1. **Estimate**: Calculate ideal worker count from YARN metrics (memory AND cores, take max)
2. **Apply factor**: Multiply delta by scaleUpFactor or scaleDownFactor
3. **Check threshold**: Delta must exceed minWorkerFraction to act
4. **Apply bounds**: Enforce minInstances/maxInstances limits
5. **Execute**: Add or decommission workers

## YARN Metrics Used

| Metric | Scale Direction | Meaning |
|--------|----------------|---------|
| Pending resources | Up | Containers waiting for resources |
| Allocated resources | Baseline | Resources used by running containers |
| Available resources | Down | Unused cluster resources |
| Reserved resources | Up | Resources reserved but not yet allocated |

## Common Mistakes

### Wrong

```yaml
# Primary workers autoscale -- slow HDFS decommissioning
workerConfig:
  minInstances: 2
  maxInstances: 20
```

### Correct

```yaml
# Fixed primary, scale secondary only
workerConfig:
  minInstances: 4
  maxInstances: 4
secondaryWorkerConfig:
  minInstances: 0
  maxInstances: 50
```

## Critical Warnings

- `minInstances = maxInstances` on all groups means **no scaling occurs**
- Both scale factors set to `0` means **no scaling occurs**
- Autoscaling does **not** work on Single Node clusters
- Manual resizes are **temporary** -- autoscaler reverts them
- Policy updates **immediately affect all clusters** using that policy

## Operations

```bash
# Import policy from YAML
gcloud dataproc autoscaling-policies import my-policy \
    --source=policy.yaml --region=us-central1

# Create cluster with autoscaling
gcloud dataproc clusters create my-cluster \
    --autoscaling-policy=my-policy --region=us-central1

# Update existing cluster
gcloud dataproc clusters update my-cluster \
    --autoscaling-policy=my-policy --region=us-central1

# Disable autoscaling
gcloud dataproc clusters update my-cluster \
    --disable-autoscaling --region=us-central1
```

## Related

- [Cluster Types](../concepts/cluster-types.md)
- [Cluster Configuration](../patterns/cluster-configuration.md)
- [Cost Optimization](../patterns/cost-optimization.md)
