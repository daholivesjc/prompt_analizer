# Cluster Types

> **Purpose**: Understand Dataproc cluster configurations: Standard, Single Node, and High Availability
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-03

## Overview

Dataproc offers three cluster types optimized for different workloads. Standard clusters are the default with one master and multiple workers. Single Node clusters run everything on one VM for lightweight tasks. High Availability clusters use three masters with ZooKeeper for fault tolerance in production environments.

## The Pattern

```bash
# Standard cluster (1 master, 2 workers)
gcloud dataproc clusters create my-cluster \
    --region=us-central1 \
    --num-workers=2 \
    --master-machine-type=n1-standard-4 \
    --worker-machine-type=n1-standard-4

# Single Node cluster (no workers)
gcloud dataproc clusters create dev-cluster \
    --region=us-central1 \
    --single-node

# High Availability cluster (3 masters)
gcloud dataproc clusters create prod-cluster \
    --region=us-central1 \
    --num-masters=3 \
    --num-workers=4 \
    --master-machine-type=n1-standard-4 \
    --worker-machine-type=n1-standard-8
```

## Quick Reference

| Type | Masters | Min Workers | Autoscaling | Use Case |
|------|---------|-------------|-------------|----------|
| Standard | 1 | 2 | Yes | General workloads |
| Single Node | 1 | 0 | No | Dev, prototyping |
| High Availability | 3 | 2 | Yes | Production |

## Cluster Components

| Component | Standard | Single Node | HA |
|-----------|----------|-------------|-----|
| HDFS NameNode | Master | Master | 3 Masters (HA) |
| YARN ResourceManager | Master | Master | 3 Masters (HA) |
| Spark History Server | Master | Master | Master |
| ZooKeeper | No | No | Yes (3 nodes) |
| HDFS DataNodes | Workers | No | Workers |

## Common Mistakes

### Wrong

```bash
# Using High Availability for a one-off dev job (wasteful)
gcloud dataproc clusters create quick-test \
    --num-masters=3 \
    --num-workers=4
```

### Correct

```bash
# Use Single Node for quick tests
gcloud dataproc clusters create quick-test \
    --single-node \
    --max-idle=30m
```

## Cluster Lifecycle

1. **Creation**: ~90 seconds for cluster to be fully operational
2. **Running**: Jobs execute on YARN; autoscaling adjusts workers
3. **Idle deletion**: Use `--max-idle` to auto-delete after inactivity
4. **Scheduled deletion**: Use `--expiration-time` or `--max-age` for TTL

```bash
# Auto-delete after 2 hours idle
gcloud dataproc clusters create ephemeral-cluster \
    --region=us-central1 \
    --num-workers=4 \
    --max-idle=2h

# Auto-delete after 8 hours regardless
gcloud dataproc clusters create batch-cluster \
    --region=us-central1 \
    --num-workers=4 \
    --max-age=8h
```

## Related

- [Autoscaling](../concepts/autoscaling.md)
- [Cluster Configuration](../patterns/cluster-configuration.md)
- [Cost Optimization](../patterns/cost-optimization.md)
