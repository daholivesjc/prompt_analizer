# Initialization Actions

> **Purpose**: Scripts that run on all cluster nodes during setup to install dependencies
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-03

## Overview

Initialization actions are executables or scripts that Dataproc runs on all cluster nodes immediately after cluster setup. They install dependencies, configure software, or stage binaries so that jobs do not need to handle setup at runtime. Scripts execute as root, run serially on each node, and also run on nodes added during autoscaling.

## The Pattern

```bash
#!/bin/bash
# init-install-deps.sh -- install Python packages on all nodes
set -euo pipefail

ROLE=$(/usr/share/google/get_metadata_value attributes/dataproc-role)

# Install on all nodes
pip install pandas==2.1.0 pyarrow==14.0.0

# Master-only setup
if [[ "${ROLE}" == 'Master' ]]; then
    pip install jupyter-lab
    echo "Master-specific setup complete"
fi
```

```bash
# Create cluster with init action
gcloud dataproc clusters create my-cluster \
    --region=us-central1 \
    --initialization-actions=gs://my-bucket/init/v1.0/init-install-deps.sh \
    --initialization-action-timeout=10m \
    --metadata=PACKAGE_VERSION=2.1.0
```

## Quick Reference

| Aspect | Detail |
|--------|--------|
| Execution user | root (no `sudo` needed) |
| Default timeout | 10 minutes |
| Execution order | Serial per node |
| Path requirements | Absolute paths only |
| Failure behavior | Non-zero exit -> cluster ERROR status |
| Log location | `/var/log/dataproc-initialization-script-N.log` |

## Node Role Detection

```bash
ROLE=$(/usr/share/google/get_metadata_value attributes/dataproc-role)
if [[ "${ROLE}" == 'Master' ]]; then
    # Master-only actions
elif [[ "${ROLE}" == 'Driver' ]]; then
    # Driver-only actions (Dataproc on GKE)
else
    # Worker actions
fi
```

## Passing Arguments via Metadata

```bash
# At cluster creation
gcloud dataproc clusters create my-cluster \
    --metadata=MY_PARAM=value1,OTHER_PARAM=value2 \
    --initialization-actions=gs://bucket/init.sh

# Inside the init script
MY_PARAM=$(/usr/share/google/get_metadata_value attributes/MY_PARAM)
```

## Common Mistakes

### Wrong

```bash
# Referencing public Google bucket directly (inconsistent with autoscaler)
gcloud dataproc clusters create my-cluster \
    --initialization-actions=gs://goog-dataproc-initialization-actions-us-central1/python/pip-install.sh
```

### Correct

```bash
# Copy to your own versioned bucket first
gsutil cp gs://goog-dataproc-initialization-actions-us-central1/python/pip-install.sh \
    gs://my-bucket/init-actions/v1.0/pip-install.sh

gcloud dataproc clusters create my-cluster \
    --initialization-actions=gs://my-bucket/init-actions/v1.0/pip-install.sh
```

## Best Practices

1. **Version scripts** in GCS folders (e.g., `gs://bucket/init/v1.0/script.sh`)
2. **Add retry logic** for network downloads
3. **Use custom images** for complex dependency setups (faster than init actions)
4. **Internal-IP clusters** need Cloud NAT or Private Google Access for dependencies
5. **Test scripts** on a throwaway cluster before applying to production

## Related

- [Cluster Types](../concepts/cluster-types.md)
- [Cluster Configuration](../patterns/cluster-configuration.md)
- [Security](../concepts/security.md)
