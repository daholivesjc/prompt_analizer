# Job Types

> **Purpose**: Supported job types on Dataproc: Spark, PySpark, Hive, Pig, Flink, Presto
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-03

## Overview

Dataproc supports multiple open-source processing frameworks as first-class job types. Each job type has a dedicated gcloud command, REST API endpoint, and client library interface. Jobs run on YARN and their output is stored in the cluster's GCS staging bucket. The most common types for data engineering are PySpark and Spark SQL.

## The Pattern

```bash
# PySpark job
gcloud dataproc jobs submit pyspark \
    gs://my-bucket/jobs/etl_pipeline.py \
    --cluster=my-cluster \
    --region=us-central1 \
    --properties=spark.sql.shuffle.partitions=200 \
    -- --date=2026-03-01 --output=gs://my-bucket/output/

# Spark (Java/Scala) job
gcloud dataproc jobs submit spark \
    --cluster=my-cluster \
    --region=us-central1 \
    --class=com.example.SparkApp \
    --jars=gs://my-bucket/jars/app.jar \
    -- 1000

# Hive query
gcloud dataproc jobs submit hive \
    --cluster=my-cluster \
    --region=us-central1 \
    --file=gs://my-bucket/queries/report.hql

# Spark SQL query
gcloud dataproc jobs submit spark-sql \
    --cluster=my-cluster \
    --region=us-central1 \
    --file=gs://my-bucket/queries/transform.sql
```

## Quick Reference

| Job Type | Language | Command | Primary Use |
|----------|----------|---------|-------------|
| PySpark | Python | `jobs submit pyspark` | ETL, ML pipelines |
| Spark | Java/Scala | `jobs submit spark` | High-performance processing |
| Spark SQL | SQL | `jobs submit spark-sql` | SQL transformations |
| Hive | HiveQL | `jobs submit hive` | Warehouse queries |
| Pig | Pig Latin | `jobs submit pig` | Data transformation |
| Hadoop | Java | `jobs submit hadoop` | MapReduce jobs |
| Flink | Java/Scala | Optional component | Stream processing |
| Presto/Trino | SQL | Optional component | Interactive queries |

## File Path Schemes

| Scheme | Description | Example |
|--------|-------------|---------|
| `gs://` | Google Cloud Storage | `gs://bucket/job.py` |
| `hdfs://` | Hadoop Distributed FS | `hdfs:///user/data/` |
| `file:///` | Local filesystem on master | `file:///usr/lib/spark/examples/` |

## Job Lifecycle

| State | Description |
|-------|-------------|
| PENDING | Job submitted, waiting for resources |
| SETUP_DONE | Job resources allocated |
| RUNNING | Job executing on cluster |
| DONE | Job completed successfully |
| ERROR | Job failed |
| CANCELLED | Job cancelled by user |

## Job Concurrency

Default max concurrent jobs per cluster:

```
max((masterMemoryMb - 3584) / masterMemoryMbPerJob, 5)
```

Where `masterMemoryMbPerJob` defaults to 1024 MB. Configurable via:

```
dataproc:dataproc.scheduler.max-concurrent-jobs
```

## Common Mistakes

### Wrong

```bash
# No explicit region (defaults to "global", may cause errors)
gcloud dataproc jobs submit pyspark gs://bucket/job.py \
    --cluster=my-cluster
```

### Correct

```bash
# Always specify region explicitly
gcloud dataproc jobs submit pyspark gs://bucket/job.py \
    --cluster=my-cluster \
    --region=us-central1
```

## Related

- [Spark Job Submission](../patterns/spark-job-submission.md)
- [Serverless](../concepts/serverless.md)
- [Cluster Types](../concepts/cluster-types.md)
