# Security

> **Purpose**: IAM roles, service accounts, VPC configuration, and Kerberos for Dataproc
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-03

## Overview

Dataproc security encompasses IAM roles for access control, dedicated service accounts for VM instances, VPC networking for isolation, and optional Kerberos for multi-tenant authentication. The key principle is least privilege: use `roles/dataproc.worker` for VM service accounts instead of the broad Editor role, and restrict network access with internal-IP-only clusters.

## The Pattern

```bash
# Create a dedicated service account for Dataproc VMs
gcloud iam service-accounts create dataproc-worker \
    --display-name="Dataproc Worker SA"

# Grant required roles
gcloud projects add-iam-policy-binding my-project \
    --member="serviceAccount:dataproc-worker@my-project.iam.gserviceaccount.com" \
    --role="roles/dataproc.worker"

gcloud projects add-iam-policy-binding my-project \
    --member="serviceAccount:dataproc-worker@my-project.iam.gserviceaccount.com" \
    --role="roles/storage.objectAdmin"

# Create cluster with dedicated SA and internal IPs
gcloud dataproc clusters create secure-cluster \
    --region=us-central1 \
    --service-account=dataproc-worker@my-project.iam.gserviceaccount.com \
    --scopes=cloud-platform \
    --subnet=dataproc-subnet \
    --no-address
```

## IAM Roles

| Role | ID | Purpose |
|------|----|---------|
| Administrator | `roles/dataproc.admin` | Full control + IAM policy management |
| Editor | `roles/dataproc.editor` | Create/manage clusters and jobs |
| Viewer | `roles/dataproc.viewer` | Read-only access to resources |
| Worker | `roles/dataproc.worker` | VM service account role (least privilege) |
| Serverless Editor | `roles/dataproc.serverlessEditor` | Submit serverless batches/sessions |
| Serverless Viewer | `roles/dataproc.serverlessViewer` | View serverless workloads |

## Permission Requirements

| Operation | Required Permissions |
|-----------|---------------------|
| Create cluster | `dataproc.clusters.create` + `iam.serviceAccounts.actAs` |
| Submit job | `dataproc.jobs.create` + `dataproc.clusters.use` |
| Delete cluster | `dataproc.clusters.delete` |
| Use autoscaling | `dataproc.autoscalingPolicies.use` |
| View job output | `storage.objects.get` on staging bucket |

## VPC Configuration

```bash
# Internal-IP-only cluster (recommended for production)
gcloud dataproc clusters create private-cluster \
    --region=us-central1 \
    --subnet=projects/my-project/regions/us-central1/subnetworks/private-subnet \
    --no-address \
    --enable-private-ip-google-access
```

**Requirements for internal-IP clusters:**
- Private Google Access enabled on the subnet
- Cloud NAT for external package downloads (if needed)
- Firewall rules allowing internal cluster communication

## Common Mistakes

### Wrong

```bash
# Using default Compute Engine service account (overly permissive)
gcloud dataproc clusters create my-cluster \
    --region=us-central1
```

### Correct

```bash
# Dedicated SA with minimal roles
gcloud dataproc clusters create my-cluster \
    --region=us-central1 \
    --service-account=dataproc-worker@my-project.iam.gserviceaccount.com \
    --scopes=cloud-platform \
    --no-address
```

## Kerberos and Multi-Tenancy

- **Kerberos**: Enable for secure multi-user authentication on clusters
- **Apache Ranger**: Fine-grained authorization for Hive, HDFS, and Spark
- **Service account isolation**: Alternative model where each tenant uses a separate SA

## Related

- [Cluster Configuration](../patterns/cluster-configuration.md)
- [Terraform Provisioning](../patterns/terraform-provisioning.md)
- [IAM Roles](../../gcp/concepts/iam.md)
