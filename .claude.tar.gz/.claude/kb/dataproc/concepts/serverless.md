# Dataproc Serverless

> **Purpose**: Run Spark workloads without provisioning or managing clusters
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-03

## Overview

Dataproc Serverless lets you submit Spark batch jobs and interactive sessions without creating or managing clusters. Infrastructure is handled automatically with usage-based billing -- you pay only while the workload executes. It supports PySpark, Spark SQL, SparkR, and Spark (Java/Scala).

## The Pattern

```bash
# Submit a PySpark batch job (serverless)
gcloud dataproc batches submit pyspark \
    gs://my-bucket/jobs/etl_job.py \
    --region=us-central1 \
    --version=2.3 \
    --subnet=projects/my-project/regions/us-central1/subnetworks/my-subnet \
    --service-account=spark-sa@my-project.iam.gserviceaccount.com \
    --properties=spark.sql.shuffle.partitions=200 \
    -- --input=gs://my-bucket/data/ --output=gs://my-bucket/output/

# Submit a Spark SQL batch
gcloud dataproc batches submit spark-sql \
    --region=us-central1 \
    --version=2.3 \
    "SELECT * FROM my_table LIMIT 10"
```

## Quick Reference

| Feature | Serverless | Cluster-based |
|---------|-----------|---------------|
| Provisioning | None | ~90 seconds |
| Billing | Execution time only | Full uptime |
| Autoscaling | Automatic | Policy-based |
| Management | Zero | Cluster lifecycle |
| Custom images | Custom containers | Init actions |
| Max runtime (TTL) | 14 days (default 4h) | Unlimited |

## Supported Batch Types

| Type | Command | Primary Use |
|------|---------|-------------|
| PySpark | `batches submit pyspark` | Python ETL jobs |
| Spark | `batches submit spark` | Java/Scala jobs |
| Spark SQL | `batches submit spark-sql` | SQL queries |
| SparkR | `batches submit spark-r` | R analytics |

## Runtime Versions

| Version | Status | Notes |
|---------|--------|-------|
| 3.0 | Latest | Newest features |
| 2.3 | Stable | Recommended for production |
| 2.2 | Supported | Widely tested |
| 1.2 | Legacy | Consider upgrading |

## Key Configuration Flags

| Flag | Purpose | Example |
|------|---------|---------|
| `--version` | Runtime version | `2.3` |
| `--subnet` | VPC subnet (enables PGA) | `projects/p/regions/r/subnetworks/s` |
| `--service-account` | Custom SA | `sa@project.iam.gserviceaccount.com` |
| `--properties` | Spark config | `spark.executor.memory=4g` |
| `--ttl` | Max workload lifetime | `4h` (min 10m, max 14d) |
| `--deps-bucket` | Dependency staging | `gs://my-deps-bucket` |

## Common Mistakes

### Wrong

```bash
# Missing subnet -- uses default network (may lack Private Google Access)
gcloud dataproc batches submit pyspark gs://bucket/job.py \
    --region=us-central1
```

### Correct

```bash
# Explicit subnet with proper service account
gcloud dataproc batches submit pyspark gs://bucket/job.py \
    --region=us-central1 \
    --version=2.3 \
    --subnet=projects/my-project/regions/us-central1/subnetworks/dataproc-subnet \
    --service-account=spark-sa@my-project.iam.gserviceaccount.com
```

## Related

- [Serverless Batch Pattern](../patterns/serverless-batch.md)
- [Job Types](../concepts/job-types.md)
- [Cost Optimization](../patterns/cost-optimization.md)
