# Google Dataproc Knowledge Base

> **Purpose**: Managed Apache Spark and Hadoop service for batch processing, ETL, and machine learning on GCP
> **MCP Validated**: 2026-03-03

## Quick Navigation

### Concepts (< 150 lines each)

| File | Purpose |
|------|---------|
| [concepts/cluster-types.md](concepts/cluster-types.md) | Standard, Single Node, and High Availability clusters |
| [concepts/serverless.md](concepts/serverless.md) | Dataproc Serverless for Spark batches without cluster management |
| [concepts/autoscaling.md](concepts/autoscaling.md) | Autoscaling policies and YARN-based scaling algorithms |
| [concepts/init-actions.md](concepts/init-actions.md) | Initialization actions for cluster bootstrapping |
| [concepts/job-types.md](concepts/job-types.md) | Supported job types: Spark, PySpark, Hive, Pig, Flink, Presto |
| [concepts/security.md](concepts/security.md) | IAM roles, service accounts, VPC, and Kerberos |

### Patterns (< 200 lines each)

| File | Purpose |
|------|---------|
| [patterns/spark-job-submission.md](patterns/spark-job-submission.md) | Submit PySpark and Spark jobs via gcloud, API, and Python |
| [patterns/cluster-configuration.md](patterns/cluster-configuration.md) | Production cluster setup with autoscaling and init actions |
| [patterns/serverless-batch.md](patterns/serverless-batch.md) | Serverless Spark batch submission without cluster management |
| [patterns/terraform-provisioning.md](patterns/terraform-provisioning.md) | Terraform modules for Dataproc cluster and policy provisioning |
| [patterns/cost-optimization.md](patterns/cost-optimization.md) | Preemptible VMs, ephemeral clusters, and billing strategies |

---

## Quick Reference

- [quick-reference.md](quick-reference.md) - Fast lookup tables

---

## Key Concepts

| Concept | Description |
|---------|-------------|
| **Managed Spark** | Fully managed Spark/Hadoop with 90-second cluster creation |
| **Serverless** | Submit Spark batches without provisioning clusters |
| **Autoscaling** | YARN-based horizontal scaling of worker VMs |
| **GCS-Native** | Cloud Storage as primary persistent data store (not HDFS) |

---

## Learning Path

| Level | Files |
|-------|-------|
| **Beginner** | concepts/cluster-types.md, concepts/job-types.md |
| **Intermediate** | patterns/spark-job-submission.md, concepts/autoscaling.md |
| **Advanced** | patterns/terraform-provisioning.md, patterns/cost-optimization.md |

---

## Agent Usage

| Agent | Primary Files | Use Case |
|-------|---------------|----------|
| spark-specialist | patterns/spark-job-submission.md | Submit and tune Spark jobs |
| infra-deployer | patterns/terraform-provisioning.md | Provision Dataproc via Terraform |
| pipeline-architect | concepts/serverless.md | Design batch processing pipelines |

---

## Project Context

This KB supports batch data processing for the Invoice Processing Pipeline:

| Use Case | Dataproc Service |
|----------|-----------------|
| Batch invoice reprocessing | Dataproc Serverless (PySpark) |
| Historical data ETL | Ephemeral clusters with autoscaling |
| BigQuery data preparation | Spark-BigQuery connector |
| Large-scale image processing | Cluster with preemptible workers |
