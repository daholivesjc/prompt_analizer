# Cluster Configuration Pattern

> **Purpose**: Production-ready Dataproc cluster setup with autoscaling, init actions, and optional components
> **MCP Validated**: 2026-03-03

## When to Use

- Setting up a production Dataproc cluster with proper networking
- Configuring autoscaling with fixed primary and elastic secondary workers
- Installing custom dependencies via initialization actions
- Enabling optional components (Jupyter, Presto, Flink)

## Implementation

```bash
# Step 1: Create autoscaling policy
gcloud dataproc autoscaling-policies import production-policy \
    --source=autoscaling-policy.yaml \
    --region=us-central1

# Step 2: Create production cluster
gcloud dataproc clusters create invoice-processing \
    --region=us-central1 \
    --zone=us-central1-a \
    --master-machine-type=n1-standard-4 \
    --master-boot-disk-size=100GB \
    --num-workers=4 \
    --worker-machine-type=n1-standard-4 \
    --worker-boot-disk-size=200GB \
    --num-secondary-workers=0 \
    --secondary-worker-type=spot \
    --image-version=2.2-debian12 \
    --optional-components=JUPYTER \
    --enable-component-gateway \
    --autoscaling-policy=production-policy \
    --service-account=dataproc-worker@my-project.iam.gserviceaccount.com \
    --scopes=cloud-platform \
    --subnet=dataproc-subnet \
    --no-address \
    --initialization-actions=gs://my-bucket/init/v1.0/install-deps.sh \
    --initialization-action-timeout=15m \
    --metadata=ENV=production \
    --properties="\
spark:spark.sql.shuffle.partitions=200,\
spark:spark.dynamicAllocation.enabled=true,\
spark:spark.dynamicAllocation.cachedExecutorIdleTimeout=30m,\
dataproc:dataproc.logging.stackdriver.job.driver.enable=true,\
dataproc:dataproc.logging.stackdriver.enable=true" \
    --max-idle=2h \
    --labels=team=data-engineering,env=production
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `--image-version` | Latest | Dataproc image (e.g., `2.2-debian12`) |
| `--optional-components` | None | JUPYTER, FLINK, PRESTO, HBASE, etc. |
| `--enable-component-gateway` | false | Web UIs via Cloud Console |
| `--max-idle` | None | Auto-delete after idle period |
| `--max-age` | None | Auto-delete after total lifetime |
| `--no-address` | false | Internal IP only (recommended) |
| `--secondary-worker-type` | `preemptible` | `preemptible`, `spot`, or `non-preemptible` |
| `--properties` | -- | Hadoop/Spark/YARN config overrides |

## Autoscaling Policy (YAML)

```yaml
# autoscaling-policy.yaml
workerConfig:
  minInstances: 4
  maxInstances: 4
  weight: 1
secondaryWorkerConfig:
  minInstances: 0
  maxInstances: 20
  weight: 1
basicAlgorithm:
  cooldownPeriod: 4m
  yarnConfig:
    scaleUpFactor: 0.05
    scaleDownFactor: 1.0
    scaleUpMinWorkerFraction: 0.0
    scaleDownMinWorkerFraction: 0.0
    gracefulDecommissionTimeout: 1h
```

## Image Versions

| Version | Spark | Hadoop | Python | Status |
|---------|-------|--------|--------|--------|
| 2.2 | 3.5.x | 3.3.x | 3.11 | Current |
| 2.1 | 3.3.x | 3.3.x | 3.10 | Supported |
| 2.0 | 3.1.x | 3.2.x | 3.8 | Supported |
| 1.5 | 2.4.x | 2.10.x | 2.7/3.6 | Legacy |

## Optional Components

| Component | Flag | Purpose |
|-----------|------|---------|
| Jupyter | `JUPYTER` | Interactive notebooks |
| Flink | `FLINK` | Stream processing |
| Presto | `PRESTO` | Interactive SQL queries |
| Trino | `TRINO` | Distributed SQL engine |
| Hive | Built-in | SQL on Hadoop |
| HBase | `HBASE` | NoSQL database |
| Docker | `DOCKER` | Container support |
| Ranger | `RANGER` | Fine-grained authorization |

## Example Usage

```bash
# Development cluster (minimal, auto-deletes)
gcloud dataproc clusters create dev-cluster \
    --region=us-central1 \
    --single-node \
    --optional-components=JUPYTER \
    --enable-component-gateway \
    --max-idle=1h \
    --max-age=8h

# High-Availability production cluster
gcloud dataproc clusters create ha-cluster \
    --region=us-central1 \
    --num-masters=3 \
    --num-workers=6 \
    --master-machine-type=n1-standard-8 \
    --worker-machine-type=n1-highmem-8 \
    --no-address \
    --autoscaling-policy=ha-policy
```

## See Also

- [Cluster Types](../concepts/cluster-types.md)
- [Autoscaling](../concepts/autoscaling.md)
- [Terraform Provisioning](../patterns/terraform-provisioning.md)
