# Cost Optimization Pattern

> **Purpose**: Reduce Dataproc costs with preemptible VMs, ephemeral clusters, and Serverless
> **MCP Validated**: 2026-03-03

## When to Use

- Running batch workloads where cost matters more than latency
- Processing jobs that can tolerate preemption/spot interruptions
- Ad-hoc or infrequent workloads that do not justify persistent clusters
- Optimizing existing Dataproc spend across environments

## Implementation

```bash
# Strategy 1: Ephemeral cluster with auto-deletion
# Create -> Run Job -> Auto-delete
gcloud dataproc clusters create batch-job-cluster \
    --region=us-central1 \
    --num-workers=4 \
    --worker-machine-type=n1-standard-4 \
    --num-secondary-workers=8 \
    --secondary-worker-type=spot \
    --max-idle=30m \
    --max-age=4h \
    --labels=cost-center=data-team

# Submit job to ephemeral cluster
gcloud dataproc jobs submit pyspark \
    gs://my-bucket/jobs/batch_etl.py \
    --cluster=batch-job-cluster \
    --region=us-central1

# Strategy 2: Dataproc Serverless (zero idle cost)
gcloud dataproc batches submit pyspark \
    gs://my-bucket/jobs/batch_etl.py \
    --region=us-central1 \
    --version=2.3 \
    --ttl=2h
```

## Configuration

| Strategy | Savings | Trade-off |
|----------|---------|-----------|
| Spot/Preemptible workers | 60-80% on VMs | Possible interruption |
| Ephemeral clusters | No idle cost | ~90s startup time |
| Serverless | No idle cost | Limited to Spark |
| Right-sizing machines | Variable | Requires tuning |
| Autoscaling secondaries | Pay for demand | Scaling lag |
| Committed use discounts | Up to 57% | 1-3 year commitment |

## Cost Breakdown

| Component | Cost Model | Optimization |
|-----------|-----------|--------------|
| Dataproc premium | $0.01/vCPU/hr | Use fewer, larger VMs |
| Compute Engine VMs | Standard rates | Spot/preemptible for workers |
| GCS storage | Per-GB/month | Lifecycle rules, cleanup |
| Network egress | Per-GB | Keep data in same region |
| Persistent disks | Per-GB/month | Use pd-standard (not pd-ssd) for workers |

## Ephemeral Cluster with Workflow Template

```bash
# Create a reusable workflow template
gcloud dataproc workflow-templates create invoice-batch \
    --region=us-central1

# Configure managed cluster (created and deleted per run)
gcloud dataproc workflow-templates set-managed-cluster invoice-batch \
    --region=us-central1 \
    --master-machine-type=n1-standard-4 \
    --worker-machine-type=n1-standard-4 \
    --num-workers=4 \
    --num-secondary-workers=8 \
    --secondary-worker-type=spot

# Add job to workflow
gcloud dataproc workflow-templates add-job pyspark \
    gs://my-bucket/jobs/etl.py \
    --workflow-template=invoice-batch \
    --region=us-central1 \
    --step-id=etl-step

# Instantiate (creates cluster, runs job, deletes cluster)
gcloud dataproc workflow-templates instantiate invoice-batch \
    --region=us-central1
```

## Example Usage

```python
"""Cost-optimized Dataproc job submission with Serverless."""
from google.cloud import dataproc_v1 as dataproc


def submit_cost_optimized_batch(
    project_id: str,
    region: str,
    script_uri: str,
    args: list[str],
) -> str:
    """Submit serverless batch -- zero idle cost."""
    client = dataproc.BatchControllerClient(
        client_options={
            "api_endpoint": f"{region}-dataproc.googleapis.com:443"
        }
    )

    batch = dataproc.Batch()
    batch.pyspark_batch.main_python_file_uri = script_uri
    batch.pyspark_batch.args = args
    batch.runtime_config.version = "2.3"

    request = dataproc.CreateBatchRequest(
        parent=f"projects/{project_id}/locations/{region}",
        batch=batch,
    )

    operation = client.create_batch(request=request)
    return operation.result().name
```

## Cost Decision Matrix

| Scenario | Recommended Approach |
|----------|---------------------|
| Daily scheduled ETL | Workflow template (ephemeral cluster) |
| Ad-hoc analysis | Dataproc Serverless |
| 24/7 streaming | Persistent cluster + committed use |
| Occasional large batch | Ephemeral cluster + spot workers |
| Development/testing | Single-node + max-idle=1h |
| Predictable daily workload | Autoscaling with spot secondary |

## See Also

- [Cluster Types](../concepts/cluster-types.md)
- [Autoscaling](../concepts/autoscaling.md)
- [Serverless Batch](../patterns/serverless-batch.md)
