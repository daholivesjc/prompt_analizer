# Serverless Batch Pattern

> **Purpose**: Submit Spark batch jobs without cluster management using Dataproc Serverless
> **MCP Validated**: 2026-03-03

## When to Use

- One-off or ad-hoc PySpark/Spark SQL jobs
- ETL pipelines that do not need a persistent cluster
- Cost-sensitive batch processing (pay only for execution time)
- Teams that want zero infrastructure management

## Implementation

```python
"""Submit a Dataproc Serverless batch job using the Python client library."""
from google.cloud import dataproc_v1 as dataproc


def submit_serverless_pyspark(
    project_id: str,
    region: str,
    script_uri: str,
    args: list[str] | None = None,
    subnet: str | None = None,
    service_account: str | None = None,
) -> str:
    """Submit a serverless PySpark batch and return the batch ID."""
    client = dataproc.BatchControllerClient(
        client_options={
            "api_endpoint": f"{region}-dataproc.googleapis.com:443"
        }
    )

    batch = dataproc.Batch()
    batch.pyspark_batch.main_python_file_uri = script_uri
    batch.pyspark_batch.args = args or []

    # Runtime configuration
    batch.runtime_config.version = "2.3"
    batch.runtime_config.properties = {
        "spark.sql.shuffle.partitions": "200",
    }

    # Environment configuration
    if subnet:
        batch.environment_config.execution_config.subnetwork_uri = subnet
    if service_account:
        batch.environment_config.execution_config.service_account = (
            service_account
        )

    request = dataproc.CreateBatchRequest(
        parent=f"projects/{project_id}/locations/{region}",
        batch=batch,
    )

    operation = client.create_batch(request=request)
    response = operation.result()
    return response.name
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `--version` | Latest | Runtime version (2.3, 2.2, 1.2) |
| `--subnet` | Default | VPC subnet (enables Private Google Access) |
| `--service-account` | Compute default | Custom service account |
| `--properties` | -- | Spark configuration properties |
| `--ttl` | 4h | Max workload lifetime (10m to 14d) |
| `--deps-bucket` | -- | GCS bucket for dependency staging |
| `--history-server-cluster` | None | PHS cluster for Spark UI |

## gcloud Examples

```bash
# Basic PySpark batch
gcloud dataproc batches submit pyspark \
    gs://my-bucket/jobs/daily_etl.py \
    --region=us-central1 \
    --version=2.3 \
    -- --date=2026-03-01

# PySpark with full configuration
gcloud dataproc batches submit pyspark \
    gs://my-bucket/jobs/invoice_reprocessor.py \
    --region=us-central1 \
    --version=2.3 \
    --subnet=projects/my-project/regions/us-central1/subnetworks/dataproc-subnet \
    --service-account=spark-sa@my-project.iam.gserviceaccount.com \
    --properties=spark.sql.shuffle.partitions=400,spark.executor.memory=8g \
    --deps-bucket=gs://my-deps-bucket \
    --ttl=2h \
    --history-server-cluster=projects/my-project/regions/us-central1/clusters/phs \
    -- --input=gs://invoices-archive/ --output=gs://invoices-processed/

# Spark SQL batch
gcloud dataproc batches submit spark-sql \
    --region=us-central1 \
    --version=2.3 \
    "SELECT invoice_id, total FROM invoices WHERE date = '2026-03-01'"

# List running batches
gcloud dataproc batches list --region=us-central1

# Describe a specific batch
gcloud dataproc batches describe BATCH_ID --region=us-central1
```

## IAM Requirements

| Principal | Role | Purpose |
|-----------|------|---------|
| User/SA submitting | `roles/dataproc.editor` | Create batches |
| User/SA submitting | `roles/iam.serviceAccountUser` | Act as runtime SA |
| Runtime SA | `roles/dataproc.worker` | Execute workload |
| Runtime SA | `roles/storage.objectAdmin` | Read/write GCS |

## Persistent History Server

```bash
# Create a single-node PHS cluster for Spark UI access
gcloud dataproc clusters create spark-history \
    --region=us-central1 \
    --single-node \
    --enable-component-gateway \
    --properties=spark:spark.history.fs.logDirectory=gs://my-bucket/phs/*/spark-job-history

# Reference PHS in batch submission
gcloud dataproc batches submit pyspark gs://bucket/job.py \
    --region=us-central1 \
    --history-server-cluster=projects/my-project/regions/us-central1/clusters/spark-history
```

## See Also

- [Serverless Concepts](../concepts/serverless.md)
- [Spark Job Submission](../patterns/spark-job-submission.md)
- [Cost Optimization](../patterns/cost-optimization.md)
