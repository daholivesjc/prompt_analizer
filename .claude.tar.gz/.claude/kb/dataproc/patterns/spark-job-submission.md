# Spark Job Submission Pattern

> **Purpose**: Submit PySpark and Spark jobs via gcloud, REST API, and Python client library
> **MCP Validated**: 2026-03-03

## When to Use

- Running batch ETL jobs on an existing Dataproc cluster
- Submitting PySpark scripts stored in GCS
- Programmatic job submission from Python applications
- Orchestrating jobs via Cloud Composer or Airflow

## Implementation

```python
"""Submit a PySpark job to Dataproc using the Python client library."""
from google.cloud import dataproc_v1 as dataproc


def submit_pyspark_job(
    project_id: str,
    region: str,
    cluster_name: str,
    gcs_script_uri: str,
    args: list[str] | None = None,
    properties: dict[str, str] | None = None,
) -> str:
    """Submit a PySpark job and return the job ID."""
    job_client = dataproc.JobControllerClient(
        client_options={
            "api_endpoint": f"{region}-dataproc.googleapis.com:443"
        }
    )

    job = {
        "placement": {"cluster_name": cluster_name},
        "pyspark_job": {
            "main_python_file_uri": gcs_script_uri,
            "args": args or [],
            "properties": properties or {},
        },
    }

    operation = job_client.submit_job_as_operation(
        request={
            "project_id": project_id,
            "region": region,
            "job": job,
        }
    )

    response = operation.result()
    return response.reference.job_id
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `main_python_file_uri` | -- | GCS path to PySpark script |
| `args` | `[]` | Arguments passed to the script |
| `properties` | `{}` | Spark configuration properties |
| `jar_file_uris` | `[]` | Additional JARs (for Spark jobs) |
| `python_file_uris` | `[]` | Additional Python files (modules) |
| `file_uris` | `[]` | Files available in working directory |

## gcloud Examples

```bash
# PySpark with arguments and properties
gcloud dataproc jobs submit pyspark \
    gs://my-bucket/jobs/invoice_etl.py \
    --cluster=my-cluster \
    --region=us-central1 \
    --properties=spark.sql.shuffle.partitions=200,spark.executor.memory=4g \
    --py-files=gs://my-bucket/libs/utils.zip \
    -- --date=2026-03-01 --output=gs://my-bucket/output/

# Spark (Java/Scala) with JARs
gcloud dataproc jobs submit spark \
    --cluster=my-cluster \
    --region=us-central1 \
    --class=com.example.InvoiceProcessor \
    --jars=gs://my-bucket/jars/processor-1.0.jar \
    --properties=spark.executor.instances=10 \
    -- --input=gs://my-bucket/invoices/

# Wait for job completion
gcloud dataproc jobs wait JOB_ID \
    --project=my-project \
    --region=us-central1
```

## REST API Submission

```bash
curl -X POST \
  "https://dataproc.googleapis.com/v1/projects/my-project/regions/us-central1/jobs:submit" \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -d '{
    "job": {
      "placement": {"clusterName": "my-cluster"},
      "pysparkJob": {
        "mainPythonFileUri": "gs://my-bucket/jobs/etl.py",
        "args": ["--date=2026-03-01"],
        "properties": {
          "spark.sql.shuffle.partitions": "200"
        }
      }
    }
  }'
```

## Common Spark Properties

| Property | Default | Recommended |
|----------|---------|-------------|
| `spark.sql.shuffle.partitions` | 200 | 2x num cores |
| `spark.executor.memory` | 1g | Based on data size |
| `spark.executor.instances` | 2 (dynamic) | Let dynamic allocation manage |
| `spark.dynamicAllocation.enabled` | true | Keep true with autoscaling |
| `spark.default.parallelism` | -- | 2-3x total cores |

## See Also

- [Job Types](../concepts/job-types.md)
- [Cluster Configuration](../patterns/cluster-configuration.md)
- [Serverless Batch](../patterns/serverless-batch.md)
