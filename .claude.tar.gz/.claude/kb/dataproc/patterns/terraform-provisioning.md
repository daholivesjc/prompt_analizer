# Terraform Provisioning Pattern

> **Purpose**: Provision Dataproc clusters, autoscaling policies, and job resources with Terraform
> **MCP Validated**: 2026-03-03

## When to Use

- Infrastructure as Code for reproducible Dataproc environments
- Managing autoscaling policies alongside cluster definitions
- Integrating Dataproc with existing Terraform-managed GCP infrastructure
- Multi-environment (dev/staging/prod) cluster provisioning via Terragrunt

## Implementation

```hcl
# dataproc.tf -- Production Dataproc cluster with autoscaling

resource "google_dataproc_autoscaling_policy" "production" {
  policy_id = "production-autoscaling"
  location  = var.region

  worker_config {
    min_instances = var.primary_workers
    max_instances = var.primary_workers  # Fixed primary
    weight        = 1
  }

  secondary_worker_config {
    min_instances = 0
    max_instances = var.max_secondary_workers
    weight        = 1
  }

  basic_algorithm {
    cooldown_period = "4m"

    yarn_config {
      scale_up_factor                 = 0.05
      scale_down_factor               = 1.0
      scale_up_min_worker_fraction    = 0.0
      scale_down_min_worker_fraction  = 0.0
      graceful_decommission_timeout   = "1h"
    }
  }
}

resource "google_dataproc_cluster" "processing" {
  name   = "${var.cluster_name}-${var.environment}"
  region = var.region

  cluster_config {
    master_config {
      num_instances = var.num_masters
      machine_type  = var.master_machine_type

      disk_config {
        boot_disk_type    = "pd-ssd"
        boot_disk_size_gb = 100
      }
    }

    worker_config {
      num_instances = var.primary_workers
      machine_type  = var.worker_machine_type

      disk_config {
        boot_disk_type    = "pd-standard"
        boot_disk_size_gb = 200
      }
    }

    preemptible_worker_config {
      num_instances  = 0
      preemptibility = "SPOT"

      disk_config {
        boot_disk_type    = "pd-standard"
        boot_disk_size_gb = 100
      }
    }

    software_config {
      image_version = var.image_version

      override_properties = {
        "spark:spark.sql.shuffle.partitions"                  = "200"
        "spark:spark.dynamicAllocation.enabled"               = "true"
        "dataproc:dataproc.logging.stackdriver.enable"        = "true"
        "dataproc:dataproc.logging.stackdriver.job.driver.enable" = "true"
      }

      optional_components = var.optional_components
    }

    gce_cluster_config {
      subnetwork       = var.subnetwork
      service_account  = var.service_account_email
      internal_ip_only = true
      zone             = var.zone

      service_account_scopes = [
        "https://www.googleapis.com/auth/cloud-platform",
      ]
    }

    initialization_action {
      script      = "gs://${var.init_bucket}/init/v1.0/install-deps.sh"
      timeout_sec = 600
    }

    autoscaling_config {
      policy_uri = google_dataproc_autoscaling_policy.production.name
    }
  }

  labels = {
    environment = var.environment
    team        = "data-engineering"
    managed_by  = "terraform"
  }

  lifecycle {
    prevent_destroy = true
  }
}
```

## Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `cluster_name` | -- | Base name for the cluster |
| `region` | `us-central1` | GCP region |
| `num_masters` | `1` | Number of masters (1 or 3 for HA) |
| `primary_workers` | `4` | Fixed primary worker count |
| `max_secondary_workers` | `20` | Max autoscaled secondary workers |
| `master_machine_type` | `n1-standard-4` | Master VM type |
| `worker_machine_type` | `n1-standard-4` | Worker VM type |
| `image_version` | `2.2-debian12` | Dataproc image version |
| `optional_components` | `["JUPYTER"]` | Optional components to install |

## Example Usage

```hcl
# Terragrunt usage (environments/prod/dataproc/terragrunt.hcl)
terraform {
  source = "../../../modules/dataproc"
}

inputs = {
  cluster_name          = "invoice-processing"
  environment           = "prod"
  num_masters           = 1
  primary_workers       = 4
  max_secondary_workers = 20
  subnetwork            = "projects/my-project/regions/us-central1/subnetworks/prod"
  zone                  = "us-central1-a"
  service_account_email = "dataproc-worker@my-project.iam.gserviceaccount.com"
  init_bucket           = "my-project-dataproc-init"
}
```

## See Also

- [Cluster Configuration](../patterns/cluster-configuration.md)
- [Autoscaling](../concepts/autoscaling.md)
- [Terraform Modules](../../terraform/concepts/modules.md)
