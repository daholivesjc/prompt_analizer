# Dataproc Quick Reference

> Fast lookup tables. For code examples, see linked files.
> **MCP Validated**: 2026-03-03

## Cluster Type Selection

| Type | Masters | Workers | Use Case |
|------|---------|---------|----------|
| Standard | 1 | 2+ | General workloads, development |
| Single Node | 1 | 0 | Lightweight jobs, prototyping |
| High Availability | 3 | 2+ | Production, fault tolerance |
| Serverless | N/A | N/A | Ad-hoc Spark batches, no management |

## Job Submission Commands

| Job Type | Command |
|----------|---------|
| PySpark | `gcloud dataproc jobs submit pyspark gs://bucket/job.py --cluster=NAME --region=REGION` |
| Spark | `gcloud dataproc jobs submit spark --class=CLASS --jars=JAR --cluster=NAME --region=REGION` |
| Hive | `gcloud dataproc jobs submit hive --file=gs://bucket/query.hql --cluster=NAME --region=REGION` |
| Serverless | `gcloud dataproc batches submit pyspark gs://bucket/job.py --region=REGION --version=2.3` |

## Machine Type Guidelines

| Workload | Machine Type | Workers | Memory |
|----------|-------------|---------|--------|
| Development | n1-standard-2 | 2 | 7.5 GB |
| General ETL | n1-standard-4 | 2-10 | 15 GB |
| Memory-intensive | n1-highmem-8 | 4-20 | 52 GB |
| CPU-intensive | n1-highcpu-16 | 4-50 | 14.4 GB |

## Pricing (per vCPU/hour)

| Component | Cost |
|-----------|------|
| Dataproc premium | $0.01/vCPU/hr |
| Compute Engine VMs | Standard rates |
| Preemptible/Spot VMs | ~60-80% discount |
| Serverless | Per-DCU-hour (no idle cost) |

## IAM Roles

| Task | Role |
|------|------|
| Full cluster management | `roles/dataproc.admin` |
| Create and manage clusters | `roles/dataproc.editor` |
| Read-only access | `roles/dataproc.viewer` |
| VM service account | `roles/dataproc.worker` |
| Serverless batch execution | `roles/dataproc.serverlessEditor` |

## Decision Matrix

| Use Case | Choose |
|----------|--------|
| One-off Spark batch | Dataproc Serverless |
| Recurring scheduled jobs | Ephemeral cluster + Cloud Composer |
| Interactive exploration | Serverless sessions or Jupyter on cluster |
| HDFS-dependent workload | Standard cluster (fixed workers) |
| Cost-sensitive batch ETL | Preemptible workers + autoscaling |
| Multi-tenant production | HA cluster + Kerberos + Ranger |

## Common Pitfalls

| Avoid | Do Instead |
|-------|------------|
| Long-running idle clusters | Ephemeral clusters or Serverless |
| HDFS as primary storage | GCS with `gs://` paths |
| Default service account | Dedicated SA with `roles/dataproc.worker` |
| Public init action buckets | Copy scripts to your own GCS bucket |
| Autoscaling primary workers | Fix primary, autoscale secondary only |
| `minInstances = maxInstances` | Use different values or cluster will not scale |

## Related Documentation

| Topic | Path |
|-------|------|
| Cluster types | `concepts/cluster-types.md` |
| Serverless batches | `concepts/serverless.md` |
| Full Index | `index.md` |
