# Azure DevOps Pipelines

> **Purpose**: Pipelines YAML no Azure DevOps para CI/CD de Terraform e jobs de dados
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-19

## Overview

Azure DevOps Pipelines permite definir pipelines CI/CD como codigo YAML. No contexto deste projeto, e usado para automatizar validacao e deploy de infraestrutura Terraform e scripts PySpark para o GCP. Os pipelines sao versionados junto ao codigo no Azure Repos.

## The Pattern

### Estrutura Basica do Pipeline YAML

```yaml
trigger:
  branches:
    include:
      - main
      - develop

pool:
  vmImage: 'ubuntu-latest'

variables:
  - group: gcp-credentials  # Variable Group com segredos

stages:
  - stage: validate
    displayName: 'Validacao'
    jobs:
      - job: lint_and_test
        steps:
          - script: terraform fmt -check -recursive
          - script: terraform validate

  - stage: deploy
    displayName: 'Deploy'
    dependsOn: validate
    condition: and(succeeded(), eq(variables['Build.SourceBranch'], 'refs/heads/main'))
    jobs:
      - deployment: apply
        environment: production
        strategy:
          runOnce:
            deploy:
              steps:
                - script: terraform apply -auto-approve tfplan
```

## Componentes Principais

### Service Connections

| Tipo | Uso | Configuracao |
|------|-----|-------------|
| GCP (Workload Identity) | Deploy no GCP | Project ID + SA key |
| Azure Repos | Checkout de codigo | Automatico |
| Docker Registry | Push de imagens | Artifact Registry URL |

### Variable Groups

```yaml
# Referencia no pipeline
variables:
  - group: gcp-dev-credentials    # SA key, project ID
  - group: terraform-backend      # Bucket, prefix do state
  - name: ENVIRONMENT
    value: dev
```

### Environments e Approvals

```yaml
# Definir environment com gate manual
- deployment: deploy_production
  environment: production  # Configurar aprovadores no portal
  strategy:
    runOnce:
      deploy:
        steps:
          - script: terraform apply tfplan
```

## Quick Reference

| Recurso | Finalidade |
|---------|-----------|
| `trigger` | Branches que disparam o pipeline |
| `pr` | Trigger em Pull Requests |
| `pool` | Agente de execucao (hosted/self-hosted) |
| `variables` | Variaveis e grupos de variaveis |
| `stages` | Fases do pipeline (sequenciais) |
| `jobs` | Trabalhos dentro de um stage |
| `steps` | Passos dentro de um job |
| `deployment` | Job com tracking de environment |
| `environment` | Ambiente com gates de aprovacao |
| `condition` | Condicao para execucao |

## Templates Reutilizaveis

```yaml
# templates/terraform-plan.yml
parameters:
  - name: working_directory
    type: string

steps:
  - task: TerraformInstaller@1
    inputs:
      terraformVersion: '1.7.x'
  - script: |
      terraform init -reconfigure
      terraform plan -out=tfplan
    workingDirectory: ${{ parameters.working_directory }}
```

## Common Mistakes

### Errado

```yaml
# Segredos hardcoded no YAML
variables:
  GCP_SA_KEY: '{"type":"service_account"...}'  # NUNCA
```

### Correto

```yaml
# Segredos em Variable Groups (marcados como secret)
variables:
  - group: gcp-credentials  # Configurado no portal como secret
```

## Related

- [CI/CD Fundamentals](ci-cd-fundamentals.md)
- [Terraform CI/CD](../patterns/terraform-ci-cd.md)
- [Gitflow Branching](../patterns/gitflow-branching.md)
