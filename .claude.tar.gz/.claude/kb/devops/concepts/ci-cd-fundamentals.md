# Fundamentos de CI/CD

> **Purpose**: Conceitos essenciais de Integracao Continua e Entrega/Deploy Continuo
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-19

## Overview

CI/CD (Continuous Integration / Continuous Delivery) e a pratica de automatizar build, testes e deploy de software. A Integracao Continua garante que mudancas de codigo sejam validadas automaticamente. A Entrega Continua estende isso ate o deploy automatizado em ambientes controlados.

## The Pattern

### Pipeline Tipico

```text
Code Commit -> Build -> Unit Tests -> Integration Tests -> Deploy Staging -> Approval Gate -> Deploy Production
```

### Componentes Fundamentais

| Componente | Descricao | Exemplo |
|-----------|-----------|---------|
| **Source** | Repositorio de codigo | Azure Repos, GitHub |
| **Build** | Compilacao/empacotamento | Docker build, zip de scripts |
| **Test** | Validacao automatizada | pytest, terraform validate |
| **Deploy** | Entrega ao ambiente | gcloud deploy, terraform apply |
| **Gate** | Aprovacao manual/automatica | PR review, quality gate |

### Principios Chave

1. **Fail Fast**: testes rapidos primeiro, pesados depois
2. **Idempotencia**: executar o pipeline N vezes produz o mesmo resultado
3. **Imutabilidade**: artefatos de build nao mudam apos criacao
4. **Rastreabilidade**: cada deploy vinculado a um commit

## Tipos de Pipeline

### CI (Integracao Continua)

```yaml
# Trigger: push em qualquer branch
trigger:
  branches:
    include: ['*']
steps:
  - script: uv sync --extra dev
  - script: uv run pytest tests/ -v
  - script: terraform validate
```

### CD (Entrega Continua)

```yaml
# Trigger: merge em main
trigger:
  branches:
    include: ['main']
stages:
  - stage: deploy_staging
    jobs:
      - deployment: staging
  - stage: deploy_production
    dependsOn: deploy_staging
    condition: succeeded()
    jobs:
      - deployment: production
        environment: production  # Gate de aprovacao
```

## Quick Reference

| Conceito | CI | CD |
|----------|----|----|
| Trigger | Push/PR | Merge em branch protegida |
| Objetivo | Validar codigo | Entregar ao ambiente |
| Frequencia | A cada commit | A cada merge aprovado |
| Aprovacao | Automatica (testes) | Manual (gates) |
| Artefato | Report de testes | Deploy realizado |

## Stages Comuns

| Stage | Atividades | Ferramentas |
|-------|-----------|-------------|
| **Lint** | Formatacao, style checks | ruff, black, tflint |
| **Test** | Unitarios, integracao | pytest, terraform validate |
| **Build** | Empacotar artefatos | docker build, zip |
| **Security** | Scan de vulnerabilidades | trivy, gitleaks |
| **Deploy** | Aplicar mudancas | terraform apply, gcloud |

## Common Mistakes

### Errado

```yaml
# Pipeline sem testes - nunca faca isso
steps:
  - script: terraform apply -auto-approve
```

### Correto

```yaml
# Pipeline com validacao antes do deploy
steps:
  - script: terraform fmt -check
  - script: terraform validate
  - script: terraform plan -out=tfplan
  # Gate de aprovacao manual
  - script: terraform apply tfplan
```

## Metricas de Saude do Pipeline

| Metrica | Bom | Ruim |
|---------|-----|------|
| Tempo de build | < 10 min | > 30 min |
| Taxa de sucesso | > 95% | < 80% |
| Tempo para deploy | < 1 hora | > 1 dia |
| Frequencia de deploy | Diario | Mensal |

## Related

- [Azure DevOps Pipelines](azure-devops-pipelines.md)
- [GCP Cloud Build](gcp-cloud-build.md)
- [Terraform CI/CD](../patterns/terraform-ci-cd.md)
- [Gitflow Branching](../patterns/gitflow-branching.md)
