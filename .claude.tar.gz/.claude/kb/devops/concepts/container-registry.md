# Container Registry e Artifact Registry

> **Purpose**: Armazenamento e distribuicao de artefatos (imagens Docker, pacotes) no GCP e Azure
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-19

## Overview

Artifact Registry (GCP) e Azure Container Registry (ACR) sao servicos gerenciados para armazenar, gerenciar e distribuir artefatos de software. No contexto deste projeto, o Artifact Registry armazena imagens Docker para Cloud Run e artefatos Python. O ACR pode ser usado em cenarios hibridos com Azure DevOps.

## The Pattern

### Artifact Registry (GCP) - Repositorio Docker

```bash
# Criar repositorio
gcloud artifacts repositories create my-repo \
  --repository-format=docker \
  --location=us-central1 \
  --description="Repositorio de imagens Docker"

# Configurar autenticacao Docker
gcloud auth configure-docker us-central1-docker.pkg.dev

# Build e push
docker build -t us-central1-docker.pkg.dev/PROJECT/my-repo/my-image:v1 .
docker push us-central1-docker.pkg.dev/PROJECT/my-repo/my-image:v1
```

### Artifact Registry - Repositorio Python

```bash
# Criar repositorio Python
gcloud artifacts repositories create python-packages \
  --repository-format=python \
  --location=us-central1

# Configurar pip para usar o repositorio
gcloud artifacts print-settings python \
  --project=PROJECT \
  --repository=python-packages \
  --location=us-central1
```

## Quick Reference

| Caracteristica | Artifact Registry (GCP) | Azure Container Registry |
|---------------|------------------------|-------------------------|
| Formatos | Docker, Maven, npm, Python, apt | Docker, Helm, OCI |
| Autenticacao | gcloud auth, SA key | az acr login, SP |
| Scan de vulnerabilidade | Container Analysis | Microsoft Defender |
| Replicacao | Multi-regional | Geo-replicacao (Premium) |
| Limpeza automatica | Cleanup policies | Purge tasks |

## Terraform - Artifact Registry

```hcl
resource "google_artifact_registry_repository" "docker_repo" {
  location      = "us-central1"
  repository_id = "docker-images"
  format        = "DOCKER"
  description   = "Repositorio de imagens Docker para Cloud Run"

  cleanup_policies {
    id     = "delete-old-images"
    action = "DELETE"
    condition {
      older_than = "2592000s"  # 30 dias
      tag_state  = "UNTAGGED"
    }
  }
}

# IAM - permitir pull pelo Cloud Run
resource "google_artifact_registry_repository_iam_member" "reader" {
  location   = google_artifact_registry_repository.docker_repo.location
  repository = google_artifact_registry_repository.docker_repo.name
  role       = "roles/artifactregistry.reader"
  member     = "serviceAccount:${var.cloud_run_sa_email}"
}
```

## Naming Convention

```text
# Formato completo da imagem
REGION-docker.pkg.dev/PROJECT_ID/REPOSITORY/IMAGE:TAG

# Exemplo
us-central1-docker.pkg.dev/fdm-dados-dev/docker-images/data-processor:v1.2.3
us-central1-docker.pkg.dev/fdm-dados-dev/docker-images/data-processor:latest
```

## Politicas de Limpeza

| Estrategia | Configuracao | Uso |
|-----------|-------------|-----|
| Manter N versoes | `keep_count: 5` | Imagens com tag |
| Deletar antigas | `older_than: 30d` | Imagens sem tag |
| Manter por tag | `tag_prefixes: ["prod", "v"]` | Releases |

## Common Mistakes

### Errado

```bash
# Usar gcr.io (legado, sera descontinuado)
docker push gcr.io/PROJECT/image:tag
```

### Correto

```bash
# Usar Artifact Registry (pkg.dev)
docker push us-central1-docker.pkg.dev/PROJECT/repo/image:tag
```

### Errado

```bash
# Push sem cleanup policy - acumula imagens indefinidamente
```

### Correto

```bash
# Configurar cleanup policy para imagens sem tag
gcloud artifacts repositories set-cleanup-policies my-repo \
  --location=us-central1 \
  --policy=cleanup-policy.json
```

## Related

- [GCP Cloud Build](gcp-cloud-build.md)
- [Monitoring e Observability](monitoring-observability.md)
- [Terraform CI/CD](../patterns/terraform-ci-cd.md)
