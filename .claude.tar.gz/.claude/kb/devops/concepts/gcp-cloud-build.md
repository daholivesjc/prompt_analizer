# GCP Cloud Build

> **Purpose**: Servico de CI/CD nativo do GCP para build, teste e deploy de artefatos
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-19

## Overview

Cloud Build e o servico gerenciado de CI/CD do Google Cloud. Executa builds como uma serie de steps em containers Docker. Cada step roda em seu proprio container, compartilhando um volume `/workspace`. Util para builds de imagens Docker, validacao de Terraform e deploy de artefatos no GCS.

## The Pattern

### Estrutura do cloudbuild.yaml

```yaml
steps:
  # Step 1: Instalar dependencias
  - name: 'python:3.11-slim'
    entrypoint: 'pip'
    args: ['install', '-r', 'requirements.txt']

  # Step 2: Executar testes
  - name: 'python:3.11-slim'
    entrypoint: 'pytest'
    args: ['tests/', '-v']

  # Step 3: Copiar scripts para GCS
  - name: 'gcr.io/cloud-builders/gsutil'
    args: ['cp', 'jobs/raw/*.py', 'gs://${_BUCKET_NAME}/scripts/']

substitutions:
  _BUCKET_NAME: 'fdm-dados-dev'

options:
  logging: CLOUD_LOGGING_ONLY
```

### Triggers

| Tipo de Trigger | Uso | Fonte |
|----------------|-----|-------|
| Push to branch | CI em cada commit | Cloud Source Repos, GitHub |
| Pull Request | Validacao em PRs | GitHub, GitLab |
| Manual | Deploy sob demanda | Console ou gcloud |
| Pub/Sub | Trigger por evento | Topico Pub/Sub |

## Quick Reference

| Recurso | Descricao |
|---------|-----------|
| `steps` | Lista de containers a executar |
| `name` | Imagem Docker do step |
| `entrypoint` | Comando a executar |
| `args` | Argumentos do comando |
| `substitutions` | Variaveis parametrizaveis (`_PREFIXO`) |
| `options` | Configuracoes globais do build |
| `timeout` | Tempo maximo de execucao |
| `availableSecrets` | Segredos do Secret Manager |

## Usando Secret Manager no Build

```yaml
steps:
  - name: 'gcr.io/cloud-builders/gcloud'
    entrypoint: 'bash'
    args:
      - '-c'
      - |
        echo "$$DB_PASSWORD" > /workspace/db_pass.txt
    secretEnv: ['DB_PASSWORD']

availableSecrets:
  secretManager:
    - versionName: projects/$PROJECT_ID/secrets/db-password/versions/latest
      env: 'DB_PASSWORD'
```

## Build de Imagens Docker

```yaml
steps:
  - name: 'gcr.io/cloud-builders/docker'
    args:
      - 'build'
      - '-t'
      - '${_REGION}-docker.pkg.dev/${PROJECT_ID}/${_REPO}/${_IMAGE}:${SHORT_SHA}'
      - '.'

  - name: 'gcr.io/cloud-builders/docker'
    args:
      - 'push'
      - '${_REGION}-docker.pkg.dev/${PROJECT_ID}/${_REPO}/${_IMAGE}:${SHORT_SHA}'

images:
  - '${_REGION}-docker.pkg.dev/${PROJECT_ID}/${_REPO}/${_IMAGE}:${SHORT_SHA}'
```

## Variaveis Built-in

| Variavel | Valor |
|----------|-------|
| `$PROJECT_ID` | ID do projeto GCP |
| `$BUILD_ID` | ID unico do build |
| `$COMMIT_SHA` | SHA completo do commit |
| `$SHORT_SHA` | SHA curto (7 chars) |
| `$BRANCH_NAME` | Nome da branch |
| `$TAG_NAME` | Tag do git (se houver) |
| `$REPO_NAME` | Nome do repositorio |

## Common Mistakes

### Errado

```yaml
# Sem timeout - pode rodar indefinidamente
steps:
  - name: 'ubuntu'
    script: './long-running-script.sh'
```

### Correto

```yaml
# Timeout explicito
timeout: '1200s'  # 20 minutos
steps:
  - name: 'ubuntu'
    script: './long-running-script.sh'
    timeout: '600s'  # 10 minutos por step
```

## Limites

| Limite | Valor |
|--------|-------|
| Timeout maximo | 24 horas (padrao: 10 min) |
| Steps por build | 100 |
| Tamanho do source | 100 MB (comprimido) |
| Builds simultaneos | Depende da cota |

## Related

- [CI/CD Fundamentals](ci-cd-fundamentals.md)
- [Container Registry](container-registry.md)
- [Terraform CI/CD](../patterns/terraform-ci-cd.md)
- [Dataproc Job Deployment](../patterns/dataproc-job-deployment.md)
