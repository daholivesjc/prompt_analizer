# Google Cloud Workflows

> **Purpose**: Orquestracao serverless de servicos GCP para pipelines de dados
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-19

## Overview

Cloud Workflows e um servico serverless de orquestracao que coordena chamadas a APIs e servicos GCP. No contexto deste projeto, orquestra a submissao de jobs PySpark no Dataproc Serverless, aguardando a conclusao de cada batch e tratando erros. Cada workflow e definido em YAML e pode ser trigado por Cloud Scheduler, Pub/Sub ou manualmente.

## The Pattern

### Workflow para Dataproc Serverless Batch

```yaml
main:
  params: [args]
  steps:
    - init:
        assign:
          - project_id: ${sys.get_env("GOOGLE_CLOUD_PROJECT_ID")}
          - region: "us-central1"
          - batch_id: ${"batch-" + string(int(sys.now()))}

    - submit_batch:
        call: http.post
        args:
          url: ${"https://dataproc.googleapis.com/v1/projects/" + project_id + "/locations/" + region + "/batches"}
          auth:
            type: OAuth2
          query:
            batchId: ${batch_id}
          body:
            pysparkBatch:
              mainPythonFileUri: ${args.script_uri}
              args: ${args.job_args}
            runtimeConfig:
              version: "2.2"
            environmentConfig:
              executionConfig:
                subnetworkUri: ${args.subnet}
                serviceAccount: ${args.service_account}
        result: batch_response

    - poll_batch:
        call: http.get
        args:
          url: ${"https://dataproc.googleapis.com/v1/projects/" + project_id + "/locations/" + region + "/batches/" + batch_id}
          auth:
            type: OAuth2
        result: status_response

    - check_status:
        switch:
          - condition: ${status_response.body.state == "SUCCEEDED"}
            next: success
          - condition: ${status_response.body.state == "FAILED"}
            raise: ${"Batch falhou: " + status_response.body.stateMessage}
          - condition: ${status_response.body.state == "CANCELLED"}
            raise: "Batch cancelado"
        next: wait_and_poll

    - wait_and_poll:
        call: sys.sleep
        args:
          seconds: 30
        next: poll_batch

    - success:
        return:
          batch_id: ${batch_id}
          state: "SUCCEEDED"
```

## Quick Reference

| Recurso | Descricao |
|---------|-----------|
| `params` | Parametros de entrada do workflow |
| `assign` | Atribuicao de variaveis |
| `call` | Chamada HTTP ou a connector |
| `switch` | Condicional (if/else) |
| `for` | Loop sobre lista |
| `try/except` | Tratamento de erros |
| `sys.sleep` | Espera (polling) |
| `sys.now()` | Timestamp atual |

## Triggers

| Trigger | Uso |
|---------|-----|
| Cloud Scheduler | Execucao agendada (cron) |
| Eventarc | Evento de GCS ou Pub/Sub |
| gcloud CLI | Execucao manual |
| API REST | Chamada programatica |

```bash
# Executar workflow manualmente
gcloud workflows run ingest-postgres-workflow \
  --data='{"script_uri":"gs://bucket/scripts/ingest.py","job_args":["--source","tabla"]}'

# Agendar com Cloud Scheduler
gcloud scheduler jobs create http ingest-daily \
  --schedule="0 6 * * *" \
  --uri="https://workflowexecutions.googleapis.com/v1/projects/PROJECT/locations/REGION/workflows/WORKFLOW/executions" \
  --oauth-service-account-email=SA@PROJECT.iam.gserviceaccount.com
```

## Limites

| Limite | Valor |
|--------|-------|
| Timeout de execucao | 1 ano |
| Tamanho do YAML | 1 MB |
| Variaveis por execucao | 20.000 |
| Profundidade de aninhamento | 25 |
| Execucoes simultaneas | 10.000 |

## Common Mistakes

### Errado

```yaml
# Polling sem limite - pode rodar para sempre
- poll:
    call: http.get
    args:
      url: ${status_url}
    result: r
    next: poll  # Loop infinito!
```

### Correto

```yaml
# Polling com contador e timeout
- check_timeout:
    switch:
      - condition: ${poll_count > 120}  # 60 min com sleep de 30s
        raise: "Timeout aguardando batch"
    next: poll
```

## Related

- [CI/CD Fundamentals](ci-cd-fundamentals.md)
- [Dataproc Job Deployment](../patterns/dataproc-job-deployment.md)
- [Multi-Environment Promotion](../patterns/multi-environment-promotion.md)
