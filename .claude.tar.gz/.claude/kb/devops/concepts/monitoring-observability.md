# Monitoring e Observability

> **Purpose**: Monitoramento, logging e alertas em GCP e Azure para pipelines de dados
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-19

## Overview

Observabilidade combina metricas, logs e traces para entender o estado dos sistemas. No GCP, Cloud Monitoring e Cloud Logging sao os servicos centrais. No Azure, Azure Monitor agrega metricas e logs. Para pipelines de dados no Dataproc Serverless, os logs dos jobs PySpark sao automaticamente enviados ao Cloud Logging.

## The Pattern

### Pilares da Observabilidade

| Pilar | Servico GCP | Servico Azure | Uso |
|-------|------------|---------------|-----|
| Metricas | Cloud Monitoring | Azure Monitor Metrics | Uso de recursos, latencia |
| Logs | Cloud Logging | Azure Monitor Logs | Eventos, erros, audit |
| Traces | Cloud Trace | Application Insights | Rastreamento distribuido |
| Alertas | Alerting Policies | Azure Alerts | Notificacao proativa |

### Cloud Logging - Consulta de Logs

```text
# Logs de um batch Dataproc Serverless
resource.type="cloud_dataproc_batch"
resource.labels.batch_id="batch-123456"
severity>=WARNING

# Logs de Cloud Workflows
resource.type="workflows.googleapis.com/Workflow"
resource.labels.workflow_id="ingest-postgres-workflow"

# Logs de erro em qualquer recurso do projeto
severity=ERROR
timestamp>="2026-03-19T00:00:00Z"
```

### Cloud Monitoring - Metricas Customizadas

```python
from google.cloud import monitoring_v3
import time

def report_job_metric(project_id: str, metric_name: str, value: float):
    """Envia metrica customizada ao Cloud Monitoring."""
    client = monitoring_v3.MetricServiceClient()
    project_name = f"projects/{project_id}"

    series = monitoring_v3.TimeSeries()
    series.metric.type = f"custom.googleapis.com/dataproc/{metric_name}"
    series.resource.type = "global"

    point = monitoring_v3.Point()
    point.value.double_value = value
    now = time.time()
    point.interval.end_time.seconds = int(now)
    series.points = [point]

    client.create_time_series(name=project_name, time_series=[series])
```

## Alertas - Configuracao

### GCP Alerting Policy (Terraform)

```hcl
resource "google_monitoring_alert_policy" "batch_failure" {
  display_name = "Dataproc Batch Failure"
  combiner     = "OR"

  conditions {
    display_name = "Batch com estado FAILED"
    condition_matched_log {
      filter = <<-EOT
        resource.type="cloud_dataproc_batch"
        jsonPayload.state="FAILED"
      EOT
    }
  }

  notification_channels = [google_monitoring_notification_channel.email.name]

  alert_strategy {
    auto_close = "604800s"  # 7 dias
  }
}

resource "google_monitoring_notification_channel" "email" {
  display_name = "Email Equipe Dados"
  type         = "email"
  labels = {
    email_address = "dados@empresa.com"
  }
}
```

## Quick Reference

| Acao | Comando gcloud |
|------|----------------|
| Ver logs recentes | `gcloud logging read "severity>=ERROR" --limit=10` |
| Listar metricas | `gcloud monitoring metrics list --filter="metric.type:custom"` |
| Listar alertas | `gcloud monitoring policies list` |
| Ver batches com falha | `gcloud dataproc batches list --filter="state=FAILED"` |

## Dashboards Recomendados

| Dashboard | Metricas |
|-----------|---------|
| Pipeline Overview | Jobs executados, taxa de sucesso, duracao media |
| Dataproc Batches | Batches ativos, falhas, tempo de execucao |
| Cloud Workflows | Execucoes, erros, latencia |
| Storage | Objetos criados/dia, tamanho do bucket |

## Common Mistakes

### Errado

```python
# Logs apenas em stdout sem estrutura
print(f"Processados {count} registros")
```

### Correto

```python
import logging
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Log estruturado compativel com Cloud Logging
logger.info(json.dumps({
    "message": "Registros processados",
    "count": count,
    "job_name": "ingest-postgres",
    "severity": "INFO"
}))
```

## Related

- [CI/CD Fundamentals](ci-cd-fundamentals.md)
- [GCP Cloud Workflows](gcp-cloud-workflows.md)
- [Dataproc Job Deployment](../patterns/dataproc-job-deployment.md)
