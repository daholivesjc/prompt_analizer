# DevOps (GCP + Azure) Knowledge Base

> **Purpose**: Praticas de DevOps para pipelines CI/CD, deploy de infraestrutura e jobs de dados em GCP e Azure DevOps
> **MCP Validated**: 2026-03-19

## Quick Navigation

### Concepts (< 150 lines each)

| File | Purpose |
|------|---------|
| [concepts/ci-cd-fundamentals.md](concepts/ci-cd-fundamentals.md) | Fundamentos de CI/CD, pipelines, stages e gates |
| [concepts/azure-devops-pipelines.md](concepts/azure-devops-pipelines.md) | Azure DevOps Pipelines YAML, service connections, variable groups |
| [concepts/gcp-cloud-build.md](concepts/gcp-cloud-build.md) | Cloud Build no GCP, triggers e cloudbuild.yaml |
| [concepts/gcp-cloud-workflows.md](concepts/gcp-cloud-workflows.md) | Google Cloud Workflows para orquestracao serverless |
| [concepts/container-registry.md](concepts/container-registry.md) | Artifact Registry (GCP) e Azure Container Registry |
| [concepts/monitoring-observability.md](concepts/monitoring-observability.md) | Cloud Monitoring, Logging, Azure Monitor e alertas |

### Patterns (< 200 lines each)

| File | Purpose |
|------|---------|
| [patterns/terraform-ci-cd.md](patterns/terraform-ci-cd.md) | Pipeline CI/CD para Terraform (plan em PR, apply em merge) |
| [patterns/dataproc-job-deployment.md](patterns/dataproc-job-deployment.md) | Deploy de jobs PySpark no Dataproc Serverless via pipeline |
| [patterns/multi-environment-promotion.md](patterns/multi-environment-promotion.md) | Promocao dev, staging, prod com gates de aprovacao |
| [patterns/gitflow-branching.md](patterns/gitflow-branching.md) | Estrategia Gitflow com feature/*, fix/*, develop, main |
| [patterns/secret-rotation.md](patterns/secret-rotation.md) | Rotacao de segredos no Secret Manager e Azure Key Vault |

---

## Quick Reference

- [quick-reference.md](quick-reference.md) - Tabelas de consulta rapida

---

## Contexto do Projeto

| Componente | Tecnologia |
|------------|-----------|
| Processamento de dados | Dataproc Serverless (PySpark) |
| Orquestracao | Google Cloud Workflows |
| Armazenamento | GCS (landing, raw, trusted) |
| Banco relacional | Cloud SQL PostgreSQL |
| Segredos | Secret Manager (GCP) |
| CI/CD | Azure DevOps Pipelines |
| IaC | Terraform (modulos remotos Azure DevOps) |
| Branching | Gitflow (feature/*, fix/* -> develop -> main) |

---

## Learning Path

| Level | Files |
|-------|-------|
| **Iniciante** | concepts/ci-cd-fundamentals.md, patterns/gitflow-branching.md |
| **Intermediario** | concepts/azure-devops-pipelines.md, patterns/terraform-ci-cd.md |
| **Avancado** | patterns/dataproc-job-deployment.md, patterns/multi-environment-promotion.md |
