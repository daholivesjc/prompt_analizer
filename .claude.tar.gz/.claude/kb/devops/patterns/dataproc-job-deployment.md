# Deploy de Jobs PySpark no Dataproc Serverless

> **Purpose**: Automatizar deploy de scripts PySpark e workflows para Dataproc Serverless via pipeline CI/CD
> **MCP Validated**: 2026-03-19

## When to Use

- Deploy automatizado de jobs de ingestao (raw layer) ou transformacao (trusted layer)
- Upload de scripts PySpark para GCS como parte do pipeline
- Atualizacao de Cloud Workflows que orquestram os batches
- Necessidade de testar antes de fazer deploy

## Implementation

### Pipeline de Deploy - Azure DevOps

```yaml
trigger:
  branches:
    include:
      - develop
      - main
  paths:
    include:
      - 'jobs/**'
      - 'workflows/**'

stages:
  # Stage 1: Testes unitarios
  - stage: test
    displayName: 'Testes'
    jobs:
      - job: unit_tests
        pool:
          vmImage: 'ubuntu-latest'
        steps:
          - script: |
              pip install uv
              uv sync --extra dev
            displayName: 'Instalar dependencias'

          - script: uv run pytest tests/ -v --cov=jobs --cov-report=term-missing
            displayName: 'Executar testes com cobertura'

  # Stage 2: Upload de scripts para GCS
  - stage: deploy_scripts
    displayName: 'Deploy Scripts'
    dependsOn: test
    condition: and(succeeded(), ne(variables['Build.Reason'], 'PullRequest'))
    jobs:
      - job: upload
        steps:
          - script: |
              gcloud auth activate-service-account \
                --key-file=<(echo $GOOGLE_CREDENTIALS)

              # Upload dos scripts de ingestao
              gsutil -m cp jobs/raw/*.py \
                gs://$(BUCKET_NAME)/scripts/raw/

              # Upload dos scripts trusted
              gsutil -m cp jobs/trusted/*.py \
                gs://$(BUCKET_NAME)/scripts/trusted/
            displayName: 'Upload scripts para GCS'

  # Stage 3: Deploy de Workflows
  - stage: deploy_workflows
    displayName: 'Deploy Workflows'
    dependsOn: deploy_scripts
    jobs:
      - job: update_workflows
        steps:
          - script: |
              for workflow_file in workflows/*.yaml; do
                workflow_name=$(basename "$workflow_file" .yaml)
                gcloud workflows deploy "$workflow_name" \
                  --source="$workflow_file" \
                  --location=us-central1 \
                  --service-account=$(WORKFLOW_SA)
              done
            displayName: 'Atualizar Cloud Workflows'
```

### Estrutura de Artefatos no GCS

```text
gs://fdm-dados-dev/
  scripts/
    raw/
      ingest_txt_to_parquet.py
      ingest_json_to_parquet.py
      ingest_xml_to_parquet.py
      ingest_excel_to_parquet.py
      ingest_avro_to_parquet.py
      ingest_postgres_to_parquet.py
      ingest_mongodb_to_parquet.py
    trusted/
      full_parquet_to_delta.py
      incremental_parquet_to_delta.py
      merge_parquet_to_delta.py
      dynamic_partition_overwrite_parquet_to_delta.py
      delta_table_maintenance.py
  sources/
    txt/sample.txt
    json/sample.json
```

## Configuration

### Terraform - Upload via Modulo

```hcl
# Usando modulo local de jobs
module "jobs" {
  source = "../../modules/jobs"

  project_id  = var.project_id
  bucket_name = var.bucket_name

  script_files = {
    "scripts/raw/ingest_postgres_to_parquet.py" = "../../jobs/raw/ingest_postgres_to_parquet.py"
  }

  source_files = {}  # Sem arquivos fonte para Postgres
}

module "workflow" {
  source = "../../modules/workflows"

  project_id       = var.project_id
  region           = var.region
  workflow_name    = "ingest-postgres-workflow"
  workflow_source  = "../../workflows/ingest_postgres_to_parquet.yaml"
  service_account  = var.workflow_sa_email
}
```

### Submissao Manual de Batch (teste)

```bash
gcloud dataproc batches submit pyspark \
  gs://fdm-dados-dev/scripts/raw/ingest_postgres_to_parquet.py \
  --region=us-central1 \
  --subnet=projects/PROJECT/regions/us-central1/subnetworks/SUBNET \
  --service-account=SA@PROJECT.iam.gserviceaccount.com \
  --version=2.2 \
  --jars=gs://fdm-dados-dev/jars/postgresql-42.7.3.jar \
  -- \
  --source=schema.tabela \
  --destination=gs://fdm-dados-dev/raw/postgres/tabela/
```

## Checklist de Deploy

```text
[ ] Testes unitarios passaram (pytest)
[ ] Script testado localmente ou no ambiente dev
[ ] Workflow YAML validado (sintaxe correta)
[ ] JARs necessarios disponiveis no GCS
[ ] Service Account com permissoes corretas
[ ] Subnet configurada para o Dataproc Serverless
```

## Example Usage

```bash
# Verificar estado do ultimo batch
gcloud dataproc batches list \
  --region=us-central1 \
  --filter="state=FAILED" \
  --limit=5

# Ver logs de um batch
gcloud dataproc batches describe BATCH_ID \
  --region=us-central1

# Cancelar batch em execucao
gcloud dataproc batches cancel BATCH_ID \
  --region=us-central1
```

## See Also

- [CI/CD Fundamentals](../concepts/ci-cd-fundamentals.md)
- [GCP Cloud Workflows](../concepts/gcp-cloud-workflows.md)
- [Terraform CI/CD](terraform-ci-cd.md)
- [Multi-Environment Promotion](multi-environment-promotion.md)
