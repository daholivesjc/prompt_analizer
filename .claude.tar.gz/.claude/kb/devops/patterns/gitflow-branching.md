# Gitflow Branching Strategy

> **Purpose**: Estrategia de branching Gitflow para desenvolvimento colaborativo com feature/*, fix/*, develop e main
> **MCP Validated**: 2026-03-19

## When to Use

- Equipe com multiplos desenvolvedores trabalhando em paralelo
- Necessidade de releases controladas
- Ambientes de dev, staging e producao separados
- Projeto com ciclos de entrega definidos

## Implementation

### Estrutura de Branches

```text
main (producao)
  │
  ├── develop (integracao)
  │     │
  │     ├── feature/jobs-spark-ingestion-postgres
  │     ├── feature/add-mongodb-connector
  │     ├── fix/postgres-connection-timeout
  │     └── feature/terraform-job-isolation
  │
  └── hotfix/critical-security-patch (emergencia)
```

### Regras de Branch

| Branch | Criada de | Merge para | Metodo |
|--------|----------|-----------|--------|
| `feature/*` | develop | develop | Squash merge via PR |
| `fix/*` | develop | develop | Squash merge via PR |
| `hotfix/*` | main | main + develop | Merge commit |
| `develop` | main | main | Merge commit |
| `main` | - | - | Protegida |

### Convencao de Nomes

```text
# Features
feature/jobs-spark-ingestion-postgres
feature/terraform-job-isolation
feature/add-delta-maintenance

# Fixes
fix/postgres-connection-timeout
fix/xml-namespace-parsing

# Hotfixes (emergencia em producao)
hotfix/security-patch-sa-key
```

## Configuration

### Protecao de Branches (Azure DevOps)

```json
{
  "main": {
    "require_pull_request": true,
    "minimum_reviewers": 2,
    "allow_squash_merge": true,
    "allow_rebase_merge": false,
    "require_linked_work_items": true,
    "build_validation": "azure-pipelines.yml"
  },
  "develop": {
    "require_pull_request": true,
    "minimum_reviewers": 1,
    "allow_squash_merge": true,
    "default_merge_type": "squash"
  }
}
```

### Fluxo Completo

```bash
# 1. Criar feature branch
git checkout develop
git pull origin develop
git checkout -b feature/add-new-ingestion-job

# 2. Desenvolver (commits frequentes)
git add jobs/raw/ingest_new_to_parquet.py
git commit -m "Implementacao do job de ingestao"

git add tests/test_ingest_new_to_parquet.py
git commit -m "Testes unitarios do job de ingestao"

# 3. Push e criar PR
git push -u origin feature/add-new-ingestion-job
# Criar PR no Azure DevOps: feature/* -> develop

# 4. Apos aprovacao: squash merge no Azure DevOps
# Resultado: 1 commit limpo em develop

# 5. Promocao para producao
git checkout main
git pull origin main
git merge develop  # Merge commit (nao squash)
git push origin main
```

## Fluxo Visual

```text
Tempo →

main:     ●─────────────────────────────●──────── (producao)
           \                           /
develop:    ●───●───●───●───●───●───●─── (integracao)
               / \     / \     /
feature/a:    ●───●   /   \   /
feature/b:        ●──●     \ /
fix/c:                  ●───●
```

## Politicas de PR

| Regra | develop | main |
|-------|---------|------|
| Revisores minimos | 1 | 2 |
| Build obrigatorio | Sim | Sim |
| Testes obrigatorios | Sim | Sim |
| Work items vinculados | Nao | Sim |
| Tipo de merge | Squash | Merge commit |
| Deletar branch apos merge | Sim | N/A |

## Mensagem de Commit (Squash)

```text
# Formato padrao (pt-BR conforme CLAUDE.md)
Implementacao job Postgres, ja com testes unitarios, testado na gcp

# Para fixes
Correcao na adicao do metadado nome do arquivo que esta sendo processado

# Para terraform
Preparacao de infra para testar job Postgres
```

## Common Mistakes

### Errado

```bash
# Commit direto em main
git checkout main
git commit -m "quick fix"  # NUNCA

# Merge sem PR
git checkout develop
git merge feature/xyz  # Sem revisao!

# Rebase de branch publica
git rebase develop  # Em branch ja com push - PERIGOSO
```

### Correto

```bash
# Sempre via PR com revisao
git push origin feature/xyz
# Criar PR no Azure DevOps
# Aguardar revisao e aprovacao
# Squash merge via portal
```

## Example Usage

```bash
# Ver branches ativas
git branch -a | grep feature/

# Limpar branches ja mergeadas
git branch --merged develop | grep -v develop | xargs git branch -d

# Verificar historico de merges em develop
git log --oneline --graph develop --first-parent -20
```

## See Also

- [CI/CD Fundamentals](../concepts/ci-cd-fundamentals.md)
- [Multi-Environment Promotion](multi-environment-promotion.md)
- [Terraform CI/CD](terraform-ci-cd.md)
