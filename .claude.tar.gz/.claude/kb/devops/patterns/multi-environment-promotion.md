# Promocao Multi-Ambiente

> **Purpose**: Estrategia de promocao de mudancas entre ambientes dev, staging e producao com gates de aprovacao
> **MCP Validated**: 2026-03-19

## When to Use

- Projeto com multiplos ambientes (dev, staging, prod)
- Necessidade de validacao progressiva antes de chegar a producao
- Diferentes niveis de aprovacao por ambiente
- Infraestrutura e dados precisam ser promovidos de forma controlada

## Implementation

### Fluxo de Promocao

```text
feature/* ──PR──> develop ──merge──> staging ──aprovacao──> main (prod)
    │                │                  │                      │
    ▼                ▼                  ▼                      ▼
  Testes          Deploy Dev       Deploy Staging         Deploy Prod
  (CI)           (automatico)     (auto + validacao)    (manual gate)
```

### Pipeline Multi-Ambiente - Azure DevOps

```yaml
trigger:
  branches:
    include:
      - develop
      - main

variables:
  - name: TF_VERSION
    value: '1.7.5'

stages:
  # DEV: deploy automatico em push para develop
  - stage: dev
    displayName: 'Deploy DEV'
    condition: eq(variables['Build.SourceBranch'], 'refs/heads/develop')
    variables:
      - group: gcp-dev
    jobs:
      - deployment: deploy_dev
        environment: dev
        strategy:
          runOnce:
            deploy:
              steps:
                - template: templates/terraform-apply.yml
                  parameters:
                    environment: dev
                    state_prefix: fdm-dados/dev

  # STAGING: deploy automatico em push para main, com testes
  - stage: staging
    displayName: 'Deploy STAGING'
    condition: eq(variables['Build.SourceBranch'], 'refs/heads/main')
    variables:
      - group: gcp-staging
    jobs:
      - deployment: deploy_staging
        environment: staging  # Pode ter aprovacao automatica
        strategy:
          runOnce:
            deploy:
              steps:
                - template: templates/terraform-apply.yml
                  parameters:
                    environment: staging
                    state_prefix: fdm-dados/staging

      - job: smoke_tests
        dependsOn: deploy_staging
        steps:
          - script: |
              # Verificar que o workflow foi criado
              gcloud workflows describe ingest-postgres-workflow \
                --location=us-central1
              # Executar job de teste
              gcloud workflows run ingest-postgres-workflow \
                --data='{"test_mode": true}'
            displayName: 'Smoke Tests'

  # PROD: deploy com aprovacao manual
  - stage: production
    displayName: 'Deploy PRODUCAO'
    dependsOn: staging
    condition: and(succeeded(), eq(variables['Build.SourceBranch'], 'refs/heads/main'))
    variables:
      - group: gcp-prod
    jobs:
      - deployment: deploy_prod
        environment: production  # Gate: 2 aprovadores obrigatorios
        strategy:
          runOnce:
            deploy:
              steps:
                - template: templates/terraform-apply.yml
                  parameters:
                    environment: prod
                    state_prefix: fdm-dados/prod
```

## Configuration

### Ambientes e Gates

| Ambiente | Branch Source | Gate | Aprovadores |
|----------|-------------|------|------------|
| dev | develop | Nenhum | Automatico |
| staging | main | Smoke tests | Tech Lead (1) |
| production | main | Manual + testes | 2 aprovadores |

### Isolamento de State Terraform

```text
terraformxerticatest (GCS bucket)
├── fdm-dados/dev/         # State do ambiente dev
├── fdm-dados/staging/     # State do ambiente staging
├── fdm-dados/prod/        # State do ambiente prod
├── fdm-dados/jobs/        # States isolados por job
│   ├── ingest-txt/
│   ├── ingest-json/
│   └── ingest-postgres/
```

### Variable Groups por Ambiente

```yaml
# gcp-dev
GCP_PROJECT_ID: fdm-dados-dev
GCS_BUCKET: fdm-dados-dev
GOOGLE_CREDENTIALS: (secret)

# gcp-staging
GCP_PROJECT_ID: fdm-dados-staging
GCS_BUCKET: fdm-dados-staging
GOOGLE_CREDENTIALS: (secret)

# gcp-prod
GCP_PROJECT_ID: fdm-dados-prod
GCS_BUCKET: fdm-dados-prod
GOOGLE_CREDENTIALS: (secret)
```

## Estrategias de Rollback

| Estrategia | Quando Usar | Como |
|-----------|-------------|------|
| Terraform revert | Infra com problema | `git revert` + re-apply |
| Workflow rollback | Job com erro | Deploy versao anterior do YAML |
| Script rollback | Bug no PySpark | Upload versao anterior do script |

## Checklist por Ambiente

### Dev

```text
[ ] Testes unitarios passaram
[ ] Terraform plan sem erros
[ ] Deploy automatico executado
```

### Staging

```text
[ ] Todos checks de dev
[ ] Smoke tests passaram
[ ] Job executou com dados de teste
[ ] Aprovacao do Tech Lead
```

### Production

```text
[ ] Todos checks de staging
[ ] Plano de rollback documentado
[ ] 2 aprovacoes obtidas
[ ] Janela de deploy respeitada
[ ] Monitoramento ativo pos-deploy
```

## See Also

- [Terraform CI/CD](terraform-ci-cd.md)
- [Gitflow Branching](gitflow-branching.md)
- [Azure DevOps Pipelines](../concepts/azure-devops-pipelines.md)
