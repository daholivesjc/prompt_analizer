# Rotacao de Segredos

> **Purpose**: Estrategias de rotacao de segredos no GCP Secret Manager e Azure Key Vault para pipelines de dados
> **MCP Validated**: 2026-03-19

## When to Use

- Credenciais de banco de dados (Cloud SQL PostgreSQL, MongoDB)
- Service Account keys do GCP
- API keys de servicos externos
- Conformidade com politicas de seguranca (rotacao periodica)
- Apos incidente de seguranca (rotacao emergencial)

## Implementation

### GCP Secret Manager - Rotacao Manual

```bash
# 1. Criar nova versao do segredo
echo -n "nova-senha-segura-2026" | \
  gcloud secrets versions add db-password --data-file=-

# 2. Verificar que a nova versao esta ativa
gcloud secrets versions list db-password

# 3. Testar a nova credencial
# (executar job de teste ou verificar conectividade)

# 4. Desabilitar versao antiga (nao deletar imediatamente)
gcloud secrets versions disable db-password --version=1

# 5. Apos periodo de graca (7 dias), destruir versao antiga
gcloud secrets versions destroy db-password --version=1
```

### GCP Secret Manager - Rotacao Automatizada

```python
from google.cloud import secretmanager
import google.cloud.workflows_v1 as workflows

def rotate_secret(project_id: str, secret_id: str, new_value: str):
    """Rotaciona um segredo criando nova versao e desabilitando a anterior."""
    client = secretmanager.SecretManagerServiceClient()
    parent = f"projects/{project_id}/secrets/{secret_id}"

    # Obter versao atual (latest)
    current = client.access_secret_version(
        request={"name": f"{parent}/versions/latest"}
    )
    current_version = current.name.split("/")[-1]

    # Adicionar nova versao
    client.add_secret_version(
        request={
            "parent": parent,
            "payload": {"data": new_value.encode("UTF-8")},
        }
    )

    # Desabilitar versao anterior
    client.disable_secret_version(
        request={"name": f"{parent}/versions/{current_version}"}
    )

    return f"Segredo {secret_id} rotacionado. Versao {current_version} desabilitada."
```

### Azure Key Vault - Rotacao

```bash
# Criar/atualizar segredo no Key Vault
az keyvault secret set \
  --vault-name "meu-keyvault" \
  --name "db-password" \
  --value "nova-senha-segura" \
  --expires "2026-09-19T00:00:00Z"  # Expiracao explicita

# Listar versoes
az keyvault secret list-versions \
  --vault-name "meu-keyvault" \
  --name "db-password"

# Configurar politica de expiracao
az keyvault secret set-attributes \
  --vault-name "meu-keyvault" \
  --name "db-password" \
  --expires "2026-09-19T00:00:00Z"
```

## Configuration

### Terraform - Secret com Rotacao Programada

```hcl
resource "google_secret_manager_secret" "db_password" {
  secret_id = "cloud-sql-password"

  replication {
    auto {}
  }

  # Topico para notificacao de rotacao
  topics {
    name = google_pubsub_topic.secret_rotation.id
  }

  # Rotacao automatica (requer Cloud Function)
  rotation {
    rotation_period    = "7776000s"  # 90 dias
    next_rotation_time = "2026-06-19T00:00:00Z"
  }
}

# Topico de notificacao
resource "google_pubsub_topic" "secret_rotation" {
  name = "secret-rotation-notifications"
}

# IAM para o servico que acessa o segredo
resource "google_secret_manager_secret_iam_member" "accessor" {
  secret_id = google_secret_manager_secret.db_password.id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${var.dataproc_sa_email}"
}
```

### Calendario de Rotacao

| Tipo de Segredo | Frequencia | Metodo |
|----------------|-----------|--------|
| SA keys | 90 dias | Automatico (recomendado: Workload Identity) |
| DB passwords | 90 dias | Semi-automatico |
| API keys | 180 dias | Manual com notificacao |
| Certificados TLS | 365 dias | Automatico (Certificate Manager) |

## Fluxo de Rotacao Seguro

```text
1. Criar nova versao ──> 2. Testar nova versao ──> 3. Validar conexoes
         │                        │                        │
         ▼                        ▼                        ▼
   Secret Manager            Job de teste           Monitoramento
   (nova versao ativa)      (batch Dataproc)       (Cloud Logging)
                                                         │
                                                         ▼
4. Desabilitar versao antiga ──> 5. Periodo de graca ──> 6. Destruir
         (imediato)                  (7 dias)           (permanente)
```

## Common Mistakes

### Errado

```python
# Hardcoded credentials no codigo
DB_PASSWORD = "minha-senha-123"  # NUNCA

# Acessar segredo por versao fixa
get_secret("project", "db-pass", version="1")  # Impede rotacao
```

### Correto

```python
# Sempre usar "latest" para suportar rotacao
password = get_secret("project", "db-pass", version="latest")

# Ou usar variaveis de ambiente injetadas pelo servico
password = os.environ.get("DB_PASSWORD")
```

### Errado

```bash
# Deletar versao antiga sem periodo de graca
gcloud secrets versions destroy db-password --version=1  # E se algo falhar?
```

### Correto

```bash
# Desabilitar primeiro, destruir depois
gcloud secrets versions disable db-password --version=1
# Aguardar 7 dias, monitorar erros
gcloud secrets versions destroy db-password --version=1
```

## See Also

- [Monitoring e Observability](../concepts/monitoring-observability.md)
- [GCP Cloud Build](../concepts/gcp-cloud-build.md)
- [Multi-Environment Promotion](multi-environment-promotion.md)
