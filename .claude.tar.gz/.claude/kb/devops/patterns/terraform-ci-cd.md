# Terraform CI/CD Pipeline

> **Purpose**: Automatizar validacao e deploy de infraestrutura Terraform com plan em PR e apply em merge
> **MCP Validated**: 2026-03-19

## When to Use

- Infraestrutura gerenciada por Terraform com multiplos colaboradores
- Necessidade de revisao de mudancas antes do apply
- Deploy automatizado apos aprovacao do PR
- Multiplos ambientes (dev, staging, prod) com states isolados

## Implementation

### Pipeline Azure DevOps - Terraform

```yaml
# azure-pipelines.yml
trigger:
  branches:
    include:
      - main
      - develop

pr:
  branches:
    include:
      - main
      - develop

pool:
  vmImage: 'ubuntu-latest'

variables:
  - group: gcp-credentials
  - group: terraform-backend
  - name: TF_VERSION
    value: '1.7.5'

stages:
  # Stage 1: Validacao (roda em PR e push)
  - stage: validate
    displayName: 'Terraform Validate'
    jobs:
      - job: validate
        steps:
          - task: TerraformInstaller@1
            inputs:
              terraformVersion: $(TF_VERSION)

          - script: terraform fmt -check -recursive
            displayName: 'Verificar formatacao'
            workingDirectory: terraform/

          - script: |
              terraform init -reconfigure \
                -backend-config="bucket=$(TF_STATE_BUCKET)" \
                -backend-config="prefix=$(TF_STATE_PREFIX)"
              terraform validate
            displayName: 'Init e Validate'
            workingDirectory: terraform/envs/dev/

  # Stage 2: Plan (roda em PR e push)
  - stage: plan
    displayName: 'Terraform Plan'
    dependsOn: validate
    jobs:
      - job: plan
        steps:
          - task: TerraformInstaller@1
            inputs:
              terraformVersion: $(TF_VERSION)

          - script: |
              terraform init -reconfigure \
                -backend-config="bucket=$(TF_STATE_BUCKET)" \
                -backend-config="prefix=$(TF_STATE_PREFIX)"
              terraform plan -out=tfplan -input=false
            displayName: 'Terraform Plan'
            workingDirectory: terraform/envs/dev/

          - publish: terraform/envs/dev/tfplan
            artifact: tfplan
            displayName: 'Publicar Plan'

  # Stage 3: Apply (somente em merge para main/develop)
  - stage: apply
    displayName: 'Terraform Apply'
    dependsOn: plan
    condition: |
      and(
        succeeded(),
        or(
          eq(variables['Build.SourceBranch'], 'refs/heads/main'),
          eq(variables['Build.SourceBranch'], 'refs/heads/develop')
        ),
        ne(variables['Build.Reason'], 'PullRequest')
      )
    jobs:
      - deployment: apply
        environment: $(ENVIRONMENT)  # Gate de aprovacao
        strategy:
          runOnce:
            deploy:
              steps:
                - download: current
                  artifact: tfplan

                - task: TerraformInstaller@1
                  inputs:
                    terraformVersion: $(TF_VERSION)

                - script: |
                    terraform init -reconfigure \
                      -backend-config="bucket=$(TF_STATE_BUCKET)" \
                      -backend-config="prefix=$(TF_STATE_PREFIX)"
                    terraform apply -input=false $(Pipeline.Workspace)/tfplan/tfplan
                  displayName: 'Terraform Apply'
                  workingDirectory: terraform/envs/dev/
```

## Configuration

### Variable Groups Necessarios

| Variable Group | Variaveis | Tipo |
|---------------|-----------|------|
| `gcp-credentials` | `GOOGLE_CREDENTIALS` (SA key JSON) | Secret |
| `terraform-backend` | `TF_STATE_BUCKET`, `TF_STATE_PREFIX` | Plain |

### Environments com Aprovacao

| Environment | Branch | Aprovadores |
|-------------|--------|------------|
| dev | develop | Automatico |
| staging | main (PR) | Tech Lead |
| production | main (merge) | 2 aprovadores |

## Jobs Isolados - Pipeline por Job

```yaml
# Para a estrutura de states isolados por job
# terraform/envs/jobs/<job_name>/

parameters:
  - name: job_name
    type: string
    values:
      - ingest-txt
      - ingest-json
      - ingest-postgres

stages:
  - stage: plan_job
    jobs:
      - job: plan
        steps:
          - script: |
              cd terraform/envs/jobs/${{ parameters.job_name }}
              terraform init -reconfigure \
                -backend-config="bucket=terraformxerticatest" \
                -backend-config="prefix=fdm-dados/jobs/${{ parameters.job_name }}"
              terraform plan -out=tfplan
```

## Checklist Pre-Apply

```text
[ ] terraform fmt -check passou
[ ] terraform validate passou
[ ] terraform plan revisado no PR
[ ] Nenhum recurso sendo destruido inesperadamente
[ ] PR aprovado por pelo menos 1 revisor
[ ] Testes de integracao passaram (se aplicavel)
```

## Example Usage

```bash
# Fluxo manual equivalente
cd terraform/envs/jobs/ingest-postgres

terraform init -reconfigure \
  -backend-config="bucket=terraformxerticatest" \
  -backend-config="prefix=fdm-dados/jobs/ingest-postgres"

terraform plan -out=tfplan
# Revisar output do plan
terraform apply tfplan
```

## See Also

- [CI/CD Fundamentals](../concepts/ci-cd-fundamentals.md)
- [Azure DevOps Pipelines](../concepts/azure-devops-pipelines.md)
- [Multi-Environment Promotion](multi-environment-promotion.md)
- [Gitflow Branching](gitflow-branching.md)
