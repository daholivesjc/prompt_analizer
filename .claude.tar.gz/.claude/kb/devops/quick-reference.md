# DevOps Quick Reference

> Tabelas de consulta rapida. Para exemplos de codigo, veja os arquivos linkados.
> **MCP Validated**: 2026-03-19

## Selecao de Ferramenta CI/CD

| Caso de Uso | Ferramenta | Motivo |
|-------------|-----------|--------|
| Pipeline CI/CD completo | Azure DevOps Pipelines | Integrado com repos Azure DevOps |
| Build de containers GCP | Cloud Build | Nativo GCP, triggers automaticos |
| Orquestracao de jobs | Cloud Workflows | Serverless, integracao nativa GCP |
| Deploy Terraform | Azure DevOps + backend GCS | Plan em PR, apply em merge |

## Comandos Essenciais

| Acao | Comando |
|------|---------|
| Submeter batch Dataproc | `gcloud dataproc batches submit pyspark` |
| Executar workflow | `gcloud workflows run WORKFLOW_NAME` |
| Ver logs Cloud Build | `gcloud builds log BUILD_ID` |
| Acessar segredo | `gcloud secrets versions access latest --secret=NAME` |
| Listar pipelines Azure | `az pipelines list --org URL --project NAME` |

## Estrategia de Branches (Gitflow)

| Branch | Proposito | Merge Para |
|--------|----------|-----------|
| `feature/*` | Novas funcionalidades | `develop` (squash) |
| `fix/*` | Correcoes de bugs | `develop` (squash) |
| `develop` | Integracao | `main` (merge) |
| `main` | Producao | - |

## Ambientes e Promocao

| Ambiente | Trigger | Aprovacao |
|----------|---------|-----------|
| dev | Push em `develop` | Automatico |
| staging | PR para `main` | Manual (tech lead) |
| prod | Merge em `main` | Manual (2 aprovadores) |

## Roles IAM para CI/CD (GCP)

| Tarefa | Role |
|--------|------|
| Deploy Dataproc batch | `roles/dataproc.editor` |
| Upload para GCS | `roles/storage.objectCreator` |
| Executar Workflow | `roles/workflows.invoker` |
| Acessar segredos | `roles/secretmanager.secretAccessor` |
| Gerenciar Terraform state | `roles/storage.objectAdmin` (bucket state) |

## Erros Comuns

| Evite | Faca Isso |
|-------|-----------|
| Segredos em variavel de ambiente | Use Secret Manager / Key Vault |
| Apply sem plan review | Plan em PR, apply apos aprovacao |
| Branch direto em main | Use Gitflow com PRs |
| Deploy manual em producao | Pipeline automatizado com gates |
| Ignorar falhas de testes | Gate obrigatorio antes do deploy |
| Mesmo service account para tudo | SA dedicado por job/servico |

## Documentacao Relacionada

| Topico | Path |
|--------|------|
| Concepts CI/CD | `concepts/ci-cd-fundamentals.md` |
| Azure Pipelines | `concepts/azure-devops-pipelines.md` |
| Terraform CI/CD | `patterns/terraform-ci-cd.md` |
| Indice completo | `index.md` |
