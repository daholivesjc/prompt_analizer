# Encoding de Variaveis Categoricas

> **Purpose**: Tecnicas para converter variaveis categoricas em representacoes numericas para ML
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-23

## Overview

Variaveis categoricas (cor, tipo, regiao) precisam ser convertidas em numeros para
algoritmos de ML. A escolha do encoding impacta diretamente a performance do modelo:
um encoding inadequado pode introduzir vies ordinal falso ou causar explosao dimensional.

## One-Hot Encoding

Cada categoria vira um vetor binario onde apenas a posicao correspondente e 1.

**Representacao:** Para categorias {C1, C2, ..., Cn}, vetor vi[j] = 1 se j=i, 0 caso contrario.

Exemplo: Cor {Vermelho, Verde, Azul} -> [1,0,0], [0,1,0], [0,0,1]

**Aplicacoes:** classificacao, NLP, sistemas de recomendacao, reconhecimento de imagem, series temporais.

**Vantagens:**
- Compatibilidade com a maioria dos algoritmos de ML
- Preserva independencia entre categorias (sem ordem falsa)
- Alta interpretabilidade
- Previne vies ordinal

**Desafios:**
- Maldicao da dimensionalidade: muitas categorias = explosao de features esparsas
- Alto consumo de memoria com matrizes esparsas
- Categorias nao vistas no teste causam erro
- Features correlacionadas entre si
- Perda de informacao ordinal quando existe hierarquia real

**Dummy Variable Trap (Multicolinearidade):** com n categorias, usar n-1 colunas
(`drop_first=True`) para evitar multicolinearidade em modelos lineares.

**Categorias nao vistas:** agrupar categorias raras em "Outros" antes do encoding
ou usar `handle_unknown='ignore'` no sklearn.

## Label Encoding

Mapeia cada categoria para um inteiro unico. Ex: Vermelho=0, Verde=1, Azul=2.

**Risco critico:** o modelo interpreta como ordenacao (Verde=1 > Vermelho=0) quando
nao existe hierarquia real entre as categorias.

**Quando usar:** apenas para variaveis ORDINAIS com ordem natural.
Ex: Escolaridade: Ensino Medio(0) < Graduacao(1) < Mestrado(2) < Doutorado(3).

**Vantagens:** compacto, nao aumenta dimensionalidade.
**Desvantagens com nominais:** cria hierarquia falsa que prejudica modelos lineares e
baseados em distancia (SVM, kNN).

## Two-Hot Encoding (Samuels, Imperial College)

Metodo nascente que cria espaco vetorial 2D com "head card" (total de valores) e
"tails cards" (vetores indexados). Preserva relacoes hierarquicas melhor que one-hot
e permite data augmentation via shuffling de cards. Desafios: maior uso de memoria
e requer modificacao de algoritmos (feed-forward, attention).

## Feature Hashing (Hashing Trick)

Reduz dimensionalidade mapeando categorias para numero fixo de colunas via funcao hash.
Troca representacao perfeita por eficiencia de memoria. Ideal para alta cardinalidade
onde one-hot e inviavel.

## Comparacao Label Encoding vs One-Hot

| Aspecto | Label Encoding | One-Hot Encoding |
|---------|---------------|-----------------|
| Dimensionalidade | Mantem original | Aumenta (1 coluna por categoria) |
| Ordenacao | Implica ordem | Preserva independencia |
| Algoritmos | Arvores toleram | Necessario para lineares/distancia |
| Cardinalidade alta | Melhor | Explosao dimensional |
| Dados nominais | Risco de vies | Correto |
| Dados ordinais | Correto | Perde hierarquia |

## Quando Usar Cada Encoding

| Encoding | Cenario Ideal |
|----------|---------------|
| One-Hot | Variaveis nominais (regiao, cor, tipo), categorias gerenciaveis, modelos lineares |
| Label Encoding | Variaveis ordinais, alta cardinalidade com modelos baseados em arvore |
| Feature Hashing | Alta cardinalidade quando one-hot e inviavel |
| Embeddings | NLP e categorias com muitas dimensoes semanticas |

## Related

- [Feature Engineering](../concepts/feature-engineering.md)
- [Reducao de Dimensionalidade](../concepts/dimensionality-reduction.md)
- [Pipeline de Encoding](../patterns/categorical-encoding-pipeline.md)
