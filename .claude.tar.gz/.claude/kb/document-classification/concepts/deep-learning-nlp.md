# Deep Learning para Classificacao de Documentos

> **Purpose**: CNNs, RNNs, LSTM, Transformers e BERT aplicados a classificacao textual
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-23

## Overview

Deep learning superou metodos classicos em classificacao de documentos ao capturar
relacoes contextuais e semanticas. BERT e Transformers alcancam estado-da-arte, mas
exigem recursos computacionais significativos. O review de Pardhi & Margaj (2025)
confirma que RNNs tratam dados sequenciais melhor e Transformers eliminam recorrencia,
melhorando paralelizacao, porem ambos demandam datasets grandes e GPUs.

## CNNs para Texto (TextCNN)

CNNs capturam padroes locais (n-grams) usando filtros convolucionais sobre embeddings.
Eficazes para capturar features relevantes sem dependencia sequencial.

```python
import torch.nn as nn

class TextCNN(nn.Module):
    def __init__(self, vocab_size, embed_dim, num_classes, filter_sizes=[3,4,5]):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.convs = nn.ModuleList([
            nn.Conv1d(embed_dim, 100, fs) for fs in filter_sizes
        ])
        self.fc = nn.Linear(100 * len(filter_sizes), num_classes)
        self.dropout = nn.Dropout(0.5)

    def forward(self, x):
        x = self.embedding(x).permute(0, 2, 1)
        x = [torch.relu(conv(x)).max(dim=2)[0] for conv in self.convs]
        x = self.dropout(torch.cat(x, dim=1))
        return self.fc(x)
```

## RNNs e LSTM

RNNs processam sequencias mantendo estado oculto. LSTM resolve o problema de
vanishing gradients com gates (forget, input, output). BiLSTM processa em ambas
direcoes, capturando contexto completo. LSTMbase alcanca 87.6% e LSTMreg 89.1%
de accuracy no Reuters-21578 (ISI 2025).

```python
class BiLSTMClassifier(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim, num_classes):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, bidirectional=True, batch_first=True)
        self.fc = nn.Linear(hidden_dim * 2, num_classes)

    def forward(self, x):
        x = self.embedding(x)
        _, (h, _) = self.lstm(x)
        h = torch.cat([h[-2], h[-1]], dim=1)
        return self.fc(h)
```

## Transformers e Mecanismo de Atencao

Atencao multi-cabeca (Vaswani et al., 2017) permite processar toda a sequencia
em paralelo, capturando dependencias de longo alcance. Elimina a recorrencia,
melhorando eficiencia de treinamento.

## BERT para Classificacao

BERT (Devlin et al., 2018) usa pre-treinamento bidirecional em grandes corpora.
Fine-tuning para classificacao adiciona camada linear sobre o token [CLS].
DocBERT (Adhikari et al., 2019) demonstrou eficacia especifica para documentos.
No paper Neurocomputing (Pham et al., 2025), BERT com deep metric learning
alcancou 98.76% de accuracy em datasets administrativos.

```python
from transformers import BertForSequenceClassification, Trainer

model = BertForSequenceClassification.from_pretrained(
    "bert-base-uncased", num_labels=num_classes
)
# Fine-tuning com Trainer API (ver pattern bert-fine-tuning.md)
```

## DistilBERT (Eficiente)

40% menor que BERT, 60% mais rapido, mantem 97% da performance. Ideal para
producao com recursos limitados.

## Quick Reference

| Modelo | Parametros | Contexto | Treinamento | Uso |
|--------|-----------|----------|-------------|-----|
| TextCNN | ~1M | Local | Rapido | Features locais |
| BiLSTM | ~5M | Sequencial | Medio | Sequencias longas |
| BERT-base | 110M | Bidirecional | Lento | Estado-da-arte |
| DistilBERT | 66M | Bidirecional | Medio | Producao eficiente |

## Common Mistakes

### Errado

```python
# Treinar BERT do zero para classificacao
model = BertModel(config)  # Desperdicando pre-treinamento
```

### Correto

```python
# Usar fine-tuning sobre modelo pre-treinado
model = BertForSequenceClassification.from_pretrained("bert-base-uncased")
```

## Related

- [Representacao Textual](../concepts/text-representation.md)
- [Fine-tuning BERT](../patterns/bert-fine-tuning.md)
- [Classificacao Multi-pagina](../concepts/multi-page-classification.md)
