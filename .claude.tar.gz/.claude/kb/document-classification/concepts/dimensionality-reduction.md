# Reducao de Dimensionalidade

> **Purpose**: PCA, SVD, t-SNE e autoencoders para reduzir espaco de features textuais
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-23

## Overview

Classificacao de texto enfrenta o problema da alta dimensionalidade: cada palavra unica e
uma dimensao. Com vocabularios de 50K-100K termos, tecnicas de reducao sao essenciais.
Thaoroijam (2014) destaca Latent Semantic Indexing (LSI/SVD) como abordagem fundamental
que comprime vetores de documentos em espacos de menor dimensao usando padroes de
co-ocorrencia. Tecnicas modernas incluem PCA, t-SNE para visualizacao e autoencoders.

## LSI / Truncated SVD

Latent Semantic Indexing usa decomposicao em valores singulares (SVD) para reduzir
a matriz termo-documento. Captura relacoes semanticas latentes entre termos que
co-ocorrem nos mesmos contextos. Funcao mapeando vetores originais em novos vetores
e obtida aplicando SVD a matriz TF-IDF (Thaoroijam, 2014).

```python
from sklearn.decomposition import TruncatedSVD
from sklearn.pipeline import Pipeline

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(max_features=20000)),
    ('svd', TruncatedSVD(n_components=300, random_state=42)),
    ('clf', LinearSVC())
])
pipeline.fit(X_train, y_train)
```

## PCA (Principal Component Analysis)

Encontra direcoes de maxima variancia nos dados. Requer matriz densa, entao
primeiro converte TF-IDF esparsa. Eficaz com PCA autoencoders para reducao
nao-linear.

```python
from sklearn.decomposition import PCA

# Para dados densos (Word2Vec, BERT embeddings)
pca = PCA(n_components=100, random_state=42)
X_reduced = pca.fit_transform(X_dense)

# Variancia explicada
print(f"Variancia explicada: {sum(pca.explained_variance_ratio_):.2%}")
```

## t-SNE (Visualizacao)

Tecnica nao-linear para visualizacao em 2D/3D. Preserva estrutura local dos dados.
Nao deve ser usado como pre-processamento para classificacao, apenas para analise
exploratoria e visualizacao de clusters.

```python
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

tsne = TSNE(n_components=2, perplexity=30, random_state=42)
X_2d = tsne.fit_transform(X_reduced)

plt.scatter(X_2d[:, 0], X_2d[:, 1], c=labels, cmap='tab10', alpha=0.6)
plt.title("Documentos projetados em 2D via t-SNE")
plt.show()
```

## UMAP (Alternativa Moderna)

Mais rapido que t-SNE, preserva estrutura global e local. Pode ser usado tanto
para visualizacao quanto como pre-processamento.

```python
from umap import UMAP

reducer = UMAP(n_components=50, n_neighbors=15, min_dist=0.1)
X_umap = reducer.fit_transform(X_tfidf.toarray())
```

## Autoencoders

Redes neurais que aprendem representacoes comprimidas. O encoder comprime a entrada
em um espaco latente de menor dimensao. Util para reducao nao-linear complexa.

```python
import torch.nn as nn

class TextAutoencoder(nn.Module):
    def __init__(self, input_dim, hidden_dim=256, latent_dim=64):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim), nn.ReLU()
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, input_dim)
        )

    def forward(self, x):
        latent = self.encoder(x)
        return self.decoder(latent), latent
```

## Quick Reference

| Tecnica | Tipo | Dimensoes Tipicas | Uso |
|---------|------|-------------------|-----|
| SVD/LSI | Linear | 100-500 | Pre-processamento |
| PCA | Linear | 50-300 | Pre-processamento |
| t-SNE | Nao-linear | 2-3 | Visualizacao apenas |
| UMAP | Nao-linear | 2-100 | Ambos |
| Autoencoder | Nao-linear | 32-256 | Features complexas |

## Related

- [Representacao Textual](../concepts/text-representation.md)
- [Feature Engineering](../concepts/feature-engineering.md)
- [Metodos Nao-Supervisionados](../concepts/unsupervised-methods.md)
