# Metricas de Avaliacao para Classificacao

> **Purpose**: Accuracy, Precision, Recall, F1, ROC-AUC, confusion matrix e protocolos
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-23

## Overview

Avaliar a qualidade de um classificador requer metricas apropriadas ao problema.
O paper ISI 2025 (Ahmed et al.) utiliza accuracy, precision, recall e F1-score como
metricas padrao. Thaoroijam (2014) distingue micro-averaging (peso igual por documento)
e macro-averaging (peso igual por classe), sendo macro mais informativo para classes
desbalanceadas. O paper Neurocomputing (Pham et al., 2025) adiciona Coverage (COV)
e weighted Precision para cenarios com novelty detection.

## Confusion Matrix

Base para todas as metricas. Para categoria j:
- **TP (True Positive)**: classificado corretamente como positivo
- **FP (False Positive)**: classificado incorretamente como positivo
- **FN (False Negative)**: classificado incorretamente como negativo
- **TN (True Negative)**: classificado corretamente como negativo

```python
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

cm = confusion_matrix(y_true, y_pred)
disp = ConfusionMatrixDisplay(cm, display_labels=class_names)
disp.plot(cmap='Blues')
```

## Metricas Fundamentais

```python
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score
)

# Accuracy: (TP + TN) / (TP + TN + FP + FN)
acc = accuracy_score(y_true, y_pred)

# Precision: TP / (TP + FP) -- custo de falso positivo
prec = precision_score(y_true, y_pred, average='macro')

# Recall: TP / (TP + FN) -- custo de falso negativo
rec = recall_score(y_true, y_pred, average='macro')

# F1-Score: 2 * (P * R) / (P + R) -- media harmonica
f1 = f1_score(y_true, y_pred, average='macro')
```

## Micro vs Macro Averaging

Micro-averaging da peso igual a cada documento; macro-averaging da peso igual
a cada classe. Macro e mais informativo para classes desbalanceadas.

```python
# Micro: TP_total / (TP_total + FP_total) -- favorece classes grandes
p_micro = precision_score(y_true, y_pred, average='micro')

# Macro: media de P por classe -- trata todas as classes igualmente
p_macro = precision_score(y_true, y_pred, average='macro')

# Weighted: media ponderada pelo suporte de cada classe
p_weighted = precision_score(y_true, y_pred, average='weighted')
```

## ROC-AUC

Area sob a curva ROC. Util para comparar modelos independente do threshold.

```python
from sklearn.metrics import roc_auc_score

# Para multiclasse: One-vs-Rest
auc = roc_auc_score(y_true, y_scores, multi_class='ovr', average='macro')
```

## Coverage Rate (COV)

Percentual de documentos efetivamente classificados (nao rejeitados).
Essencial em sistemas com novelty/ambiguity rejection (Pham et al., 2025).

```python
# COV = TP_correct / (TP + FP + TN + FN)
cov = tp_correct / total_documents
```

## Classification Report Completo

```python
from sklearn.metrics import classification_report

report = classification_report(y_true, y_pred, target_names=class_names)
print(report)
# Inclui: precision, recall, f1-score, support por classe
```

## Quick Reference

| Metrica | Usar Quando | Nao Usar Quando |
|---------|-------------|-----------------|
| Accuracy | Classes balanceadas | Desbalanceamento > 1:5 |
| Precision | FP tem custo alto | FN importa mais |
| Recall | FN tem custo alto | FP importa mais |
| F1-macro | Classes desbalanceadas | Todas iguais |
| ROC-AUC | Comparar modelos | Classes muito raras |

## Related

- [Classificacao Supervisionada](../concepts/supervised-classification.md)
- [Pipeline de Avaliacao](../patterns/model-evaluation-pipeline.md)
- [Metodos de Ensemble](../concepts/tree-ensemble-methods.md)
