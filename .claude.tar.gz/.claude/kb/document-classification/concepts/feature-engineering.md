# Feature Engineering para Classificacao de Texto

> **Purpose**: Tokenizacao, stemming, lemmatizacao, n-grams, stopwords e selecao de features
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-23

## Overview

Feature engineering e a etapa de pre-processamento que transforma texto bruto em features
numericas para ML. O pipeline tipico inclui: limpeza de dados, tokenizacao, normalizacao,
remocao de stopwords e vetorizacao (Ahmed et al., ISI 2025). A qualidade do pre-processamento
impacta diretamente a classificacao -- stemming melhora resultados de clustering mais que
remocao de stopwords isolada (Khalilian & Hassanzadeh).

## Tokenizacao

Divisao do texto em unidades menores (tokens): palavras, subpalavras ou caracteres.

```python
import nltk
from nltk.tokenize import word_tokenize

nltk.download('punkt')
tokens = word_tokenize("Classificacao de documentos com ML.")
# ['Classificacao', 'de', 'documentos', 'com', 'ML', '.']
```

## Remocao de Stopwords

Palavras sem valor discriminativo (artigos, preposicoes). A remocao melhora clustering
mas o efeito nao e significativo isoladamente. Stemming + stopwords juntos nao supera
stemming sozinho (Khalilian & Hassanzadeh).

```python
from nltk.corpus import stopwords

stop_words = set(stopwords.words('portuguese'))
filtered = [w for w in tokens if w.lower() not in stop_words]
```

## Stemming e Lemmatizacao

Stemming reduz palavras ao radical (heuristica). Lemmatizacao reduz a forma canonica
(dicionario). Stemming e mais rapido; lemmatizacao e mais precisa.

```python
from nltk.stem import RSLPStemmer, WordNetLemmatizer

# Stemming (portugues)
stemmer = RSLPStemmer()
stemmed = [stemmer.stem(w) for w in tokens]

# Lemmatizacao (ingles)
lemmatizer = WordNetLemmatizer()
lemmatized = [lemmatizer.lemmatize(w, pos='v') for w in tokens]
```

## N-grams

Sequencias contiguaas de n tokens. Bigramas e trigramas capturam frases e contexto
local que unigramas perdem.

```python
from sklearn.feature_extraction.text import TfidfVectorizer

# Unigramas + bigramas: melhor balanco custo-beneficio
tfidf = TfidfVectorizer(ngram_range=(1, 2), max_features=20000)
```

## Selecao de Features

Reduzir dimensionalidade mantendo features discriminativas. Metodos comuns:
Information Gain, Mutual Information e Chi-squared (Thaoroijam, 2014).

```python
from sklearn.feature_selection import SelectKBest, chi2, mutual_info_classif

# Chi-squared: mede dependencia entre feature e classe
selector = SelectKBest(chi2, k=5000)
X_selected = selector.fit_transform(X_tfidf, y)

# Mutual Information: mede informacao compartilhada
selector_mi = SelectKBest(mutual_info_classif, k=5000)
X_mi = selector_mi.fit_transform(X_tfidf, y)
```

## Document Frequency Thresholding

Remove termos que aparecem em menos documentos que um limiar minimo,
assumindo que termos raros sao pouco informativos (Thaoroijam, 2014).

```python
tfidf = TfidfVectorizer(min_df=5, max_df=0.95)
# min_df=5: ignora termos em menos de 5 documentos
# max_df=0.95: ignora termos em mais de 95% dos documentos
```

## Quick Reference

| Tecnica | Quando Usar | Impacto |
|---------|-------------|---------|
| Tokenizacao | Sempre (primeiro passo) | Fundamental |
| Stopwords | Texto generico | Moderado |
| Stemming | Clustering, busca | Alto em clustering |
| Lemmatizacao | Classificacao precisa | Alto em classificacao |
| Bigramas | Contexto local importante | Moderado-alto |
| Feature selection | > 50K features | Alto |

## Related

- [Representacao Textual](../concepts/text-representation.md)
- [Pipeline de Pre-processamento](../patterns/text-preprocessing-pipeline.md)
- [Reducao de Dimensionalidade](../concepts/dimensionality-reduction.md)
