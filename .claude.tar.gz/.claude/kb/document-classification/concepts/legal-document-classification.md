# Classificacao de Documentos Juridicos Brasileiros

> **Purpose**: Dominio juridico brasileiro — categorias, desafios especificos e benchmarks
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-23
> **Fonte**: Lopes, M.H. (2019). Classificadores Textuais de Dados Juridicos. TCC, UNESP Bauru.

## Overview

A classificacao automatica de documentos juridicos no Brasil enfrenta desafios unicos:
vocabulario altamente repetitivo entre categorias, escassez de dados rotulados por
especialistas e volumes massivos de publicacoes diarias. O TCC de Lopes (2019) apresentou
dois classificadores — publicacoes juridicas (6 categorias) e status de processos (11
categorias) — demonstrando que SVM e o melhor algoritmo classico para texto juridico
(83.38% accuracy) e que dados rotulados insuficientes inviabilizam a abordagem supervisionada.

## Volume do Dominio Juridico

| Porte do escritorio | Advogados | Processos/mes |
|---------------------|-----------|---------------|
| Pequeno | 6-10 | ~3.000 |
| Medio | 25-50 | ~20.000 |
| Grande | 100-150 | ~160.000 |
| Mega | 400-500 | ~550.000 |

Caso real: 20 profissionais lendo ~3.000 publicacoes/dia manualmente.
Fonte de dados: portais do TJSP (eSAJ) e diarios oficiais.

## Classificador 1: Publicacoes Juridicas (6 Categorias)

Dominio: Direito Empresarial/Comercial. Dataset: 2.470 documentos, 299.148 publicacoes.

| Categoria | Sentencas-chave |
|-----------|-----------------|
| Insolvencia Civil | "declaro a insolvencia", "declaracao de insolvencia" |
| Decreto de Falencia | "decretacao de falencia", "decretada a falencia" |
| Convolacao | "convolacao da recuperacao judicial em falencia" |
| Extensao Falencia | "extensao dos efeitos da falencia" |
| Recuperacao Judicial | "processamento da recuperacao judicial" |
| Recuperacao Extrajudicial | "decretada a liquidacao extrajudicial" |

### Resultados Supervisionados (apenas 18 amostras rotuladas!)

| Algoritmo | Accuracy | Observacao |
|-----------|----------|------------|
| OneVsRest (LinearSVC) | 38.75% | Melhor supervisionado |
| OneVsOne (LinearSVC) | 32.50% | |
| Naive Bayes (MultinomialNB) | 28.75% | |
| AdaBoost | 21.25% | Pior resultado |
| Validacao "mundo real" | ~40% | OneVsRest em dados reais |

**Causa do fracasso**: 18 amostras rotuladas para 6 classes = ~3 por classe.

### Cenario Nao-Supervisionado (K-Means)

- Pre-filtro por sentencas-chave: 7.288 publicacoes (2.44% do total)
- K-Means com k=6 sobre TF-IDF
- PCA e t-SNE revelaram clusters muito sobrepostos
- **Causa**: termos juridicos repetitivos entre categorias (ex: "falencia" aparece em 4 das 6)

## Classificador 2: Status de Processos (11 Categorias)

Dataset: 15.698 processos rotulados via crawler de portais de justica.
Features: 20 ultimos andamentos processuais concatenados.

| Status | Precision | Recall | Observacao |
|--------|-----------|--------|------------|
| Aguarda partes | 1.00 | 0.01 | Classe rara |
| Arquivado | 0.92 | 0.74 | |
| Ativo | 0.89 | 0.95 | Classe majoritaria |
| Baixado | 0.89 | 0.88 | |
| Cartorio | 0.56 | 0.56 | Classe rara |
| Concluso | 0.67 | 0.02 | Classe rara |
| Extinto | 0.86 | 0.95 | |
| Grau recurso | 0.90 | 0.99 | Melhor recall |
| Instancia superior | 0.90 | 0.93 | |
| Julgado | 0.84 | 0.81 | |
| Suspenso | 0.75 | 0.86 | |

**SVM: 83.38% accuracy (melhor)** vs Naive Bayes: 66.11%.

## Dicionario de Palavras-Chave Juridicas

60+ termos definidos por especialistas: declarar, convolacao, deferido, efeitos, falencia,
recuperacao, liquidacao, insolvencia, judicial, extrajudicial, decreto, processamento.
Esses termos sao usados como pre-filtro antes da classificacao ML.

## Desafios Especificos do Texto Juridico

1. **Vocabulario repetitivo**: termos como "falencia", "recuperacao", "judicial" aparecem
   em multiplas categorias, dificultando separacao por TF-IDF e clustering
2. **Escassez de rotulos**: rotulacao exige advogado especialista (custo alto)
3. **Desbalanceamento severo**: classes como "Aguarda partes" e "Concluso" tem recall < 0.02
4. **Formalidade textual**: estrutura rigida de publicacoes com linguagem formulaica
5. **Termos latinos e arcaicos**: vocabulario juridico com origens no latim

## Licoes Aprendidas

- Dataset rotulado e **fundamental** — 18 amostras e absolutamente insuficiente
- SVM e superior ao NB para texto juridico (83% vs 66%)
- Pre-filtro por sentencas-chave reduz escopo drasticamente (2.44% do total)
- Desbalanceamento de classes impacta severamente o recall
- Sugestao: plataforma colaborativa de rotulacao + balanceamento (max 390/classe)

## Related

- [Classificacao Supervisionada](supervised-classification.md)
- [Metodos Nao-Supervisionados](unsupervised-methods.md)
- [Metricas de Avaliacao](evaluation-metrics.md)
- [Padrao TF-IDF + SVM](../patterns/tfidf-svm-classifier.md)
- [Classificador Juridico (pattern)](../patterns/legal-text-classifier.md)
