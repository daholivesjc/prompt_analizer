# Classificacao de Documentos Multi-Pagina

> **Purpose**: Doc2Vec, deep metric learning e novelty detection para documentos complexos
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-23

## Overview

Documentos reais frequentemente possuem multiplas paginas (faturas, contratos, relatorios).
A classificacao multi-pagina requer representar o documento inteiro como um vetor unico.
Doc2Vec (Paragraph Vectors) e a abordagem classica. O paper Neurocomputing (Pham et al., 2025)
propoe um framework end-to-end com BERT + deep metric learning + novelty/ambiguity
rejection, alcancando 98.76% de accuracy e 99.5% de precision apos rejeicao.

## Desafios Especificos

1. **Volume de texto**: documentos multi-pagina excedem limites de contexto de modelos
2. **Categorias dinamicas**: novas categorias surgem continuamente (>200 em sistemas reais)
3. **Novelty detection**: documentos fora da distribuicao devem ser identificados
4. **Ambiguidade**: documentos na fronteira entre categorias geram incerteza

## Doc2Vec para Multi-Pagina

Cada documento (independente do numero de paginas) recebe um vetor unico.
O texto completo e tratado como uma unica sequencia de tokens.

```python
from gensim.models.doc2vec import Doc2Vec, TaggedDocument

# Preparar documentos (concatenar todas as paginas)
tagged_docs = []
for idx, doc in enumerate(documents):
    full_text = " ".join(doc.pages)  # concatena paginas
    tagged_docs.append(TaggedDocument(words=full_text.split(), tags=[str(idx)]))

# Treinar modelo
model = Doc2Vec(
    tagged_docs,
    vector_size=200,
    window=5,
    min_count=2,
    epochs=40,
    dm=1  # distributed memory (preserva ordem)
)

# Inferir vetor para novo documento
new_vector = model.infer_vector(new_doc_text.split())
```

## Deep Metric Learning (Pham et al., 2025)

Framework que usa contrastive loss para compactar o espaco de conhecimento.
Documentos da mesma categoria ficam proximos; de categorias diferentes, distantes.
Custom margin-based contrastive loss com mini-batch adaptativo.

```python
# Pseudocodigo do framework end-to-end
# 1. Encoder BERT (embedding_dim=768)
# 2. Contrastive loss customizada:
#    L = L_ce + lambda * L_margin
#    L_margin = (1/d^M) * (L_pos * beta + L_neg)
#    L_pos: media das distancias entre pares positivos
#    L_neg: penalidade para pares negativos proximos

# 3. KNN-based rejector para novelty e ambiguidade:
#    Score(x) = -EuclideanDistance(x, x_k_nearest)
#    Se Score(x) < theta: documento e novel (OOD)
```

## Novelty e Ambiguity Rejection

Sistema end-to-end com tres componentes (Pham et al., 2025):
1. **Classificador**: BERT fine-tuned com contrastive loss
2. **Rejector**: KNN com distancia euclidiana sobre embeddings
3. **Consenso**: acordo entre logits e rotulo do k-esimo vizinho

```python
from sklearn.neighbors import NearestNeighbors

# Indexar features de treinamento
nn = NearestNeighbors(n_neighbors=1, metric='euclidean')
nn.fit(train_embeddings)

# Score de novidade para documento novo
distances, indices = nn.kneighbors(new_embedding.reshape(1, -1))
score = -distances[0][0]  # quanto menor, mais novel

# Threshold estimado para TPR >= 95%
if score < threshold:
    prediction = "NOVEL (fora da distribuicao)"
else:
    prediction = classifier.predict(new_embedding)
```

## Resultados de Referencia (Pham et al., 2025)

| Metodo | Dataset | ACC | PRE | REC |
|--------|---------|-----|-----|-----|
| KNN* + Margin | Private Small | 98.76% | 98.77% | 95.04% |
| KNN* + Margin | Private Tiny | 99.13% | 99.13% | 98.00% |
| KNN* + Margin | RVL-CDIP | 90.55% | 90.62% | 90.21% |

## Estrategia de Chunking para Documentos Longos

Para documentos que excedem o limite de 512 tokens do BERT:

```python
def classify_long_document(text, tokenizer, model, max_length=512):
    tokens = tokenizer.encode(text)
    chunks = [tokens[i:i+max_length] for i in range(0, len(tokens), max_length-50)]
    embeddings = [model.encode(chunk) for chunk in chunks]
    # Agregar: media, max-pooling ou atencao
    doc_embedding = np.mean(embeddings, axis=0)
    return doc_embedding
```

## Related

- [Deep Learning NLP](../concepts/deep-learning-nlp.md)
- [Fine-tuning BERT](../patterns/bert-fine-tuning.md)
- [Representacao Textual](../concepts/text-representation.md)
