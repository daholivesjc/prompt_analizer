# Fundamentos de OCR (Optical Character Recognition)

> **Purpose**: O que e OCR, como funciona, engines disponiveis e comparacao entre eles
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-23

## Overview

OCR (Optical Character Recognition) e a tecnologia que converte imagens contendo texto
(escaneados, fotografados, impressos ou manuscritos) em texto editavel e pesquisavel.
E uma etapa critica antes da classificacao de documentos, pois documentos fisicos
(faturas, notas fiscais, recibos) precisam ter seu texto extraido antes de serem
classificados por modelos de ML/NLP.

## Como Funciona o OCR

O pipeline basico de OCR segue estas etapas:

```text
Imagem Original
  -> Pre-processamento (grayscale, binarizacao, deskew, denoise)
    -> Segmentacao de pagina (detectar blocos, linhas, palavras)
      -> Reconhecimento de caracteres (engine OCR)
        -> Pos-processamento (correcao ortografica, formatacao)
          -> Texto extraido
```

### Etapas Detalhadas

1. **Pre-processamento**: Melhora a qualidade da imagem (contraste, rotacao, ruido)
2. **Segmentacao (Layout Analysis)**: Identifica regioes de texto, tabelas, imagens
3. **Reconhecimento**: Engine LSTM/CNN converte pixels em caracteres Unicode
4. **Pos-processamento**: Correcao ortografica, reconstrucao de paragrafos

## Engines OCR Disponiveis

### Tesseract OCR

Engine open-source mais popular. Suporta 100+ idiomas. Versao 4+ usa LSTM.

```python
import pytesseract
text = pytesseract.image_to_string(image, lang='por')
```

### EasyOCR

Baseado em deep learning (CRAFT + CRNN). Simples de usar, bom para multiplos idiomas.

```python
import easyocr
reader = easyocr.Reader(['pt', 'en'])
results = reader.readtext('imagem.png')
```

### Keras-OCR

Pipeline end-to-end com CRAFT (detector) + CRNN (reconhecedor). Customizavel.

```python
import keras_ocr
pipeline = keras_ocr.pipeline.Pipeline()
predictions = pipeline.recognize([image])
```

### Google Cloud Vision API

API gerenciada com alta precisao. Pago por uso. Ideal para producao em GCP.

## Comparacao de Engines

| Engine | Tipo | Precisao | Velocidade | GPU | Custo |
|--------|------|----------|------------|-----|-------|
| Tesseract | Tradicional+LSTM | Moderada-Alta | Rapida | Nao | Gratis |
| EasyOCR | Deep Learning | Alta | Media | Sim (opc.) | Gratis |
| Keras-OCR | Deep Learning | Alta | Lenta | Sim | Gratis |
| Cloud Vision | API gerenciada | Muito alta | Variavel | N/A | Pago |

## Quando Usar OCR

| Cenario | Engine Recomendado |
|---------|-------------------|
| Documentos escaneados simples | Tesseract |
| Textos em multiplos idiomas | EasyOCR |
| Layouts complexos (tabelas) | Cloud Vision ou Keras-OCR |
| Alto volume em producao (GCP) | Cloud Vision API |
| Prototipacao rapida | pytesseract |
| Performance com threading | tesserocr (API C++ nativa) |

## Formatos de Entrada e Saida

**Entrada**: PNG, JPEG, TIFF, BMP, PDF (via pdf2image/poppler)

**Saida do Tesseract**:
- Texto puro (string)
- hOCR (HTML com coordenadas)
- PDF pesquisavel (texto invisivel sobre imagem)
- TSV (dados tabulares com bounding boxes e confianca)
- ALTO/PAGE XML

## Metricas de Qualidade OCR

| Metrica | Descricao |
|---------|-----------|
| Character Error Rate (CER) | % de caracteres errados vs referencia |
| Word Error Rate (WER) | % de palavras erradas vs referencia |
| Confidence Score | Confianca do engine por palavra (0-100) |

## Related

- [Tesseract Engine](tesseract-engine.md) -- Detalhes do Tesseract (PSM, OEM, LSTM)
- [Pipeline OCR](../patterns/tesseract-ocr-pipeline.md) -- Implementacao pratica
- [Pre-processamento de Imagem](../patterns/image-preprocessing-ocr.md) -- Melhorar qualidade
- [OCR para Classificacao](../patterns/ocr-to-classification.md) -- Pipeline integrado
