# Classificacao Supervisionada de Documentos

> **Purpose**: Algoritmos classicos de ML para classificacao de texto com dados rotulados
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-23

## Overview

Na classificacao supervisionada, um modelo e treinado com documentos rotulados (D = {d1,...,dn})
para aprender a funcao f: D -> C que mapeia documentos a categorias. Os metodos classicos --
Naive Bayes, SVM, kNN e Logistic Regression -- sao a base da classificacao textual e continuam
relevantes por sua simplicidade e eficacia com TF-IDF (Thaoroijam, 2014; Pardhi & Margaj, 2025).

## Naive Bayes

Classificador probabilistico baseado no teorema de Bayes com suposicao de independencia
entre features. Apesar da suposicao simplista, funciona bem em texto. Eficaz com TF-IDF
para papers de pesquisa (Pardhi & Margaj, 2025).

```python
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(max_features=20000)),
    ('clf', MultinomialNB(alpha=0.1))  # alpha: suavizacao Laplace
])
pipeline.fit(X_train, y_train)
predictions = pipeline.predict(X_test)
```

## Support Vector Machine (SVM)

SVM encontra o hiperplano de margem maxima que separa as classes. Propriedade fundamental:
o aprendizado e quase independente da dimensionalidade do espaco de features, tornando SVM
ideal para texto onde o espaco e naturalmente de alta dimensionalidade (Thaoroijam, 2014).

```python
from sklearn.svm import LinearSVC

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(max_features=20000, ngram_range=(1, 2))),
    ('clf', LinearSVC(C=1.0, max_iter=10000))
])
pipeline.fit(X_train, y_train)
# SVM raramente requer feature selection explicita
```

## k-Nearest Neighbors (kNN)

Classifica documentos pela votacao majoritaria dos k vizinhos mais proximos usando
similaridade cosseno. No paper ISI 2025, KNN alcancou 87.1% de accuracy no Reuters-21578.
Limitacao: ineficiente em tempo de inferencia para datasets grandes.

```python
from sklearn.neighbors import KNeighborsClassifier

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(max_features=20000)),
    ('clf', KNeighborsClassifier(n_neighbors=5, metric='cosine'))
])
pipeline.fit(X_train, y_train)
```

## Logistic Regression

Modelo linear que estima probabilidades de pertencimento a cada classe. Funciona
bem com regularizacao L2 para texto de alta dimensionalidade.

```python
from sklearn.linear_model import LogisticRegression

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(max_features=20000)),
    ('clf', LogisticRegression(C=1.0, max_iter=1000, solver='lbfgs'))
])
pipeline.fit(X_train, y_train)
probabilities = pipeline.predict_proba(X_test)
```

## Quick Reference

| Algoritmo | Treinamento | Inferencia | Feature Selection | Interpretavel |
|-----------|-------------|------------|-------------------|---------------|
| Naive Bayes | Muito rapido | Muito rapido | Nao necessaria | Parcial |
| SVM linear | Rapido | Muito rapido | Automatica | Parcial |
| kNN | Zero | Lento | Necessaria | Sim |
| Log. Regression | Rapido | Muito rapido | Via regularizacao | Sim |

## Common Mistakes

### Errado

```python
# Usar SVM com kernel RBF em texto de alta dimensao
clf = SVC(kernel='rbf')  # Lento e geralmente pior que linear
```

### Correto

```python
# SVM linear e ideal para texto (alta dimensao, linearmente separavel)
clf = LinearSVC(C=1.0)  # Rapido e eficaz
```

## Related

- [Representacao Textual](../concepts/text-representation.md)
- [Metricas de Avaliacao](../concepts/evaluation-metrics.md)
- [Padrao TF-IDF + SVM](../patterns/tfidf-svm-classifier.md)
