# Tesseract OCR Engine

> **Purpose**: Arquitetura do Tesseract, LSTM engine, Page Segmentation Modes, OEM e configuracao
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-23

## Overview

Tesseract e o engine OCR open-source mais utilizado no mundo. Originalmente desenvolvido
pela HP Labs (1985-1994), tornou-se open-source em 2005 e foi mantido pelo Google de 2006
a 2018. A versao 4+ introduziu o engine LSTM (redes neurais recorrentes) para reconhecimento
de linhas inteiras, substituindo o reconhecimento caractere-a-caractere da versao 3.
Versao estavel atual: 5.x. Licenca Apache 2.0.

## Arquitetura do Engine

```text
Imagem de Entrada (via Leptonica)
  -> Adaptive Thresholding (binarizacao)
    -> Connected Component Analysis
      -> Page Layout Analysis (segmentacao por blocos/linhas/palavras)
        -> Reconhecimento (LSTM ou Legacy)
          -> Trained Data (modelos de idioma .traineddata)
            -> Texto UTF-8
```

### Dependencias Principais

| Biblioteca | Funcao |
|------------|--------|
| **Leptonica** | Abertura e processamento de imagens |
| **zlib** | Compressao |
| **libpng** | Suporte a PNG |
| **libtiff** | Suporte a TIFF multipagina |

## OCR Engine Modes (OEM)

O parametro `--oem` define qual engine de reconhecimento usar.

| OEM | Descricao | Quando Usar |
|-----|-----------|-------------|
| `0` | Legacy (Tesseract 3) | Compatibilidade, patterns de caracteres |
| `1` | LSTM only (padrao v4+) | Melhor precisao geral |
| `2` | Legacy + LSTM | Combinacao dos dois |
| `3` | Default (auto) | Deixar Tesseract decidir |

```python
# Usando OEM via pytesseract
text = pytesseract.image_to_string(img, config='--oem 1')
```

## Page Segmentation Modes (PSM)

O parametro `--psm` controla como o Tesseract segmenta a pagina antes do OCR.
A escolha correta do PSM e critica para a qualidade do resultado.

| PSM | Descricao | Caso de Uso |
|-----|-----------|-------------|
| `0` | OSD only (orientacao e script) | Detectar rotacao |
| `1` | Auto + OSD | Pagina completa com deteccao |
| `3` | Auto (padrao) | Documento generico |
| `4` | Coluna unica de tamanhos variados | Texto corrido |
| `6` | Bloco uniforme de texto | Paragrafo isolado |
| `7` | Linha unica de texto | Campo de formulario |
| `8` | Palavra unica | Placa, label |
| `9` | Palavra unica em circulo | Logos |
| `10` | Caractere unico | Digitos isolados |
| `11` | Texto esparso (sem ordem) | Texto sobre imagem |
| `12` | Texto esparso + OSD | Texto espalhado |
| `13` | Raw line | Linha sem segmentacao |

```python
# Exemplo: OCR de campo de formulario (linha unica)
text = pytesseract.image_to_string(img, config='--psm 7')

# Exemplo: OCR de documento completo
text = pytesseract.image_to_string(img, config='--psm 3 --oem 1')
```

## Configuracao de Idioma

Tesseract usa arquivos `.traineddata` com modelos LSTM treinados por idioma.

```bash
# Instalar idioma portugues
sudo apt install tesseract-ocr-por

# Verificar idiomas instalados
tesseract --list-langs
```

```python
# Usar idioma portugues
text = pytesseract.image_to_string(img, lang='por')

# Multiplos idiomas
text = pytesseract.image_to_string(img, lang='por+eng')

# Diretorio customizado de tessdata
config = '--tessdata-dir /caminho/tessdata'
text = pytesseract.image_to_string(img, lang='por', config=config)
```

### Repositorios de Dados Treinados

| Repositorio | Velocidade | Precisao | Uso |
|-------------|------------|----------|-----|
| `tessdata` | Rapido | Padrao | Uso geral |
| `tessdata_best` | Lento | Maxima | Quando precisao e critica |
| `tessdata_fast` | Muito rapido | Menor | Alto volume |

## pytesseract vs tesserocr

| Caracteristica | pytesseract | tesserocr |
|----------------|-------------|-----------|
| Integracao | Subprocess (CLI) | API C++ via Cython |
| GIL Python | Bloqueado | Liberado durante OCR |
| Threading | Limitado | Concorrencia real |
| Inicializacao | Por chamada | Reutilizavel |
| API | Alto nivel | Alto + baixo nivel |
| Instalacao | `pip install pytesseract` | Requer libtesseract-dev |
| Bounding boxes | `image_to_data()` | `GetComponentImages()` |
| Confianca | Via TSV output | `AllWordConfidences()` |

## Instalacao

```bash
# Ubuntu/Debian
sudo apt install tesseract-ocr libtesseract-dev libleptonica-dev
sudo apt install tesseract-ocr-por  # idioma portugues

# macOS
brew install tesseract

# Python wrappers
pip install pytesseract   # wrapper via subprocess
pip install tesserocr     # wrapper via API C++ (Cython)
```

## Related

- [Fundamentos de OCR](ocr-fundamentals.md) -- Visao geral de OCR e engines
- [Pipeline OCR com Tesseract](../patterns/tesseract-ocr-pipeline.md) -- Implementacao
- [Pre-processamento de Imagem](../patterns/image-preprocessing-ocr.md) -- Melhorar input
