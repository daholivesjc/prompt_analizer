# Representacao Textual de Documentos

> **Purpose**: Metodos para converter documentos textuais em vetores numericos para ML
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-23

## Overview

Antes de qualquer classificacao, documentos textuais precisam ser convertidos em representacoes
numericas. O modelo mais usado e o Vector Space Model (VSM), onde cada documento e representado
como um vetor em espaco de m dimensoes. A escolha da representacao impacta diretamente a
qualidade da classificacao -- TF-IDF supera BoW na maioria dos cenarios de clustering e
classificacao (Khalilian & Hassanzadeh; VivekKumar Singh et al.).

## Bag of Words (BoW)

Representacao binaria ou baseada em frequencia. Cada dimensao corresponde a um termo unico.

```python
from sklearn.feature_extraction.text import CountVectorizer

vectorizer = CountVectorizer(max_features=10000)
X = vectorizer.fit_transform(documents)
# X: matriz esparsa (n_docs x n_termos)
```

## TF-IDF (Term Frequency - Inverse Document Frequency)

Pondera a frequencia do termo pela raridade no corpus. Termos frequentes em um documento
mas raros no corpus recebem maior peso. Segundo o paper ISI 2025, TF-IDF e a base do
pipeline de pre-processamento mais eficaz para classificacao com ML.

```python
from sklearn.feature_extraction.text import TfidfVectorizer

tfidf = TfidfVectorizer(max_features=20000, ngram_range=(1, 2))
X = tfidf.fit_transform(documents)
# TF(t,d) * IDF(t) = freq(t,d) * log(N / df(t))
```

## Word Embeddings (Word2Vec / GloVe)

Vetores densos de 100-300 dimensoes que capturam relacoes semanticas entre palavras.
Word2Vec (Mikolov et al., 2013) revolucionou NLP ao mapear palavras em espacos vetoriais
onde relacoes analogicas sao preservadas.

```python
from gensim.models import Word2Vec

model = Word2Vec(sentences, vector_size=200, window=5, min_count=2)
doc_vector = np.mean([model.wv[w] for w in doc_tokens if w in model.wv], axis=0)
```

## Doc2Vec (Paragraph Vectors)

Extensao do Word2Vec para documentos inteiros. Gera um vetor unico por documento,
ideal para classificacao multi-pagina. Cada documento recebe uma tag unica durante
o treinamento.

```python
from gensim.models.doc2vec import Doc2Vec, TaggedDocument

tagged = [TaggedDocument(words=doc.split(), tags=[str(i)]) for i, doc in enumerate(docs)]
model = Doc2Vec(tagged, vector_size=200, window=5, epochs=40)
new_vector = model.infer_vector(new_doc.split())
```

## BERT Embeddings (Contextuais)

Embeddings contextuais de 768 dimensoes onde a mesma palavra tem representacoes diferentes
conforme o contexto. O paper Neurocomputing (Pham et al., 2025) usa BERT com embedding
de 768 dimensoes como encoder, alcancando 98.76% de accuracy em datasets privados.

```python
from transformers import AutoTokenizer, AutoModel
import torch

tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
model = AutoModel.from_pretrained("bert-base-uncased")
inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
outputs = model(**inputs)
doc_embedding = outputs.last_hidden_state[:, 0, :]  # [CLS] token
```

## Quick Reference

| Metodo | Dimensao | Semantica | Contexto | Velocidade |
|--------|----------|-----------|----------|------------|
| BoW | ~10K-100K | Nao | Nao | Muito rapida |
| TF-IDF | ~10K-100K | Parcial | Nao | Muito rapida |
| Word2Vec | 100-300 | Sim | Nao | Rapida |
| Doc2Vec | 100-300 | Sim | Nao | Media |
| BERT | 768 | Sim | Sim | Lenta |

## Related

- [Feature Engineering](../concepts/feature-engineering.md)
- [Pipeline TF-IDF + SVM](../patterns/tfidf-svm-classifier.md)
- [Reducao de Dimensionalidade](../concepts/dimensionality-reduction.md)
