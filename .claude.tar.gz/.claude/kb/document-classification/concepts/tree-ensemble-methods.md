# Metodos de Arvores e Ensembles

> **Purpose**: Decision Trees, Random Forests, Gradient Boosting e XGBoost para classificacao
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-23

## Overview

Metodos baseados em arvores de decisao e seus ensembles sao amplamente utilizados em
classificacao de documentos. No estudo ISI 2025 (Ahmed et al.), XGBoost alcancou 91.1% de
accuracy no dataset Reuters-21578, superando KNN (87.1%), RF (82.9%) e DT (81.7%). Estes
metodos sao mais rapidos de treinar que deep learning e produzem resultados competitivos.

## Decision Trees

Estrutura de fluxograma onde cada no interno testa um atributo, cada ramo representa
um resultado, e cada folha contem um rotulo de classe. Algoritmos classicos: ID3, C4.5.

```python
from sklearn.tree import DecisionTreeClassifier

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(max_features=10000)),
    ('clf', DecisionTreeClassifier(
        criterion='gini',        # ou 'entropy' (information gain)
        max_depth=20,            # prevenir overfitting
        min_samples_leaf=5
    ))
])
pipeline.fit(X_train, y_train)
```

## Random Forests

Ensemble de arvores treinadas em subsets aleatorios de dados e features.
Reduz variancia e overfitting em relacao a arvores individuais. RF seleciona
as features mais fortes e usa probabilidade simples para combinar resultados.

```python
from sklearn.ensemble import RandomForestClassifier

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(max_features=15000)),
    ('clf', RandomForestClassifier(
        n_estimators=100,        # numero de arvores
        max_features='sqrt',     # features por split
        n_jobs=-1,               # paralelismo total
        random_state=42
    ))
])
pipeline.fit(X_train, y_train)
```

## Gradient Boosting

Constroi arvores sequencialmente, cada nova arvore corrigindo erros da anterior.
Foco nas instancias classificadas incorretamente (boosting iterativo).

```python
from sklearn.ensemble import GradientBoostingClassifier

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(max_features=15000)),
    ('clf', GradientBoostingClassifier(
        n_estimators=200,
        learning_rate=0.1,
        max_depth=5,
        subsample=0.8
    ))
])
```

## XGBoost

Implementacao otimizada de gradient boosting com regularizacao L1/L2.
No paper ISI 2025, XGBoost obteve os melhores resultados entre todos os metodos
testados: accuracy 91.1%, precision 90.38%, recall 91.15%, F1 90.55%.

```python
from xgboost import XGBClassifier

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(max_features=20000)),
    ('clf', XGBClassifier(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        use_label_encoder=False,
        eval_metric='mlogloss'
    ))
])
pipeline.fit(X_train, y_train)
```

## Quick Reference

| Metodo | Accuracy (Reuters) | Treinamento | Interpretabilidade |
|--------|-------------------|-------------|-------------------|
| Decision Tree | 81.7% | Rapido | Alta |
| Random Forest | 82.9% | Medio | Media |
| XGBoost | 91.1% | Medio | Baixa |

## Common Mistakes

### Errado

```python
# Muitas arvores sem ganho significativo
rf = RandomForestClassifier(n_estimators=1000)  # > 100 nao melhora muito
```

### Correto

```python
# Usar cross-validation para encontrar n_estimators ideal
rf = RandomForestClassifier(n_estimators=100)  # suficiente na maioria dos casos
```

## Related

- [Classificacao Supervisionada](../concepts/supervised-classification.md)
- [Ensemble Stacking](../patterns/ensemble-stacking.md)
- [Pipeline de Avaliacao](../patterns/model-evaluation-pipeline.md)
