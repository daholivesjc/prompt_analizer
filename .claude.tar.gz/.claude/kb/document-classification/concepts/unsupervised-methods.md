# Metodos Nao-Supervisionados para Documentos

> **Purpose**: Clustering (k-means, DBSCAN, hierarquico) e topic modeling (LDA)
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-23

## Overview

Na classificacao nao-supervisionada, documentos sao agrupados em clusters sem rotulos
pre-definidos, usando medidas de distancia/similaridade. Khalilian & Hassanzadeh
demonstram que TF-IDF com stemming produz os melhores resultados de clustering em
todos os datasets avaliados. FCM (Fuzzy C-Means) e mais robusto que k-means por ser
insensivel a inicializacao.

## K-Means

Algoritmo de particionamento iterativo que divide n documentos em k clusters,
minimizando a distancia intra-cluster. Vantagens: simplicidade e velocidade.
Limitacoes: k deve ser definido previamente e e sensivel a outliers.

```python
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer

tfidf = TfidfVectorizer(max_features=10000)
X = tfidf.fit_transform(documents)

kmeans = KMeans(n_clusters=10, init='k-means++', n_init=10, random_state=42)
clusters = kmeans.fit_predict(X)
```

## Clustering Hierarquico

Dois tipos: aglomerativo (bottom-up) e divisivo (top-down). Aglomerativo
comeca com cada documento como cluster e merge clusters similares.
Linkage: single-link, complete-link, average-link. Complexidade O(N^2).

```python
from sklearn.cluster import AgglomerativeClustering

clustering = AgglomerativeClustering(
    n_clusters=10, linkage='ward', metric='euclidean'
)
labels = clustering.fit_predict(X.toarray())
```

## DBSCAN (Density-Based)

Descobre clusters de forma arbitraria baseado em densidade. Nao requer definir
numero de clusters. Identifica outliers automaticamente.

```python
from sklearn.cluster import DBSCAN

clustering = DBSCAN(eps=0.5, min_samples=5, metric='cosine')
labels = clustering.fit_predict(X.toarray())
# -1 indica outliers/ruido
```

## LDA (Latent Dirichlet Allocation)

Modelo probabilistico para topic modeling. Cada documento e uma mistura de topicos
e cada topico e uma distribuicao de palavras. No paper ISI 2025, gLDA alcancou
89.1% de accuracy no Reuters-21578.

```python
from sklearn.decomposition import LatentDirichletAllocation

lda = LatentDirichletAllocation(
    n_components=20,      # numero de topicos
    max_iter=50,
    learning_method='online',
    random_state=42
)
topic_dist = lda.fit_transform(X)  # distribuicao de topicos por documento
```

## Fuzzy C-Means (FCM)

Soft clustering onde cada documento pertence a todos os clusters com diferentes
graus de pertinencia [0,1]. FCM e mais estavel e robusto que k-means, sendo
insensivel a inicializacao (VivekKumar Singh et al.).

```python
import skfuzzy as fuzz

cntr, u, _, _, _, _, _ = fuzz.cluster.cmeans(
    X.toarray().T, c=10, m=2, error=0.005, maxiter=1000
)
labels = u.argmax(axis=0)
```

## Quick Reference

| Metodo | Requer k | Outliers | Complexidade | Melhor Para |
|--------|----------|----------|--------------|-------------|
| K-Means | Sim | Sensivel | O(nkt) | Clusters esferico |
| Hierarquico | Sim/Nao | Moderado | O(n^2) | Dendrogramas |
| DBSCAN | Nao | Robusto | O(n log n) | Formas arbitrarias |
| LDA | Sim | N/A | O(nkt) | Topic modeling |

## Related

- [Reducao de Dimensionalidade](../concepts/dimensionality-reduction.md)
- [Representacao Textual](../concepts/text-representation.md)
- [Feature Engineering](../concepts/feature-engineering.md)
