# Document Classification Knowledge Base

> **Purpose**: Classificacao automatica de documentos textuais usando ML, Deep Learning e LLMs
> **MCP Validated**: 2026-04-23

## Quick Navigation

### Concepts (< 150 lines each)

| File | Purpose |
|------|---------|
| [concepts/text-representation.md](concepts/text-representation.md) | BoW, TF-IDF, word embeddings, Doc2Vec |
| [concepts/supervised-classification.md](concepts/supervised-classification.md) | Naive Bayes, SVM, kNN, Logistic Regression |
| [concepts/tree-ensemble-methods.md](concepts/tree-ensemble-methods.md) | Decision Trees, Random Forests, XGBoost |
| [concepts/deep-learning-nlp.md](concepts/deep-learning-nlp.md) | CNNs, RNNs, LSTM, Transformers, BERT |
| [concepts/unsupervised-methods.md](concepts/unsupervised-methods.md) | Clustering (k-means, DBSCAN), topic modeling (LDA) |
| [concepts/feature-engineering.md](concepts/feature-engineering.md) | Tokenizacao, stemming, lemmatizacao, n-grams |
| [concepts/evaluation-metrics.md](concepts/evaluation-metrics.md) | Accuracy, Precision, Recall, F1, ROC-AUC |
| [concepts/dimensionality-reduction.md](concepts/dimensionality-reduction.md) | PCA, SVD, t-SNE, autoencoders |
| [concepts/multi-page-classification.md](concepts/multi-page-classification.md) | Classificacao multi-pagina, Doc2Vec, novelty detection |
| [concepts/ocr-fundamentals.md](concepts/ocr-fundamentals.md) | OCR: engines, comparacao (Tesseract, EasyOCR, Keras-OCR) |
| [concepts/tesseract-engine.md](concepts/tesseract-engine.md) | Tesseract: LSTM, PSM, OEM, pytesseract vs tesserocr |
| [concepts/legal-document-classification.md](concepts/legal-document-classification.md) | Classificacao juridica brasileira: categorias, desafios, benchmarks |
| [concepts/categorical-encoding.md](concepts/categorical-encoding.md) | One-Hot, Label Encoding, Feature Hashing, Two-Hot |

### Patterns (< 200 lines each)

| File | Purpose |
|------|---------|
| [patterns/text-preprocessing-pipeline.md](patterns/text-preprocessing-pipeline.md) | Pipeline completo de pre-processamento |
| [patterns/tfidf-svm-classifier.md](patterns/tfidf-svm-classifier.md) | Padrao classico TF-IDF + SVM |
| [patterns/bert-fine-tuning.md](patterns/bert-fine-tuning.md) | Fine-tuning de BERT para classificacao |
| [patterns/ensemble-stacking.md](patterns/ensemble-stacking.md) | Stacking de modelos para classificacao |
| [patterns/llm-zero-shot-classification.md](patterns/llm-zero-shot-classification.md) | Classificacao zero-shot com LLMs |
| [patterns/model-evaluation-pipeline.md](patterns/model-evaluation-pipeline.md) | Pipeline de avaliacao e comparacao |
| [patterns/document-categorization-workflow.md](patterns/document-categorization-workflow.md) | Workflow completo de categorizacao |
| [patterns/tesseract-ocr-pipeline.md](patterns/tesseract-ocr-pipeline.md) | Pipeline OCR com pytesseract e tesserocr |
| [patterns/image-preprocessing-ocr.md](patterns/image-preprocessing-ocr.md) | Pre-processamento de imagem para OCR |
| [patterns/ocr-to-classification.md](patterns/ocr-to-classification.md) | Pipeline integrado OCR + classificacao |
| [patterns/legal-text-classifier.md](patterns/legal-text-classifier.md) | Classificador juridico com pre-filtro + SVM |
| [patterns/categorical-encoding-pipeline.md](patterns/categorical-encoding-pipeline.md) | Pipeline de encoding categorico com pandas e sklearn |

### Specs (Machine-Readable)

| File | Purpose |
|------|---------|
| [specs/classification-taxonomy.yaml](specs/classification-taxonomy.yaml) | Taxonomia de metodos e algoritmos |

---

## Quick Reference

- [quick-reference.md](quick-reference.md) - Tabelas de decisao rapida

---

## Key Concepts

| Concept | Description |
|---------|-------------|
| **Representacao Textual** | Converter documentos em vetores numericos (BoW, TF-IDF, embeddings) |
| **Classificacao Supervisionada** | Treinar modelos com documentos rotulados (SVM, NB, kNN) |
| **Deep Learning para NLP** | Redes neurais profundas para capturar contexto (BERT, RNN) |
| **Avaliacao de Modelos** | Metricas e protocolos para medir qualidade da classificacao |
| **OCR (Reconhecimento Optico)** | Extrair texto de imagens/PDFs escaneados (Tesseract, EasyOCR) |
| **Classificacao Juridica** | Classificar publicacoes e processos do dominio juridico brasileiro |
| **Encoding Categorico** | Converter variaveis categoricas em representacoes numericas (One-Hot, Label, Hashing) |

---

## Learning Path

| Level | Files |
|-------|-------|
| **Iniciante** | concepts/text-representation.md, concepts/feature-engineering.md |
| **Intermediario** | concepts/supervised-classification.md, patterns/tfidf-svm-classifier.md |
| **Avancado** | patterns/bert-fine-tuning.md, patterns/ensemble-stacking.md |
| **OCR** | concepts/ocr-fundamentals.md, patterns/ocr-to-classification.md |
| **Juridico** | concepts/legal-document-classification.md, patterns/legal-text-classifier.md |
| **Encoding** | concepts/categorical-encoding.md, patterns/categorical-encoding-pipeline.md |

---

## Agent Usage

| Agent | Primary Files | Use Case |
|-------|---------------|----------|
| python-developer | patterns/tfidf-svm-classifier.md | Implementar classificador classico |
| python-developer | patterns/bert-fine-tuning.md | Fine-tuning de transformers |
| kb-architect | specs/classification-taxonomy.yaml | Consultar taxonomia de metodos |
