# Fine-tuning de BERT para Classificacao de Documentos

> **Purpose**: Adaptar modelos pre-treinados BERT/DistilBERT para classificacao especifica
> **MCP Validated**: 2026-04-23

## When to Use

- Dataset com mais de 5K documentos rotulados
- Necessidade de capturar semantica contextual
- Classificacao multilingual ou dominio especializado
- BERT alcanca estado-da-arte: 98.76% accuracy em docs administrativos (Pham et al., 2025)
- Transfer learning resolve escassez de dados rotulados (Howard & Ruder, 2018)

## Implementation

```python
"""
Fine-tuning de BERT para classificacao de documentos.

BERT (Devlin et al., 2018) usa pre-treinamento bidirecional para capturar
contexto completo. O review de Pardhi & Margaj (2025) confirma que
Transformers alcancam resultados estado-da-arte mas requerem recursos
computacionais significativos. DistilBERT oferece 97% da performance
com 40% menos parametros.
"""

import torch
from torch.utils.data import Dataset, DataLoader
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer,
    EarlyStoppingCallback
)
from sklearn.metrics import accuracy_score, f1_score
import numpy as np


class DocumentDataset(Dataset):
    """Dataset para documentos textuais."""

    def __init__(self, texts, labels, tokenizer, max_length=512):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        encoding = self.tokenizer(
            self.texts[idx],
            truncation=True,
            padding='max_length',
            max_length=self.max_length,
            return_tensors='pt'
        )
        return {
            'input_ids': encoding['input_ids'].squeeze(),
            'attention_mask': encoding['attention_mask'].squeeze(),
            'labels': torch.tensor(self.labels[idx], dtype=torch.long)
        }


def compute_metrics(eval_pred):
    """Calcula metricas durante treinamento."""
    predictions, labels = eval_pred
    preds = np.argmax(predictions, axis=-1)
    return {
        'accuracy': accuracy_score(labels, preds),
        'f1_macro': f1_score(labels, preds, average='macro'),
        'f1_weighted': f1_score(labels, preds, average='weighted')
    }


def fine_tune_bert(
    train_texts, train_labels,
    val_texts, val_labels,
    num_labels: int,
    model_name: str = "bert-base-uncased",
    output_dir: str = "./bert_classifier",
    epochs: int = 5,
    batch_size: int = 16,
    learning_rate: float = 2e-5,
    max_length: int = 512
):
    """
    Fine-tuning completo de BERT para classificacao.

    Args:
        model_name: 'bert-base-uncased', 'distilbert-base-uncased',
                    'neuralmind/bert-base-portuguese-cased' (pt-BR)
    """
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name, num_labels=num_labels
    )

    train_dataset = DocumentDataset(train_texts, train_labels, tokenizer, max_length)
    val_dataset = DocumentDataset(val_texts, val_labels, tokenizer, max_length)

    training_args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=epochs,
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=batch_size * 2,
        learning_rate=learning_rate,
        weight_decay=0.01,
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="f1_macro",
        warmup_ratio=0.1,
        fp16=torch.cuda.is_available(),
        logging_steps=50,
        seed=42
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
        compute_metrics=compute_metrics,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=3)]
    )

    trainer.train()
    trainer.save_model(f"{output_dir}/best_model")
    tokenizer.save_pretrained(f"{output_dir}/best_model")

    return trainer
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `model_name` | bert-base-uncased | Modelo pre-treinado (ver opcoes abaixo) |
| `epochs` | 5 | Epocas de fine-tuning (3-10 recomendado) |
| `batch_size` | 16 | Batch size (8-32 conforme memoria GPU) |
| `learning_rate` | 2e-5 | Taxa de aprendizado (1e-5 a 5e-5) |
| `max_length` | 512 | Tokens maximo por documento |
| `warmup_ratio` | 0.1 | Percentual de warmup steps |
| `weight_decay` | 0.01 | Regularizacao L2 |

## Modelos Recomendados

| Modelo | Params | Idioma | Uso |
|--------|--------|--------|-----|
| bert-base-uncased | 110M | Ingles | Padrao |
| distilbert-base-uncased | 66M | Ingles | Producao eficiente |
| neuralmind/bert-base-portuguese-cased | 110M | PT-BR | Portugues |
| bert-base-multilingual-cased | 110M | Multi | Multilingual |

## Example Usage

```python
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# Preparar dados
le = LabelEncoder()
encoded_labels = le.fit_transform(labels)

X_train, X_val, y_train, y_val = train_test_split(
    texts, encoded_labels, test_size=0.2, stratify=encoded_labels
)

# Fine-tuning
trainer = fine_tune_bert(
    X_train, y_train, X_val, y_val,
    num_labels=len(le.classes_),
    model_name="neuralmind/bert-base-portuguese-cased",
    epochs=5,
    batch_size=16
)

# Avaliar
results = trainer.evaluate()
print(f"F1-macro: {results['eval_f1_macro']:.4f}")
```

## See Also

- [Deep Learning NLP](../concepts/deep-learning-nlp.md)
- [Classificacao Multi-pagina](../concepts/multi-page-classification.md)
- [Pipeline de Avaliacao](../patterns/model-evaluation-pipeline.md)
