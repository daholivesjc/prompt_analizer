# Pipeline de Encoding para Variaveis Categoricas

> **Purpose**: Padroes de implementacao para encoding de variaveis categoricas com pandas e sklearn
> **MCP Validated**: 2026-04-23

## When to Use

- Dados com colunas categoricas que precisam ser numericizadas para ML
- Necessidade de pipeline reprodutivel entre treino e teste
- Alta cardinalidade exigindo estrategias alem de one-hot simples

## Implementacao com pandas get_dummies()

```python
"""
One-Hot Encoding rapido com pandas.
Ideal para analise exploratoria e prototipacao.
"""
import pandas as pd

# Encoding basico
df_encoded = pd.get_dummies(df, columns=['cor', 'tipo'], dtype=int)

# drop_first=True para evitar multicolinearidade em modelos lineares
df_encoded = pd.get_dummies(df, columns=['cor'], drop_first=True, dtype=int)

# Boa pratica: converter para Categorical antes (menor memoria, deteccao de typos)
df['cor'] = pd.Categorical(df['cor'], categories=['vermelho', 'verde', 'azul'])
df_encoded = pd.get_dummies(df, columns=['cor'], dtype=int)
```

## Implementacao com sklearn OneHotEncoder

```python
"""
OneHotEncoder do sklearn -- preferido para pipelines de producao.
Mantem consistencia entre treino e teste.
"""
from sklearn.preprocessing import OneHotEncoder

encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
encoded = encoder.fit_transform(df[['cor', 'tipo']])
encoded_df = pd.DataFrame(
    encoded,
    columns=encoder.get_feature_names_out(['cor', 'tipo'])
)
```

## Implementacao com sklearn LabelEncoder

```python
"""
LabelEncoder -- APENAS para variaveis ordinais com ordem natural.
NAO usar para variaveis nominais (cria hierarquia falsa).
"""
from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()
df['escolaridade_encoded'] = le.fit_transform(df['escolaridade'])
# Ex: Ensino Medio=0, Graduacao=1, Mestrado=2, Doutorado=3
```

## Pipeline sklearn com ColumnTransformer

```python
"""
Pipeline completo: separa tratamento de colunas numericas e categoricas.
Padrao recomendado para producao.
"""
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline

preprocessor = ColumnTransformer(transformers=[
    ('num', StandardScaler(), numerical_cols),
    ('cat', OneHotEncoder(handle_unknown='ignore', drop='first'), categorical_cols)
])

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', model)
])

# Treino e predicao consistentes
pipeline.fit(X_train, y_train)
predictions = pipeline.predict(X_test)
```

## Feature Hashing para Alta Cardinalidade

```python
"""
Feature Hashing -- reduz dimensionalidade via funcao hash.
Ideal quando one-hot geraria milhares de colunas.
"""
from sklearn.feature_extraction import FeatureHasher

hasher = FeatureHasher(n_features=10, input_type='string')
hashed = hasher.fit_transform(df['produto_id'].apply(lambda x: [x]))
```

## Reducao de Dimensionalidade Pos-Encoding

```python
"""
PCA apos one-hot para reduzir features esparsas.
Util quando one-hot gera muitas colunas e o modelo nao e baseado em arvore.
"""
from sklearn.decomposition import PCA
from sklearn.preprocessing import OneHotEncoder

encoder = OneHotEncoder(sparse_output=False)
encoded = encoder.fit_transform(df[categorical_cols])

pca = PCA(n_components=10)
reduced = pca.fit_transform(encoded)
```

## Decisao por Algoritmo

| Algoritmo | Encoding Recomendado |
|-----------|---------------------|
| Regressao Linear/Logistica | One-Hot (drop_first=True) |
| SVM | One-Hot |
| kNN | One-Hot |
| Decision Tree | Label Encoding OK |
| Random Forest | Label Encoding OK |
| XGBoost/LightGBM | Label Encoding OK (suporte nativo a categoricos) |
| Redes Neurais | One-Hot ou Embeddings |
| BERT/Transformers | Embeddings contextuais |

## Boas Praticas

1. **Especificar categorias explicitamente** para consistencia treino/teste
2. **Usar `handle_unknown='ignore'`** para categorias nao vistas em producao
3. **Agrupar categorias raras em "Outros"** antes do encoding
4. **Documentar estrategia de encoding** para reprodutibilidade
5. **`drop='first'` em modelos lineares** para evitar multicolinearidade
6. **Converter para `pd.Categorical`** antes de `get_dummies` (menor memoria)
7. **Usar `ColumnTransformer`** para separar tratamento numerico/categorico

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `sparse_output` | False | Retorna array denso (True para economia de memoria) |
| `handle_unknown` | 'error' | 'ignore' para categorias nao vistas |
| `drop` | None | 'first' para evitar multicolinearidade |
| `n_features` | 10 | Numero de colunas no Feature Hashing |
| `dtype` | int | Tipo dos valores no get_dummies |

## See Also

- [Encoding de Variaveis Categoricas](../concepts/categorical-encoding.md)
- [Feature Engineering](../concepts/feature-engineering.md)
- [Pipeline de Pre-processamento](../patterns/text-preprocessing-pipeline.md)
- [TF-IDF + SVM](../patterns/tfidf-svm-classifier.md)
