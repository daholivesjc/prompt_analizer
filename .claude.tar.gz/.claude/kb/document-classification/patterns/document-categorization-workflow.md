# Workflow Completo de Categorizacao de Documentos

> **Purpose**: Workflow end-to-end desde coleta de dados ate deploy do classificador
> **MCP Validated**: 2026-04-23

## When to Use

- Projeto novo de classificacao de documentos do zero
- Guia passo-a-passo para sistema de categorizacao
- Baseado no framework ML-TDCM (Ahmed et al., ISI 2025) e Neurocomputing 2025

## Implementation

```python
"""Workflow: coleta -> pre-processamento -> modelagem -> deploy."""

import os, json
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
import numpy as np, pandas as pd, joblib
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, f1_score
from sklearn.preprocessing import LabelEncoder


@dataclass
class ClassificationConfig:
    model_dir: str = "models/"
    max_features: int = 20000
    ngram_range: Tuple[int, int] = (1, 2)
    test_size: float = 0.2
    min_samples_per_class: int = 10
    confidence_threshold: float = 0.8


class DocumentCategorizationSystem:
    def __init__(self, config: ClassificationConfig = None):
        self.config = config or ClassificationConfig()
        self.pipeline = None
        self.label_encoder = LabelEncoder()
        self.metadata = {}

    def load_data(self, texts: List[str], labels: List[str]) -> Tuple:
        """Filtra classes com poucos exemplos."""
        counts = pd.Series(labels).value_counts()
        valid = counts[counts >= self.config.min_samples_per_class].index
        mask = [l in valid for l in labels]
        return [t for t, m in zip(texts, mask) if m], [l for l, m in zip(labels, mask) if m]

    def build_pipeline(self) -> Pipeline:
        svm = CalibratedClassifierCV(LinearSVC(C=1.0, max_iter=10000, class_weight='balanced'), cv=3)
        self.pipeline = Pipeline([
            ('tfidf', TfidfVectorizer(max_features=self.config.max_features,
                ngram_range=self.config.ngram_range, min_df=2, max_df=0.95, sublinear_tf=True)),
            ('clf', svm)
        ])
        return self.pipeline

    def train_and_evaluate(self, texts: List[str], labels: List[str]) -> Dict:
        y = self.label_encoder.fit_transform(labels)
        X_train, X_test, y_train, y_test = train_test_split(
            texts, y, test_size=self.config.test_size, stratify=y, random_state=42)
        if not self.pipeline:
            self.build_pipeline()
        self.pipeline.fit(X_train, y_train)
        y_pred = self.pipeline.predict(X_test)
        self.metadata = {
            'n_classes': len(self.label_encoder.classes_), 'n_train': len(X_train),
            'f1_macro': f1_score(y_test, y_pred, average='macro'),
            'classes': list(self.label_encoder.classes_)
        }
        return classification_report(y_test, y_pred,
            target_names=self.label_encoder.classes_, output_dict=True)

    def save(self, path: Optional[str] = None):
        path = path or self.config.model_dir
        os.makedirs(path, exist_ok=True)
        joblib.dump(self.pipeline, f"{path}/pipeline.joblib")
        joblib.dump(self.label_encoder, f"{path}/label_encoder.joblib")
        with open(f"{path}/metadata.json", 'w') as f:
            json.dump(self.metadata, f, indent=2, ensure_ascii=False)

    @classmethod
    def load(cls, path: str) -> 'DocumentCategorizationSystem':
        system = cls()
        system.pipeline = joblib.load(f"{path}/pipeline.joblib")
        system.label_encoder = joblib.load(f"{path}/label_encoder.joblib")
        with open(f"{path}/metadata.json") as f:
            system.metadata = json.load(f)
        return system

    def predict(self, texts: List[str]) -> List[Dict]:
        """Classifica com score de confianca e rejeicao."""
        probas = self.pipeline.predict_proba(texts)
        results = []
        for text, proba in zip(texts, probas):
            idx = proba.argmax()
            conf = proba[idx]
            results.append({
                'category': self.label_encoder.classes_[idx],
                'confidence': float(conf),
                'rejected': conf < self.config.confidence_threshold
            })
        return results
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `max_features` | 20000 | Features TF-IDF |
| `confidence_threshold` | 0.8 | Limiar para rejeicao |
| `min_samples_per_class` | 10 | Minimo de exemplos por classe |
| `test_size` | 0.2 | Fracao para teste |

## Example Usage

```python
config = ClassificationConfig(model_dir="models/doc_classifier", confidence_threshold=0.8)
system = DocumentCategorizationSystem(config)

# Carregar, treinar, salvar
texts, labels = system.load_data(all_texts, all_labels)
report = system.train_and_evaluate(texts, labels)
system.save()

# Producao
loaded = DocumentCategorizationSystem.load("models/doc_classifier")
results = loaded.predict(["Novo documento para classificar..."])
for r in results:
    status = "REJEITADO" if r['rejected'] else "OK"
    print(f"[{status}] {r['category']} ({r['confidence']:.2f})")
```

## See Also

- [Pipeline Pre-processamento](../patterns/text-preprocessing-pipeline.md)
- [TF-IDF + SVM](../patterns/tfidf-svm-classifier.md)
- [Classificacao Zero-Shot](../patterns/llm-zero-shot-classification.md)
