# Ensemble Stacking para Classificacao de Documentos

> **Purpose**: Combinar multiplos classificadores via stacking para maximizar precisao
> **MCP Validated**: 2026-04-23

## When to Use

- Necessidade de maximizar performance alem de modelos individuais
- Quando diferentes modelos capturam aspectos complementares do texto
- Competicoes ou cenarios onde fracao de ponto percentual importa
- Combinacao de SVM + K-NN reduz dependencia do numero de vizinhos (Wan et al., 2012)
- Metodos de ensemble melhoram tanto precisao quanto robustez

## Implementation

```python
"""
Ensemble Stacking para classificacao de documentos.

Stacking treina um meta-classificador sobre as predicoes de modelos base.
Cada modelo base captura padroes diferentes:
- SVM: fronteiras lineares de margem maxima
- Random Forest: interacoes nao-lineares entre features
- XGBoost: boosting com regularizacao
- Logistic Regression: probabilidades calibradas

O meta-classificador aprende a ponderar otimamente as saidas.
"""

import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.model_selection import cross_val_predict, StratifiedKFold
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report
from xgboost import XGBClassifier


class StackingTextClassifier(BaseEstimator, ClassifierMixin):
    """Meta-classificador com stacking para texto."""

    def __init__(self, max_features=20000, n_folds=5):
        self.max_features = max_features
        self.n_folds = n_folds
        self.tfidf = None
        self.base_models = None
        self.meta_model = None

    def _build_base_models(self):
        """Define modelos base com caracteristicas complementares."""
        return [
            ('svm', CalibratedClassifierCV(
                LinearSVC(C=1.0, max_iter=10000), cv=3
            )),
            ('rf', RandomForestClassifier(
                n_estimators=100, max_features='sqrt', n_jobs=-1
            )),
            ('xgb', XGBClassifier(
                n_estimators=200, max_depth=6, learning_rate=0.1,
                use_label_encoder=False, eval_metric='mlogloss'
            )),
            ('lr', LogisticRegression(
                C=1.0, max_iter=1000, solver='lbfgs'
            ))
        ]

    def fit(self, X_texts, y):
        """Treina ensemble completo."""
        # Vetorizar
        self.tfidf = TfidfVectorizer(
            max_features=self.max_features,
            ngram_range=(1, 2), sublinear_tf=True
        )
        X = self.tfidf.fit_transform(X_texts)

        # Gerar meta-features via cross-validation
        self.base_models = self._build_base_models()
        cv = StratifiedKFold(n_splits=self.n_folds, shuffle=True, random_state=42)

        meta_features = []
        for name, model in self.base_models:
            preds = cross_val_predict(model, X, y, cv=cv, method='predict_proba')
            meta_features.append(preds)

        # Treinar modelos base no dataset completo
        for name, model in self.base_models:
            model.fit(X, y)

        # Treinar meta-classificador
        meta_X = np.hstack(meta_features)
        self.meta_model = LogisticRegression(C=1.0, max_iter=1000)
        self.meta_model.fit(meta_X, y)

        self.classes_ = np.unique(y)
        return self

    def predict(self, X_texts):
        """Classifica novos documentos."""
        X = self.tfidf.transform(X_texts)

        meta_features = []
        for name, model in self.base_models:
            preds = model.predict_proba(X)
            meta_features.append(preds)

        meta_X = np.hstack(meta_features)
        return self.meta_model.predict(meta_X)

    def predict_proba(self, X_texts):
        """Retorna probabilidades calibradas."""
        X = self.tfidf.transform(X_texts)

        meta_features = []
        for name, model in self.base_models:
            preds = model.predict_proba(X)
            meta_features.append(preds)

        meta_X = np.hstack(meta_features)
        return self.meta_model.predict_proba(meta_X)
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `max_features` | 20000 | Features TF-IDF |
| `n_folds` | 5 | Folds para meta-features |
| `base_models` | SVM+RF+XGB+LR | Modelos base complementares |
| `meta_model` | LogisticRegression | Meta-classificador |

## Example Usage

```python
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    documents, labels, test_size=0.2, stratify=labels, random_state=42
)

# Treinar ensemble
ensemble = StackingTextClassifier(max_features=20000, n_folds=5)
ensemble.fit(X_train, y_train)

# Avaliar
y_pred = ensemble.predict(X_test)
print(classification_report(y_test, y_pred))

# Probabilidades para decisoes com threshold
probas = ensemble.predict_proba(X_test)
confident = probas.max(axis=1) > 0.8  # filtrar predicoes confiantes
```

## Voting Ensemble (Alternativa Simples)

```python
from sklearn.ensemble import VotingClassifier

voting = VotingClassifier(
    estimators=[
        ('svm', Pipeline([('tfidf', TfidfVectorizer()), ('clf', LinearSVC())])),
        ('rf', Pipeline([('tfidf', TfidfVectorizer()), ('clf', RandomForestClassifier())])),
        ('xgb', Pipeline([('tfidf', TfidfVectorizer()), ('clf', XGBClassifier())]))
    ],
    voting='soft'  # requer predict_proba
)
```

## See Also

- [Metodos de Arvores e Ensembles](../concepts/tree-ensemble-methods.md)
- [TF-IDF + SVM](../patterns/tfidf-svm-classifier.md)
- [Pipeline de Avaliacao](../patterns/model-evaluation-pipeline.md)
