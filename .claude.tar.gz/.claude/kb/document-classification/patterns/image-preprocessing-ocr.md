# Pre-processamento de Imagem para OCR

> **Purpose**: Tecnicas de pre-processamento para melhorar qualidade do OCR com OpenCV
> **MCP Validated**: 2026-04-23

## When to Use

- Documentos escaneados com baixa qualidade ou ruido
- Imagens com iluminacao irregular ou sombras
- Textos com rotacao (skew) ou inclinacao
- Fontes muito finas ou muito grossas
- Documentos antigos com degradacao
- Quando a confianca do OCR esta abaixo de 70%

## Implementation

```python
import cv2
import numpy as np
from typing import Optional
from dataclasses import dataclass


@dataclass
class PreprocessConfig:
    """Configuracao de pre-processamento para OCR."""
    grayscale: bool = True
    denoise: bool = True
    binarize: bool = True
    deskew: bool = False
    sharpen: bool = False
    dilate: bool = False
    erode: bool = False
    resize_factor: Optional[float] = None  # Ex: 2.0 para dobrar


class ImagePreprocessor:
    """Pre-processador de imagens para OCR."""

    def __init__(self, config: Optional[PreprocessConfig] = None):
        self.config = config or PreprocessConfig()

    def process(self, image_path: str) -> np.ndarray:
        """Aplica pipeline completo de pre-processamento."""
        img = cv2.imread(image_path)
        if img is None:
            raise FileNotFoundError(f"Imagem nao encontrada: {image_path}")

        if self.config.resize_factor:
            img = self._resize(img, self.config.resize_factor)
        if self.config.grayscale:
            img = self._to_grayscale(img)
        if self.config.denoise:
            img = self._denoise(img)
        if self.config.sharpen:
            img = self._sharpen(img)
        if self.config.binarize:
            img = self._binarize(img)
        if self.config.deskew:
            img = self._deskew(img)
        if self.config.dilate:
            img = self._dilate(img)
        if self.config.erode:
            img = self._erode(img)
        return img

    @staticmethod
    def _to_grayscale(img: np.ndarray) -> np.ndarray:
        """Converte para escala de cinza. Remove variacoes de cor."""
        if len(img.shape) == 3:
            return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        return img

    @staticmethod
    def _denoise(img: np.ndarray) -> np.ndarray:
        """Reduz ruido com filtro mediano. Bom para documentos escaneados."""
        return cv2.medianBlur(img, 3)

    @staticmethod
    def _binarize(img: np.ndarray) -> np.ndarray:
        """Binariza com threshold adaptativo. Separa texto do fundo."""
        if len(img.shape) == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        return cv2.adaptiveThreshold(
            img, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY,
            blockSize=11,
            C=2
        )

    @staticmethod
    def _sharpen(img: np.ndarray) -> np.ndarray:
        """Aumenta nitidez com filtro Laplaciano. Para imagens desfocadas."""
        kernel = np.array([[0, -1, 0],
                           [-1,  5, -1],
                           [0, -1, 0]])
        return cv2.filter2D(img, -1, kernel)

    @staticmethod
    def _deskew(img: np.ndarray) -> np.ndarray:
        """Corrige inclinacao do texto (skew correction)."""
        if len(img.shape) == 3:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        else:
            gray = img
        coords = np.column_stack(np.where(gray > 0))
        if len(coords) < 10:
            return img
        angle = cv2.minAreaRect(coords)[-1]
        if angle < -45:
            angle = -(90 + angle)
        else:
            angle = -angle
        (h, w) = img.shape[:2]
        center = (w // 2, h // 2)
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        return cv2.warpAffine(img, M, (w, h),
                              flags=cv2.INTER_CUBIC,
                              borderMode=cv2.BORDER_REPLICATE)

    @staticmethod
    def _dilate(img: np.ndarray) -> np.ndarray:
        """Dilata texto fino para tornar mais visivel ao OCR."""
        kernel = np.ones((2, 2), np.uint8)
        return cv2.dilate(img, kernel, iterations=1)

    @staticmethod
    def _erode(img: np.ndarray) -> np.ndarray:
        """Erode texto grosso para melhorar separacao de caracteres."""
        kernel = np.ones((2, 2), np.uint8)
        return cv2.erode(img, kernel, iterations=1)

    @staticmethod
    def _resize(img: np.ndarray, factor: float) -> np.ndarray:
        """Redimensiona imagem. Ampliar melhora OCR em imagens pequenas."""
        h, w = img.shape[:2]
        return cv2.resize(img, (int(w * factor), int(h * factor)),
                          interpolation=cv2.INTER_CUBIC)
```

## Guia de Tecnicas por Problema

| Problema | Tecnica | Parametro Chave |
|----------|---------|-----------------|
| Imagem colorida | Grayscale | `cv2.COLOR_BGR2GRAY` |
| Ruido/granulacao | Denoise (median blur) | kernel_size=3 ou 5 |
| Iluminacao irregular | Binarizacao adaptativa | blockSize=11, C=2 |
| Texto desfocado | Sharpen (Laplaciano) | Cuidado: pode amplificar ruido |
| Documento inclinado | Deskew | `minAreaRect` + `warpAffine` |
| Texto muito fino | Dilatacao | kernel 2x2, iterations=1 |
| Texto muito grosso | Erosao | kernel 2x2, iterations=1 |
| Imagem muito pequena | Resize 2x-3x | `INTER_CUBIC` |
| BGR do OpenCV | Converter para RGB | Tesseract espera RGB |

## Example Usage

```python
import pytesseract

# Configuracao para documentos escaneados com baixa qualidade
config = PreprocessConfig(
    grayscale=True,
    denoise=True,
    binarize=True,
    deskew=True,
    resize_factor=2.0
)
preprocessor = ImagePreprocessor(config)

# Pre-processar e executar OCR
processed_img = preprocessor.process('nota_fiscal_escaneada.png')
text = pytesseract.image_to_string(processed_img, lang='por', config='--oem 1 --psm 3')
print(text)

# Salvar imagem pre-processada para debug
cv2.imwrite('/tmp/preprocessed_debug.png', processed_img)
```

## Ordem Recomendada de Aplicacao

```text
1. Resize (se imagem < 300 DPI)
2. Grayscale
3. Denoise
4. Sharpen (opcional, so se desfocada)
5. Binarize
6. Deskew
7. Dilate/Erode (opcional, conforme espessura do texto)
```

## See Also

- [Pipeline OCR](tesseract-ocr-pipeline.md) -- Pipeline completo de OCR
- [Tesseract Engine](../concepts/tesseract-engine.md) -- Configuracao do engine
- [OCR para Classificacao](ocr-to-classification.md) -- Integracao com classificacao
