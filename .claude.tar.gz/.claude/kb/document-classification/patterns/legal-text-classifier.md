# Classificador de Texto Juridico Brasileiro

> **Purpose**: Pipeline completo para classificar documentos juridicos com pre-filtro e SVM
> **MCP Validated**: 2026-04-23
> **Fonte**: Lopes, M.H. (2019). Classificadores Textuais de Dados Juridicos. TCC, UNESP Bauru.

## When to Use

- Classificar publicacoes juridicas em categorias de Direito Empresarial
- Determinar status de processos judiciais a partir de andamentos
- Volume alto de documentos juridicos (3K-550K/mes) exigindo automacao
- Texto em portugues brasileiro com vocabulario juridico formal
- Baseline antes de abordagens mais complexas (BERT, LLM)

## Pre-Classificador por Sentencas-Chave

```python
"""
Pre-filtro por sentencas-chave (Tabela 3 de Lopes, 2019).
Reduz escopo de 100% para ~2.5% dos documentos relevantes.
"""
import re, unicodedata
from typing import Optional

SENTENCAS_CHAVE = {
    "insolvencia_civil": ["declaro a insolvencia", "declaracao de insolvencia"],
    "decreto_falencia": ["decretacao de falencia", "decretada a falencia"],
    "convolacao": ["convolacao da recuperacao judicial em falencia"],
    "extensao_falencia": ["extensao dos efeitos da falencia"],
    "recuperacao_judicial": ["processamento da recuperacao judicial"],
    "recuperacao_extrajudicial": ["decretada a liquidacao extrajudicial"],
}
# Sentencas compostas (todas as palavras devem estar presentes)
SENTENCAS_COMPOSTAS = {
    "convolacao": [["convolacao", "recuperacao judicial", "falencia"]],
    "extensao_falencia": [["extensao dos efeitos", "falencia", "recuperacao judicial"]],
    "recuperacao_extrajudicial": [["recuperacao extrajudicial", "decretad", "falencia"]],
}

def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower().strip())
    return re.sub(r"\s+", " ", text)

def pre_classify(text: str) -> Optional[str]:
    """Classifica por sentencas-chave. Retorna categoria ou None."""
    normalized = normalize_text(text)
    for category, phrases in SENTENCAS_CHAVE.items():
        if any(p in normalized for p in phrases):
            return category
    for category, word_groups in SENTENCAS_COMPOSTAS.items():
        for words in word_groups:
            if all(w in normalized for w in words):
                return category
    return None
```

## Pipeline SVM para Status de Processos

```python
"""
CountVectorizer + TfidfTransformer + SVM para status de processos.
Referencia: SVM 83.38% accuracy, NB 66.11% (Lopes, 2019).
"""
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.svm import LinearSVC
from sklearn.pipeline import Pipeline
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

STATUS_PROCESSOS = [
    "aguarda_partes", "arquivado", "ativo", "baixado", "cartorio",
    "concluso", "extinto", "grau_recurso", "instancia_superior",
    "julgado", "suspenso",
]

def build_legal_classifier(max_features=20000, C=1.0, class_weight="balanced"):
    """Pipeline otimizado para texto juridico brasileiro."""
    svm = CalibratedClassifierCV(
        LinearSVC(C=C, max_iter=10000, class_weight=class_weight),
        cv=3, method="sigmoid",
    )
    return Pipeline([
        ("count", CountVectorizer(
            max_features=max_features, ngram_range=(1, 2),
            min_df=2, max_df=0.95, strip_accents="unicode",
        )),
        ("tfidf", TfidfTransformer(sublinear_tf=True)),
        ("clf", svm),
    ])

def train_legal_classifier(texts, labels, test_size=0.2):
    """Treina e avalia o classificador juridico."""
    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=test_size, stratify=labels, random_state=42,
    )
    pipeline = build_legal_classifier()
    pipeline.fit(X_train, y_train)
    print(classification_report(y_test, pipeline.predict(X_test), zero_division=0))
    return pipeline
```

## Estrategias para Desbalanceamento

```python
"""Tecnicas para classes minoritarias (recall < 0.02 sem tratamento)."""
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from collections import Counter

def build_balanced_pipeline():
    """Pipeline com SMOTE (requer: pip install imbalanced-learn)."""
    return ImbPipeline([
        ("tfidf", TfidfVectorizer(max_features=20000, ngram_range=(1, 2),
                                  sublinear_tf=True, strip_accents="unicode")),
        ("smote", SMOTE(random_state=42, k_neighbors=3)),
        ("clf", LinearSVC(C=1.0, max_iter=10000, class_weight="balanced")),
    ])

def filter_rare_classes(texts, labels, min_samples=1000):
    """Remove classes com menos de min_samples (sugestao: Lopes, 2019)."""
    valid = {c for c, n in Counter(labels).items() if n >= min_samples}
    filtered = [(t, l) for t, l in zip(texts, labels) if l in valid]
    return zip(*filtered) if filtered else ([], [])
```

## Configuration

| Parametro | Valor | Justificativa |
|-----------|-------|---------------|
| `max_features` | 20000 | Equilibrio entre cobertura e performance |
| `ngram_range` | (1, 2) | Bigramas capturam termos compostos juridicos |
| `class_weight` | balanced | Essencial para classes minoritarias |
| `C` | 1.0 | Regularizacao padrao, ajustar via GridSearchCV |
| `min_df` | 2 | Remove termos unicos (typos, nomes proprios) |
| `sublinear_tf` | True | log(1+tf) para suavizar frequencias |

## Benchmarks de Referencia (Lopes, 2019)

| Tarefa | Algoritmo | Accuracy | Dataset |
|--------|-----------|----------|---------|
| Status processos | SVM | 83.38% | 15.698 processos |
| Status processos | Naive Bayes | 66.11% | 15.698 processos |
| Publicacoes (sup.) | OneVsRest SVM | 38.75% | 18 amostras(!) |
| Publicacoes (sup.) | Naive Bayes | 28.75% | 18 amostras(!) |

## See Also

- [Classificacao Juridica (concept)](../concepts/legal-document-classification.md)
- [Padrao TF-IDF + SVM](tfidf-svm-classifier.md)
- [Pipeline Pre-processamento](text-preprocessing-pipeline.md)
- [Pipeline de Avaliacao](model-evaluation-pipeline.md)
- [Metodos Nao-Supervisionados](../concepts/unsupervised-methods.md)
