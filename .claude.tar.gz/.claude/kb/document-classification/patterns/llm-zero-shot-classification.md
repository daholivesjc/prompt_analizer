# Classificacao Zero-Shot com LLMs

> **Purpose**: Classificar documentos sem dados de treinamento usando LLMs e prompts
> **MCP Validated**: 2026-04-23

## When to Use

- Zero dados rotulados disponiveis
- Categorias mudam frequentemente (sem retreino)
- Prototipacao rapida antes de coletar dados
- Classificacao exploratoria para definir taxonomia
- Complementar com LangChain para sumarizacao e categorizacao (AI Agents and Applications)

## Implementation

```python
"""
Classificacao zero-shot de documentos usando LLMs.

Abordagens:
1. Pipeline HuggingFace com modelos NLI (BART, DeBERTa)
2. Prompt engineering com APIs de LLMs (Gemini, GPT)
3. LangChain para workflows complexos de categorizacao
"""

from typing import List, Dict, Optional
import json


# ============================================================
# Abordagem 1: HuggingFace Zero-Shot Pipeline (local)
# ============================================================
def classify_zero_shot_hf(
    texts: List[str],
    candidate_labels: List[str],
    model_name: str = "facebook/bart-large-mnli",
    multi_label: bool = False
) -> List[Dict]:
    """
    Classificacao zero-shot com modelos NLI do HuggingFace.
    Nao requer GPU para modelos menores.
    """
    from transformers import pipeline

    classifier = pipeline(
        "zero-shot-classification",
        model=model_name,
        device=-1  # CPU; use 0 para GPU
    )

    results = classifier(
        texts,
        candidate_labels,
        multi_label=multi_label,
        batch_size=8
    )

    return [
        {"text": r["sequence"][:100], "label": r["labels"][0], "score": r["scores"][0]}
        for r in results
    ]


# ============================================================
# Abordagem 2: LLM via API (Gemini/OpenAI)
# ============================================================
def classify_with_llm(
    text: str,
    categories: List[str],
    model: str = "gemini-2.5-flash"
) -> Dict:
    """
    Classificacao via API de LLM com structured output.
    Usa prompt engineering para classificacao confiavel.
    """
    from google import genai

    client = genai.Client(vertexai=True, project="PROJECT_ID", location="us-central1")

    prompt = f"""Classifique o documento abaixo em UMA das seguintes categorias:
{json.dumps(categories, ensure_ascii=False)}

Documento:
{text[:3000]}

Responda APENAS com um JSON no formato:
{{"categoria": "nome_da_categoria", "confianca": 0.95, "justificativa": "breve explicacao"}}
"""

    response = client.models.generate_content(
        model=model,
        contents=prompt,
        config={"response_mime_type": "application/json"}
    )

    return json.loads(response.text)


# ============================================================
# Abordagem 3: LangChain para Batch Classification
# ============================================================
def classify_batch_langchain(
    documents: List[str],
    categories: List[str],
    model_name: str = "gemini-2.5-flash"
) -> List[Dict]:
    """
    Classificacao em lote usando LangChain com MapReduce
    para documentos que excedem o contexto do modelo.
    """
    from langchain_google_genai import ChatGoogleGenerativeAI
    from langchain.prompts import PromptTemplate
    from langchain.chains import LLMChain

    llm = ChatGoogleGenerativeAI(model=model_name, temperature=0)

    template = PromptTemplate(
        input_variables=["text", "categories"],
        template="""Classifique o documento na categoria mais adequada.

Categorias disponiveis: {categories}

Documento: {text}

Responda com JSON: {{"categoria": "...", "confianca": 0.0-1.0}}"""
    )

    chain = LLMChain(llm=llm, prompt=template)

    results = []
    for doc in documents:
        result = chain.invoke({
            "text": doc[:3000],
            "categories": ", ".join(categories)
        })
        results.append(json.loads(result["text"]))

    return results
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `model_name` (HF) | bart-large-mnli | Modelo NLI para zero-shot |
| `multi_label` | False | Permitir multiplas categorias |
| `model` (API) | gemini-2.5-flash | LLM para classificacao |
| `temperature` | 0 | Determinismo na classificacao |
| `max_text_length` | 3000 | Truncar documento para contexto |

## Modelos Zero-Shot Recomendados

| Modelo | Tipo | Tamanho | Qualidade | Custo |
|--------|------|---------|-----------|-------|
| bart-large-mnli | NLI local | 400M | Boa | Gratis |
| deberta-v3-large-mnli | NLI local | 304M | Muito boa | Gratis |
| gemini-2.5-flash | API | N/A | Excelente | $0.15/1M tokens |
| gemini-2.5-flash-lite | API | N/A | Boa | $0.10/1M tokens |

## Example Usage

```python
categories = ["Fatura", "Contrato", "Relatorio", "Nota Fiscal", "Correspondencia"]

# Zero-shot local (sem API)
results = classify_zero_shot_hf(
    texts=["Este documento refere-se ao pagamento..."],
    candidate_labels=categories
)
print(results)  # [{"label": "Fatura", "score": 0.87}]

# Com LLM via API
result = classify_with_llm(
    text="Contrato de prestacao de servicos...",
    categories=categories
)
print(result)  # {"categoria": "Contrato", "confianca": 0.95}
```

## See Also

- [Deep Learning NLP](../concepts/deep-learning-nlp.md)
- [Workflow de Categorizacao](../patterns/document-categorization-workflow.md)
- [Pipeline de Avaliacao](../patterns/model-evaluation-pipeline.md)
