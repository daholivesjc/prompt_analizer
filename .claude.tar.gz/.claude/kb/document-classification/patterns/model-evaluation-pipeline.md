# Pipeline de Avaliacao e Comparacao de Modelos

> **Purpose**: Protocolo padronizado para avaliar e comparar classificadores de documentos
> **MCP Validated**: 2026-04-23

## When to Use

- Comparar multiplos algoritmos de classificacao no mesmo dataset
- Selecionar o melhor modelo para producao
- Avaliar impacto de diferentes representacoes textuais
- Gerar relatorio completo com metricas padrao (Ahmed et al., ISI 2025)
- Detectar overfitting e avaliar generalizacao

## Implementation

```python
"""
Pipeline de avaliacao para classificadores de documentos.

Baseado nas melhores praticas dos papers:
- ISI 2025: accuracy, precision, recall, F1-score
- Thaoroijam 2014: micro/macro averaging, contingency tables
- Neurocomputing 2025: PRE, REC, COV para sistemas com rejeicao
"""

import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.model_selection import (
    StratifiedKFold, cross_validate, learning_curve
)
from sklearn.metrics import (
    classification_report, confusion_matrix,
    f1_score, accuracy_score, roc_auc_score
)
import matplotlib.pyplot as plt


@dataclass
class ModelResult:
    """Resultado de avaliacao de um modelo."""
    name: str
    accuracy: float
    f1_macro: float
    f1_weighted: float
    precision_macro: float
    recall_macro: float
    train_time: float
    inference_time: float
    cv_scores: np.ndarray


def evaluate_model(
    name: str,
    pipeline,
    X_train, y_train,
    X_test, y_test,
    n_folds: int = 5
) -> ModelResult:
    """Avalia um modelo com cross-validation e metricas completas."""

    # Cross-validation no treino
    cv = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
    cv_results = cross_validate(
        pipeline, X_train, y_train, cv=cv,
        scoring=['accuracy', 'f1_macro', 'precision_macro', 'recall_macro'],
        return_train_score=True
    )

    # Treinar no dataset completo e avaliar
    t0 = time.time()
    pipeline.fit(X_train, y_train)
    train_time = time.time() - t0

    t0 = time.time()
    y_pred = pipeline.predict(X_test)
    inference_time = time.time() - t0

    return ModelResult(
        name=name,
        accuracy=accuracy_score(y_test, y_pred),
        f1_macro=f1_score(y_test, y_pred, average='macro'),
        f1_weighted=f1_score(y_test, y_pred, average='weighted'),
        precision_macro=cv_results['test_precision_macro'].mean(),
        recall_macro=cv_results['test_recall_macro'].mean(),
        train_time=train_time,
        inference_time=inference_time,
        cv_scores=cv_results['test_f1_macro']
    )


def compare_models(
    models: List[tuple],  # [(nome, pipeline), ...]
    X_train, y_train,
    X_test, y_test,
    class_names: Optional[List[str]] = None
) -> pd.DataFrame:
    """Compara multiplos modelos e gera relatorio."""

    results = []
    for name, pipeline in models:
        print(f"Avaliando {name}...")
        result = evaluate_model(
            name, pipeline, X_train, y_train, X_test, y_test
        )
        results.append(result)

        # Classification report detalhado
        pipeline.fit(X_train, y_train)
        y_pred = pipeline.predict(X_test)
        print(f"\n--- {name} ---")
        print(classification_report(y_test, y_pred, target_names=class_names))

    # Tabela comparativa
    df = pd.DataFrame([{
        'Modelo': r.name,
        'Accuracy': f"{r.accuracy:.4f}",
        'F1-macro': f"{r.f1_macro:.4f}",
        'F1-weighted': f"{r.f1_weighted:.4f}",
        'CV F1 (mean)': f"{r.cv_scores.mean():.4f}",
        'CV F1 (std)': f"{r.cv_scores.std():.4f}",
        'Treino (s)': f"{r.train_time:.2f}",
        'Inferencia (s)': f"{r.inference_time:.4f}"
    } for r in results])

    return df
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `n_folds` | 5 | Folds para cross-validation |
| `scoring` | f1_macro | Metrica principal de selecao |
| `stratify` | True | Manter proporcao de classes |
| `random_state` | 42 | Reproducibilidade |

## Example Usage

```python
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier

# Definir modelos para comparacao
models = [
    ("Naive Bayes", Pipeline([
        ('tfidf', TfidfVectorizer(max_features=20000)),
        ('clf', MultinomialNB())
    ])),
    ("SVM Linear", Pipeline([
        ('tfidf', TfidfVectorizer(max_features=20000, ngram_range=(1,2))),
        ('clf', LinearSVC(C=1.0))
    ])),
    ("Random Forest", Pipeline([
        ('tfidf', TfidfVectorizer(max_features=15000)),
        ('clf', RandomForestClassifier(n_estimators=100))
    ])),
    ("XGBoost", Pipeline([
        ('tfidf', TfidfVectorizer(max_features=20000)),
        ('clf', XGBClassifier(n_estimators=200, eval_metric='mlogloss'))
    ]))
]

# Comparar
comparison = compare_models(models, X_train, y_train, X_test, y_test)
print(comparison.to_string(index=False))
```

## See Also

- [Metricas de Avaliacao](../concepts/evaluation-metrics.md)
- [Ensemble Stacking](../patterns/ensemble-stacking.md)
- [TF-IDF + SVM](../patterns/tfidf-svm-classifier.md)
