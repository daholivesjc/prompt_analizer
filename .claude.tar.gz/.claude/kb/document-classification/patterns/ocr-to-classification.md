# Pipeline Integrado: OCR para Classificacao de Documentos

> **Purpose**: Workflow completo imagem -> OCR -> texto limpo -> features -> classificador
> **MCP Validated**: 2026-04-23

## When to Use

- Classificar documentos fisicos digitalizados (faturas, contratos, recibos, notas fiscais)
- Pipeline end-to-end: imagem escaneada ate a categoria do documento
- Processar lotes de documentos com OCR + classificacao automatica
- Integrar extracao de texto com modelos de ML/NLP ja existentes

## Architecture

```text
Imagem/PDF -> Pre-proc. Imagem -> OCR -> Limpeza OCR -> NLP -> TF-IDF -> Classificador -> Categoria
                (grayscale,       (Tesseract)  (artefatos)  (stopwords,  (features)   (SVM/XGBoost)
                 binarize,                                   stemming)
                 deskew)
```

## Implementation

```python
import cv2
import pytesseract
import re
import unicodedata
from pathlib import Path
from typing import List, Tuple, Optional
from dataclasses import dataclass

import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
import joblib


@dataclass
class ClassificationResult:
    """Resultado da classificacao de documento."""
    source_file: str
    category: str
    confidence: float
    ocr_confidence: float
    extracted_text: str
    text_length: int


class DocumentClassificationPipeline:
    """Pipeline completo: imagem -> OCR -> classificacao."""

    def __init__(self, model_path: Optional[str] = None,
                 lang: str = 'por', min_ocr_confidence: float = 50.0):
        self.lang = lang
        self.min_ocr_confidence = min_ocr_confidence
        self.model = None
        if model_path:
            self.model = joblib.load(model_path)

    def process_document(self, image_path: str) -> ClassificationResult:
        """Pipeline completo para um documento."""
        # Etapa 1-2: Pre-processamento de imagem
        processed_img = self._preprocess_image(image_path)

        # Etapa 3: OCR
        raw_text, ocr_conf = self._extract_text(processed_img)

        # Verificar qualidade do OCR
        if ocr_conf < self.min_ocr_confidence:
            return ClassificationResult(
                source_file=image_path,
                category='LOW_OCR_CONFIDENCE',
                confidence=0.0,
                ocr_confidence=ocr_conf,
                extracted_text=raw_text,
                text_length=len(raw_text)
            )

        # Etapa 4: Limpeza de artefatos OCR
        clean_text = self._clean_ocr_text(raw_text)

        # Etapa 5-7: Classificacao (NLP + features + modelo)
        if self.model is None:
            raise ValueError("Modelo nao carregado. Use model_path no init.")

        category = self.model.predict([clean_text])[0]

        # Confianca via decision_function (SVM) ou predict_proba
        if hasattr(self.model, 'decision_function'):
            scores = self.model.decision_function([clean_text])
            conf = float(np.max(np.abs(scores)))
        else:
            conf = float(np.max(self.model.predict_proba([clean_text])))

        return ClassificationResult(
            source_file=image_path,
            category=category,
            confidence=conf,
            ocr_confidence=ocr_conf,
            extracted_text=clean_text,
            text_length=len(clean_text)
        )

    def _preprocess_image(self, image_path: str) -> np.ndarray:
        """Pre-processamento de imagem para OCR."""
        img = cv2.imread(image_path)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        denoised = cv2.medianBlur(gray, 3)
        binary = cv2.adaptiveThreshold(
            denoised, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY, 11, 2
        )
        return binary

    def _extract_text(self, img: np.ndarray) -> Tuple[str, float]:
        """Extrai texto e calcula confianca media."""
        from pytesseract import Output

        text = pytesseract.image_to_string(
            img, lang=self.lang, config='--oem 1 --psm 3'
        )
        data = pytesseract.image_to_data(
            img, lang=self.lang, config='--oem 1 --psm 3',
            output_type=Output.DICT
        )
        confs = [int(c) for c in data['conf'] if int(c) > 0]
        avg_conf = sum(confs) / len(confs) if confs else 0.0
        return text.strip(), avg_conf

    @staticmethod
    def _clean_ocr_text(text: str) -> str:
        """Limpa artefatos tipicos de OCR."""
        # Normalizar unicode
        text = unicodedata.normalize('NFKC', text)
        # Remover caracteres de controle
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text)
        # Corrigir espacos multiplos
        text = re.sub(r' {2,}', ' ', text)
        # Corrigir quebras de linha excessivas
        text = re.sub(r'\n{3,}', '\n\n', text)
        # Remover linhas com apenas caracteres especiais (artefatos)
        lines = text.split('\n')
        clean_lines = [
            l for l in lines
            if len(re.sub(r'[^a-zA-ZÀ-ú0-9]', '', l)) > 2
            or l.strip() == ''
        ]
        return '\n'.join(clean_lines).strip()

    def process_batch(self, image_paths: List[str]) -> List[ClassificationResult]:
        """Processa lote de documentos."""
        return [self.process_document(p) for p in image_paths]


def train_document_classifier(
    texts: List[str], labels: List[str],
    save_path: str = 'document_classifier.joblib'
) -> Pipeline:
    """Treina classificador para documentos OCR."""
    pipeline = Pipeline([
        ('tfidf', TfidfVectorizer(
            max_features=15000, ngram_range=(1, 2),
            min_df=2, max_df=0.95, sublinear_tf=True
        )),
        ('clf', LinearSVC(C=1.0, max_iter=10000))
    ])
    pipeline.fit(texts, labels)
    joblib.dump(pipeline, save_path)
    return pipeline
```

## Example Usage

```python
# Treinar e classificar documentos escaneados
model = train_document_classifier(train_texts, train_labels, 'clf.joblib')
pipeline = DocumentClassificationPipeline(model_path='clf.joblib', lang='por')
result = pipeline.process_document('documento_escaneado.png')
print(f"{result.category} (OCR: {result.ocr_confidence:.0f}%)")
```

## See Also

- [Pre-processamento de Imagem](image-preprocessing-ocr.md) -- Etapa 2 do pipeline
- [Pipeline OCR](tesseract-ocr-pipeline.md) -- Etapa 3 do pipeline
- [Pre-processamento de Texto](text-preprocessing-pipeline.md) -- Etapa 5 do pipeline
- [TF-IDF + SVM](tfidf-svm-classifier.md) -- Etapa 7 (classificador classico)
- [BERT Fine-tuning](bert-fine-tuning.md) -- Etapa 7 (classificador deep learning)
- [Representacao Textual](../concepts/text-representation.md) -- Etapa 6 (features)
