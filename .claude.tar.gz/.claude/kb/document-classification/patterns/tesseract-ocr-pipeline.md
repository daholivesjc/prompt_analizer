# Pipeline OCR com Tesseract (pytesseract e tesserocr)

> **Purpose**: Pipeline completo de OCR usando pytesseract e tesserocr com exemplos funcionais
> **MCP Validated**: 2026-04-23

## When to Use

- Extrair texto de documentos escaneados (faturas, notas fiscais, recibos)
- Converter PDFs escaneados em texto pesquisavel
- Preprocessar texto para pipeline de classificacao de documentos
- Processar lotes de imagens com necessidade de performance

## Implementation com pytesseract

```python
import cv2
import pytesseract
from pytesseract import Output
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass


@dataclass
class OCRResult:
    """Resultado de OCR com texto e metadados."""
    text: str
    confidence: float
    words: List[Dict]
    source_file: str


class TesseractOCR:
    """Pipeline OCR reutilizavel com pytesseract."""

    def __init__(self, lang: str = 'por', oem: int = 1, psm: int = 3,
                 tessdata_dir: Optional[str] = None):
        self.lang = lang
        self.config = f'--oem {oem} --psm {psm}'
        if tessdata_dir:
            self.config += f' --tessdata-dir {tessdata_dir}'

    def extract_text(self, image_path: str) -> OCRResult:
        """Extrai texto de uma imagem com metadados de confianca."""
        img = cv2.imread(image_path)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        # Extrair texto
        text = pytesseract.image_to_string(
            img_rgb, lang=self.lang, config=self.config
        )

        # Extrair dados detalhados (bounding boxes + confianca)
        data = pytesseract.image_to_data(
            img_rgb, lang=self.lang, config=self.config,
            output_type=Output.DICT
        )

        # Filtrar palavras com confianca > 0
        words = []
        for i in range(len(data['text'])):
            if int(data['conf'][i]) > 0 and data['text'][i].strip():
                words.append({
                    'text': data['text'][i],
                    'conf': int(data['conf'][i]),
                    'bbox': (data['left'][i], data['top'][i],
                             data['width'][i], data['height'][i])
                })

        avg_conf = (sum(w['conf'] for w in words) / len(words)
                    if words else 0.0)

        return OCRResult(
            text=text.strip(),
            confidence=avg_conf,
            words=words,
            source_file=image_path
        )

    def extract_from_pdf(self, pdf_path: str,
                         output_dir: str = '/tmp/ocr_pages') -> List[OCRResult]:
        """Extrai texto de PDF escaneado (cada pagina vira imagem)."""
        from pdf2image import convert_from_path

        Path(output_dir).mkdir(parents=True, exist_ok=True)
        pages = convert_from_path(pdf_path, output_folder=output_dir, fmt='png')

        results = []
        for i, page in enumerate(pages):
            page_path = f'{output_dir}/page_{i}.png'
            page.save(page_path)
            results.append(self.extract_text(page_path))
        return results

    def to_searchable_pdf(self, image_path: str, output_path: str) -> None:
        """Converte imagem em PDF pesquisavel."""
        img = cv2.imread(image_path)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        pdf_bytes = pytesseract.image_to_pdf_or_hocr(
            img_rgb, lang=self.lang, config=self.config
        )
        with open(output_path, 'w+b') as f:
            f.write(bytearray(pdf_bytes))
```

## Implementation com tesserocr (Alto Desempenho)

```python
from tesserocr import PyTessBaseAPI, PSM, OEM, RIL
from PIL import Image
from typing import List
from concurrent.futures import ThreadPoolExecutor


def ocr_batch_tesserocr(image_paths: List[str], lang: str = 'por',
                        max_workers: int = 4) -> List[str]:
    """OCR em lote com tesserocr — libera GIL, suporta threading real."""
    def process_image(path: str) -> str:
        with PyTessBaseAPI(lang=lang, oem=OEM.LSTM_ONLY,
                           psm=PSM.AUTO) as api:
            api.SetImageFile(path)
            return api.GetUTF8Text().strip()

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(process_image, image_paths))
    return results


def ocr_with_confidence(image_path: str, lang: str = 'por') -> dict:
    """OCR com confianca por palavra usando tesserocr."""
    with PyTessBaseAPI(lang=lang, oem=OEM.LSTM_ONLY, psm=PSM.AUTO) as api:
        api.SetImageFile(image_path)
        text = api.GetUTF8Text()
        confidences = api.AllWordConfidences()
        mean_conf = api.MeanTextConf()

    return {
        'text': text.strip(),
        'word_confidences': confidences,
        'mean_confidence': mean_conf
    }


def ocr_with_bboxes(image_path: str, lang: str = 'por') -> list:
    """Extrai texto com bounding boxes por linha usando tesserocr."""
    results = []
    with PyTessBaseAPI(lang=lang, oem=OEM.LSTM_ONLY, psm=PSM.AUTO) as api:
        api.SetImageFile(image_path)
        boxes = api.GetComponentImages(RIL.TEXTLINE, True)
        for i, (im, box, _, _) in enumerate(boxes):
            api.SetRectangle(box['x'], box['y'], box['w'], box['h'])
            text = api.GetUTF8Text().strip()
            conf = api.MeanTextConf()
            if text:
                results.append({
                    'line': i,
                    'text': text,
                    'confidence': conf,
                    'bbox': box
                })
    return results
```

## Example Usage

```python
# pytesseract: uso basico
ocr = TesseractOCR(lang='por', psm=3)
result = ocr.extract_text('/caminho/fatura_escaneada.png')
print(f"Confianca media: {result.confidence:.1f}%")

# tesserocr: lote com threading (libera GIL)
texts = ocr_batch_tesserocr(['doc1.png', 'doc2.png'], lang='por', max_workers=8)
```

## See Also

- [Fundamentos de OCR](../concepts/ocr-fundamentals.md) -- Visao geral de OCR
- [Tesseract Engine](../concepts/tesseract-engine.md) -- PSM, OEM, configuracao
- [Pre-processamento de Imagem](image-preprocessing-ocr.md) -- Melhorar qualidade antes do OCR
- [OCR para Classificacao](ocr-to-classification.md) -- Pipeline integrado OCR + classificacao
