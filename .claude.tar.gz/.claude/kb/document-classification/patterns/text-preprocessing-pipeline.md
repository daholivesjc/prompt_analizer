# Pipeline de Pre-processamento de Texto

> **Purpose**: Pipeline completo e reutilizavel para preparar texto para classificacao
> **MCP Validated**: 2026-04-23

## When to Use

- Antes de qualquer classificacao de documentos textuais
- Quando dados vem de fontes diversas (OCR, web scraping, PDFs)
- Para garantir consistencia no pre-processamento entre treino e inferencia
- Baseado no pipeline ML-TDCM (Ahmed et al., ISI 2025): limpeza, tokenizacao, text cleaning, TF-IDF

## Implementation

```python
import re
import unicodedata
from typing import List, Optional

import nltk
from nltk.corpus import stopwords
from nltk.stem import RSLPStemmer, SnowballStemmer
from nltk.tokenize import word_tokenize
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer

nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)

class TextPreprocessor(BaseEstimator, TransformerMixin):
    """Transformador sklearn para pre-processamento de texto."""

    def __init__(self, language='portuguese', use_stemming=True,
                 remove_numbers=True, min_token_length=2):
        self.language = language
        self.use_stemming = use_stemming
        self.remove_numbers = remove_numbers
        self.min_token_length = min_token_length

    def fit(self, X, y=None):
        return self

    def transform(self, X) -> List[str]:
        return [self._preprocess(text) for text in X]

    def _preprocess(self, text: str) -> str:
        # 1. Lowercase
        text = text.lower()

        # 2. Remover acentos (normalizar unicode)
        text = unicodedata.normalize('NFKD', text)
        text = text.encode('ascii', 'ignore').decode('ascii')

        # 3. Remover URLs e emails
        text = re.sub(r'http\S+|www\.\S+', '', text)
        text = re.sub(r'\S+@\S+', '', text)

        # 4. Remover caracteres especiais e pontuacao
        text = re.sub(r'[^a-z0-9\s]', ' ', text)

        # 5. Remover numeros (opcional)
        if self.remove_numbers:
            text = re.sub(r'\d+', '', text)

        # 6. Tokenizar
        tokens = word_tokenize(text, language=self.language)

        # 7. Remover stopwords
        stop_words = set(stopwords.words(self.language))
        tokens = [t for t in tokens if t not in stop_words]

        # 8. Filtrar tokens curtos
        tokens = [t for t in tokens if len(t) >= self.min_token_length]

        # 9. Stemming (opcional)
        if self.use_stemming:
            stemmer = (RSLPStemmer() if self.language == 'portuguese'
                      else SnowballStemmer(self.language))
            tokens = [stemmer.stem(t) for t in tokens]

        return ' '.join(tokens)


def build_classification_pipeline(
    max_features: int = 20000,
    ngram_range: tuple = (1, 2),
    language: str = 'portuguese',
    classifier=None
) -> Pipeline:
    """Constroi pipeline completo de pre-processamento + classificacao."""
    from sklearn.svm import LinearSVC

    steps = [
        ('preprocessor', TextPreprocessor(language=language)),
        ('tfidf', TfidfVectorizer(
            max_features=max_features,
            ngram_range=ngram_range,
            min_df=2,
            max_df=0.95,
            sublinear_tf=True  # aplica log(1 + tf)
        )),
        ('clf', classifier or LinearSVC(C=1.0, max_iter=10000))
    ]
    return Pipeline(steps)
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `max_features` | 20000 | Maximo de features TF-IDF |
| `ngram_range` | (1, 2) | Unigramas e bigramas |
| `language` | portuguese | Idioma para stopwords e stemming |
| `use_stemming` | True | Aplicar stemming (melhora clustering) |
| `min_df` | 2 | Minimo de documentos por termo |
| `max_df` | 0.95 | Maximo percentual de documentos |
| `sublinear_tf` | True | Aplica log(1+tf) para atenuar termos frequentes |

## Example Usage

```python
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

# Dados
documents = ["texto do documento 1...", "texto do documento 2...", ...]
labels = ["categoria_a", "categoria_b", ...]

# Split
X_train, X_test, y_train, y_test = train_test_split(
    documents, labels, test_size=0.2, stratify=labels, random_state=42
)

# Pipeline
pipeline = build_classification_pipeline(
    max_features=15000,
    ngram_range=(1, 2),
    language='portuguese'
)

# Treinar e avaliar
pipeline.fit(X_train, y_train)
y_pred = pipeline.predict(X_test)
print(classification_report(y_test, y_pred))
```

## Pipeline para PySpark (Dataproc)

```python
from pyspark.ml.feature import Tokenizer, StopWordsRemover, HashingTF, IDF
from pyspark.ml import Pipeline as SparkPipeline

spark_pipeline = SparkPipeline(stages=[
    Tokenizer(inputCol="text", outputCol="tokens"),
    StopWordsRemover(inputCol="tokens", outputCol="filtered"),
    HashingTF(inputCol="filtered", outputCol="raw_features", numFeatures=20000),
    IDF(inputCol="raw_features", outputCol="features")
])
model = spark_pipeline.fit(train_df)
result = model.transform(test_df)
```

## See Also

- [Feature Engineering](../concepts/feature-engineering.md)
- [TF-IDF + SVM](../patterns/tfidf-svm-classifier.md)
- [Representacao Textual](../concepts/text-representation.md)
