# Padrao Classico TF-IDF + SVM

> **Purpose**: Implementacao do classificador mais eficaz para texto de alta dimensionalidade
> **MCP Validated**: 2026-04-23

## When to Use

- Dataset com menos de 10K documentos rotulados
- Recursos computacionais limitados (sem GPU)
- Necessidade de treinamento e inferencia rapidos
- Baseline solido antes de tentar deep learning
- SVM linear e quase independente da dimensionalidade do espaco de features (Thaoroijam, 2014)

## Implementation

```python
"""
Classificador TF-IDF + SVM para documentos textuais.

SVM e particularmente eficaz para classificacao de texto porque:
1. Funciona bem em espacos de alta dimensionalidade
2. Raramente requer feature selection explicita
3. Seleciona automaticamente os support vectors mais discriminativos
4. A superficie de decisao e determinada por um subconjunto pequeno de dados
(Thaoroijam, 2014; Joachims, 1998)
"""

import joblib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report


def build_tfidf_svm_pipeline(
    max_features: int = 20000,
    ngram_range: tuple = (1, 2),
    C: float = 1.0,
    calibrate: bool = True
) -> Pipeline:
    """
    Constroi pipeline TF-IDF + SVM com calibracao de probabilidade.

    Args:
        max_features: numero maximo de features TF-IDF
        ngram_range: range de n-gramas (1,2) para unigrama+bigrama
        C: parametro de regularizacao do SVM
        calibrate: se True, calibra probabilidades com Platt scaling
    """
    svm = LinearSVC(C=C, max_iter=10000, class_weight='balanced')

    if calibrate:
        # CalibratedClassifierCV permite predict_proba
        svm = CalibratedClassifierCV(svm, cv=3, method='sigmoid')

    return Pipeline([
        ('tfidf', TfidfVectorizer(
            max_features=max_features,
            ngram_range=ngram_range,
            min_df=2,
            max_df=0.95,
            sublinear_tf=True,
            strip_accents='unicode',
            analyzer='word'
        )),
        ('clf', svm)
    ])


def train_and_evaluate(
    X_train, y_train, X_test, y_test,
    max_features=20000, C=1.0
):
    """Treina, avalia com cross-validation e reporta metricas."""

    pipeline = build_tfidf_svm_pipeline(max_features=max_features, C=C)

    # Cross-validation no treino
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(pipeline, X_train, y_train, cv=cv, scoring='f1_macro')
    print(f"CV F1-macro: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")

    # Treino final e avaliacao
    pipeline.fit(X_train, y_train)
    y_pred = pipeline.predict(X_test)
    print(classification_report(y_test, y_pred))

    return pipeline


def save_model(pipeline, path: str):
    """Serializa o pipeline treinado."""
    joblib.dump(pipeline, path)


def load_and_predict(path: str, texts: list) -> np.ndarray:
    """Carrega modelo e classifica novos documentos."""
    pipeline = joblib.load(path)
    return pipeline.predict(texts)
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `max_features` | 20000 | Features TF-IDF (10K-50K recomendado) |
| `ngram_range` | (1, 2) | Unigramas + bigramas |
| `C` | 1.0 | Regularizacao SVM (menor = mais regularizado) |
| `class_weight` | balanced | Ajusta pesos inversamente proporcional a frequencia |
| `sublinear_tf` | True | log(1+tf) suaviza frequencias altas |
| `calibrate` | True | Habilita predict_proba via Platt scaling |

## Example Usage

```python
from sklearn.model_selection import train_test_split

# Carregar dados
documents = [...]  # lista de textos
labels = [...]     # lista de categorias

# Split estratificado
X_train, X_test, y_train, y_test = train_test_split(
    documents, labels, test_size=0.2, stratify=labels, random_state=42
)

# Treinar e avaliar
pipeline = train_and_evaluate(X_train, y_train, X_test, y_test)

# Salvar modelo
save_model(pipeline, "models/tfidf_svm_classifier.joblib")

# Classificar novos documentos
predictions = load_and_predict(
    "models/tfidf_svm_classifier.joblib",
    ["Novo documento para classificar..."]
)

# Obter probabilidades (com calibracao)
probabilities = pipeline.predict_proba(["Novo documento..."])
```

## Tuning de Hiperparametros

```python
from sklearn.model_selection import GridSearchCV

param_grid = {
    'tfidf__max_features': [10000, 20000, 50000],
    'tfidf__ngram_range': [(1, 1), (1, 2), (1, 3)],
    'clf__estimator__C': [0.1, 1.0, 10.0]  # com CalibratedClassifierCV
}

grid = GridSearchCV(pipeline, param_grid, cv=5, scoring='f1_macro', n_jobs=-1)
grid.fit(X_train, y_train)
print(f"Melhores parametros: {grid.best_params_}")
```

## See Also

- [Pipeline Pre-processamento](../patterns/text-preprocessing-pipeline.md)
- [Classificacao Supervisionada](../concepts/supervised-classification.md)
- [Pipeline de Avaliacao](../patterns/model-evaluation-pipeline.md)
