# Document Classification Quick Reference

> Tabelas de consulta rapida. Para exemplos de codigo, veja os arquivos linkados.
> **MCP Validated**: 2026-04-23

## Comparacao de Algoritmos

| Algoritmo | Velocidade | Precisao | Dados Necessarios | Melhor Para |
|-----------|------------|----------|-------------------|-------------|
| Naive Bayes | Muito rapida | Moderada | Poucos | Baseline, spam |
| SVM (linear) | Rapida | Alta | Medios | Alta dimensionalidade |
| kNN | Lenta (infer.) | Moderada | Medios | Poucos rotulos |
| Decision Tree | Rapida | Moderada | Poucos | Interpretabilidade |
| Random Forest | Media | Alta | Medios | Robustez geral |
| XGBoost | Media | Muito alta | Medios | Competicoes, tabular |
| BERT fine-tuned | Lenta | Estado-da-arte | Muitos | Contexto semantico |
| LLM zero-shot | Variavel | Alta | Zero | Sem dados rotulados |

## Representacoes Textuais

| Metodo | Dimensao | Semantica | Quando Usar |
|--------|----------|-----------|-------------|
| BoW | Vocabulario | Nao | Baseline rapido |
| TF-IDF | Vocabulario | Parcial | Classificacao classica |
| Word2Vec | 100-300 | Sim | Embeddings pre-treinados |
| Doc2Vec | 100-300 | Sim | Documentos multi-pagina |
| BERT embeddings | 768 | Contextual | Estado-da-arte |

## Decision Matrix

| Cenario | Escolha Recomendada |
|---------|---------------------|
| < 1K documentos rotulados | TF-IDF + SVM ou Naive Bayes |
| 1K-10K documentos | TF-IDF + XGBoost ou Random Forest |
| > 10K documentos | BERT fine-tuning |
| Sem dados rotulados | LLM zero-shot ou clustering + LDA |
| Documentos multi-pagina | Doc2Vec + classificador |
| Requisito de velocidade | TF-IDF + SVM linear |
| Requisito de precisao maxima | Ensemble (stacking) ou BERT |
| Producao com 200+ categorias | Deep metric learning + KNN |

## Metricas de Avaliacao

| Metrica | Formula | Quando Priorizar |
|---------|---------|------------------|
| Accuracy | (TP+TN)/(TP+TN+FP+FN) | Classes balanceadas |
| Precision | TP/(TP+FP) | Custo alto de falso positivo |
| Recall | TP/(TP+FN) | Custo alto de falso negativo |
| F1-Score | 2*P*R/(P+R) | Balanco entre P e R |
| ROC-AUC | Area sob curva ROC | Comparacao de modelos |
| Macro-avg | Media por classe | Classes desbalanceadas |

## Common Pitfalls

| Erro | Solucao |
|------|---------|
| Nao remover stopwords | Usar pipeline de pre-processamento |
| Ignorar desbalanceamento | Aplicar SMOTE ou class weights |
| Usar accuracy com classes desbalanceadas | Usar F1-macro ou ROC-AUC |
| BERT sem GPU | Usar modelos menores (DistilBERT) |
| TF-IDF com vocabulario muito grande | Limitar max_features (10K-50K) |
| Nao fazer validacao cruzada | Usar StratifiedKFold (5-10 folds) |

## Benchmarks de Referencia (Reuters-21578)

| Modelo | Accuracy | F1-Score | Fonte |
|--------|----------|----------|-------|
| XGBoost + TF-IDF | 91.1% | 90.55% | ISI 2025 |
| KNN + TF-IDF | 87.1% | 86.22% | ISI 2025 |
| Random Forest + TF-IDF | 82.9% | 80.46% | ISI 2025 |
| Decision Tree + TF-IDF | 81.7% | 81.45% | ISI 2025 |

## OCR Tools

| Engine | Integracao | Performance | Melhor Para |
|--------|------------|-------------|-------------|
| pytesseract | Subprocess (CLI) | Moderada | Prototipacao, uso simples |
| tesserocr | API C++ (Cython) | Alta (libera GIL) | Lotes, threading |
| EasyOCR | Deep Learning | Media | Multiplos idiomas |
| Cloud Vision | API REST | Alta | Producao GCP |

## Benchmarks Juridicos (Lopes, 2019)

| Tarefa | Algoritmo | Accuracy | Dataset |
|--------|-----------|----------|---------|
| Status processos | SVM | 83.38% | 15.698 processos |
| Publicacoes | OneVsRest SVM | 38.75% | 18 amostras |

## Encoding Categorico

| Encoding | Usar Quando | Algoritmos | Risco |
|----------|-------------|------------|-------|
| One-Hot | Nominais, lineares/SVM/kNN | Reg. Linear, SVM, kNN, NN | Explosao dimensional |
| Label | Ordinais, arvores | DT, RF, XGBoost, LightGBM | Vies ordinal falso |
| Hashing | Alta cardinalidade | Qualquer | Colisoes de hash |
| Embeddings | NLP, semantica | NN, Transformers | Complexidade |

## Links

Texto: `concepts/text-representation.md` | OCR: `concepts/ocr-fundamentals.md` | Juridico: `concepts/legal-document-classification.md` | Encoding: `concepts/categorical-encoding.md` | Indice: `index.md`
