# BigQuery Architecture

> **Purpose**: Columnar storage engine with separated compute and storage for analytics
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-06

## Overview

BigQuery is a serverless, multi-cloud data warehouse that separates storage from compute via Google's petabit-scale network. Data is stored in columnar format (Capacitor) and processed by the Dremel distributed execution engine. This separation allows each layer to scale independently without downtime.

## Core Architecture

```text
+-------------------+     Petabit Network     +-------------------+
|    COMPUTE LAYER  |<========================>|   STORAGE LAYER   |
|                   |                          |                   |
|  Dremel Engine    |                          |  Capacitor Format |
|  - Slots (vCPUs)  |                          |  - Columnar       |
|  - Query plans    |                          |  - Compressed     |
|  - Shuffle        |                          |  - Encrypted      |
|                   |                          |  - Replicated     |
+-------------------+                          +-------------------+
```

## Key Components

| Component | Role | Details |
|-----------|------|---------|
| **Capacitor** | Storage format | Columnar, compressed, encrypted at rest |
| **Dremel** | Execution engine | Distributed SQL query processing |
| **Slots** | Compute unit | Virtual CPUs for query execution |
| **Colossus** | File system | Distributed storage backend |
| **Jupiter** | Network | Petabit bisection bandwidth |
| **Borg** | Orchestration | Cluster management for compute |

## Slots and Pricing

| Model | How It Works | Best For |
|-------|-------------|----------|
| **On-demand** | Pay per TB scanned | Unpredictable workloads |
| **Editions** | Reserve slots (100 increments) | Steady workloads |
| **Autoscaling** | Baseline + burst slots | Variable workloads |

```sql
-- Check slot usage for recent queries
SELECT
  project_id,
  job_id,
  total_slot_ms / 1000 AS total_slot_seconds,
  total_bytes_processed / (1024*1024*1024) AS gb_processed
FROM `region-us`.INFORMATION_SCHEMA.JOBS
WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 DAY)
ORDER BY total_slot_ms DESC
LIMIT 10;
```

## Partitioning

Only one partition column per table. Types:

| Type | Column Types | Granularity |
|------|-------------|-------------|
| **Time-unit** | DATE, TIMESTAMP, DATETIME | Hourly, daily, monthly, yearly |
| **Ingestion time** | Auto (`_PARTITIONTIME`) | Same granularities |
| **Integer range** | INT64 | Custom start/end/interval |

Limit: 10,000 partitions per table.

## Clustering

Up to 4 columns per table. Applied on top of partitioning.

- Sorts storage blocks by cluster column values
- Enables block pruning (skip irrelevant blocks)
- Auto-reclustering runs in background at no cost
- Column order matters: first column is most significant

## ACID Transactions

BigQuery provides full ACID support:
- Serializable isolation for single-table DML
- Snapshot isolation for multi-statement transactions
- Automatic data replication across locations

## Common Mistakes

### Wrong

```sql
-- No partition filter: full table scan
SELECT * FROM `project.dataset.invoices`;

-- Date-sharded tables instead of partitioning
SELECT * FROM `project.dataset.invoices_20260301`;
```

### Correct

```sql
-- Partition filter reduces scanned data and cost
SELECT invoice_id, vendor_name, total_amount
FROM `project.dataset.invoices`
WHERE invoice_date BETWEEN '2026-03-01' AND '2026-03-31'
  AND vendor_name = 'Restaurant ABC';
```

## Related

- [Data Partitioning Strategy](../patterns/data-partitioning-strategy.md)
- [Cost Optimization](../patterns/cost-optimization.md)
- [Data Lakehouse on GCP](../concepts/data-lakehouse-gcp.md)
