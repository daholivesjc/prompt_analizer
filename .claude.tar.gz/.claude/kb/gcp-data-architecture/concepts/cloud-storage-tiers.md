# Cloud Storage Tiers

> **Purpose**: Storage class selection for data lifecycle management on GCS
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-06

## Overview

Google Cloud Storage offers four storage classes with identical APIs and millisecond access latency. The classes trade lower at-rest storage cost for higher retrieval cost and minimum storage duration commitments. All classes provide 11 nines of durability.

## Storage Classes

| Class | Min Duration | Retrieval Cost | At-Rest Cost | Availability SLA |
|-------|-------------|----------------|--------------|------------------|
| **Standard** | None | None | Highest | 99.95% (multi-region) |
| **Nearline** | 30 days | Low | Lower | 99.9% (multi-region) |
| **Coldline** | 90 days | Medium | Lower | 99.9% (multi-region) |
| **Archive** | 365 days | Highest | Lowest | 99.9% (multi-region) |

## The Pattern

```python
from google.cloud import storage

def set_lifecycle_policy(bucket_name: str) -> None:
    """Configure automatic storage tier transitions."""
    client = storage.Client()
    bucket = client.get_bucket(bucket_name)

    # Move to Nearline after 30 days
    bucket.add_lifecycle_set_storage_class_rule(
        "NEARLINE",
        age=30,
        matches_storage_class=["STANDARD"]
    )

    # Move to Coldline after 90 days
    bucket.add_lifecycle_set_storage_class_rule(
        "COLDLINE",
        age=90,
        matches_storage_class=["NEARLINE"]
    )

    # Move to Archive after 365 days
    bucket.add_lifecycle_set_storage_class_rule(
        "ARCHIVE",
        age=365,
        matches_storage_class=["COLDLINE"]
    )

    # Delete after 7 years (regulatory)
    bucket.add_lifecycle_delete_rule(age=2555)

    bucket.patch()
```

## Invoice Pipeline Application

| Stage | Class | Rationale |
|-------|-------|-----------|
| `invoices-input` | Standard | Active uploads, frequent reads |
| `invoices-processed` | Standard | Recent extractions, reprocessing |
| `invoices-archive` | Nearline | Monthly reconciliation access |
| `invoices-compliance` | Coldline/Archive | 5-year regulatory retention |

## Quick Reference

| Input | Output | Notes |
|-------|--------|-------|
| Object upload | Standard class | Default for new objects |
| Lifecycle rule trigger | Class transition | Automatic, no downtime |
| Retrieval from Archive | Same-speed access | Milliseconds, not hours |

## Early Deletion Charges

Objects deleted or transitioned before the minimum duration are charged for the full minimum period. For example, a Nearline object deleted after 10 days is billed for 30 days.

## Common Mistakes

### Wrong

```python
# Single storage class for everything
bucket = client.create_bucket("all-data", location="US")
# No lifecycle policy = paying Standard rates for cold data
```

### Correct

```python
# Separate buckets by access pattern with lifecycle policies
hot_bucket = client.create_bucket("invoices-active", location="US")
archive_bucket = client.create_bucket(
    "invoices-archive",
    location="US",
)
archive_bucket.storage_class = "NEARLINE"
archive_bucket.patch()
```

## Related

- [BigQuery Architecture](../concepts/bigquery-architecture.md)
- [Cost Optimization](../patterns/cost-optimization.md)
- [Data Lakehouse on GCP](../concepts/data-lakehouse-gcp.md)
