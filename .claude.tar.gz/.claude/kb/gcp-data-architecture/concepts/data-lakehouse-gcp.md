# Data Lakehouse on GCP

> **Purpose**: Unified analytics combining data lake flexibility with warehouse capabilities
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-06

## Overview

A data lakehouse on GCP combines Cloud Storage (data lake) with BigQuery (data warehouse) to provide schema-on-read flexibility with SQL analytics. Raw files land in GCS, are processed and curated, then loaded into BigQuery for querying. BigQuery external tables and BigLake enable querying GCS data directly without loading.

## Architecture Layers

```text
+------------------------------------------------------------------+
|                        CONSUMPTION LAYER                          |
|  BigQuery SQL | Looker | Notebooks | Vertex AI                   |
+------------------------------------------------------------------+
        |                    |                    |
+------------------------------------------------------------------+
|                         CURATED LAYER                             |
|  BigQuery native tables (partitioned + clustered)                 |
|  Schema: enforced, validated, optimized for queries               |
+------------------------------------------------------------------+
        ^                    ^                    ^
+------------------------------------------------------------------+
|                       PROCESSING LAYER                            |
|  Cloud Run Functions | Dataflow | Dataproc                        |
|  Transform, validate, enrich, deduplicate                         |
+------------------------------------------------------------------+
        ^                    ^                    ^
+------------------------------------------------------------------+
|                          RAW LAYER                                 |
|  GCS: gs://project-raw/                                           |
|  Formats: TIFF, PNG, JSON, CSV, Parquet                           |
|  Schema: none (schema-on-read)                                    |
+------------------------------------------------------------------+
```

## GCS + BigQuery Integration

| Method | Use Case | Performance |
|--------|----------|-------------|
| **Native tables** | Curated analytics data | Best (columnar, cached) |
| **External tables** | Query raw GCS files | Slower (no caching) |
| **BigLake tables** | Governed multi-format access | Good (with metadata cache) |
| **Object tables** | Unstructured data (images) | For ML/AI pipelines |

## The Pattern

```python
from google.cloud import bigquery

def create_external_table_on_gcs(
    project_id: str,
    dataset_id: str,
    table_id: str,
    gcs_uri: str,
    source_format: str = "PARQUET",
) -> None:
    """Create BigQuery external table pointing to GCS."""
    client = bigquery.Client(project=project_id)
    table_ref = f"{project_id}.{dataset_id}.{table_id}"

    external_config = bigquery.ExternalConfig(source_format)
    external_config.source_uris = [gcs_uri]
    external_config.autodetect = True

    table = bigquery.Table(table_ref)
    table.external_data_configuration = external_config

    client.create_table(table, exists_ok=True)
```

## Invoice Pipeline as Lakehouse

| Layer | Service | Content |
|-------|---------|---------|
| **Raw** | GCS `invoices-input` | Original TIFF files |
| **Processed** | GCS `invoices-processed` | Converted PNG + JSON metadata |
| **Curated** | BigQuery `invoices.extracted_data` | Validated, structured invoice data |
| **Archive** | GCS `invoices-archive` | Nearline/Coldline for retention |

## When to Use Each Approach

| Scenario | Approach |
|----------|----------|
| Known schema, frequent queries | BigQuery native tables |
| Exploratory analysis on raw data | External tables on GCS |
| Multi-format data governance | BigLake managed tables |
| ML training on images | Object tables |
| Cost-sensitive cold storage | GCS with lifecycle policies |

## Quick Reference

| Input | Output | Notes |
|-------|--------|-------|
| Raw files (GCS) | External table | Schema-on-read, no load cost |
| Processed data | Native BQ table | Best query performance |
| Historical data | GCS Archive tier | Lowest storage cost |

## Common Mistakes

### Wrong

```python
# Loading everything into BigQuery including raw/unprocessed data
client.load_table_from_uri("gs://raw-bucket/*", "dataset.raw_table")
# Expensive, no validation, schema conflicts
```

### Correct

```python
# Validate and transform before loading to curated layer
validated_rows = [validate_invoice(row) for row in raw_data]
errors = client.insert_rows_json("dataset.curated_invoices", validated_rows)
```

## Related

- [BigQuery Architecture](../concepts/bigquery-architecture.md)
- [Cloud Storage Tiers](../concepts/cloud-storage-tiers.md)
- [Schema Evolution](../patterns/schema-evolution.md)
