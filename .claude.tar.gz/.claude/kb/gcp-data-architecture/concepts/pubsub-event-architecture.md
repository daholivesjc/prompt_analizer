# Pub/Sub Event Architecture

> **Purpose**: Event-driven messaging patterns for decoupled data pipelines
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-06

## Overview

Cloud Pub/Sub is a fully managed, real-time messaging service that decouples event producers from consumers. It provides at-least-once delivery, message ordering, and dead-letter queues. For data pipelines, Pub/Sub acts as the backbone connecting processing stages, enabling independent scaling and fault isolation.

## Core Concepts

| Concept | Description |
|---------|-------------|
| **Topic** | Named resource to which publishers send messages |
| **Subscription** | Named resource representing interest in a topic |
| **Message** | Data + attributes published to a topic |
| **Ack** | Subscriber confirms processing; unacked messages retry |
| **Dead-Letter Topic** | Captures messages that fail after max delivery attempts |

## The Pattern

```python
from google.cloud import pubsub_v1
import json

def publish_pipeline_event(
    project_id: str,
    topic_id: str,
    payload: dict,
    ordering_key: str | None = None,
) -> str:
    """Publish structured event to next pipeline stage."""
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_id)

    data = json.dumps(payload).encode("utf-8")

    kwargs = {}
    if ordering_key:
        kwargs["ordering_key"] = ordering_key

    future = publisher.publish(
        topic_path,
        data,
        source="invoice-pipeline",
        stage=payload.get("stage", "unknown"),
        **kwargs,
    )
    return future.result()
```

## Delivery Guarantees

| Feature | Behavior | Configuration |
|---------|----------|---------------|
| **At-least-once** | Default; duplicates possible | Use idempotent consumers |
| **Exactly-once** | Subscription-level setting | Enable on subscription |
| **Ordering** | Per ordering key | Set `enable_message_ordering` |
| **Retry** | Exponential backoff | Min 10s, max 600s |
| **DLQ** | After N failed attempts | `max_delivery_attempts` (5-100) |

## Pipeline Topology

```text
[GCS Upload]
     |
     v (Eventarc)
[tiff_to_png] ---> topic: invoice-converted
                        |
                        v (push subscription)
                   [classifier] ---> topic: invoice-classified
                                         |
                                         v (push subscription)
                                    [extractor] ---> topic: invoice-extracted
                                                         |
                                                         v (push subscription)
                                                    [bq_writer]
                                                         |
                                                         v
                                                    [BigQuery]

Each subscription has DLQ ---> topic: dlq ---> [dlq_processor]
```

## Quick Reference

| Input | Output | Notes |
|-------|--------|-------|
| JSON message | Ack/Nack | Subscriber must ack within deadline |
| Failed message (5x) | DLQ topic | Captured for investigation |
| Ordered messages | Sequential delivery | Per ordering key only |

## Common Mistakes

### Wrong

```python
# No error handling, no DLQ, sync publish blocking
publisher.publish(topic_path, data)
```

### Correct

```python
# Async publish with error callback
from concurrent import futures

future = publisher.publish(topic_path, data)
future.add_done_callback(
    lambda f: print(f"Error: {f.exception()}") if f.exception() else None
)
```

## Related

- [Event-Driven Pipeline](../patterns/event-driven-pipeline.md)
- [BigQuery Architecture](../concepts/bigquery-architecture.md)
- [Serverless Data Processing](../concepts/serverless-data-processing.md)
