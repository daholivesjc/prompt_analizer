# Serverless Data Processing

> **Purpose**: Serverless compute options for ETL and data transformation on GCP
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-06

## Overview

GCP offers multiple serverless compute services for data processing, each suited to different workload profiles. Cloud Run handles event-driven HTTP workloads, Cloud Functions provides lightweight triggers, and Dataflow manages large-scale batch and streaming ETL via Apache Beam. All three scale to zero and require no infrastructure management.

## Service Comparison

| Feature | Cloud Run | Cloud Functions | Dataflow |
|---------|-----------|----------------|----------|
| **Runtime** | Any container | Python, Node, Go, Java | Apache Beam SDK |
| **Max timeout** | 60 min | 9 min (1st gen) / 60 min (2nd gen) | Unlimited |
| **Max memory** | 32 GB | 32 GB (2nd gen) | Per worker |
| **Concurrency** | Up to 1000 req/instance | 1 per instance | Parallel workers |
| **Trigger** | HTTP, Pub/Sub, Eventarc | HTTP, Pub/Sub, GCS, Eventarc | Template or API |
| **Use case** | API, document processing | Lightweight transforms | Large-scale ETL |
| **Min instances** | Configurable | Configurable (2nd gen) | N/A |

## The Pattern

```python
# Cloud Run Function: event-driven document processing
import functions_framework
from google.cloud import storage
import json

@functions_framework.cloud_event
def process_document(cloud_event):
    """Process uploaded document -- serverless, scales to zero."""
    data = cloud_event.data
    bucket = data["bucket"]
    name = data["name"]

    # Download, process, publish result
    client = storage.Client()
    blob = client.bucket(bucket).blob(name)
    content = blob.download_as_bytes()

    result = transform(content)

    # Write result to output bucket
    output_blob = client.bucket("output-bucket").blob(f"processed/{name}")
    output_blob.upload_from_string(json.dumps(result))
```

## When to Choose What

| Scenario | Service | Why |
|----------|---------|-----|
| Invoice image processing | Cloud Run | Needs memory (32 GB), custom containers |
| GCS upload notification | Cloud Functions | Simple trigger, minimal logic |
| Batch load millions of rows | Dataflow | Parallel workers, exactly-once |
| Real-time stream processing | Dataflow | Windowing, watermarks |
| LLM API calls per document | Cloud Run | Long timeout, retry logic |
| Lightweight webhook | Cloud Functions | Fast cold start, low cost |

## Scaling Behavior

```text
Cloud Run:
  0 ──scale-up──> N instances (based on requests)
  N ──scale-down──> min_instances (configurable)

  Concurrency: multiple requests per instance
  Cold start: ~500ms-2s (depends on container size)

Cloud Functions (2nd gen = Cloud Run based):
  0 ──scale-up──> max_instances
  Single request per instance (1st gen)

Dataflow:
  1 ──autoscale──> max_workers
  Horizontal scaling based on backlog
  No scale-to-zero (batch jobs start/stop)
```

## Cost Comparison

| Service | Billing Unit | Free Tier |
|---------|-------------|-----------|
| Cloud Run | vCPU-second + GB-second + requests | 2M requests/mo |
| Cloud Functions | Invocations + GB-second + networking | 2M invocations/mo |
| Dataflow | vCPU-hr + GB-hr + shuffle | None |

## Quick Reference

| Input | Output | Notes |
|-------|--------|-------|
| GCS event | Cloud Run invocation | Via Eventarc trigger |
| Pub/Sub message | Function invocation | Push subscription |
| Beam pipeline | Dataflow job | Batch or streaming |

## Common Mistakes

### Wrong

```python
# Using Dataflow for simple per-document transforms
# Overkill: complex setup, no scale-to-zero, higher cost
beam.Pipeline() | ReadFromPubSub() | ProcessOneDoc() | WriteToBQ()
```

### Correct

```python
# Cloud Run for per-document processing (simpler, cheaper)
@functions_framework.cloud_event
def process_one(cloud_event):
    # Direct, no Beam overhead, scales to zero
    data = extract(cloud_event.data)
    write_to_bigquery(data)
```

## Related

- [Event-Driven Pipeline](../patterns/event-driven-pipeline.md)
- [Pub/Sub Event Architecture](../concepts/pubsub-event-architecture.md)
- [Cost Optimization](../patterns/cost-optimization.md)
