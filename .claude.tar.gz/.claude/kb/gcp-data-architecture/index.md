# GCP Data Architecture Knowledge Base

> **Purpose**: Data architecture patterns and best practices on Google Cloud Platform
> **MCP Validated**: 2026-03-06

## Quick Navigation

### Concepts (< 150 lines each)

| File | Purpose |
|------|---------|
| [concepts/bigquery-architecture.md](concepts/bigquery-architecture.md) | Columnar storage, slots, partitioning, clustering |
| [concepts/cloud-storage-tiers.md](concepts/cloud-storage-tiers.md) | Storage classes for data lifecycle management |
| [concepts/pubsub-event-architecture.md](concepts/pubsub-event-architecture.md) | Event-driven messaging for data pipelines |
| [concepts/data-lakehouse-gcp.md](concepts/data-lakehouse-gcp.md) | Data lake + warehouse with BigQuery and GCS |
| [concepts/serverless-data-processing.md](concepts/serverless-data-processing.md) | Cloud Run, Cloud Functions, Dataflow for ETL |

### Patterns (< 200 lines each)

| File | Purpose |
|------|---------|
| [patterns/event-driven-pipeline.md](patterns/event-driven-pipeline.md) | GCS to Pub/Sub to Cloud Run to BigQuery |
| [patterns/data-partitioning-strategy.md](patterns/data-partitioning-strategy.md) | Time-based and field-based partitioning in BigQuery |
| [patterns/schema-evolution.md](patterns/schema-evolution.md) | Managing schema changes in BigQuery and GCS |
| [patterns/cost-optimization.md](patterns/cost-optimization.md) | Storage tiers, slot reservations, committed use |

---

## Quick Reference

- [quick-reference.md](quick-reference.md) - Fast lookup tables

---

## Key Concepts

| Concept | Description |
|---------|-------------|
| **Separation of Storage and Compute** | BigQuery decouples storage from compute via petabit network |
| **Event-Driven** | Pub/Sub decouples pipeline stages for independent scaling |
| **Data Lakehouse** | Unified analytics combining GCS flexibility with BigQuery SQL |
| **Serverless** | No infrastructure management; pay-per-use processing |

---

## Learning Path

| Level | Files |
|-------|-------|
| **Beginner** | concepts/bigquery-architecture.md, concepts/cloud-storage-tiers.md |
| **Intermediate** | patterns/event-driven-pipeline.md, patterns/data-partitioning-strategy.md |
| **Advanced** | patterns/schema-evolution.md, patterns/cost-optimization.md |

---

## Differentiation from GCP KB

This domain focuses on **data architecture** (how to structure, store, and evolve data).
The [GCP KB](../gcp/index.md) covers **serverless compute** (Cloud Run, functions, triggers).

| Topic | This KB | GCP KB |
|-------|---------|--------|
| BigQuery internals | Columnar storage, slots, partitioning | Streaming inserts API |
| GCS | Storage tiers, lifecycle policies | Event triggers, Eventarc |
| Pub/Sub | Messaging patterns, ordering, DLQ design | Fanout, push/pull config |
| Architecture | Lakehouse, schema evolution | Function deployment |

---

## Agent Usage

| Agent | Primary Files | Use Case |
|-------|---------------|----------|
| pipeline-architect | patterns/event-driven-pipeline.md | Design pipeline data flow |
| infra-deployer | patterns/data-partitioning-strategy.md | Configure BigQuery tables |
| extraction-specialist | patterns/schema-evolution.md | Evolve invoice schemas |
