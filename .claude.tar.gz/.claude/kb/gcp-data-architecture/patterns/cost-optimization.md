# Cost Optimization

> **Purpose**: Reduce GCP data architecture costs through storage tiers, slot management, and design patterns
> **MCP Validated**: 2026-03-06

## When to Use

- Monthly GCP bill exceeds budget thresholds
- BigQuery on-demand costs are unpredictable
- Storage costs grow as data volume increases
- Pipeline processing costs need right-sizing

## Cost Optimization Levers

| Area | Strategy | Typical Savings |
|------|----------|----------------|
| **BigQuery Compute** | Editions + autoscaling | 30-50% vs on-demand |
| **BigQuery Storage** | Partitioning + pruning | 50-90% per query |
| **GCS Storage** | Lifecycle policies | 40-80% on cold data |
| **Pub/Sub** | Batch publishing | 20-40% on message costs |
| **Cloud Run** | Right-size memory/CPU | 20-50% on compute |

## Implementation

### BigQuery Cost Controls

```sql
-- 1. Require partition filters to prevent full scans
ALTER TABLE `project.invoices.extracted_data`
SET OPTIONS (require_partition_filter = true);

-- 2. Set maximum bytes billed per query (safety net)
-- In client code:
-- job_config.maximum_bytes_billed = 10 * 1024**3  # 10 GB limit

-- 3. Monitor costly queries
SELECT
  user_email,
  query,
  total_bytes_processed / (1024*1024*1024) AS gb_scanned,
  total_slot_ms / 1000 AS slot_seconds,
  TIMESTAMP_DIFF(end_time, start_time, SECOND) AS duration_sec
FROM `region-us`.INFORMATION_SCHEMA.JOBS
WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND total_bytes_processed > 1024*1024*1024  -- > 1 GB
ORDER BY total_bytes_processed DESC
LIMIT 20;

-- 4. Use materialized views for repeated aggregations
CREATE MATERIALIZED VIEW `project.invoices.daily_totals` AS
SELECT
  invoice_date,
  vendor_name,
  COUNT(*) AS invoice_count,
  SUM(total_amount) AS daily_total
FROM `project.invoices.extracted_data`
GROUP BY invoice_date, vendor_name;
```

### GCS Lifecycle Automation

```python
from google.cloud import storage

def configure_cost_optimized_lifecycle(bucket_name: str) -> None:
    """Apply lifecycle rules for invoice data retention."""
    client = storage.Client()
    bucket = client.get_bucket(bucket_name)

    rules = bucket.lifecycle_rules
    rules.clear()

    # Active data: Standard (0-30 days)
    # Warm data: Nearline (30-90 days)
    bucket.add_lifecycle_set_storage_class_rule(
        "NEARLINE", age=30, matches_storage_class=["STANDARD"]
    )
    # Cold data: Coldline (90-365 days)
    bucket.add_lifecycle_set_storage_class_rule(
        "COLDLINE", age=90, matches_storage_class=["NEARLINE"]
    )
    # Archive: 1-7 years (regulatory)
    bucket.add_lifecycle_set_storage_class_rule(
        "ARCHIVE", age=365, matches_storage_class=["COLDLINE"]
    )
    # Delete after 7 years
    bucket.add_lifecycle_delete_rule(age=2555)

    bucket.patch()
```

### Cloud Run Right-Sizing

```yaml
# Analyze actual resource usage before setting limits
# Check Cloud Monitoring for:
#   - container/memory/utilization
#   - container/cpu/utilization

# Right-sized configuration per function:
tiff_to_png:
  memory: 1Gi       # Image processing needs memory
  cpu: "1"           # CPU-bound conversion
  max_instances: 50  # Bursty uploads
  min_instances: 0   # Scale to zero off-hours

data_extractor:
  memory: 512Mi      # LLM API calls, not local compute
  cpu: "1"
  max_instances: 20  # Rate-limited by Gemini API
  min_instances: 1   # Avoid cold starts for latency

bigquery_writer:
  memory: 256Mi      # Simple JSON insert
  cpu: "0.5"
  max_instances: 10  # BQ handles concurrent inserts
  min_instances: 0
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `maximum_bytes_billed` | None | Per-query cost cap |
| `require_partition_filter` | false | Force partition pruning |
| `partition_expiration_days` | None | Auto-delete old data |
| `default_table_expiration_ms` | None | Dataset-level TTL |
| GCS lifecycle age | N/A | Days before tier transition |

## Cost Monitoring Queries

```sql
-- Monthly BigQuery cost estimate (on-demand pricing)
SELECT
  DATE_TRUNC(creation_time, MONTH) AS month,
  SUM(total_bytes_processed) / POW(1024, 4) AS tb_processed,
  SUM(total_bytes_processed) / POW(1024, 4) * 6.25 AS estimated_cost_usd
FROM `region-us`.INFORMATION_SCHEMA.JOBS
WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)
GROUP BY month
ORDER BY month DESC;
```

## Invoice Pipeline Cost Profile

| Component | Monthly Estimate | Optimization Applied |
|-----------|-----------------|---------------------|
| BigQuery storage | ~$0.02/GB/mo | Partition expiration (7 yr) |
| BigQuery queries | ~$6.25/TB scanned | Partition + cluster pruning |
| GCS Standard | ~$0.02/GB/mo | Lifecycle to Nearline at 30d |
| GCS Nearline | ~$0.01/GB/mo | Lifecycle to Coldline at 90d |
| Cloud Run | ~$0.00002/req | Right-sized memory per function |
| Pub/Sub | ~$40/TB ingested | Batch publishing where possible |

## Example Usage

```python
from google.cloud import bigquery

# Set per-query cost cap
job_config = bigquery.QueryJobConfig(
    maximum_bytes_billed=10 * 1024**3,  # 10 GB limit
    use_query_cache=True,
)

client = bigquery.Client()
try:
    result = client.query(sql, job_config=job_config)
except Exception as e:
    if "bytesBilledLimitExceeded" in str(e):
        logging.warning("Query exceeded cost limit, refine filters")
```

## See Also

- [Cloud Storage Tiers](../concepts/cloud-storage-tiers.md)
- [BigQuery Architecture](../concepts/bigquery-architecture.md)
- [Data Partitioning Strategy](../patterns/data-partitioning-strategy.md)
