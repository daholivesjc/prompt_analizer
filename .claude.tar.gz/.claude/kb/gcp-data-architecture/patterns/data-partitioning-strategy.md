# Data Partitioning Strategy

> **Purpose**: Time-based and field-based partitioning in BigQuery for performance and cost
> **MCP Validated**: 2026-03-06

## When to Use

- Tables grow beyond a few GB and queries filter on specific columns
- You need pre-query cost estimates for governance
- Query patterns consistently filter by date range or category
- You want automatic partition expiration for data retention

## Choosing a Strategy

| Data Profile | Strategy | Granularity |
|-------------|----------|-------------|
| Wide date range, steady daily volume | Time-unit partitioning | Daily |
| High volume, narrow date range (< 6 months) | Time-unit partitioning | Hourly |
| Low daily volume, wide date range | Time-unit partitioning | Monthly or yearly |
| Partitions averaging < 10 GB each | Clustering instead | N/A |
| Need both date + field filtering | Partition + cluster | Daily + up to 4 columns |

## Implementation

```sql
-- Time-unit partitioned + clustered table for invoice data
CREATE TABLE IF NOT EXISTS `project.invoices.extracted_data` (
  invoice_id STRING NOT NULL,
  vendor_name STRING,
  invoice_date DATE NOT NULL,
  due_date DATE,
  total_amount NUMERIC,
  currency STRING DEFAULT 'BRL',
  line_items ARRAY<STRUCT<
    description STRING,
    quantity INT64,
    unit_price NUMERIC,
    amount NUMERIC
  >>,
  extraction_confidence FLOAT64,
  source_file STRING,
  processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
)
PARTITION BY invoice_date
CLUSTER BY vendor_name, currency
OPTIONS (
  partition_expiration_days = 2555,  -- 7 years for compliance
  description = 'Extracted invoice data partitioned by invoice date'
);
```

## Partition Types Deep Dive

### Time-Unit Column Partitioning

```sql
-- Daily partitioning (most common for invoices)
CREATE TABLE dataset.invoices
PARTITION BY invoice_date AS
SELECT * FROM dataset.raw_invoices;

-- Monthly partitioning (low-volume scenarios)
CREATE TABLE dataset.invoices_monthly
PARTITION BY DATE_TRUNC(invoice_date, MONTH) AS
SELECT * FROM dataset.raw_invoices;
```

### Ingestion Time Partitioning

```sql
-- When data lacks a reliable date column
CREATE TABLE dataset.events
PARTITION BY _PARTITIONDATE
AS SELECT * FROM dataset.raw_events;

-- Query using pseudo-column
SELECT * FROM dataset.events
WHERE _PARTITIONDATE = '2026-03-01';
```

### Integer Range Partitioning

```sql
-- Partition by customer ID range
CREATE TABLE dataset.customer_data
PARTITION BY RANGE_BUCKET(customer_id, GENERATE_ARRAY(0, 100000, 1000))
AS SELECT * FROM dataset.raw_customers;
```

## Combining Partitioning with Clustering

```sql
-- Partition prunes by date, clustering prunes by vendor within partition
SELECT invoice_id, total_amount
FROM `project.invoices.extracted_data`
WHERE invoice_date BETWEEN '2026-01-01' AND '2026-03-31'  -- partition pruning
  AND vendor_name = 'iFood'                                -- cluster pruning
  AND currency = 'BRL';                                    -- cluster pruning
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `partition_expiration_days` | None | Auto-delete old partitions |
| `require_partition_filter` | false | Force queries to filter on partition |
| `clustering_columns` | None | Up to 4 columns, order matters |
| Partition limit | 10,000 | Max partitions per table |

## Monitoring Partition Usage

```sql
-- Check partition sizes and row counts
SELECT
  table_name,
  partition_id,
  total_rows,
  total_logical_bytes / (1024*1024) AS size_mb
FROM `project.invoices.INFORMATION_SCHEMA.PARTITIONS`
WHERE table_name = 'extracted_data'
ORDER BY partition_id DESC
LIMIT 30;
```

## Invoice Pipeline Configuration

| Table | Partition Column | Granularity | Cluster Columns |
|-------|-----------------|-------------|-----------------|
| `extracted_data` | `invoice_date` | Daily | `vendor_name`, `currency` |
| `extraction_logs` | `processed_at` | Daily | `status`, `source_file` |
| `reconciliation` | `period_date` | Monthly | `vendor_name` |

## Common Mistakes

### Wrong

```sql
-- Date-sharded tables (legacy anti-pattern)
CREATE TABLE invoices_20260301 AS SELECT ...;
CREATE TABLE invoices_20260302 AS SELECT ...;
-- Forces per-table permission checks, no partition pruning
```

### Correct

```sql
-- Native partitioning with required filter
ALTER TABLE `project.invoices.extracted_data`
SET OPTIONS (require_partition_filter = true);
-- Prevents accidental full-table scans
```

## See Also

- [BigQuery Architecture](../concepts/bigquery-architecture.md)
- [Schema Evolution](../patterns/schema-evolution.md)
- [Cost Optimization](../patterns/cost-optimization.md)
