# Event-Driven Pipeline Pattern

> **Purpose**: Design GCS to Pub/Sub to Cloud Run to BigQuery data pipelines
> **MCP Validated**: 2026-03-06

## When to Use

- Processing stages have different scaling and resource requirements
- Each stage must fail and retry independently
- Pipeline must handle bursty workloads with scale-to-zero
- You need observability and dead-letter handling at every stage

## Implementation

```python
"""
Event-driven pipeline orchestration using Pub/Sub.

Architecture:
  GCS (upload) -> Eventarc -> Cloud Run (convert)
       -> Pub/Sub -> Cloud Run (classify)
       -> Pub/Sub -> Cloud Run (extract)
       -> Pub/Sub -> Cloud Run (write to BQ)

Each stage publishes a structured event for the next stage.
"""
from google.cloud import pubsub_v1
from dataclasses import dataclass
import json
import logging

logger = logging.getLogger(__name__)


@dataclass
class PipelineEvent:
    """Standard event envelope for inter-stage communication."""
    stage: str
    bucket: str
    object_name: str
    trace_id: str
    metadata: dict


def publish_event(
    project_id: str,
    topic_id: str,
    event: PipelineEvent,
) -> str:
    """Publish pipeline event with tracing metadata."""
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_id)

    data = json.dumps({
        "bucket": event.bucket,
        "name": event.object_name,
        "metadata": event.metadata,
    }).encode("utf-8")

    future = publisher.publish(
        topic_path,
        data,
        stage=event.stage,
        trace_id=event.trace_id,
    )

    message_id = future.result()
    logger.info(
        "Published event",
        extra={
            "stage": event.stage,
            "topic": topic_id,
            "message_id": message_id,
            "trace_id": event.trace_id,
        },
    )
    return message_id
```

## Pipeline Topology

```text
Stage 1: TIFF Upload
  Trigger: GCS finalize event (Eventarc)
  Function: tiff_to_png
  Output: Pub/Sub topic "invoice-converted"

Stage 2: Classification
  Trigger: Pub/Sub push subscription
  Function: invoice_classifier
  Output: Pub/Sub topic "invoice-classified"

Stage 3: Extraction
  Trigger: Pub/Sub push subscription
  Function: data_extractor (Gemini 2.0 Flash)
  Output: Pub/Sub topic "invoice-extracted"

Stage 4: Storage
  Trigger: Pub/Sub push subscription
  Function: bigquery_writer
  Output: BigQuery table insert

Error Path:
  Each subscription has DLQ (max 5 attempts)
  DLQ topic -> dlq_processor -> Slack alert
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `max_delivery_attempts` | 5 | Retries before DLQ |
| `ack_deadline_seconds` | 60 | Time to process message |
| `minimum_backoff` | 10s | Initial retry delay |
| `maximum_backoff` | 600s | Max retry delay |
| `max_instances` | 50 | Per-stage scaling limit |
| `min_instances` | 0 | Set > 0 for latency-sensitive stages |

## Dead-Letter Queue Design

```python
# Terraform: Subscription with DLQ
resource "google_pubsub_subscription" "extractor_sub" {
  name  = "invoice-classified-extractor-sub"
  topic = google_pubsub_topic.invoice_classified.name

  push_config {
    push_endpoint = google_cloud_run_v2_service.extractor.uri
    oidc_token {
      service_account_email = google_service_account.extractor.email
    }
  }

  dead_letter_policy {
    dead_letter_topic     = google_pubsub_topic.dlq.id
    max_delivery_attempts = 5
  }

  retry_policy {
    minimum_backoff = "10s"
    maximum_backoff = "600s"
  }

  expiration_policy {
    ttl = ""  # Never expire
  }
}
```

## Example Usage

```bash
# Deploy with Eventarc trigger for GCS
gcloud eventarc triggers create tiff-upload-trigger \
  --location=us-central1 \
  --destination-run-service=tiff-to-png \
  --destination-run-region=us-central1 \
  --event-filters="type=google.cloud.storage.object.v1.finalized" \
  --event-filters="bucket=invoices-input" \
  --service-account=eventarc-sa@project.iam.gserviceaccount.com
```

## Key Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Push vs Pull | Push subscriptions | Cloud Run handles HTTP natively |
| Message format | JSON with envelope | Consistent tracing across stages |
| DLQ strategy | Shared DLQ topic | Single processor for all failures |
| Ordering | Not required | Invoices are independent documents |

## See Also

- [Pub/Sub Event Architecture](../concepts/pubsub-event-architecture.md)
- [Serverless Data Processing](../concepts/serverless-data-processing.md)
- [Data Partitioning Strategy](../patterns/data-partitioning-strategy.md)
