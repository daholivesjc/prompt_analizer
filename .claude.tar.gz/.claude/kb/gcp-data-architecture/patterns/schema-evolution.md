# Schema Evolution

> **Purpose**: Managing schema changes in BigQuery and GCS without breaking pipelines
> **MCP Validated**: 2026-03-06

## When to Use

- Adding new fields to extraction output (e.g., new invoice fields)
- Relaxing column constraints (REQUIRED to NULLABLE)
- Evolving Pydantic models that map to BigQuery tables
- Maintaining backward compatibility during schema migrations

## BigQuery Schema Rules

| Operation | Supported | Constraints |
|-----------|-----------|-------------|
| Add column | Yes | Must be NULLABLE or REPEATED |
| Remove column | No | Drop + recreate table |
| Rename column | No | Add new + backfill + drop old |
| Change type | Limited | Only widening (INT64 to NUMERIC) |
| REQUIRED to NULLABLE | Yes | Via schema update |
| NULLABLE to REQUIRED | No | Not reversible |
| Add nested field to RECORD | Yes | Via API/CLI only (not Console/SQL) |

## Implementation

```python
"""Schema evolution utilities for BigQuery tables."""
from google.cloud import bigquery


def add_columns_safely(
    project_id: str,
    dataset_id: str,
    table_id: str,
    new_columns: list[bigquery.SchemaField],
) -> list[bigquery.SchemaField]:
    """Add new NULLABLE columns to existing table without data loss.

    Args:
        project_id: GCP project ID
        dataset_id: BigQuery dataset
        table_id: Target table
        new_columns: List of SchemaField objects to add

    Returns:
        Updated schema
    """
    client = bigquery.Client(project=project_id)
    table_ref = f"{project_id}.{dataset_id}.{table_id}"
    table = client.get_table(table_ref)

    # Validate: new columns must be NULLABLE
    for col in new_columns:
        if col.mode == "REQUIRED":
            raise ValueError(
                f"Cannot add REQUIRED column '{col.name}' to existing table. "
                "Use NULLABLE instead."
            )

    # Append new columns to existing schema
    updated_schema = list(table.schema) + list(new_columns)
    table.schema = updated_schema
    client.update_table(table, ["schema"])

    return updated_schema


def add_column_via_ddl(
    client: bigquery.Client,
    table_ref: str,
    column_name: str,
    column_type: str,
    description: str = "",
) -> None:
    """Add column using SQL DDL (simpler for single columns)."""
    query = f"""
    ALTER TABLE `{table_ref}`
    ADD COLUMN IF NOT EXISTS {column_name} {column_type}
    OPTIONS (description='{description}')
    """
    client.query(query).result()
```

## Pydantic Model Evolution Strategy

```python
"""Keep Pydantic models in sync with BigQuery schema."""
from pydantic import BaseModel, Field
from typing import Optional


# Version 1: Original schema
class InvoiceV1(BaseModel):
    invoice_id: str
    vendor_name: str
    total_amount: float


# Version 2: Added fields (backward compatible)
class InvoiceV2(BaseModel):
    invoice_id: str
    vendor_name: str
    total_amount: float
    # New fields are Optional (maps to NULLABLE in BigQuery)
    currency: Optional[str] = Field(default="BRL")
    payment_method: Optional[str] = Field(default=None)
    extraction_confidence: Optional[float] = Field(default=None)
```

## Migration Workflow

```text
1. Update Pydantic model (add Optional fields)
     |
2. Run tests with new model
     |
3. ALTER TABLE ADD COLUMN in BigQuery
     |
4. Deploy updated Cloud Run functions
     |
5. New rows include new fields; old rows have NULL
     |
6. (Optional) Backfill old rows with default values
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `schemaUpdateOptions` | None | Set to `ALLOW_FIELD_ADDITION` for load jobs |
| `autodetect` | false | Auto-detect schema from source files |
| `create_disposition` | `CREATE_IF_NEEDED` | Create table if missing |
| `write_disposition` | `WRITE_APPEND` | Append to existing table |

## GCS Schema Strategy

| Format | Schema Evolution | Notes |
|--------|-----------------|-------|
| JSON | Flexible (schema-on-read) | New fields appear automatically |
| Parquet | Schema embedded in file | Version files by path prefix |
| CSV | No schema | Requires external schema definition |
| Avro | Forward/backward compatible | Best for schema evolution |

## Backfill Pattern

```sql
-- Backfill new column with default values for existing rows
UPDATE `project.invoices.extracted_data`
SET currency = 'BRL'
WHERE currency IS NULL
  AND invoice_date >= '2026-01-01';
```

## Common Mistakes

### Wrong

```python
# Adding REQUIRED column to existing table -- will fail
new_col = bigquery.SchemaField("tax_id", "STRING", mode="REQUIRED")
```

### Correct

```python
# Add as NULLABLE, enforce in application layer (Pydantic)
new_col = bigquery.SchemaField("tax_id", "STRING", mode="NULLABLE")
# Pydantic model validates at extraction time
class Invoice(BaseModel):
    tax_id: str  # Required in Pydantic, NULLABLE in BigQuery
```

## See Also

- [BigQuery Architecture](../concepts/bigquery-architecture.md)
- [Data Partitioning Strategy](../patterns/data-partitioning-strategy.md)
- [Data Lakehouse on GCP](../concepts/data-lakehouse-gcp.md)
