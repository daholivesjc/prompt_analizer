# GCP Data Architecture Quick Reference

> Fast lookup tables. For code examples, see linked files.
> **MCP Validated**: 2026-03-06

## GCP Data Services Comparison

| Service | Type | Best For | Pricing Model |
|---------|------|----------|---------------|
| BigQuery | Data Warehouse | Analytics, SQL queries | On-demand or slots |
| Cloud Storage | Object Store | Files, blobs, backups | Per GB stored + ops |
| Pub/Sub | Messaging | Event-driven pipelines | Per message + volume |
| Dataflow | Stream/Batch ETL | Apache Beam pipelines | Per vCPU-hr + GB-hr |
| Cloud Run | Serverless Compute | HTTP/event handlers | Per request + vCPU-s |
| Cloud Functions | FaaS | Lightweight triggers | Per invocation + GB-s |

## BigQuery Partitioning vs Clustering

| Feature | Partitioning | Clustering |
|---------|-------------|------------|
| Max columns | 1 | 4 |
| Pre-query cost estimate | Yes | No |
| Minimum benefit threshold | Any size | > 64 MB per partition |
| Auto-maintenance | N/A | Auto-reclustering |
| Best for | Date-range filters | High-cardinality filters |

## Cloud Storage Tiers

| Tier | Min Duration | Retrieval Cost | Use Case |
|------|-------------|----------------|----------|
| Standard | None | None | Hot data, frequent access |
| Nearline | 30 days | Low | Monthly access, backups |
| Coldline | 90 days | Medium | Quarterly access |
| Archive | 365 days | High | Yearly access, compliance |

## Common Architecture Patterns

| Pattern | Flow | Use Case |
|---------|------|----------|
| Event-Driven | GCS -> Pub/Sub -> Cloud Run -> BQ | Document processing |
| Streaming | Pub/Sub -> Dataflow -> BQ | Real-time analytics |
| Batch ETL | GCS -> Dataflow -> BQ | Historical data loads |
| Lakehouse | GCS (raw) + BQ (curated) | Unified analytics |

## Key Limits and Quotas

| Resource | Limit | Notes |
|----------|-------|-------|
| BQ partitions per table | 10,000 | Across all partition types |
| BQ clustering columns | 4 | Order matters for pruning |
| BQ streaming row size | 10 MB | Per row |
| BQ columns per table | 10,000 | Including nested fields |
| Pub/Sub message size | 10 MB | Per message |
| Pub/Sub message retention | 31 days max | Default 7 days |
| GCS object size | 5 TB | Per object |

## Decision Matrix

| Use Case | Choose |
|----------|--------|
| Query by date range | Partition by date column |
| Filter by high-cardinality field | Cluster on that column |
| Both date + field filters | Partition + cluster |
| Store raw files for reprocessing | GCS Standard |
| Archive processed invoices | GCS Nearline (30d) or Coldline (90d) |
| Schema changes needed | `ALTER TABLE ADD COLUMN` (nullable only) |

## Common Pitfalls

| Avoid | Do Instead |
|-------|------------|
| `SELECT *` without partition filter | Filter on partition column |
| Adding REQUIRED columns to existing tables | Use NULLABLE for new columns |
| Date-sharded tables (`table_YYYYMMDD`) | Use native partitioning |
| Skipping clustering on large tables | Cluster on filter/aggregation columns |
| Single storage class for all data | Use lifecycle policies across tiers |
| Ignoring slot contention | Monitor with INFORMATION_SCHEMA.JOBS |

## Related Documentation

| Topic | Path |
|-------|------|
| BigQuery internals | `concepts/bigquery-architecture.md` |
| Storage lifecycle | `concepts/cloud-storage-tiers.md` |
| Pipeline patterns | `patterns/event-driven-pipeline.md` |
| GCP serverless KB | `../gcp/index.md` |
| Full index | `index.md` |
