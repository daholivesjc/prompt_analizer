# Chaves de Identificacao GS1

> **Purpose**: Visao geral de todas as chaves de identificacao do sistema GS1 e suas aplicacoes no varejo
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

O sistema GS1 define um conjunto de chaves de identificacao padronizadas, cada uma projetada para identificar um tipo especifico de entidade na cadeia de suprimentos. Todas as chaves compartilham o mesmo algoritmo de digito verificador (modulo 10) e sao gerenciadas globalmente para garantir unicidade. No varejo brasileiro, GTIN, GLN e SSCC sao as mais utilizadas.

## The Pattern

```text
Mapa completo das chaves GS1:

PRODUTOS E SERVICOS:
  GTIN  -> Global Trade Item Number
           Identifica: produtos, servicos, embalagens
           Tamanho: 8, 12, 13 ou 14 digitos
           AI: (01) para GTIN-14 no GS1-128

LOCALIZACOES:
  GLN   -> Global Location Number
           Identifica: empresas, filiais, depositos, docas
           Tamanho: 13 digitos
           AI: (410)-(415) no GS1-128

LOGISTICA:
  SSCC  -> Serial Shipping Container Code
           Identifica: paletes, caixas, containers
           Tamanho: 18 digitos
           AI: (00) no GS1-128

ATIVOS:
  GRAI  -> Global Returnable Asset Identifier
           Identifica: paletes retornaveis, containers
           Tamanho: ate 30 caracteres
           AI: (8003)

  GIAI  -> Global Individual Asset Identifier
           Identifica: ativos fixos (empilhadeiras, etc.)
           Tamanho: ate 30 caracteres
           AI: (8004)

RELACOES:
  GSRN  -> Global Service Relation Number
           Identifica: relacoes de servico (cliente fidelidade)
           Tamanho: 18 digitos
           AI: (8018)

DOCUMENTOS:
  GDTI  -> Global Document Type Identifier
           Identifica: tipos de documento
           Tamanho: ate 30 caracteres
           AI: (253)

CUPONS:
  GCN   -> Global Coupon Number
           Identifica: cupons digitais
           Tamanho: ate 25 digitos
           AI: (255)

COMPONENTES:
  CPID  -> Component/Part Identifier
           Identifica: componentes/pecas
           Tamanho: ate 30 caracteres
           AI: (8010)

IDENTIFICACAO ELETRONICA:
  EPC   -> Electronic Product Code
           Identifica: itens individuais via RFID
           Estrutura: Header + Filter + Partition + Company + Item + Serial
           Uso: tags RFID com memoria e numero de serie unico
           Gerado no CNP da GS1 Brasil
```

## Redes de Sincronizacao

- **GDSN** (Global Data Synchronisation Network): rede global para troca padronizada de dados cadastrais de produtos entre parceiros comerciais. Usa GLN para identificar as partes e GTIN para os produtos

## Quick Reference

| Chave | Digitos | AI | Uso no Varejo Brasileiro |
|-------|---------|-----|-------------------------|
| `GTIN` | 8-14 | (01) | Obrigatorio: NF-e, PDV |
| `GLN` | 13 | (410-415) | EDI, GDSN, cadastro |
| `SSCC` | 18 | (00) | Etiqueta logistica, ASN |
| `GRAI` | ate 30 | (8003) | Gestao de paletes retornaveis |
| `GSRN` | 18 | (8018) | Cartao fidelidade |
| `GDTI` | ate 30 | (253) | Nota fiscal, documentos |

## Common Mistakes

### Wrong

```text
Confundir chaves — usar GTIN para identificar local:
  "Loja 001" = 7891234567895  <- Isso e um GTIN de produto!

Inventar numeracao sem registro GS1:
  SSCC: 000000000000000001  <- Prefixo 000 nao pertence a empresa
```

### Correct

```text
Usar a chave correta para cada entidade:
  Produto no PDV     -> GTIN-13
  Filial da empresa  -> GLN
  Palete no CD       -> SSCC
  Empilhadeira       -> GIAI

Todas as chaves derivam do prefixo GS1 da empresa:
  Prefixo GS1: 789 1234
  GTIN-13: 789 1234 XXXXX C  (produto)
  GLN:     789 1234 XXXXX C  (local)
  SSCC:  E 789 1234 XXXXXXX C (logistica)
```

## Related

- [GTIN](../concepts/gtin.md)
- [GLN](../concepts/gln.md)
- [SSCC](../concepts/sscc.md)
- [GS1 Digital Link](../concepts/gs1-digital-link.md)
