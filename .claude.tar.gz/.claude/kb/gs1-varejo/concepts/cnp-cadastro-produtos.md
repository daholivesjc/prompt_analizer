# CNP — Cadastro Nacional de Produtos

> **Purpose**: Plataforma online da GS1 Brasil para cadastro de produtos, geracao de GTIN e gestao de dados cadastrais
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

O CNP (Cadastro Nacional de Produtos) e a plataforma oficial da GS1 Brasil (https://cnp.gs1br.org) onde empresas associadas cadastram seus produtos, geram GTINs, criam etiquetas e gerenciam dados cadastrais. Os dados cadastrados alimentam o CCG (Cadastro Centralizado de GTIN), base compartilhada com o varejo brasileiro.

## Funcionalidades Principais

| Funcionalidade | Descricao |
|----------------|-----------|
| Cadastro de produtos | Registro com dados obrigatorios e geracao de GTIN |
| Geracao de etiquetas | Suporte a EAN-8, UPC-A, EAN-13, ITF-14 |
| GTIN-14 | Criado a partir de GTIN-13 de origem (caixas/agrupamentos) |
| GLN | Criacao e gestao de Global Location Numbers |
| RFID/EPC | Geracao de Electronic Product Code para tags RFID |
| Importacao em massa | Planilha padrao Excel com campos obrigatorios |
| Exportacao | Formato Excel/XLSX com campos selecionaveis |

## Campos Obrigatorios para GTIN-13

```text
Campos obrigatorios no cadastro CNP:
  - Descricao do produto
  - Foto ou URL da imagem
  - Marca
  - Idioma do rotulo
  - Pais de origem
  - Peso bruto
  - Conteudo liquido
  - NCM (Nomenclatura Comum do Mercosul)
  - CEST (Codigo Especificador da Substituicao Tributaria)
  - GPC (Global Product Classification)
  - Pais de destino
```

## Classificacoes Obrigatorias

### GPC — Global Product Classification

```text
Hierarquia GPC (8 digitos):
  Segmento (2 digitos)
    └── Familia (4 digitos)
         └── Classe (6 digitos)
              └── Subclasse / Brick (8 digitos)

Exemplo:
  50000000 - Alimentos, Bebidas e Tabaco (Segmento)
    50200000 - Bebidas (Familia)
      50202200 - Sucos (Classe)
        10000263 - Suco de Laranja (Brick)
```

### NCM — Nomenclatura Comum do Mercosul

- 8 digitos para identificar a natureza das mercadorias
- Base para tributacao (ICMS, IPI, II)
- Obrigatorio na NF-e e no cadastro CNP

### CEST — Codigo Especificador da Substituicao Tributaria

- Identifica produtos sujeitos a substituicao tributaria (ST)
- Vinculado ao NCM do produto
- Obrigatorio quando o produto esta sujeito a ST

## CCG — Cadastro Centralizado de GTIN

- Base centralizada mantida pela GS1 Brasil
- Recebe dados do CNP **diariamente**
- Compartilhada com redes varejistas para validacao de cadastro
- Permite verificar se um GTIN esta ativo e quem e o detentor

## Quick Reference

| Sigla | Nome | Digitos | Uso |
|-------|------|---------|-----|
| GPC | Global Product Classification | 8 | Classificacao hierarquica do produto |
| NCM | Nomenclatura Comum do Mercosul | 8 | Identificacao fiscal/tributaria |
| CEST | Cod. Especificador ST | 7 | Substituicao tributaria |
| CCG | Cadastro Centralizado de GTIN | - | Base compartilhada com varejo |
| EPC | Electronic Product Code | Variavel | Identificacao RFID |

## Related

- [GTIN](../concepts/gtin.md)
- [GLN](../concepts/gln.md)
- [Chaves de Identificacao](../concepts/chaves-identificacao.md)
- [Codigos de Barras](../concepts/codigos-barras.md)
- [Cadastro de Produtos](../patterns/cadastro-produtos.md)
- [Gestao de GTIN](../patterns/gestao-gtin.md)
