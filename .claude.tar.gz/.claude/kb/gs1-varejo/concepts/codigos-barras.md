# Codigos de Barras GS1

> **Purpose**: Tipos de simbologias de codigos de barras padronizadas pelo GS1 para varejo e logistica
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

O GS1 padroniza diversas simbologias de codigos de barras, cada uma otimizada para um contexto especifico. No varejo brasileiro, o EAN-13 e predominante nos pontos de venda (PDV), enquanto o GS1-128 e ITF-14 sao usados na logistica. Simbologias 2D como GS1 DataMatrix e GS1 QR Code permitem codificar mais dados em menos espaco, habilitando rastreabilidade unitaria.

## The Pattern

```text
Simbologias Lineares (1D):
+------------+----------+-----------------------------------+
| Simbologia | Dados    | Aplicacao                         |
+------------+----------+-----------------------------------+
| EAN-13     | 13N      | PDV varejo (padrao mundial)       |
| EAN-8      | 8N       | Produtos muito pequenos           |
| UPC-A      | 12N      | PDV varejo (America do Norte)     |
| UPC-E      | 8N       | Produtos pequenos (EUA)           |
| ITF-14     | 14N      | Caixas de embarque (GTIN-14)      |
| GS1-128    | Variavel | Logistica (lote, validade, SSCC)  |
| GS1 DataBar| Variavel | Produtos frescos/pesaveis         |
+------------+----------+-----------------------------------+

Simbologias 2D:
+----------------+----------+---------------------------------+
| Simbologia     | Dados    | Aplicacao                       |
+----------------+----------+---------------------------------+
| GS1 DataMatrix | Variavel | Rastreabilidade, saude, unitario|
| GS1 QR Code   | Variavel | Marketing, Digital Link         |
+----------------+----------+---------------------------------+

Anatomia do codigo EAN-13:
  ||||| |||| ||||| |||||| ||||||| |||
  ^                                ^
  Barras de inicio              Barras de fim

  [Digito sistema] [Dados esquerda] [Guarda central] [Dados direita] [Check]
```

## Quick Reference

| Simbologia | Capacidade | Leitura | Uso Principal |
|------------|-----------|---------|---------------|
| `EAN-13` | 13 digitos | Laser/CCD | Checkout varejo |
| `GS1-128` | ~48 caracteres | Laser/CCD | Etiqueta logistica |
| `ITF-14` | 14 digitos | Laser | Caixa de papelao |
| `GS1 DataMatrix` | ~2335 alfanum | Camera/Imager | Rastreabilidade |
| `GS1 QR Code` | ~4296 alfanum | Camera/Smartphone | Consumidor final |
| `GS1 DataBar` | 14+ digitos | Omnidirecional | Hortifruti, padaria |

## Common Mistakes

### Wrong

```text
Usar QR Code generico no lugar de GS1 QR Code:
  QR generico: https://meusite.com/produto123
  -> Nao segue padrao GS1, incompativel com sistemas da cadeia

Imprimir GS1-128 em embalagem de consumo:
  -> GS1-128 NAO e lido por scanners de PDV convencionais
  -> Use EAN-13 para o ponto de venda
```

### Correct

```text
GS1 QR Code com Digital Link:
  https://id.gs1.org/01/07891234567895/10/ABC123
  -> URI padronizada, resolvivel na web, compativel com GS1

Combinacao correta por nivel:
  Unidade consumidor: EAN-13
  Caixa de embarque:  ITF-14 ou GS1-128
  Palete:             GS1-128 com SSCC
```

## GS1 DataBar — Detalhes

```text
7 tipos de GS1 DataBar:
  Omnidirectional, Stacked Omnidirectional, Expanded,
  Expanded Stacked, Truncated, Stacked, Limited

Aplicacao principal: FLV (frutas, legumes, verduras)
  - Codifica GTIN + informacoes variaveis (peso, validade)
  - Ideal para produtos de peso variavel no PDV
```

## GS1 DataMatrix — Detalhes

- Codigo 2D com capacidade de GTIN + dados complementares (lote, validade, numero de serie)
- Uso principal: rastreabilidade unitaria e setor de saude
- Permite codificar multiplos AIs em espaco reduzido

## ITF-14 — Detalhes

- Exclusivo para caixas de embarque e unidades logisticas
- Ideal para substrato de baixa qualidade (papelao corrugado)
- **Minimo 2 paineis adjacentes** da caixa devem conter o codigo
- NAO e lido em PDV — uso exclusivamente logistico

## Certificacao GS1

- Codigos certificados pela GS1 sao **26% mais rapidos** na leitura em PDV
- Certificacao valida magnitude, contraste, quiet zones e estrutura

## Requisitos de Impressao

| Parametro | EAN-13 | GS1-128 | DataMatrix |
|-----------|--------|---------|------------|
| Modulo minimo (X Dimension) | 0.264mm | 0.250mm | Depende |
| Quiet zone (margem de silencio) | 11x modulo | 10x modulo | 1 modulo |
| Altura minima | 22.85mm | 31.75mm | N/A |
| Cor barra | Preto/escuro | Preto/escuro | Preto/escuro |
| Cor fundo | Branco/claro | Branco/claro | Branco/claro |

**Regras de qualidade:**
- **Truncamento**: proibido — alterar altura do codigo compromete leitura
- **Cores**: barras sempre em tons escuros sobre fundo claro (nunca vermelho/laranja em barras)
- **Localizacao recomendada**: quadrante inferior direito da embalagem, entre 4mm e 102mm das bordas

## Related

- [GTIN](../concepts/gtin.md)
- [SSCC](../concepts/sscc.md)
- [GS1 Digital Link](../concepts/gs1-digital-link.md)
- [Validacao GTIN](../patterns/validacao-gtin.md)
- [CNP — Cadastro Nacional de Produtos](../concepts/cnp-cadastro-produtos.md)
