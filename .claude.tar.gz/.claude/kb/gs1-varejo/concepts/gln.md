# GLN — Global Location Number

> **Purpose**: Numero global de 13 digitos que identifica unicamente locais fisicos e entidades legais na cadeia de suprimentos
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

O GLN (Global Location Number) e a chave GS1 usada para identificar locais fisicos (fabricas, depositos, lojas, docas) e entidades legais (empresas, filiais). No Brasil, o GLN e fundamental para EDI (troca eletronica de dados) e GDSN, permitindo que parceiros comerciais se identifiquem de forma unica e padronizada. Tem a mesma estrutura de 13 digitos do GTIN-13, mas aplicado a localizacoes.

## The Pattern

```text
Estrutura do GLN (13 digitos):
+-------+------------------+----+
| 789   | 123400000        | 1  |
+-------+------------------+----+
  |           |               |
  Prefixo    Referencia       Digito
  GS1        de localizacao   verificador
  (Brasil)   (atribuido       (mesmo algoritmo
              pela empresa)    do GTIN)

Hierarquia de GLNs em uma empresa:
  GLN Entidade Legal:  7891234000017  <- Empresa (CNPJ raiz)
  GLN Funcional:       7891234000024  <- Departamento Compras
  GLN Fisico:          7891234000031  <- Centro de Distribuicao SP
  GLN Fisico:          7891234000048  <- Loja Filial 001
  GLN Fisico:          7891234000055  <- Doca de Recebimento 3
```

## Quick Reference

| Tipo GLN | Identifica | Exemplo de Uso |
|----------|-----------|----------------|
| `Entidade Legal` | Pessoa juridica | Emissao de NF-e, contratos |
| `Funcional` | Departamento/area | Roteamento de pedidos EDI |
| `Fisico` | Endereco/local | Entrega, coleta, armazenagem |

## Common Mistakes

### Wrong

```text
Usar CNPJ como identificador em EDI internacional:
  CNPJ: 12.345.678/0001-90
  -> CNPJ e exclusivo do Brasil, nao reconhecido globalmente

Criar um unico GLN para toda a empresa:
  GLN: 7891234000017 (para tudo)
  -> Impossivel rotear entregas para filiais diferentes
```

### Correct

```text
Usar GLN como identificador padrao em EDI:
  Empresa: GLN 7891234000017
  CD Sao Paulo: GLN 7891234000031
  CD Rio: GLN 7891234000048
  -> Parceiros internacionais reconhecem automaticamente

Registrar GLN para cada ponto de entrega:
  Cada filial/doca recebe seu GLN unico
  -> Sistema logistico roteia corretamente
```

## 4 Tipos de GLN

| Tipo | Identifica | Exemplo |
|------|-----------|---------|
| **Entidade Legal** | Pessoa juridica (CNPJ) | Matriz da empresa |
| **Funcao** | Departamento ou area funcional | Setor de compras, financeiro |
| **Localizacao Fisica** | Endereco fisico especifico | CD, loja, doca, prateleira |
| **Localizacao Digital** | Endpoint eletronico | Servidor EDI, URL de API |

## Criacao de GLN no CNP

- GLNs sao criados e gerenciados no [CNP](../concepts/cnp-cadastro-produtos.md) da GS1 Brasil
- Empresas associadas recebem GLN base automaticamente com o prefixo
- GLNs adicionais sao criados pela propria empresa dentro de sua faixa de numeracao

## GLN no Contexto Brasileiro

- **GDSN**: GLN identifica fornecedor e varejista na sincronizacao de cadastro
- **EDI (EANCOM)**: GLN nos campos NAD (Name and Address) das mensagens
- **NF-e**: Embora a NF-e use CNPJ, o GLN pode ser referenciado em campos auxiliares

## Related

- [Chaves de Identificacao](../concepts/chaves-identificacao.md)
- [GTIN](../concepts/gtin.md)
- [Rastreabilidade](../patterns/rastreabilidade.md)
- [Cadastro de Produtos](../patterns/cadastro-produtos.md)
- [CNP — Cadastro Nacional de Produtos](../concepts/cnp-cadastro-produtos.md)
