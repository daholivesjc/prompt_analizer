# GS1 Digital Link

> **Purpose**: Padrao que conecta identificadores GS1 a recursos na web atraves de URIs padronizadas
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

O GS1 Digital Link e um padrao que transforma chaves de identificacao GS1 (GTIN, GLN, SSCC) em URIs web resolviveis. Em vez de apenas um numero, o codigo de barras (ou QR Code) carrega uma URL que pode direcionar para informacoes do produto, rastreabilidade, manual, recall ou qualquer recurso digital. E a ponte entre o mundo fisico e digital, permitindo que um unico codigo sirva tanto para o PDV quanto para o consumidor.

## The Pattern

```text
Estrutura da URI GS1 Digital Link:

https://id.gs1.org/01/07891234567895
^^^^^^^^^^^^^^^  ^^  ^^^^^^^^^^^^^^
Dominio          AI   GTIN-13
resolucao

Com atributos adicionais:
https://id.gs1.org/01/07891234567895/10/LOTEABC/21/SN12345
                                      ^^  ^^^^^^^  ^^  ^^^^^^^
                                      AI  Lote     AI  Serial

Anatomia completa:
  https://{dominio}/{ai_primario}/{valor}
         /{ai_qualificador}/{valor}
         ?{parametros_de_contexto}

Exemplos praticos:
  Produto:
    https://id.gs1.org/01/07891234567895

  Produto + Lote:
    https://id.gs1.org/01/07891234567895/10/L2026A

  Produto + Lote + Serial:
    https://id.gs1.org/01/07891234567895/10/L2026A/21/001

  Localizacao:
    https://id.gs1.org/414/7891234000017

  Unidade logistica:
    https://id.gs1.org/00/378912340000000014
```

## Quick Reference

| AI na URI | Significado | Exemplo |
|-----------|------------|---------|
| `/01/` | GTIN | `/01/07891234567895` |
| `/10/` | Numero do lote | `/10/ABC123` |
| `/21/` | Numero serial | `/21/XYZ789` |
| `/414/` | GLN (local fisico) | `/414/7891234000017` |
| `/00/` | SSCC | `/00/378912340000014` |
| `/8010/` | CPID (componente) | `/8010/PART001` |

## Common Mistakes

### Wrong

```text
Colocar URL generica no QR Code do produto:
  https://minha-empresa.com/produto/123
  -> Nao e padrao GS1, incompativel com resolucao global

Criar Digital Link sem resolver para conteudo:
  https://id.gs1.org/01/07891234567895 -> 404 Not Found
  -> A URI deve resolver para informacoes reais do produto
```

### Correct

```text
Usar estrutura GS1 Digital Link no QR Code:
  https://id.gs1.org/01/07891234567895
  -> Padrao global, qualquer resolver GS1 entende

Configurar resolver para redirecionar por contexto:
  Scanner PDV  -> retorna GTIN para checkout
  Smartphone   -> redireciona para pagina do produto
  App recall   -> mostra alertas de seguranca
  Regulador    -> exibe dados de rastreabilidade
```

## Beneficios para o Varejo

- **Codigo unico**: mesmo QR Code serve PDV, consumidor e regulador
- **Sunset do EAN-13**: GS1 planeja migracao gradual para 2D com Digital Link
- **Sunrise 2027**: data alvo para PDVs aceitarem codigos 2D globalmente
- **Rastreabilidade**: lote e serial embutidos no codigo
- **Engajamento**: consumidor acessa informacoes escaneando com smartphone

## Related

- [Codigos de Barras](../concepts/codigos-barras.md)
- [GTIN](../concepts/gtin.md)
- [Chaves de Identificacao](../concepts/chaves-identificacao.md)
- [Rastreabilidade](../patterns/rastreabilidade.md)
