# GTIN — Global Trade Item Number

> **Purpose**: Numero global que identifica unicamente itens comerciais (produtos) em qualquer ponto da cadeia de suprimentos
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

O GTIN (Global Trade Item Number) e a chave de identificacao GS1 mais utilizada no mundo. Ele identifica de forma unica qualquer item comercial (produto ou servico) sobre o qual ha necessidade de obter informacoes pre-definidas. No Brasil, o GTIN-13 (antigo EAN-13) e o padrao predominante no varejo, com o prefixo 789 ou 790 atribuido pela GS1 Brasil.

## The Pattern

```text
Estrutura do GTIN-13 (EAN-13):
+-------+---------------------+----+
| 789   | 1234 56789          | 5  |
+-------+---------------------+----+
  |           |                  |
  Prefixo    Codigo empresa     Digito
  GS1        + produto          verificador
  (Brasil)   (atribuido pela    (mod 10)
              empresa)

Variantes do GTIN:
+----------+----------+------------------------------+
| Tipo     | Digitos  | Uso principal                |
+----------+----------+------------------------------+
| GTIN-8   | 8        | Produtos muito pequenos      |
| GTIN-12  | 12       | UPC-A (America do Norte)     |
| GTIN-13  | 13       | EAN-13 (padrao mundial)      |
| GTIN-14  | 14       | Caixas e unidades logisticas |
+----------+----------+------------------------------+

Conversao entre formatos (preenchimento com zeros a esquerda):
  GTIN-8:  00000040170725  (14 digitos)
  GTIN-12: 00012345678905  (14 digitos)
  GTIN-13: 07891234567895  (14 digitos)
  GTIN-14: 17891234567892  (14 digitos)
```

## Quick Reference

| Entrada | Saida | Notas |
|---------|-------|-------|
| `789123456789` | `7891234567895` | 12 digitos + check digit = GTIN-13 |
| `7891234567895` | Valido | Digito verificador confere |
| `7891234567890` | Invalido | Digito verificador incorreto |
| `1` + GTIN-13 sem check | GTIN-14 | Indicador de embalagem (1-8) + GTIN base |

## Common Mistakes

### Wrong

```text
Usar prefixo 789 sem registro na GS1 Brasil:
  789 9999 99999 X  <- GTIN nao registrado, causara conflitos

Reutilizar GTIN de produto descontinuado imediatamente:
  Produto A (descontinuado) -> GTIN transferido para Produto B
  Resultado: confusao em sistemas que ainda tem cache do Produto A
```

### Correct

```text
Registrar empresa na GS1 Brasil e receber faixa de numeracao:
  GS1 atribui prefixo: 789 1234
  Empresa numera produtos: 789 1234 00001 a 789 1234 99999
  Cada GTIN recebe digito verificador calculado

Regra dos 48 meses:
  Produto descontinuado -> aguardar 48 meses -> so entao reutilizar o GTIN
```

## Responsabilidade pela Numeracao

- **Detentor da marca** e sempre o responsavel pela numeracao GTIN, independente de quem fabrica
- Importador exclusivo pode atribuir numeracao temporaria ao produto importado
- Varejista pode usar codigo interno com **prefixo 2** (uso restrito a loja)

## Regras de Modificacao do GTIN

**DEVE receber novo GTIN quando:**
- Altera quantidade, peso ou dimensoes do produto
- Muda tipo de embalagem (lata para vidro, por exemplo)
- Troca de marca ou submarca
- Traduz idioma do rotulo para outro mercado

**NAO modificar GTIN quando:**
- Pequenas melhorias de formulacao (sem impacto em alergenicos)
- Rejuvenescimento visual da embalagem (mesmo conteudo)
- Mudanca de fornecedor de materia-prima sem impacto ao consumidor

## Promocoes

- Variantes promocionais que alteram tamanho/peso **DEVEM** receber GTIN exclusivo
- Cupons internos de desconto **NAO** exigem novo GTIN
- Packs promocionais (leve 3 pague 2) com embalagem propria recebem GTIN novo

## Reutilizacao de GTIN

| Categoria | Prazo minimo | Observacao |
|-----------|-------------|------------|
| Geral | 48 meses | Apos descontinuacao do produto |
| Vestuario | 30 meses | Ciclos de colecao mais curtos |
| Medicamentos | **NUNCA** | Risco de confusao em farmacovigilancia |

## Prefixo 2 — Uso Interno

```text
Faixas do prefixo 2 (20-26):
  Indicadores 0-4: peso variavel (hortifruti, acougue)
  Indicadores 5-6: uso interno da loja (producao propria)

IMPORTANTE: codigos com prefixo 2 NAO devem circular fora da loja
```

## GTIN no Banco de Dados

- Armazenar **sempre** como string de 14 digitos com zeros a esquerda
- Nunca processar partes isoladas do GTIN (prefixo, empresa, produto)
- Conversao: `GTIN-8 -> 00000040170725`, `GTIN-13 -> 07891234567895`

## Regras Importantes no Brasil

- **Prefixo 789/790**: atribuido exclusivamente pela GS1 Brasil
- **GTIN-8**: licenciado 1 a 1 pela GS1 Brasil, condicionado a avaliacao tecnica
- **GTIN-14**: indicador (1-8) + GTIN-13 sem DV + novo DV. Indicador 9 = medida variavel
- **Obrigatoriedade**: GTIN e obrigatorio na NF-e (campo cEAN) desde 2018
- **Cadastro Centralizado**: [CNP](../concepts/cnp-cadastro-produtos.md) da GS1 Brasil
- **Validade**: GTIN nao expira enquanto o produto existir
- **Variantes de prefixo**: 977=ISSN, 978=ISBN, 979=ISMN/ISBN, 980=recibos, 99=cupons

## Related

- [Codigos de Barras](../concepts/codigos-barras.md)
- [Chaves de Identificacao](../concepts/chaves-identificacao.md)
- [Validacao GTIN](../patterns/validacao-gtin.md)
- [Cadastro de Produtos](../patterns/cadastro-produtos.md)
- [CNP — Cadastro Nacional de Produtos](../concepts/cnp-cadastro-produtos.md)
- [Gestao de GTIN](../patterns/gestao-gtin.md)
