# SSCC — Serial Shipping Container Code

> **Purpose**: Codigo serial de 18 digitos que identifica unicamente unidades logisticas (paletes, caixas, containers) na cadeia de suprimentos
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

O SSCC (Serial Shipping Container Code) e a chave GS1 usada para identificar de forma unica cada unidade logistica (palete, caixa, container) que se move na cadeia de suprimentos. Diferente do GTIN que identifica o tipo de produto, o SSCC identifica uma instancia fisica especifica de uma unidade de despacho. E codificado em barras GS1-128 com o AI (00) e e essencial para rastreabilidade logistica, recebimento automatizado e ASN (Aviso de Embarque).

## The Pattern

```text
Estrutura do SSCC (18 digitos):
+---+-------+-----------+----+
| 3 | 789   | 1234 00000001 | 4  |
+---+-------+-----------+----+
  |    |         |          |
  Digito  Prefixo  Referencia   Digito
  extensao GS1     serial       verificador
  (0-9)   (Brasil) (sequencial,
                    unico)

AI (Application Identifier) no GS1-128:
  (00) 378912340000000014
  ^^^^
  AI 00 = SSCC

Composicao da etiqueta logistica GS1:
  +-------------------------------------------+
  |  SSCC: (00) 3 789 1234 00000001 4         |
  |  GTIN: (01) 07891234567895                |
  |  Lote: (10) LOTE2026A                     |
  |  Validade: (17) 261231                    |
  |  Quantidade: (37) 00000144                |
  |  |||||||||||||||||||||||||||||||||||       |
  |  (codigo de barras GS1-128)               |
  +-------------------------------------------+
```

## Quick Reference

| Campo | Tamanho | Descricao |
|-------|---------|-----------|
| `Digito extensao` | 1 digito | Aumenta capacidade de numeracao (0-9) |
| `Prefixo GS1` | 7-10 digitos | Identifica a empresa (prefixo GS1 Brasil) |
| `Referencia serial` | 6-9 digitos | Sequencial unico atribuido pela empresa |
| `Digito verificador` | 1 digito | Calculado pelo algoritmo mod 10 padrao |

## Common Mistakes

### Wrong

```text
Reutilizar SSCC antes de 12 meses:
  SSCC 378912340000000014 -> Palete entregue em Jan/2026
  SSCC 378912340000000014 -> Reusado em Mar/2026
  -> Sistemas de rastreamento confundem as duas entregas

Omitir SSCC na etiqueta do palete:
  Etiqueta com apenas GTIN e quantidade
  -> Impossivel rastrear unidade logistica individualmente
```

### Correct

```text
Gerar SSCC sequencial unico:
  SSCC 378912340000000014 -> Palete #1 (Jan/2026)
  SSCC 378912340000000021 -> Palete #2 (Jan/2026)
  Nunca reutilizar dentro de 12 meses

ASN (Advanced Shipping Notice) com SSCC:
  Mensagem DESADV (EDI) referencia o SSCC
  -> Varejista sabe exatamente o que chega em cada palete
  -> Recebimento cego: escanear SSCC = conferencia automatica
```

## SSCC no Varejo Brasileiro

- **Recebimento automatizado**: grandes varejistas exigem SSCC nos paletes
- **Etiqueta logistica padrao**: GS1-128 com SSCC + GTIN + lote + validade
- **Cross-docking**: SSCC permite redirecionamento sem abrir o palete
- **Rastreabilidade**: vincula produto final ao lote e local de producao
- **SEFAZ**: SSCC pode ser referenciado em campos adicionais da NF-e

## Related

- [GTIN](../concepts/gtin.md)
- [Codigos de Barras](../concepts/codigos-barras.md)
- [Chaves de Identificacao](../concepts/chaves-identificacao.md)
- [Rastreabilidade](../patterns/rastreabilidade.md)
