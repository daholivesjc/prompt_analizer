# GS1 para Varejo Knowledge Base

> **Purpose**: Padrao global GS1 de identificacao de produtos, locais e unidades logisticas aplicado ao varejo brasileiro
> **MCP Validated**: 2026-03-23

## Quick Navigation

### Concepts (< 150 linhas cada)

| Arquivo | Proposito |
|---------|-----------|
| [concepts/gtin.md](concepts/gtin.md) | Global Trade Item Number — EAN-13, EAN-8, UPC-A, GTIN-14 |
| [concepts/codigos-barras.md](concepts/codigos-barras.md) | Tipos de codigos de barras GS1 (EAN, UPC, GS1-128, DataMatrix, QR) |
| [concepts/gln.md](concepts/gln.md) | Global Location Number para identificacao de locais |
| [concepts/sscc.md](concepts/sscc.md) | Serial Shipping Container Code para logistica |
| [concepts/chaves-identificacao.md](concepts/chaves-identificacao.md) | Visao geral de todas as chaves GS1 |
| [concepts/gs1-digital-link.md](concepts/gs1-digital-link.md) | GS1 Digital Link e evolucao para web |
| [concepts/cnp-cadastro-produtos.md](concepts/cnp-cadastro-produtos.md) | CNP — Cadastro Nacional de Produtos, GPC, NCM, CEST |

### Patterns (< 200 linhas cada)

| Arquivo | Proposito |
|---------|-----------|
| [patterns/validacao-gtin.md](patterns/validacao-gtin.md) | Algoritmos de validacao do digito verificador |
| [patterns/cadastro-produtos.md](patterns/cadastro-produtos.md) | Padrao de cadastro de produtos com GTIN |
| [patterns/rastreabilidade.md](patterns/rastreabilidade.md) | Rastreabilidade na cadeia de suprimentos |
| [patterns/nota-fiscal-eletronica.md](patterns/nota-fiscal-eletronica.md) | GS1 na NF-e brasileira (EAN em XML) |
| [patterns/gestao-gtin.md](patterns/gestao-gtin.md) | Ciclo de vida do GTIN, regras de modificacao e reutilizacao |

### Reference (Comprehensive)

| Arquivo | Proposito |
|---------|-----------|
| [reference/glossario-varejo.md](reference/glossario-varejo.md) | Glossario completo de termos do varejo (55+ termos) |

### Specs (Machine-Readable)

| Arquivo | Proposito |
|---------|-----------|
| [specs/gs1-keys-spec.yaml](specs/gs1-keys-spec.yaml) | Especificacao tecnica das chaves GS1 |

---

## Quick Reference

- [quick-reference.md](quick-reference.md) - Tabelas de consulta rapida

---

## Conceitos-Chave

| Conceito | Descricao |
|----------|-----------|
| **GTIN** | Numero global de identificacao de item comercial (codigo de barras do produto) |
| **GLN** | Numero global de localizacao (identifica empresas, filiais, depositos) |
| **SSCC** | Codigo serial de container de transporte (identifica paletes e volumes) |
| **GS1-128** | Codigo de barras logistico com Application Identifiers |
| **DataMatrix** | Codigo 2D para rastreabilidade unitaria |
| **Digital Link** | URI que conecta produto fisico a informacoes na web |
| **CNP** | Cadastro Nacional de Produtos da GS1 Brasil |
| **GPC** | Global Product Classification — classificacao hierarquica de produtos |
| **EPC** | Electronic Product Code para identificacao RFID |

---

## Trilha de Aprendizado

| Nivel | Arquivos |
|-------|----------|
| **Iniciante** | concepts/gtin.md, concepts/codigos-barras.md |
| **Intermediario** | patterns/validacao-gtin.md, patterns/cadastro-produtos.md |
| **Avancado** | patterns/rastreabilidade.md, concepts/gs1-digital-link.md |

---

## Uso por Agentes

| Agente | Arquivos Primarios | Caso de Uso |
|--------|---------------------|-------------|
| KB Architect | Todos | Referencia sobre padroes GS1 no varejo |
| Data Engineer | patterns/cadastro-produtos.md, specs/ | Modelagem de dados com GTIN |
| QA/Validacao | patterns/validacao-gtin.md | Validacao de codigos de barras |
