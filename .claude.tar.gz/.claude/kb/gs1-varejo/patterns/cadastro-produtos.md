# Cadastro de Produtos com GTIN

> **Purpose**: Padrao de cadastro de produtos no varejo usando GTIN como chave primaria, incluindo hierarquia de embalagens e sincronizacao via GDSN
> **MCP Validated**: 2026-03-23

## When to Use

- Cadastrar novos produtos no sistema do varejo com codigo de barras GS1
- Estruturar hierarquia de embalagens (unidade, caixa, palete)
- Sincronizar cadastro entre industria e varejo via GDSN/CNP
- Modelar tabelas de produtos em bancos de dados com campos GS1

## Implementation

```python
from dataclasses import dataclass, field
from typing import Optional
from datetime import date


@dataclass
class ProdutoGS1:
    """
    Modelo de cadastro de produto seguindo padrao GS1.
    Campos alinhados com o Cadastro Nacional de Produtos (CNP).
    """
    # Identificacao GS1
    gtin: str                          # GTIN-13 (EAN-13) principal
    gtin_tributario: Optional[str] = None  # cEANTrib na NF-e
    gtin_14: Optional[str] = None      # GTIN-14 da caixa de embarque

    # Descricao
    descricao_completa: str = ""       # Ate 200 caracteres
    descricao_pdv: str = ""            # Ate 30 caracteres (para cupom fiscal)
    marca: str = ""

    # Classificacao
    ncm: str = ""                      # NCM (8 digitos) para NF-e
    cest: Optional[str] = None         # CEST (7 digitos) para ICMS-ST
    gpc_codigo: Optional[str] = None   # GS1 GPC (Global Product Classification)
    gpc_descricao: Optional[str] = None

    # Medidas
    peso_bruto_kg: float = 0.0
    peso_liquido_kg: float = 0.0
    altura_cm: float = 0.0
    largura_cm: float = 0.0
    profundidade_cm: float = 0.0

    # Embalagem
    unidade_medida: str = "UN"         # UN, KG, LT, ML, GR, MT, M2, M3
    quantidade_embalagem: int = 1
    tipo_embalagem: str = ""           # CX, FD, PT, SC, etc.

    # Fornecedor
    gln_fornecedor: Optional[str] = None
    cnpj_fornecedor: str = ""

    # Controle
    data_cadastro: date = field(default_factory=date.today)
    data_ultima_atualizacao: date = field(default_factory=date.today)
    ativo: bool = True


# Hierarquia de embalagens GS1
HIERARQUIA_EMBALAGEM = {
    "unidade_consumidor": {
        "gtin": "GTIN-13",     # EAN-13 na embalagem individual
        "codigo_barras": "EAN-13",
        "exemplo": "7891234567895 (1 unidade de shampoo)"
    },
    "embalagem_multipla": {
        "gtin": "GTIN-13",     # Outro GTIN-13 para o pack
        "codigo_barras": "EAN-13",
        "exemplo": "7891234567888 (pack com 3 unidades)"
    },
    "caixa_embarque": {
        "gtin": "GTIN-14",    # Indicador (1-8) + GTIN-13 base
        "codigo_barras": "ITF-14 ou GS1-128",
        "exemplo": "17891234567892 (caixa com 12 unidades)"
    },
    "palete": {
        "identificador": "SSCC",
        "codigo_barras": "GS1-128",
        "exemplo": "SSCC 378912340000000014 (80 caixas)"
    }
}
```

## Configuration

| Campo | Obrigatorio NF-e | Padrao GS1 | Descricao |
|-------|-------------------|------------|-----------|
| `gtin` (cEAN) | Sim | GTIN-13 | Codigo de barras principal |
| `gtin_tributario` (cEANTrib) | Sim | GTIN-13/14 | Codigo tributario |
| `ncm` | Sim | N/A | Nomenclatura Comum Mercosul |
| `descricao_completa` (xProd) | Sim | Ate 200 chars | Nome do produto |
| `gpc_codigo` | Nao | GPC Brick | Classificacao global |
| `gln_fornecedor` | Nao | GLN-13 | Para EDI/GDSN |

## Example Usage

```python
# Cadastro de um produto no varejo
produto = ProdutoGS1(
    gtin="7891234567895",
    gtin_tributario="7891234567895",
    gtin_14="17891234567892",
    descricao_completa="Shampoo Anticaspa Marca X 400ml",
    descricao_pdv="SHAMPOO MARCA X 400ML",
    marca="Marca X",
    ncm="33051000",
    gpc_codigo="10000267",
    gpc_descricao="Shampoo/Condicionador",
    peso_bruto_kg=0.450,
    peso_liquido_kg=0.400,
    altura_cm=22.0,
    largura_cm=7.0,
    profundidade_cm=5.0,
    unidade_medida="UN",
    quantidade_embalagem=1,
    cnpj_fornecedor="12345678000190",
    gln_fornecedor="7891234000017"
)

# SQL para tabela de produtos
SQL_CRIAR_TABELA = """
CREATE TABLE produtos (
    gtin           VARCHAR(14) PRIMARY KEY,
    gtin_tributario VARCHAR(14),
    gtin_14        VARCHAR(14),
    descricao      VARCHAR(200) NOT NULL,
    descricao_pdv  VARCHAR(30),
    marca          VARCHAR(100),
    ncm            CHAR(8) NOT NULL,
    cest           CHAR(7),
    gpc_codigo     VARCHAR(10),
    peso_bruto_kg  DECIMAL(10,3),
    peso_liquido_kg DECIMAL(10,3),
    unidade_medida VARCHAR(3) DEFAULT 'UN',
    gln_fornecedor CHAR(13),
    ativo          BOOLEAN DEFAULT TRUE,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_produtos_ncm ON produtos(ncm);
CREATE INDEX idx_produtos_fornecedor ON produtos(gln_fornecedor);
"""
```

## See Also

- [GTIN](../concepts/gtin.md)
- [GLN](../concepts/gln.md)
- [Validacao GTIN](../patterns/validacao-gtin.md)
- [Nota Fiscal Eletronica](../patterns/nota-fiscal-eletronica.md)
