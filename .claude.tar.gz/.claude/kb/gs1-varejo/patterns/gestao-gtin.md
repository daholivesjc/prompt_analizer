# Gestao de GTIN — Ciclo de Vida e Boas Praticas

> **Purpose**: Regras e padroes para gestao completa do ciclo de vida do GTIN, desde a criacao ate a reutilizacao
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

A gestao correta do GTIN envolve regras claras sobre quando criar, modificar, descontinuar e reutilizar numeros. O detentor da marca e sempre o responsavel, e o SGN (Sistema de Gerenciamento de Numeros) ou CNP da GS1 Brasil sao as ferramentas oficiais para essa gestao.

## Ciclo de Vida do GTIN

```text
CRIACAO                    USO ATIVO              DESCONTINUACAO         REUTILIZACAO
   |                          |                         |                     |
   v                          v                         v                     v
Cadastro no CNP  -->  Produto no mercado  -->  Produto retirado  -->  Novo produto
(gerar GTIN)          (NF-e, PDV, EDI)         (quarentena)           (apos prazo)

Prazos de quarentena:
  Geral:        48 meses minimo
  Vestuario:    30 meses minimo
  Medicamentos: NUNCA reutilizar
```

## Quando Criar Novo GTIN

### DEVE receber novo GTIN

| Situacao | Motivo |
|----------|--------|
| Alterou quantidade/peso/volume | Consumidor espera mesma quantidade |
| Mudou tipo de embalagem | Lata para vidro, saco para caixa |
| Trocou marca ou submarca | Identidade comercial diferente |
| Traduziu rotulo para outro idioma | Mercado de destino diferente |
| Pack promocional com embalagem propria | Nova unidade de venda |
| Mudanca de dimensoes da embalagem | Afeta logistica e gondola |

### NAO deve receber novo GTIN

| Situacao | Motivo |
|----------|--------|
| Pequena melhoria de formulacao | Sem impacto ao consumidor |
| Rejuvenescimento visual | Mesmo conteudo, nova arte |
| Troca de fornecedor de insumo | Produto final identico |
| Promocao tipo "20% gratis" sem alterar embalagem | Comunicacao, nao produto |
| Cupom de desconto interno | Nao altera o item comercial |

## Gestao de Promocoes

```text
Promocao REQUER novo GTIN:
  - "Leve 3 Pague 2" com embalagem agrupadora propria
  - "500ml pelo preco de 400ml" (alterou quantidade)
  - Edicao limitada com embalagem diferente

Promocao NAO requer novo GTIN:
  - Cupom de desconto no caixa
  - Desconto percentual no preco (sem alterar produto)
  - Programa de fidelidade (pontos extras)
```

## Prefixo 2 — Codigos de Uso Interno

```text
Faixas reservadas para uso interno da loja (prefixo 20-26):

  Estrutura com peso variavel (indicadores 0-4):
  +----+-------+------+----+
  | 2X | Codigo| Peso | DV |
  +----+-------+------+----+
    Uso: hortifruti, acougue, padaria, frios fatiados

  Estrutura com preco (indicadores 5-6):
  +----+-------+-------+----+
  | 2X | Codigo| Preco | DV |
  +----+-------+-------+----+
    Uso: producao propria, produtos preparados na loja

IMPORTANTE:
  - Codigos com prefixo 2 NAO devem circular fora da loja
  - NAO devem aparecer em NF-e para outros destinatarios
  - Sao de responsabilidade exclusiva do varejista
```

## GTIN no Banco de Dados

```text
Regra de armazenamento:
  - SEMPRE armazenar como STRING de 14 digitos
  - SEMPRE justificar com zeros a esquerda
  - NUNCA processar partes isoladas (prefixo, empresa, produto)
  - NUNCA armazenar como INTEGER (perde zeros a esquerda)

Exemplos de conversao:
  GTIN-8:   40170725  -->  "00000040170725"
  GTIN-12:  012345678905  -->  "00012345678905"
  GTIN-13:  7891234567895  -->  "07891234567895"
  GTIN-14:  17891234567892  -->  "17891234567892"

Em SQL:
  LPAD(gtin, 14, '0')  -- padroniza para 14 digitos

Em PySpark:
  F.lpad(F.col("gtin"), 14, "0")
```

## SGN — Sistema de Gerenciamento de Numeros

- Ferramenta da GS1 para controle de faixas de numeracao
- Integrado ao CNP para geracao automatica de GTINs
- Permite visualizar GTINs disponiveis, em uso e descontinuados

## Responsabilidade

```text
Quem numera?
  Regra geral:      Detentor da marca
  Marca propria:    Varejista (e o detentor)
  Importacao:       Importador exclusivo (numeracao temporaria)
  Uso interno:      Varejista (prefixo 2)
  Fabricacao por terceiros: Detentor da marca (nao o fabricante)
```

## Common Mistakes

### Wrong

```text
Armazenar GTIN como numero inteiro:
  INTEGER: 7891234567895 -> perde zeros iniciais em GTIN-8

Reutilizar GTIN apos 12 meses:
  Produto A descontinuado jan/2025 -> GTIN em Produto B jan/2026
  Resultado: sistemas com cache ainda mostram Produto A
```

### Correct

```text
Armazenar como string de 14 digitos:
  "07891234567895" -> preserva formato, facilita JOINs

Respeitar quarentena de 48 meses:
  Produto A descontinuado jan/2025 -> GTIN disponivel jan/2029
```

## Related

- [GTIN](../concepts/gtin.md)
- [CNP — Cadastro Nacional de Produtos](../concepts/cnp-cadastro-produtos.md)
- [Validacao GTIN](../patterns/validacao-gtin.md)
- [Cadastro de Produtos](../patterns/cadastro-produtos.md)
- [Codigos de Barras](../concepts/codigos-barras.md)
