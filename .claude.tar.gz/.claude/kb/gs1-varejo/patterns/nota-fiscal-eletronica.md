# GS1 na Nota Fiscal Eletronica (NF-e)

> **Purpose**: Uso dos padroes GS1 nos campos da NF-e brasileira, incluindo GTIN no XML, validacao pela SEFAZ e integracao com cadastro de produtos
> **MCP Validated**: 2026-03-23

## When to Use

- Emitir NF-e com campos GS1 preenchidos corretamente (cEAN, cEANTrib)
- Validar GTIN antes da transmissao para evitar rejeicao pela SEFAZ
- Integrar cadastro de produtos GS1 com sistema emissor de NF-e
- Processar XML de NF-e extraindo dados GS1 para analytics

## Implementation

```xml
<!--
  Campos GS1 no XML da NF-e (versao 4.00)
  Grupo I - Produtos e Servicos (det/prod)
-->
<det nItem="1">
  <prod>
    <!-- cEAN: Codigo de barras GTIN do produto -->
    <cEAN>7891234567895</cEAN>

    <!-- cProd: Codigo interno do emitente -->
    <cProd>SKU001234</cProd>

    <!-- xProd: Descricao do produto -->
    <xProd>SHAMPOO ANTICASPA MARCA X 400ML</xProd>

    <!-- NCM: Nomenclatura Comum do Mercosul -->
    <NCM>33051000</NCM>

    <!-- CEST: Codigo Especificador da Substituicao Tributaria -->
    <CEST>2800100</CEST>

    <!-- uCom: Unidade comercial -->
    <uCom>UN</uCom>

    <!-- qCom: Quantidade comercial -->
    <qCom>10.0000</qCom>

    <!-- cEANTrib: Codigo de barras GTIN da unidade tributavel -->
    <cEANTrib>7891234567895</cEANTrib>

    <!-- uTrib: Unidade tributavel -->
    <uTrib>UN</uTrib>

    <!-- qTrib: Quantidade tributavel -->
    <qTrib>10.0000</qTrib>
  </prod>
</det>
```

```python
"""
Validacao e extracao de campos GS1 em XML de NF-e.
"""
import xml.etree.ElementTree as ET
from typing import Optional


NFE_NS = {"nfe": "http://www.portalfiscal.inf.br/nfe"}


def extrair_gtins_nfe(xml_path: str) -> list[dict]:
    """
    Extrai todos os GTINs de um XML de NF-e.
    Retorna lista de dicts com item, cEAN, cEANTrib e descricao.
    """
    tree = ET.parse(xml_path)
    root = tree.getroot()

    itens = []
    for det in root.findall(".//nfe:det", NFE_NS):
        prod = det.find("nfe:prod", NFE_NS)
        if prod is None:
            continue

        item = {
            "nItem": det.get("nItem"),
            "cEAN": _get_text(prod, "nfe:cEAN"),
            "cEANTrib": _get_text(prod, "nfe:cEANTrib"),
            "xProd": _get_text(prod, "nfe:xProd"),
            "NCM": _get_text(prod, "nfe:NCM"),
            "cProd": _get_text(prod, "nfe:cProd"),
        }
        itens.append(item)

    return itens


def _get_text(element, tag: str) -> Optional[str]:
    """Extrai texto de um subelemento XML."""
    el = element.find(tag, NFE_NS)
    return el.text if el is not None else None


def validar_cean_nfe(cean: str) -> dict:
    """
    Valida o campo cEAN conforme regras da SEFAZ.

    Regras de validacao (NT 2019.001 v1.60):
    - Aceita: GTIN-8, GTIN-12, GTIN-13, GTIN-14 ou 'SEM GTIN'
    - Digito verificador deve ser valido
    - Nao aceita GTIN zerado (00000000, etc.)
    - GTIN deve existir no CCG (Cadastro Centralizado GTIN)
    """
    resultado = {"cean": cean, "valido": False, "rejeicao": None}

    if cean == "SEM GTIN":
        resultado["valido"] = True
        return resultado

    if not cean.isdigit():
        resultado["rejeicao"] = "886 - cEAN invalido"
        return resultado

    if len(cean) not in (8, 12, 13, 14):
        resultado["rejeicao"] = "886 - Tamanho cEAN invalido"
        return resultado

    if all(c == "0" for c in cean):
        resultado["rejeicao"] = "886 - cEAN zerado"
        return resultado

    # Validar digito verificador
    from .validacao_gtin import validar_gtin
    if not validar_gtin(cean):
        resultado["rejeicao"] = "886 - Digito verificador invalido"
        return resultado

    resultado["valido"] = True
    return resultado
```

## Configuration

| Campo NF-e | Tag XML | Obrigatorio | Regra |
|------------|---------|-------------|-------|
| `cEAN` | `<cEAN>` | Sim | GTIN ou `SEM GTIN` |
| `cEANTrib` | `<cEANTrib>` | Sim | GTIN tributavel ou `SEM GTIN` |
| `NCM` | `<NCM>` | Sim | 8 digitos (nao e GS1, mas relacionado) |
| `CEST` | `<CEST>` | Condicional | 7 digitos (ICMS-ST) |

## Codigos de Rejeicao Relacionados a GS1

| Codigo | Descricao | Causa |
|--------|-----------|-------|
| 886 | Rejeicao: GTIN informado, mas nao cadastrado no CCG | GTIN nao existe no cadastro centralizado |
| 887 | Rejeicao: GTIN incompativel com info do CCG | NCM ou descricao divergente do cadastro |
| 888 | Rejeicao: NCM informado difere do CCG | NCM do XML diferente do cadastrado |
| 889 | Rejeicao: Marca informada difere do CCG | Marca divergente |

## Example Usage

```python
# Processar NF-e para carga em data lake
itens = extrair_gtins_nfe("nfe_35260312345678000190550010000001231234567890.xml")

for item in itens:
    validacao = validar_cean_nfe(item["cEAN"])
    if not validacao["valido"]:
        print(f"Item {item['nItem']}: {validacao['rejeicao']}")
    else:
        print(f"Item {item['nItem']}: GTIN {item['cEAN']} OK")

# Diferenca entre cEAN e cEANTrib:
# cEAN = codigo da embalagem vendida (unidade consumidor)
# cEANTrib = codigo da unidade tributavel
# Exemplo: vende pack de 6 (cEAN do pack), tributa por unidade (cEANTrib da unidade)
```

## Timeline de Obrigatoriedade

| Data | Evento |
|------|--------|
| 2018 | GTIN obrigatorio na NF-e (campo cEAN) |
| 2019 | NT 2019.001: validacao de digito verificador |
| 2020 | Inicio validacao CCG (por CNAE) |
| 2022 | Ampliacao gradual dos CNAEs validados |
| 2024+ | Validacao CCG para todos os segmentos |

## See Also

- [GTIN](../concepts/gtin.md)
- [Validacao GTIN](../patterns/validacao-gtin.md)
- [Cadastro de Produtos](../patterns/cadastro-produtos.md)
- [Rastreabilidade](../patterns/rastreabilidade.md)
