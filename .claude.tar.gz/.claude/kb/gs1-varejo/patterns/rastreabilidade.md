# Rastreabilidade na Cadeia de Suprimentos

> **Purpose**: Implementacao de rastreabilidade usando padroes GS1 para identificar, capturar e compartilhar dados ao longo da cadeia de suprimentos do varejo
> **MCP Validated**: 2026-03-23

## When to Use

- Rastrear produtos da producao ao ponto de venda (farm-to-fork)
- Atender regulamentacoes de rastreabilidade (ANVISA, MAPA, SEFAZ)
- Implementar recall de produtos com precisao de lote/serial
- Garantir autenticidade de produtos (anti-falsificacao)
- Monitorar cadeia fria para pereciveis

## Implementation

```python
"""
Modelo de rastreabilidade GS1 baseado no padrao EPCIS
(Electronic Product Code Information Services).

EPCIS responde 4 perguntas:
  O QUE? -> GTIN + Lote/Serial
  ONDE?  -> GLN
  QUANDO? -> Timestamp
  POR QUE? -> Evento de negocio
"""
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional


class TipoEvento(Enum):
    """Tipos de eventos EPCIS padrao GS1."""
    OBJECT = "ObjectEvent"           # Observacao de objeto
    AGGREGATION = "AggregationEvent" # Agrupamento/desagrupamento
    TRANSACTION = "TransactionEvent" # Vinculo a transacao
    TRANSFORMATION = "TransformationEvent"  # Transformacao


class AcaoEvento(Enum):
    """Acoes possiveis em eventos EPCIS."""
    ADD = "ADD"           # Adicionar (embalagem, paletizacao)
    OBSERVE = "OBSERVE"   # Observar (leitura em ponto de controle)
    DELETE = "DELETE"     # Remover (desagrupamento)


class EtapaNegocio(Enum):
    """Etapas de negocio na cadeia de suprimentos."""
    COMMISSIONING = "urn:epcglobal:cbv:bizstep:commissioning"
    PACKING = "urn:epcglobal:cbv:bizstep:packing"
    SHIPPING = "urn:epcglobal:cbv:bizstep:shipping"
    RECEIVING = "urn:epcglobal:cbv:bizstep:receiving"
    STORING = "urn:epcglobal:cbv:bizstep:storing"
    PICKING = "urn:epcglobal:cbv:bizstep:picking"
    RETAIL_SELLING = "urn:epcglobal:cbv:bizstep:retail_selling"


@dataclass
class EventoRastreabilidade:
    """Evento de rastreabilidade baseado em EPCIS."""
    # O QUE
    gtin: str
    lote: Optional[str] = None
    serial: Optional[str] = None
    sscc: Optional[str] = None

    # ONDE
    gln_origem: Optional[str] = None
    gln_destino: Optional[str] = None

    # QUANDO
    timestamp: datetime = None

    # POR QUE
    tipo_evento: TipoEvento = TipoEvento.OBJECT
    acao: AcaoEvento = AcaoEvento.OBSERVE
    etapa: EtapaNegocio = EtapaNegocio.COMMISSIONING

    def to_epcis_uri(self) -> str:
        """Gera URI EPCIS para o item rastreado."""
        base = f"urn:epc:id:sgtin:{self.gtin}"
        if self.serial:
            return f"{base}.{self.serial}"
        if self.lote:
            return f"urn:epc:class:lgtin:{self.gtin}.{self.lote}"
        return base


# Fluxo tipico de rastreabilidade no varejo
FLUXO_RASTREABILIDADE = [
    {
        "etapa": "1. Producao",
        "evento": "Commissioning",
        "dados_capturados": ["GTIN", "Lote", "Data producao", "GLN fabrica"],
        "codigo": "GS1 DataMatrix com (01)(10)(11)"
    },
    {
        "etapa": "2. Embalagem",
        "evento": "Packing/Aggregation",
        "dados_capturados": ["GTIN-14 caixa", "SSCC palete", "Quantidade"],
        "codigo": "GS1-128 com (01)(10)(37)(17)"
    },
    {
        "etapa": "3. Expedicao",
        "evento": "Shipping",
        "dados_capturados": ["SSCC", "GLN origem", "GLN destino", "NF-e"],
        "codigo": "GS1-128 com (00), ASN via EDI"
    },
    {
        "etapa": "4. Recebimento CD",
        "evento": "Receiving",
        "dados_capturados": ["SSCC", "GLN CD", "Conferencia"],
        "codigo": "Leitura GS1-128 na doca"
    },
    {
        "etapa": "5. Armazenagem",
        "evento": "Storing",
        "dados_capturados": ["SSCC", "Posicao estoque", "Temperatura"],
        "codigo": "WMS com GLN do endereco"
    },
    {
        "etapa": "6. Venda PDV",
        "evento": "Retail Selling",
        "dados_capturados": ["GTIN", "Quantidade", "GLN loja", "Timestamp"],
        "codigo": "Leitura EAN-13 no checkout"
    }
]
```

## Configuration

| Parametro | Valor | Descricao |
|-----------|-------|-----------|
| `nivel_rastreabilidade` | `lote` ou `serial` | Granularidade do rastreamento |
| `retencao_dados` | 5 anos (minimo) | Tempo de retencao de eventos |
| `formato_troca` | EPCIS 2.0 (JSON-LD) | Formato de compartilhamento |
| `frequencia_captura` | Por evento | Cada movimentacao gera evento |

## Example Usage

```python
# Registrar evento de recebimento no CD
evento = EventoRastreabilidade(
    gtin="07891234567895",
    lote="L2026A",
    sscc="378912340000000014",
    gln_origem="7891234000031",   # Fabrica
    gln_destino="7891234000048",  # CD Sao Paulo
    timestamp=datetime(2026, 3, 23, 14, 30, 0),
    tipo_evento=TipoEvento.OBJECT,
    acao=AcaoEvento.OBSERVE,
    etapa=EtapaNegocio.RECEIVING
)

# Em caso de RECALL:
# 1. Identificar GTIN + Lote afetado
# 2. Consultar eventos EPCIS para encontrar todos os GLNs
# 3. Notificar cada ponto de venda que recebeu o lote
# 4. Bloquear venda no PDV pelo GTIN+Lote
```

## Regulamentacao no Brasil

| Setor | Regulamentacao | Exigencia GS1 |
|-------|---------------|---------------|
| Medicamentos | SNCM/ANVISA | DataMatrix com GTIN+Serial obrigatorio |
| Alimentos | MAPA/ANVISA | Lote e validade (AI 10, 17) |
| Cigarros | SCORPIOS/RFB | Codigo unico por unidade |
| Geral varejo | SEFAZ NF-e | GTIN obrigatorio no cEAN |

## See Also

- [SSCC](../concepts/sscc.md)
- [GLN](../concepts/gln.md)
- [GS1 Digital Link](../concepts/gs1-digital-link.md)
- [Nota Fiscal Eletronica](../patterns/nota-fiscal-eletronica.md)
