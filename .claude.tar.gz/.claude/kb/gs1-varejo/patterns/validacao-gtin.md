# Validacao de GTIN

> **Purpose**: Algoritmos e regras para validar codigos GTIN (EAN-13, EAN-8, UPC-A, GTIN-14) incluindo calculo do digito verificador
> **MCP Validated**: 2026-03-23

## When to Use

- Validar codigos de barras digitados manualmente ou lidos por scanner
- Calcular o digito verificador ao gerar novos GTINs
- Verificar integridade de dados de cadastro de produtos
- Validar campo cEAN/cEANTrib na NF-e antes de transmissao

## Implementation

```python
def calcular_digito_verificador(codigo: str) -> int:
    """
    Calcula o digito verificador de um GTIN (EAN-8, EAN-13, GTIN-14).
    O algoritmo e o mesmo para todas as variantes.

    Regra: soma ponderada com pesos alternados 1 e 3 (da direita para esquerda),
    digito verificador = (10 - (soma % 10)) % 10
    """
    if not codigo.isdigit():
        raise ValueError(f"Codigo deve conter apenas digitos: {codigo}")

    tamanho_esperado = {7: 8, 11: 12, 12: 13, 13: 14}
    if len(codigo) not in tamanho_esperado:
        raise ValueError(f"Tamanho invalido: {len(codigo)} digitos")

    soma = 0
    for i, digito in enumerate(reversed(codigo)):
        peso = 3 if i % 2 == 0 else 1
        soma += int(digito) * peso

    return (10 - (soma % 10)) % 10


def validar_gtin(gtin: str) -> bool:
    """
    Valida um GTIN completo (com digito verificador).
    Aceita GTIN-8, GTIN-12, GTIN-13 e GTIN-14.
    """
    if not gtin.isdigit():
        return False

    if len(gtin) not in (8, 12, 13, 14):
        return False

    corpo = gtin[:-1]
    digito_informado = int(gtin[-1])
    digito_calculado = calcular_digito_verificador(corpo)

    return digito_informado == digito_calculado


def normalizar_gtin(gtin: str) -> str:
    """
    Normaliza qualquer GTIN para formato de 14 digitos
    preenchendo com zeros a esquerda.
    """
    if not validar_gtin(gtin):
        raise ValueError(f"GTIN invalido: {gtin}")
    return gtin.zfill(14)


def validar_gtin_brasileiro(gtin: str) -> dict:
    """
    Validacao completa para GTIN no contexto brasileiro.
    Retorna dict com status e detalhes.
    """
    resultado = {
        "gtin": gtin,
        "valido": False,
        "tipo": None,
        "prefixo_pais": None,
        "uso_interno": False,
        "erros": []
    }

    if not gtin.isdigit():
        resultado["erros"].append("Contem caracteres nao numericos")
        return resultado

    tamanhos = {8: "GTIN-8", 12: "GTIN-12", 13: "GTIN-13", 14: "GTIN-14"}
    if len(gtin) not in tamanhos:
        resultado["erros"].append(f"Tamanho invalido: {len(gtin)}")
        return resultado

    resultado["tipo"] = tamanhos[len(gtin)]

    if not validar_gtin(gtin):
        resultado["erros"].append("Digito verificador invalido")
        return resultado

    gtin14 = gtin.zfill(14)
    prefixo3 = gtin14[1:4]
    prefixo2 = gtin14[1:3]

    if prefixo3 in ("789", "790"):
        resultado["prefixo_pais"] = "Brasil"
    elif prefixo2 == "20" or (20 <= int(prefixo2) <= 29):
        resultado["uso_interno"] = True
        resultado["prefixo_pais"] = "Uso interno"

    resultado["valido"] = True
    return resultado
```

## Configuration

| Parametro | Valor | Descricao |
|-----------|-------|-----------|
| `tamanhos_validos` | `[8, 12, 13, 14]` | Tamanhos aceitos de GTIN |
| `prefixo_brasil` | `789, 790` | Prefixos GS1 Brasil |
| `prefixo_interno` | `20-29` | Faixa reservada para uso interno |
| `sem_gtin` | `SEM GTIN` | Valor aceito na NF-e quando nao ha GTIN |

## Example Usage

```python
# Validacao simples
print(validar_gtin("7891234567895"))   # True
print(validar_gtin("7891234567890"))   # False (check digit errado)

# Calcular digito verificador
print(calcular_digito_verificador("789123456789"))  # 5

# Normalizacao para 14 digitos
print(normalizar_gtin("7891234567895"))  # "07891234567895"
print(normalizar_gtin("40170725"))       # "00000040170725"

# Validacao brasileira completa
info = validar_gtin_brasileiro("7891234567895")
# {'gtin': '7891234567895', 'valido': True, 'tipo': 'GTIN-13',
#  'prefixo_pais': 'Brasil', 'uso_interno': False, 'erros': []}

# Produto de uso interno (balanca)
info = validar_gtin_brasileiro("2012345000015")
# {'uso_interno': True, 'prefixo_pais': 'Uso interno', ...}
```

## Regras Especiais NF-e

| Situacao | Valor cEAN | Observacao |
|----------|------------|------------|
| Produto com GTIN | GTIN-13 valido | Validado pelo SEFAZ |
| Produto sem GTIN | `SEM GTIN` | Literal, aceito desde NT 2019.001 |
| Produto pesavel (balanca) | GTIN com prefixo 2 | Uso interno, nao validado |
| Servico | `SEM GTIN` | Servicos nao tem GTIN |

## See Also

- [GTIN](../concepts/gtin.md)
- [Cadastro de Produtos](../patterns/cadastro-produtos.md)
- [Nota Fiscal Eletronica](../patterns/nota-fiscal-eletronica.md)
