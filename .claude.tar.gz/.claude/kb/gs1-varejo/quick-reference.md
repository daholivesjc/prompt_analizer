# GS1 para Varejo Quick Reference

> Tabelas de consulta rapida. Para exemplos de codigo, veja os arquivos linkados.
> **MCP Validated**: 2026-03-23

## Chaves de Identificacao GS1

| Chave | Tamanho | Identifica | Exemplo |
|-------|---------|------------|---------|
| GTIN-8 (EAN-8) | 8 digitos | Produtos pequenos | 40170725 |
| GTIN-13 (EAN-13) | 13 digitos | Produtos no PDV | 7891234567895 |
| GTIN-14 | 14 digitos | Caixas e fardos | 17891234567892 |
| UPC-A | 12 digitos | Produtos (America do Norte) | 012345678905 |
| GLN | 13 digitos | Locais (empresa, filial) | 7891234000017 |
| SSCC | 18 digitos | Unidades logisticas | 378912345000000014 |
| GRAI | 29+ digitos | Ativos retornaveis | 78912340000001234 |
| GSRN | 18 digitos | Relacao de servico | 789123400000000018 |

## Application Identifiers (AIs) Comuns

| AI | Conteudo | Formato | Uso |
|----|----------|---------|-----|
| (01) | GTIN | N14 | Identificacao do produto |
| (10) | Lote | X..20 | Numero do lote |
| (11) | Data de producao | N6 (AAMMDD) | Rastreabilidade |
| (13) | Data de embalagem | N6 (AAMMDD) | Logistica |
| (15) | Melhor consumir ate | N6 (AAMMDD) | Validade |
| (17) | Data de validade | N6 (AAMMDD) | Validade |
| (21) | Numero serial | X..20 | Unitario |
| (37) | Quantidade | N..8 | Contagem |
| (310n) | Peso liquido (kg) | N6 | Pesaveis |
| (391n) | Preco | N..15 | Valor |

## Estrutura do GTIN-13 (EAN-13)

| Posicao | Conteudo | Exemplo |
|---------|----------|---------|
| 1-3 | Prefixo GS1 (pais) | 789 (Brasil) |
| 4-12 | Codigo empresa + produto | 123456789 |
| 13 | Digito verificador | 5 |

## Decision Matrix

| Caso de Uso | Codigo Recomendado |
|-------------|-------------------|
| Produto no PDV (varejo) | EAN-13 (GTIN-13) |
| Produto muito pequeno | EAN-8 (GTIN-8) |
| Caixa de embarque | GTIN-14 ou ITF-14 |
| Palete/container | SSCC + GS1-128 |
| Rastreabilidade unitaria | GS1 DataMatrix |
| Exportacao para EUA/Canada | UPC-A (GTIN-12) |
| Identificar filial/deposito | GLN |
| Cupom fiscal eletronico | GTIN-13 (campo cEAN) |

## Prefixos GS1 por Pais

| Prefixo | Pais/Regiao |
|---------|-------------|
| 789-790 | Brasil |
| 000-019 | EUA/Canada |
| 300-379 | Franca |
| 400-440 | Alemanha |
| 450-459, 490-499 | Japao |
| 690-699 | China |
| 840-849 | Espanha |
| 860 | Turquia |

## Common Pitfalls

| Nao Faca | Faca |
|----------|------|
| Usar EAN-13 inventado sem registro | Cadastrar na GS1 Brasil para obter prefixo |
| Ignorar o digito verificador | Sempre calcular e validar o check digit |
| Reutilizar GTIN de produto descontinuado | Aguardar 48 meses antes de reutilizar |
| Usar GTIN-13 em caixa de embarque | Usar GTIN-14 para niveis acima da unidade |
| Confundir EAN com codigo interno | Codigo interno usa prefixo 2 (20-29) |

## Documentacao Relacionada

| Topico | Caminho |
|--------|---------|
| Introducao | `concepts/gtin.md` |
| Validacao | `patterns/validacao-gtin.md` |
| Indice Completo | `index.md` |
