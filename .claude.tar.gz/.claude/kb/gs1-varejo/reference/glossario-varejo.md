# Glossario do Varejo

> **Purpose**: Termos e siglas essenciais do varejo brasileiro, da operacao a gestao
> **MCP Validated**: 2026-03-23

## Termos A-C

| Termo | Definicao |
|-------|-----------|
| **Acervo** | Quantidade total de produtos disponiveis para venda |
| **Analise ABC** | Metodo de classificacao de produtos com base em seu impacto no faturamento |
| **B2C** (Business to Consumer) | Modelo de venda direta ao consumidor final |
| **Break-even** | Ponto de equilibrio entre receita e custo; quando a empresa "zera" o prejuizo |
| **CAC** (Custo de Aquisicao de Cliente) | Quanto custa conquistar um novo cliente |
| **Canais de venda** | Diferentes plataformas de comercializacao: loja fisica, e-commerce, marketplaces, WhatsApp etc. |
| **Capex** | Investimentos em bens duraveis (maquinas, sistemas, estrutura) |
| **Chargeback** | Devolucao forcada de uma transacao (geralmente por fraude ou disputa no cartao) |
| **Churn rate** | Taxa de cancelamento ou perda de clientes |
| **CMV** (Custo da Mercadoria Vendida) | Valor gasto para adquirir os produtos vendidos |
| **CRM** (Customer Relationship Management) | Sistema para gestao do relacionamento com o cliente |
| **Cross-docking** | Modelo logistico em que o produto nao passa por estoque; vai direto ao cliente |
| **Cross-sell** | Estrategia de venda complementar ("Quem comprou isso tambem levou...") |
| **Curva de demanda** | Representa a variacao de vendas de um produto em funcao do preco |

## Termos D-F

| Termo | Definicao |
|-------|-----------|
| **Demanda reprimida** | Quando ha intencao de compra, mas falta estoque, preco acessivel ou oferta adequada |
| **DRE** (Demonstrativo de Resultado do Exercicio) | Relatorio que mostra se o negocio esta gerando lucro ou prejuizo |
| **E-commerce** | Comercio eletronico, vendas realizadas por loja virtual |
| **EAN** (European Article Number) | Codigo de barras padrao usado para identificar produtos. Ver [gtin.md](../concepts/gtin.md) |
| **ERP** (Enterprise Resource Planning) | Sistema que centraliza e integra todas as areas da empresa |
| **Estoque minimo** | Nivel minimo de produtos necessario para evitar rupturas |
| **Fidelizacao** | Estrategias para manter clientes ativos e recorrentes |
| **Forecast** | Previsao de vendas com base em dados historicos e tendencias |

## Termos G-M

| Termo | Definicao |
|-------|-----------|
| **Giro de estoque** | Numero de vezes que o estoque e renovado em um periodo |
| **GMV** (Gross Merchandise Volume) | Valor total de vendas realizadas em um canal |
| **KPIs** (Indicadores de desempenho) | Metricas usadas para avaliar o desempenho da loja |
| **Logistica reversa** | Processo de devolucao de produtos do consumidor para a loja |
| **LTV** (Lifetime Value) | Valor total que um cliente deixa na empresa durante todo o seu relacionamento |
| **Margem de lucro** | Diferenca entre o preco de venda e o custo |
| **Marketplaces** | Plataformas online onde varias lojas vendem seus produtos (Ex: Mercado Livre, Shopee) |
| **Multicanal** | Presenca em varios canais de venda, sem integracao entre eles |

## Termos N-P

| Termo | Definicao |
|-------|-----------|
| **NPS** (Net Promoter Score) | Indicador de satisfacao e lealdade do cliente |
| **Omnichannel** | Integracao entre todos os canais de venda e atendimento |
| **PDV** (Ponto de Venda) | Sistema utilizado na frente de caixa da loja fisica |
| **Picking** | Processo de separacao de pedidos no estoque |
| **Plano de contas** | Estrutura que organiza as receitas e despesas da empresa |
| **Precificacao dinamica** | Ajuste automatico de precos com base na demanda, concorrencia e margem |
| **Programa de fidelidade** | Estrategia para incentivar compras recorrentes |

## Termos R-S

| Termo | Definicao |
|-------|-----------|
| **ROI** (Retorno sobre o investimento) | Indicador de rentabilidade de uma acao ou campanha |
| **Ruptura de estoque** | Quando um produto se esgota e nao ha reposicao imediata |
| **SAC** (Servico de Atendimento ao Cliente) | Canal de contato pos-venda |
| **Sell-in** | Venda do fornecedor para o varejista |
| **Sell-out** | Venda do varejista para o consumidor final |
| **SKU** (Stock Keeping Unit) | Codigo unico que identifica cada item do estoque. Ver [gtin.md](../concepts/gtin.md) |
| **Supply chain** | Cadeia de suprimentos — da compra ao consumidor |

## Termos T-V

| Termo | Definicao |
|-------|-----------|
| **Taxa de conversao** | Porcentagem de visitantes que se tornam compradores |
| **Ticket medio** | Valor medio gasto por cliente em uma compra |
| **TMA** (Tempo Medio de Atendimento) | Media de tempo para atender um cliente |
| **Turnover** | Rotatividade de colaboradores |
| **Upsell** | Estrategia para vender uma versao mais completa ou cara de um produto |
| **Varejo 4.0** | Nova era do varejo com foco em digitalizacao, dados e integracao de canais |
| **XaaS** (Anything as a Service) | Modelo de servicos on-demand integrados ao varejo (instalacao, assinatura, manutencao) |

## Termos Estrategicos (BMC / PwC)

| Termo | Definicao |
|-------|-----------|
| **BMC** (Business Model Canvas) | Framework de 9 blocos que descreve como a empresa cria, entrega e captura valor |
| **Value Proposition** | Proposta de valor: sortimento, conveniencia, frescor, preco justo |
| **Revenue Streams** | Fontes de receita: vendas 1P, comissao 3P, servicos, retail media |
| **Key Partners** | Parceiros-chave: fabricantes, atacadistas, locadores, operadores logisticos |
| **Cost Structure** | Estrutura de custos: COGS, alugueis, logistica, pessoal, marketing |
| **EV/Revenue** | Enterprise Value / Receita anual — metrica de valuation (PwC) |
| **Revenue CAGR** | Taxa de crescimento composto da receita em periodo (PwC) |
| **Masters of Scale** | Arquetipo PwC: varejistas de escala massiva (Amazon, Walmart) |
| **Niche Specializers** | Arquetipo PwC: especialistas em categoria (Chewy, Tractor Supply) |
| **Experience Exemplars** | Arquetipo PwC: experiencia premium (Apple, Sephora) |
| **Innovation Accelerators** | Arquetipo PwC: inovacao em produtos e modelos (Uniqlo, Wayfair) |
| **Value Optimizers** | Arquetipo PwC: melhor valor ao menor preco (Dollar Tree, Five Below) |
| **Retail Media** | Receita de publicidade dentro da plataforma do varejista |
| **Ecosystem Orchestrator** | Varejista que cria plataforma conectando parceiros e servicos |
| **Channel Disintermediation** | Venda direta ao consumidor, sem intermediarios |

## Relacionamentos com KBs

| Termo | KB Relacionada | Arquivo |
|-------|----------------|---------|
| EAN / SKU / Giro de estoque | gs1-varejo | [concepts/gtin.md](../concepts/gtin.md) |
| Analise ABC / CMV / Margem | analise-negocios-kpis | [concepts/kpis-varejo.md](../../analise-negocios-kpis/concepts/kpis-varejo.md) |
| DRE / Break-even / ROI | analise-negocios-kpis | [concepts/analise-financeira.md](../../analise-negocios-kpis/concepts/analise-financeira.md) |
| Churn / LTV / NPS / RFM | analise-negocios-kpis | [concepts/analise-clientes.md](../../analise-negocios-kpis/concepts/analise-clientes.md) |
| Sell-in / Sell-out / Forecast | analise-negocios-kpis | [concepts/analise-vendas.md](../../analise-negocios-kpis/concepts/analise-vendas.md) |
| Giro / Ruptura / Estoque minimo | analise-negocios-kpis | [concepts/analise-estoque.md](../../analise-negocios-kpis/concepts/analise-estoque.md) |
| Cross-docking / Supply chain | gs1-varejo | [patterns/rastreabilidade.md](../patterns/rastreabilidade.md) |
| Ticket medio / Conversao / KPIs | modelagem-dimensional | [patterns/modelagem-vendas-varejo.md](../../modelagem-dimensional/patterns/modelagem-vendas-varejo.md) |
| BMC / Arquetipos / XaaS | analise-negocios-kpis | [concepts/arquetipos-varejo.md](../../analise-negocios-kpis/concepts/arquetipos-varejo.md) |
| Schema Evolution | modelagem-dimensional | [concepts/schema-evolution.md](../../modelagem-dimensional/concepts/schema-evolution.md) |
