# Granularidade (Grain)

> **Purpose**: Definicao do nivel de detalhe de cada linha na tabela fato — a decisao mais importante do modelo
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

O grain (granularidade) e a primeira e mais critica decisao ao projetar uma tabela fato.
Define exatamente o que uma unica linha representa. Kimball enfatiza: "declare o grain
antes de escolher qualquer dimensao ou metrica." Um grain ambiguo gera problemas de
dupla contagem e metricas inconsistentes.

## The Pattern

```sql
-- GRAIN: "Uma linha por item vendido em uma transacao"
-- Declaracao explicita define todas as dimensoes e metricas possiveis

-- Grain CORRETO: atomico (nivel mais baixo)
-- fato_vendas: 1 linha = 1 item de 1 cupom em 1 loja em 1 dia
CREATE TABLE fato_vendas_item (
    sk_data       INT,   -- QUANDO vendeu
    sk_loja       INT,   -- ONDE vendeu
    sk_produto    INT,   -- O QUE vendeu
    sk_cliente    INT,   -- QUEM comprou
    sk_promocao   INT,   -- COM QUAL promocao
    nro_cupom     VARCHAR(20),  -- degenerate dimension
    quantidade    DECIMAL(10,2),
    valor_unitario DECIMAL(10,2),
    valor_total   DECIMAL(12,2)
);

-- Grain AGREGADO (usar apenas quando atomico nao e possivel)
-- fato_vendas_diarias: 1 linha = total por produto por loja por dia
CREATE TABLE fato_vendas_diarias (
    sk_data       INT,
    sk_loja       INT,
    sk_produto    INT,
    qtd_total     DECIMAL(12,2),
    valor_total   DECIMAL(14,2),
    num_transacoes INT
);
```

## Processo de Definicao (4 passos Kimball)

| Passo | Acao | Exemplo |
|-------|------|---------|
| 1. Selecione o processo de negocio | Qual evento modelar? | Vendas no PDV |
| 2. Declare o grain | O que 1 linha significa? | 1 item vendido |
| 3. Identifique as dimensoes | Quem/o que/onde/quando? | data, loja, produto, cliente |
| 4. Identifique as metricas | Quais numeros medir? | quantidade, valor, desconto |

## Niveis Comuns de Grain

| Processo | Grain Atomico | Grain Agregado | Recomendacao |
|----------|---------------|----------------|-------------|
| Vendas | Item do cupom | Total diario/loja | Atomico |
| Estoque | Produto/loja/dia | Produto/regiao/mes | Atomico |
| Navegacao web | Clique/pageview | Sessao | Atomico |
| Logistica | Movimento de SKU | Carga completa | Atomico |

## Common Mistakes

### Wrong

```sql
-- Grain misto: linhas com granularidades diferentes na mesma tabela
INSERT INTO fato_vendas VALUES
    (20260301, 1, 100, 50.00),   -- 1 item vendido
    (20260301, 1, NULL, 5000.00); -- total da loja (grain diferente!)
```

### Correct

```sql
-- Grain uniforme: cada tabela tem UM grain
-- fato_vendas_item -> grain: 1 item vendido
-- fato_vendas_diarias -> grain: total por produto/loja/dia (tabela separada)
```

## Multiplos Grains em um Processo de Negocio

Um unico processo de negocio pode exigir **fatos separadas com grains diferentes**. Nunca force metricas ou dimensoes de grains diferentes na mesma tabela.

```text
Exemplo: Processo "Vendas no Varejo"
  Grain 1 (tracking vendas):  1 item vendido por cupom
  Grain 2 (tracking devoluções): 1 item devolvido por cliente

  -> Crie 2 tabelas fato separadas, cada uma com seu grain
  -> NAO misture vendas e devolucoes na mesma fato
```

### Quando Criar Fatos Separadas

| Situacao | Acao |
|----------|------|
| Fatos nao verdadeiros para o grain | Mova para fato separada |
| Dimensoes nao verdadeiras para o grain | Mova para fato separada |
| Processos de negocio diferentes | Sempre fatos separadas |
| Grain agregado complementar | Crie tabela de agregacao separada |

## Impacto do Grain

| Perspectiva | Grain Atomico | Grain Agregado |
|-------------|---------------|----------------|
| Negocio | Flexivel, responde perguntas futuras | Limitado as perguntas atuais |
| Tecnico | Fato maior, mais storage/ETL | Fato menor, mais rapido |
| Projeto | Mais complexo, mais tabelas fonte | Mais simples, menos mapeamento |

## Grain e Tipo de Fato

| Tipo Fato | Grain Tipico | Observacao |
|-----------|-------------|------------|
| Transacional | 1 evento atomico | Grain mais baixo possivel |
| Periodica | 1 snapshot por periodo (dia/mes) | Grain do snapshot, nao do evento |
| Acumulada | 1 ciclo de vida do processo | Grain do processo inteiro |

## Regra de Ouro

> **Sempre prefira o grain mais atomico possivel.** Dados atomicos podem ser
> agregados para qualquer nivel; dados pre-agregados nao podem ser desagregados.
> Se a fonte fornece o detalhe, capture-o. Mesmo que o negocio so precise de
> dados mensais hoje, armazene o diario — o custo adicional e justificado pela
> flexibilidade futura.

## Related

- [Tabelas Fato](../concepts/tabelas-fato.md)
- [Star Schema](../concepts/star-schema.md)
- [Modelo Vendas Varejo](../patterns/modelagem-vendas-varejo.md)
