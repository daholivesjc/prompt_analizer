# Evolucao de Schema Multidimensional

> **Purpose**: Estrategias para evolucao de schemas de data warehouse quando fontes ou requisitos mudam
> **Confidence**: 0.90
> **Source**: Thenmozhi & Vivekanandan (2014) — "An Ontological Approach to Handle Multidimensional Schema Evolution"
> **MCP Validated**: 2026-03-23

## Overview

Schemas de data warehouse nao sao estaticos. Mudancas nas fontes operacionais (novo campo, tabela renomeada)
ou nos requisitos de negocio (nova dimensao de analise, nova metrica) exigem evolucao do modelo dimensional.
O custo de evolucao manual e alto — a abordagem sistematica reduz erros e custo de manutencao.

## Causas de Evolucao

| Causa | Exemplo | Impacto no DW |
|-------|---------|---------------|
| **Mudanca na fonte** | ERP adiciona campo `cod_promocao` na tabela de vendas | Nova dimensao ou atributo na fato |
| **Mudanca nos requisitos** | Negocio quer analisar vendas por fornecedor | Nova dimensao, bridge table ou fato |
| **Mudanca regulatoria** | Nova obrigacao fiscal (CEST, NF-e 4.0) | Novos atributos em dimensoes existentes |
| **Novo canal de venda** | Lancamento de marketplace 3P | Nova granularidade, metricas (GMV, take rate) |
| **Fusao/aquisicao** | Incorporacao de rede de lojas | Merge de dimensoes conformadas |

## Operadores de Evolucao

Tres operacoes basicas cobrem todas as mudancas possiveis:

| Operador | Elemento DW | Mudancas Elementares |
|----------|-------------|----------------------|
| **Adicao** | Tabela (fato/dimensao) | Criar tabela + atributos + relacionamentos |
| **Adicao** | Atributo (metrica/descritivo) | Adicionar coluna + tipo + dominio |
| **Adicao** | Relacionamento (FK) | Criar FK entre fato e dimensao |
| **Remocao** | Tabela (fato/dimensao) | Remover tabela + atributos + FKs |
| **Remocao** | Atributo | Remover coluna (verificar impacto em queries) |
| **Renomeacao** | Tabela/Atributo | Renomear + atualizar views/ETL dependentes |

## Estrategias de Evolucao

### 1. Schema Evolution (Substituicao)

Schema antigo e substituido pelo novo. Dados migrados para nova estrutura.

```sql
-- Exemplo: adicionar dim_fornecedor ao star schema existente
-- 1. Criar nova dimensao
CREATE TABLE dim_fornecedor (
    sk_fornecedor INT PRIMARY KEY,
    cod_fornecedor VARCHAR(14),  -- CNPJ
    nome_fornecedor VARCHAR(200),
    cidade VARCHAR(100),
    uf CHAR(2)
);

-- 2. Adicionar FK na fato (ou criar bridge table se multi-valued)
ALTER TABLE fato_compras ADD COLUMN sk_fornecedor INT
    REFERENCES dim_fornecedor(sk_fornecedor);

-- 3. Atualizar ETL para popular nova dimensao
-- 4. Backfill dados historicos (se disponivel na fonte)
```

**Quando usar**: mudancas simples, sem necessidade de manter versoes anteriores.

### 2. Schema Versioning (Versionamento)

Multiplas versoes do schema coexistem. Queries historicas usam versao anterior.

**Quando usar**: mudancas drasticas no grain ou na estrutura, necessidade de auditoria.

### 3. Abordagem Hibrida (Recomendada)

- Mudancas **aditivas** (novo atributo, nova dimensao): schema evolution
- Mudancas **destrutivas** (remocao, mudanca de grain): schema versioning
- Mudancas **corretivas** (renomear, corrigir tipo): schema evolution + SCD Tipo 1

## Processo de Evolucao (Checklist)

```text
1. [ ] Identificar a causa (fonte, requisito, regulatorio)
2. [ ] Classificar o tipo de mudanca (adicao, remocao, renomeacao)
3. [ ] Identificar o tipo do elemento (fato, dimensao, atributo, metrica, FK)
4. [ ] Avaliar impacto nas queries existentes (bus matrix, dashboards)
5. [ ] Avaliar impacto no ETL (novos pipelines, modificacao de existentes)
6. [ ] Escolher estrategia (evolution vs versioning)
7. [ ] Implementar mudanca no modelo logico
8. [ ] Atualizar ETL e pipelines
9. [ ] Verificar consistencia (integridade referencial, metricas)
10. [ ] Atualizar documentacao (bus matrix, glossario, data catalog)
```

## Impacto por Tipo de Mudanca

| Mudanca | Impacto no Modelo | Impacto no ETL | Risco |
|---------|-------------------|----------------|-------|
| Adicionar atributo em dimensao | Baixo | Baixo | Baixo |
| Adicionar nova dimensao | Medio | Medio | Medio |
| Adicionar nova fato | Alto | Alto | Medio |
| Mudar grain da fato | Muito Alto | Muito Alto | Alto |
| Remover dimensao | Alto | Medio | Alto |
| Adicionar metrica na fato | Baixo | Medio | Baixo |
| Mudar tipo de SCD | Alto | Alto | Alto |

## Exemplo Pratico: Varejo

Cenario: varejista lanca marketplace 3P e precisa rastrear GMV e take rate.

**Mudancas necessarias:**
1. Adicionar atributos em `dim_loja`: `tipo_canal` (1P, 3P), `seller_id`
2. Adicionar metricas em `fato_vendas`: `valor_gmv`, `valor_comissao`
3. Criar KPIs derivados: `take_rate = valor_comissao / valor_gmv`
4. Atualizar bus matrix: nova coluna `dim_seller` (se necessario)

**Classificacao:**
- Tipo: Adicao de atributos + metricas
- Estrategia: Schema Evolution (aditiva, sem perda de dados)
- Impacto: Medio (ETL precisa de nova fonte de dados do marketplace)

## Anti-Patterns

| Nao Faca | Faca |
|----------|------|
| Mudar grain sem criar nova fato | Criar fato separada para grain diferente |
| Deletar dimensao sem verificar queries | Depreciar primeiro, remover apos validacao |
| Adicionar flag na fato | Criar junk dimension para flags |
| Renomear tabela sem alias/view | Manter view com nome antigo por periodo de transicao |
| Mudar SCD tipo sem migrar historico | Migrar dados historicos antes de mudar tipo |

## Related

- [Star Schema](star-schema.md)
- [Granularidade](granularidade.md)
- [Bus Matrix](../patterns/bus-matrix.md)
- [Model Review Checklist](../patterns/model-review-checklist.md)
- [Tabelas Dimensao — SCD](slowly-changing-dimensions.md)
