# Slowly Changing Dimensions (SCD)

> **Purpose**: Estrategias para tratar mudancas em atributos de dimensao ao longo do tempo (Tipo 0-6)
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

Slowly Changing Dimensions (SCD) descrevem como o data warehouse reage quando um atributo
de dimensao muda no sistema fonte. Kimball define tipos numerados (0-6), sendo o Tipo 2
o mais importante para historico completo. A escolha depende da necessidade de auditoria.

## The Pattern

```sql
-- SCD TIPO 1: Sobrescreve o valor antigo (sem historico)
UPDATE dim_cliente SET cidade = 'Curitiba' WHERE cod_cliente = 'C001';

-- SCD TIPO 2: Nova linha com versionamento
-- ANTES:
-- sk=100, cod='C001', cidade='SP',  inicio='2024-01-01', fim='9999-12-31', corrente=true
-- DEPOIS:
-- sk=100, cod='C001', cidade='SP',  inicio='2024-01-01', fim='2026-03-22', corrente=false
-- sk=201, cod='C001', cidade='CWB', inicio='2026-03-23', fim='9999-12-31', corrente=true

-- SCD TIPO 3: Coluna para valor anterior
ALTER TABLE dim_cliente ADD COLUMN cidade_anterior VARCHAR(100);
UPDATE dim_cliente SET cidade_anterior = cidade, cidade = 'Curitiba'
WHERE cod_cliente = 'C001';

-- SCD TIPO 4: Tabela de historico separada
INSERT INTO dim_cliente_historico
SELECT sk_cliente, cod_cliente, cidade, CURRENT_DATE
FROM dim_cliente WHERE cod_cliente = 'C001';
UPDATE dim_cliente SET cidade = 'Curitiba' WHERE cod_cliente = 'C001';

-- SCD TIPO 6 (Hibrido 1+2+3): Linha nova + coluna valor atual
-- sk=100, cod='C001', cidade='SP',  cidade_atual='CWB', inicio, fim, corrente=false
-- sk=201, cod='C001', cidade='CWB', cidade_atual='CWB', inicio, fim, corrente=true
```

## Quick Reference

| Tipo | Acao | Historico | Complexidade | Caso de Uso |
|------|------|-----------|-------------|-------------|
| 0 | Nao altera | N/A | Nenhuma | Data nascimento, GTIN original |
| 1 | Sobrescreve | Nao | Baixa | Correcoes, nome formatado |
| 2 | Nova linha | Completo | Media | Endereco, estado civil |
| 3 | Coluna anterior | Ultimo valor | Baixa | Apenas "antes vs agora" |
| 4 | Tabela separada | Completo | Media-Alta | Alto volume de mudancas |
| 6 | Hibrido 1+2+3 | Completo + atual | Alta | Historico + facilidade de query |

## Estrutura SCD Tipo 2

```sql
CREATE TABLE dim_cliente (
    sk_cliente     INT PRIMARY KEY,      -- surrogate key (auto-increment)
    cod_cliente    VARCHAR(20),           -- natural key (business key)
    nome           VARCHAR(200),
    cidade         VARCHAR(100),
    estado         VARCHAR(2),
    data_inicio    DATE NOT NULL,         -- quando esta versao comecou
    data_fim       DATE NOT NULL,         -- '9999-12-31' para corrente
    flag_corrente  BOOLEAN NOT NULL       -- true para versao atual
);

-- Query: estado atual do cliente
SELECT * FROM dim_cliente WHERE flag_corrente = true;

-- Query: estado do cliente em uma data especifica
SELECT * FROM dim_cliente
WHERE data_inicio <= '2025-06-15' AND data_fim >= '2025-06-15';
```

## Common Mistakes

### Wrong

```sql
-- Usar natural key como PK com SCD Tipo 2 (viola unicidade)
CREATE TABLE dim_cliente (
    cod_cliente VARCHAR(20) PRIMARY KEY,  -- ERRADO: duplica no tipo 2
    nome VARCHAR(200)
);
```

### Correct

```sql
-- Surrogate key permite multiplas versoes do mesmo cod_cliente
CREATE TABLE dim_cliente (
    sk_cliente  INT PRIMARY KEY,          -- unica por versao
    cod_cliente VARCHAR(20),              -- repete no tipo 2
    nome VARCHAR(200),
    data_inicio DATE,
    data_fim    DATE,
    flag_corrente BOOLEAN
);
```

## Related

- [Surrogate Keys](../concepts/surrogate-keys.md)
- [SCD Tipo 2 com Delta Lake](../patterns/scd-tipo-2-delta-lake.md)
- [Tabelas Dimensao](../concepts/tabelas-dimensao.md)
