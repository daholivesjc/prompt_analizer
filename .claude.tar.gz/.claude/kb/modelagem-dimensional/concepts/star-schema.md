# Star Schema

> **Purpose**: Modelo relacional otimizado para consultas analiticas com fato central e dimensoes desnormalizadas
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

O Star Schema e o padrao fundamental da modelagem dimensional Kimball. Consiste em uma tabela fato
central conectada diretamente a multiplas tabelas dimensao via chaves estrangeiras, formando uma
estrela. E otimizado para leitura (SELECT) e nao para escrita (INSERT/UPDATE).

## The Pattern

```sql
-- Star Schema classico de vendas
CREATE TABLE fato_vendas (
    sk_produto    INT REFERENCES dim_produto(sk_produto),
    sk_loja       INT REFERENCES dim_loja(sk_loja),
    sk_data       INT REFERENCES dim_data(sk_data),
    sk_cliente    INT REFERENCES dim_cliente(sk_cliente),
    sk_promocao   INT REFERENCES dim_promocao(sk_promocao),
    quantidade    DECIMAL(10,2),
    valor_unitario DECIMAL(10,2),
    valor_total   DECIMAL(12,2),
    valor_desconto DECIMAL(10,2),
    custo_unitario DECIMAL(10,2)
);

-- Dimensao desnormalizada (Star)
CREATE TABLE dim_produto (
    sk_produto      INT PRIMARY KEY,  -- surrogate key
    cod_produto     VARCHAR(14),       -- natural key (GTIN)
    nome_produto    VARCHAR(200),
    marca           VARCHAR(100),
    categoria       VARCHAR(100),
    subcategoria    VARCHAR(100),
    departamento    VARCHAR(100)       -- desnormalizado!
);
```

## Quick Reference

| Aspecto | Star Schema | Snowflake Schema |
|---------|-------------|------------------|
| Dimensoes | Desnormalizadas (1 tabela) | Normalizadas (N tabelas) |
| JOINs | Menos (fato -> dim) | Mais (fato -> dim -> sub-dim) |
| Performance | Melhor para queries | Melhor para espaco |
| Complexidade | Simples | Mais complexo |
| Recomendacao Kimball | **Padrao** | Somente se necessario |

## Quando Usar Snowflake

Snowflake e justificado APENAS em dois cenarios:

1. **Atributos de grains diferentes**: a dimensao tem 2+ conjuntos de atributos com granularidades diferentes, populados por fontes diferentes (ex: atributos de cliente vs. atributos do pais do cliente)
2. **Performance com agregados**: snowflake de uma hierarquia (ex: marca) para usar com tabela de agregacao, evitando JOIN com a dimensao completa

### Quando NAO Usar Snowflake

- **Nunca** snowflake hierarquias de uma dimensao em tabelas separadas (ex: produto -> categoria -> departamento)
- Economia de espaco e insignificante — dimensoes representam <5-15% do modelo; fatos ocupam 85-95%
- Mais tabelas = mais JOINs = queries mais lentas e modelo menos compreensivel
- Se a dimensao tem <1M linhas, snowflake nao se justifica por performance

## Common Mistakes

### Wrong

```sql
-- Snowflake desnecessario: 3 tabelas para 1 dimensao
SELECT p.nome, c.nome_categoria, d.nome_departamento
FROM fato_vendas f
JOIN dim_produto p ON f.sk_produto = p.sk_produto
JOIN dim_categoria c ON p.sk_categoria = c.sk_categoria
JOIN dim_departamento d ON c.sk_departamento = d.sk_departamento;
```

### Correct

```sql
-- Star Schema: tudo em 1 JOIN
SELECT p.nome_produto, p.categoria, p.departamento
FROM fato_vendas f
JOIN dim_produto p ON f.sk_produto = p.sk_produto;
```

## Related

- [Tabelas Fato](../concepts/tabelas-fato.md)
- [Tabelas Dimensao](../concepts/tabelas-dimensao.md)
- [Granularidade](../concepts/granularidade.md)
- [Modelo Vendas Varejo](../patterns/modelagem-vendas-varejo.md)
