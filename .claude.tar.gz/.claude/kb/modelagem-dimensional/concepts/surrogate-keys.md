# Surrogate Keys

> **Purpose**: Chaves artificiais inteiras para dimensoes — independencia do sistema fonte e suporte a SCD
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

Surrogate keys sao chaves primarias geradas pelo data warehouse, independentes dos sistemas
fonte. Sao inteiras sequenciais (ou hash) que identificam unicamente cada linha da dimensao.
Sao obrigatorias no Kimball para suportar SCD Tipo 2 e isolar o DW de mudancas nos fontes.

## The Pattern

```sql
-- Surrogate key como inteiro sequencial
CREATE TABLE dim_produto (
    sk_produto    INT PRIMARY KEY AUTO_INCREMENT,  -- surrogate key
    cod_gtin      VARCHAR(14),   -- natural key (do sistema fonte)
    cod_interno   VARCHAR(20),   -- outra natural key
    nome          VARCHAR(200),
    categoria     VARCHAR(100),
    data_inicio   DATE,
    data_fim      DATE,
    flag_corrente BOOLEAN
);

-- Na fato, referencie SEMPRE a surrogate key
CREATE TABLE fato_vendas (
    sk_produto    INT REFERENCES dim_produto(sk_produto),  -- FK surrogate
    sk_loja       INT REFERENCES dim_loja(sk_loja),
    valor_total   DECIMAL(12,2)
);

-- Hash key (alternativa para ambientes distribuidos/Delta Lake)
-- sk_produto = MD5(cod_gtin || '|' || data_inicio)
-- Vantagem: deterministica, sem sequencia central
-- Desvantagem: 16 bytes vs 4 bytes (int), colisoes teoricas
```

## Comparacao

| Criterio | Surrogate Key | Natural Key | Hash Key |
|----------|---------------|-------------|----------|
| Formato | INT sequencial | Codigo negocio | MD5/SHA |
| Tamanho | 4 bytes | Variavel | 16-32 bytes |
| SCD Tipo 2 | Suporta | Nao suporta como PK | Suporta |
| Independencia | Total | Acoplada ao fonte | Total |
| JOIN performance | Otima | Variavel | Boa |
| Legibilidade | Baixa | Alta | Nenhuma |
| Uso em Delta Lake | Viavel | Viavel | **Recomendado** |

## Dimensao Especial: dim_data

```sql
-- Excecao: dim_data usa smart key (YYYYMMDD como inteiro)
CREATE TABLE dim_data (
    sk_data  INT PRIMARY KEY,  -- 20260323 (legivel e eficiente)
    data_completa DATE,
    ano INT, mes INT, dia INT,
    dia_semana VARCHAR(15),
    trimestre INT
);
-- Na fato: sk_data = 20260323 (sem lookup, direto)
```

## Linha "Desconhecido"

```sql
-- Sempre inclua sk = -1 para valores nulos/desconhecidos
INSERT INTO dim_cliente (sk_cliente, cod_cliente, nome)
VALUES (-1, 'N/A', 'Cliente Desconhecido');

-- Na fato, use -1 em vez de NULL
INSERT INTO fato_vendas (sk_cliente, valor) VALUES (-1, 150.00);
-- Evita NULLs em FKs e simplifica JOINs (INNER em vez de LEFT)
```

## Common Mistakes

### Wrong

```sql
-- Usar natural key como PK da dimensao
CREATE TABLE dim_produto (
    cod_gtin VARCHAR(14) PRIMARY KEY,  -- ERRADO com SCD tipo 2
    nome VARCHAR(200)
);
-- Se mudar o GTIN no fonte, perde-se o historico
```

### Correct

```sql
-- Surrogate key com natural key como atributo
CREATE TABLE dim_produto (
    sk_produto INT PRIMARY KEY,       -- surrogate: unica por versao
    cod_gtin   VARCHAR(14),           -- natural key: pode repetir (SCD 2)
    nome       VARCHAR(200)
);
```

## Related

- [Slowly Changing Dimensions](../concepts/slowly-changing-dimensions.md)
- [Tabelas Dimensao](../concepts/tabelas-dimensao.md)
- [SCD Tipo 2 com Delta Lake](../patterns/scd-tipo-2-delta-lake.md)
- [GTIN como Natural Key](../../gs1-varejo/concepts/gtin.md)
