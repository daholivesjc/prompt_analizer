# Tabelas Dimensao

> **Purpose**: Tipos de dimensao — conformed, junk, degenerate, role-playing, outrigger e mini-dimension
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

Dimensoes sao as tabelas descritivas do modelo dimensional. Fornecem contexto textual e atributos
para filtrar, agrupar e rotular os fatos. Uma boa dimensao e larga (muitas colunas) e desnormalizada.
O Kimball define varios tipos especiais para cenarios comuns.

## The Pattern

```sql
-- CONFORMED DIMENSION: compartilhada entre fatos
CREATE TABLE dim_produto (
    sk_produto    INT PRIMARY KEY,    -- surrogate key
    cod_gtin      VARCHAR(14),        -- natural key (ref: gs1-varejo)
    nome          VARCHAR(200),
    marca         VARCHAR(100),
    categoria     VARCHAR(100),
    subcategoria  VARCHAR(100),
    departamento  VARCHAR(100),
    peso_kg       DECIMAL(8,3),
    unidade_medida VARCHAR(10),
    data_inicio   DATE,               -- SCD tipo 2
    data_fim      DATE,
    flag_corrente BOOLEAN
);

-- JUNK DIMENSION: agrupa flags e indicadores de baixa cardinalidade
CREATE TABLE dim_flags_pedido (
    sk_flags_pedido INT PRIMARY KEY,
    tipo_pagamento  VARCHAR(20),  -- 'credito','debito','pix'
    flag_presente   CHAR(1),      -- 'S','N'
    canal_venda     VARCHAR(20),  -- 'loja','ecommerce','app'
    prioridade      VARCHAR(10)   -- 'normal','expressa'
);

-- DEGENERATE DIMENSION: vive na propria fato
-- numero_nota_fiscal na fato_vendas (sem tabela propria)

-- ROLE-PLAYING: mesma dimensao usada N vezes
-- dim_data referenciada como sk_data_pedido, sk_data_envio, sk_data_entrega

-- OUTRIGGER: sub-dimensao de outra dimensao
CREATE TABLE dim_geografia (
    sk_geografia  INT PRIMARY KEY,
    cidade        VARCHAR(100),
    estado        VARCHAR(2),
    regiao        VARCHAR(20),
    pais          VARCHAR(50)
);
-- dim_loja.sk_geografia -> dim_geografia.sk_geografia
```

## Quick Reference

| Tipo | Tabela Propria? | Exemplo | Quando Usar |
|------|-----------------|---------|-------------|
| Conformed | Sim (compartilhada) | dim_produto, dim_data | Sempre que possivel |
| Junk (Garbage) | Sim (combinacoes) | dim_flags | Muitos flags/indicadores de baixa cardinalidade |
| Degenerate | Nao (coluna na fato) | nro_nota_fiscal | Identificador transacional |
| Role-Playing | Sim (reusada via views) | dim_data em 3 papeis | Mesma dimensao, visoes diferentes |
| Outrigger | Sim (sub-dimensao) | dim_geografia | Atributos fixos de outra dim |
| Mini-Dimension | Sim (separada) | dim_perfil_cliente | Atributos que mudam muito (fast changing) |
| Hot-Swappable | Views de uma dim | dim_produto_bens, dim_produto_servicos | Subconjuntos heterogeneos do mesmo conceito |
| Multi-Valued | Via bridge table | bridge_diagnostico | Fato se relaciona com N valores da dim |

## Garbage (Junk) Dimension — Detalhamento

Campos de baixa cardinalidade (flags, indicadores, status) nao devem ir na fato nem em dimensoes existentes. Agrupe-os em uma **garbage/junk dimension** com produto cartesiano de todas as combinacoes.

```sql
-- Exemplo: 3 flags x 2 pagamentos x 3 bolsas = 18 linhas
CREATE TABLE dim_flags_transacao (
    sk_flags        INT PRIMARY KEY,  -- surrogate
    feedback_loja   VARCHAR(10),      -- 'bom','ruim','nenhum'
    tipo_pagamento  VARCHAR(20),      -- 'credito','debito','pix','dinheiro','vale'
    tipo_sacola     VARCHAR(10)       -- 'plastica','papel','ambas'
);
-- Se a junk dimension crescer demais, divida em 2+ dimensoes
-- Carga: pre-popular com todas as combinacoes OU inserir em runtime
```

## Role-Playing Dimension — Implementacao

Uma unica tabela dim_data pode ser projetada como multiplas views, cada uma representando um papel diferente (data_pedido, data_envio, data_entrega).

```sql
-- Uma tabela fisica
CREATE TABLE dim_data ( sk_data INT PRIMARY KEY, ... );

-- Multiplas views role-playing
CREATE VIEW dim_data_pedido AS SELECT * FROM dim_data;
CREATE VIEW dim_data_envio AS SELECT * FROM dim_data;
CREATE VIEW dim_data_entrega AS SELECT * FROM dim_data;
-- Na fato: sk_data_pedido, sk_data_envio, sk_data_entrega (3 FKs para mesma dim)
```

## Mini-Dimension (Fast Changing)

Atributos que mudam frequentemente (ex: faixa salarial, score de credito) geram excesso de linhas no SCD Tipo 2. Solucao: extrair esses atributos para uma **mini-dimension** separada, referenciada diretamente pela fato.

```sql
-- Mini-dimension para perfil do cliente (muda frequentemente)
CREATE TABLE dim_perfil_cliente (
    sk_perfil         INT PRIMARY KEY,
    faixa_renda       VARCHAR(30),
    score_credito     VARCHAR(10),
    faixa_etaria      VARCHAR(20)
);
-- A fato referencia AMBAS: sk_cliente (SCD2, muda devagar) + sk_perfil (muda rapido)
-- Se a mini-dimension crescer demais, divida em 2+ mini-dimensions
```

## Hot-Swappable Dimensions

Quando uma dimensao (ex: produto) tem subconjuntos com atributos muito diferentes (bens vs. servicos vs. assinaturas), crie views especializadas da mesma dimensao base. O usuario seleciona a view adequada conforme o tipo de analise.

## dim_data: a Dimensao Obrigatoria

```sql
CREATE TABLE dim_data (
    sk_data         INT PRIMARY KEY,  -- formato YYYYMMDD
    data_completa   DATE,
    dia_semana      VARCHAR(15),
    dia_mes         INT,
    mes             INT,
    nome_mes        VARCHAR(15),
    trimestre       INT,
    ano             INT,
    flag_feriado     BOOLEAN,
    flag_fim_semana  BOOLEAN
);
-- Pre-popule para 10-20 anos. Nunca use funcoes de data no lugar.
```

## Common Mistakes

### Wrong

```sql
-- Normalizar dimensao sem necessidade (snowflake)
SELECT p.nome FROM fato_vendas f
JOIN dim_produto p ON f.sk_produto = p.sk_produto
JOIN dim_marca m ON p.sk_marca = m.sk_marca
JOIN dim_categoria c ON p.sk_categoria = c.sk_categoria;
```

### Correct

```sql
-- Desnormalizar na dimensao (star)
SELECT p.nome, p.marca, p.categoria FROM fato_vendas f
JOIN dim_produto p ON f.sk_produto = p.sk_produto;
```

## Related

- [Star Schema](../concepts/star-schema.md)
- [Slowly Changing Dimensions](../concepts/slowly-changing-dimensions.md)
- [Surrogate Keys](../concepts/surrogate-keys.md)
- [GS1 GTIN como Natural Key](../../gs1-varejo/concepts/gtin.md)
