# Tabelas Fato

> **Purpose**: Tipos de tabelas fato e suas metricas — transacional, periodica, acumulada e sem fato
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-23

## Overview

A tabela fato e o nucleo do modelo dimensional. Armazena eventos de negocio (metricas numericas)
e referencia dimensoes via foreign keys. O grain (granularidade) define o que cada linha representa.
Existem 4 tipos fundamentais, cada um para um cenario diferente.

## The Pattern

```sql
-- 1. FATO TRANSACIONAL: 1 linha por evento atomico
CREATE TABLE fato_vendas (
    sk_data       INT,  -- FK dim_data
    sk_produto    INT,  -- FK dim_produto
    sk_loja       INT,  -- FK dim_loja
    quantidade    DECIMAL(10,2),  -- metrica aditiva
    valor_total   DECIMAL(12,2),  -- metrica aditiva
    margem_pct    DECIMAL(5,2)    -- metrica nao-aditiva
);

-- 2. FATO PERIODICA (SNAPSHOT): 1 linha por periodo
CREATE TABLE fato_estoque_diario (
    sk_data       INT,
    sk_produto    INT,
    sk_loja       INT,
    qtd_em_estoque   INT,      -- semi-aditiva (nao soma no tempo)
    valor_estoque    DECIMAL(12,2)
);

-- 3. FATO ACUMULADA: 1 linha por ciclo de vida
CREATE TABLE fato_pedido (
    sk_data_pedido    INT,
    sk_data_aprovacao INT,  -- NULL ate acontecer
    sk_data_envio     INT,  -- NULL ate acontecer
    sk_data_entrega   INT,  -- NULL ate acontecer
    sk_produto        INT,
    dias_ate_envio    INT,
    dias_ate_entrega  INT,
    valor_pedido      DECIMAL(12,2)
);

-- 4. FATO SEM FATO (FACTLESS): registra evento sem metrica
CREATE TABLE fato_cobertura_promocao (
    sk_data       INT,
    sk_produto    INT,
    sk_promocao   INT
    -- sem colunas de metrica! So FKs
);
```

## Classificacao de Metricas

| Tipo | Pode Somar em Todas Dimensoes? | Exemplo | Como Agregar |
|------|-------------------------------|---------|--------------|
| Aditiva | Sim | valor_total, quantidade | SUM em qualquer dimensao |
| Semi-Aditiva | Nao soma no tempo | saldo_estoque, saldo_conta | SUM em dims exceto tempo; usar AVG no tempo |
| Nao-Aditiva | Nao soma em nenhuma | margem_pct, preco_unitario | Recalcular a partir de componentes aditivos |
| Derivada | Calculada de outros fatos | lucro_bruto = receita - custo | Pode ou nao armazenar; calcular no report |
| Textual | Texto na fato (evitar) | observacao_pedido | COUNT, nao SUM |

### Regras para Metricas Nao-Aditivas

- **Precos unitarios**: armazene `quantidade * preco_unitario` como valor_total (aditivo). Para recuperar o preco unitario, divida valor_total/quantidade
- **Percentuais e ratios**: armazene numerador e denominador separadamente. Ex: margem = (receita - custo) / receita. Armazene receita e custo, calcule margem no report
- **Medidas de intensidade**: temperatura, velocidade — use AVG, nunca SUM
- **Degenerate dimensions**: numeros como nro_pedido sao nao-aditivos mas podem ser contados (COUNT DISTINCT)

### Fatos Semi-Aditivos em Detalhe

Saldos de conta e quantidade em estoque sao semi-aditivos: podem ser somados entre clientes/produtos/lojas em um unico dia, mas **nunca somados ao longo do tempo**. Para agregar no tempo, use AVG (media diaria do periodo).

## Quick Reference

| Tipo Fato | Grain | Cresce? | Atualiza? | Exemplo |
|-----------|-------|---------|-----------|---------|
| Transacional | 1 evento | Sim (append) | Nunca | Venda, clique |
| Periodica | 1 periodo | Sim (append) | Nunca | Estoque diario |
| Acumulada | 1 ciclo | Nao (fixo) | Sim (preenche datas) | Pedido |
| Sem Fato | 1 relacao | Sim (append) | Nunca | Elegibilidade |

## Tabelas de Agregacao (Aggregate Tables)

Agregacao e o processo de calcular dados resumidos a partir do fato atomica. Agregados sao a ferramenta mais poderosa para melhorar performance de queries.

```sql
-- Fato atomica (grain: 1 item vendido)
CREATE TABLE fato_vendas_item ( ... );

-- Agregado: vendas por marca por mes (grain: 1 marca por mes)
CREATE TABLE fato_vendas_marca_mes (
    sk_data_mes      INT,
    sk_marca         INT,       -- snowflake da dim_produto
    sk_loja          INT,
    total_receita    DECIMAL(14,2),
    total_quantidade DECIMAL(12,2),
    num_transacoes   INT        -- sempre inclua contagem para calcular medias
);
-- Aggregate Navigation: redirecione queries de usuarios para agregados pre-computados
-- O middleware/BI tool deve detectar o nivel solicitado e usar o agregado automaticamente
```

### Regras para Agregados

| Regra | Descricao |
|-------|-----------|
| Sempre mantenha o atomico | Agregados complementam, nunca substituem a fato atomica |
| Inclua contagem | Sem COUNT nao e possivel calcular medias a partir do agregado |
| Navegacao de agregados | Use middleware ou views para redirecionar queries ao nivel correto |
| Snowflake para agregados | Snowflake e justificado quando usado com tabelas de agregacao |

## Year-to-Date (YTD) Facts

Fatos YTD (ex: vendas acumuladas no ano) geralmente **nao** devem ser armazenados na fato. Sao calculados em tempo de consulta via funcoes de janela (window functions), OLAP, ou views. Armazenar YTD viola o grain atomico da fato.

## Common Mistakes

### Wrong

```sql
-- Armazenar texto na fato (deveria estar na dimensao)
CREATE TABLE fato_vendas (
    nome_produto VARCHAR(200),  -- ERRADO: atributo descritivo
    nome_loja    VARCHAR(100),  -- ERRADO: atributo descritivo
    valor_total  DECIMAL(12,2)
);
```

### Correct

```sql
-- Fato so tem FKs (INT) + metricas numericas
CREATE TABLE fato_vendas (
    sk_produto   INT,    -- FK para dim_produto
    sk_loja      INT,    -- FK para dim_loja
    valor_total  DECIMAL(12,2)  -- metrica
);
```

## Related

- [Star Schema](../concepts/star-schema.md)
- [Granularidade](../concepts/granularidade.md)
- [Tabelas Dimensao](../concepts/tabelas-dimensao.md)
- [Modelo Vendas Varejo](../patterns/modelagem-vendas-varejo.md)
