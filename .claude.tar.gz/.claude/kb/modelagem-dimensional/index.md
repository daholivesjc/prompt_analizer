# Modelagem Dimensional Knowledge Base

> **Purpose**: Metodologia Kimball para design de data warehouses — star schema, tabelas fato/dimensao, SCD e aplicacao no varejo
> **MCP Validated**: 2026-03-23

## Quick Navigation

### Concepts

| Arquivo | Proposito |
|---------|-----------|
| [concepts/star-schema.md](concepts/star-schema.md) | Star Schema vs Snowflake, quando usar cada um, regras de snowflaking |
| [concepts/tabelas-fato.md](concepts/tabelas-fato.md) | Tipos de fato, classificacao de metricas (aditiva/semi/nao), agregados, YTD |
| [concepts/tabelas-dimensao.md](concepts/tabelas-dimensao.md) | Tipos de dimensao: conformed, junk, degenerate, role-playing, mini-dim, hot-swappable, multi-valued |
| [concepts/slowly-changing-dimensions.md](concepts/slowly-changing-dimensions.md) | SCD Tipo 0, 1, 2, 3, 4, 6 com exemplos |
| [concepts/granularidade.md](concepts/granularidade.md) | Grain atomico, multiplos grains, impacto do grain, grain por tipo de fato |
| [concepts/surrogate-keys.md](concepts/surrogate-keys.md) | Surrogate keys vs natural keys, sequencias, hash keys |
| [concepts/schema-evolution.md](concepts/schema-evolution.md) | Evolucao de schema DW: operadores, estrategias, impacto e checklist |

### Patterns

| Arquivo | Proposito |
|---------|-----------|
| [patterns/modelagem-vendas-varejo.md](patterns/modelagem-vendas-varejo.md) | Modelo dimensional de vendas no varejo com fato + dimensoes |
| [patterns/scd-tipo-2-delta-lake.md](patterns/scd-tipo-2-delta-lake.md) | Implementacao de SCD Tipo 2 com Delta Lake MERGE |
| [patterns/bus-matrix.md](patterns/bus-matrix.md) | Enterprise Bus Matrix e conformidade de dimensoes |
| [patterns/bridge-tables.md](patterns/bridge-tables.md) | Bridge tables para relacionamentos multi-valued |
| [patterns/aggregate-tables.md](patterns/aggregate-tables.md) | Tabelas de agregacao pre-computadas e navegacao de agregados |
| [patterns/model-review-checklist.md](patterns/model-review-checklist.md) | Checklist de revisao/validacao de modelo dimensional |

### Specs (Machine-Readable)

| Arquivo | Proposito |
|---------|-----------|
| [specs/varejo-star-schema.yaml](specs/varejo-star-schema.yaml) | Especificacao do star schema de vendas varejo |

---

## Quick Reference

- [quick-reference.md](quick-reference.md) - Tabelas de consulta rapida

---

## Conceitos-Chave

| Conceito | Descricao |
|----------|-----------|
| **Star Schema** | Modelo com tabela fato central cercada por dimensoes desnormalizadas |
| **Grain** | Nivel de detalhe de cada linha da tabela fato (decisao mais importante) |
| **Surrogate Key** | Chave inteira sequencial gerada pelo DW, independente do sistema fonte |
| **SCD Tipo 2** | Historico completo de mudancas em dimensoes via linhas adicionais |
| **Conformed Dimension** | Dimensao compartilhada entre multiplos fatos para consistencia |
| **Bus Matrix** | Ferramenta de planejamento que cruza processos de negocio com dimensoes |
| **Junk Dimension** | Agrupa flags/indicadores de baixa cardinalidade em uma unica dimensao |
| **Mini-Dimension** | Dimensao separada para atributos que mudam rapidamente (fast changing) |
| **Aggregate Table** | Fato pre-computada em grain mais alto para performance de queries |
| **Bridge Table** | Tabela ponte para resolver relacionamentos multi-valued com ponderacao |
| **Schema Evolution** | Processo de adaptar o modelo dimensional quando fontes ou requisitos mudam |

---

## Trilha de Aprendizado

| Nivel | Arquivos |
|-------|----------|
| **Iniciante** | concepts/star-schema.md, concepts/granularidade.md |
| **Intermediario** | concepts/tabelas-fato.md, concepts/tabelas-dimensao.md, concepts/surrogate-keys.md |
| **Avancado** | concepts/slowly-changing-dimensions.md, patterns/scd-tipo-2-delta-lake.md, patterns/aggregate-tables.md, concepts/schema-evolution.md |
| **Revisao** | patterns/model-review-checklist.md, patterns/bus-matrix.md |

---

## Uso por Agentes

| Agente | Arquivos Primarios | Caso de Uso |
|--------|---------------------|-------------|
| KB Architect | Todos | Referencia sobre modelagem dimensional |
| Data Engineer | patterns/modelagem-vendas-varejo.md, specs/ | Criar modelos dimensionais |
| Data Modeler | concepts/*, patterns/bus-matrix.md | Design de schema dimensional |

---

## Referencias Cruzadas

| KB Relacionada | Conexao |
|----------------|---------|
| [gs1-varejo](../gs1-varejo/index.md) | GTIN como natural key em dim_produto |
