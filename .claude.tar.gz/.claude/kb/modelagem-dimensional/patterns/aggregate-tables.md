# Tabelas de Agregacao e Navegacao

> **Purpose**: Agregados pre-computados para performance de queries e navegacao automatica entre niveis de detalhe
> **Confidence**: 0.90
> **MCP Validated**: 2026-03-23

## When to Use

- Queries frequentes em niveis agregados (mensal, por categoria, por regiao) estao lentas
- A fato atomica e muito grande para scans completos
- Usuarios de BI precisam de respostas rapidas em dashboards
- Complementar o grain atomico sem substitui-lo

## Implementation

```sql
-- =====================================================
-- AGREGACAO: Vendas por Marca por Mes (Varejo)
-- Grain atomico: 1 item por cupom (fato_vendas_item)
-- Grain agregado: 1 marca por mes por loja
-- =====================================================

-- FATO ATOMICA (base - sempre manter)
CREATE TABLE fato_vendas_item (
    sk_data       INT,
    sk_produto    INT,
    sk_loja       INT,
    sk_cliente    INT,
    nro_cupom     VARCHAR(20),
    quantidade    DECIMAL(10,2),
    valor_liquido DECIMAL(12,2),
    custo_total   DECIMAL(12,2)
);

-- FATO AGREGADA (complementar)
CREATE TABLE fato_vendas_marca_mes (
    sk_data_mes      INT,       -- FK para dim_data (primeiro dia do mes)
    sk_marca         INT,       -- FK para dim_marca (snowflake de dim_produto)
    sk_loja          INT,       -- FK para dim_loja
    total_receita    DECIMAL(14,2),
    total_custo      DECIMAL(14,2),
    total_quantidade DECIMAL(12,2),
    num_transacoes   INT,       -- ESSENCIAL: permite calcular medias
    num_itens        INT        -- COUNT de linhas atomicas
);

-- SNOWFLAKE para agregado (justificado aqui)
CREATE TABLE dim_marca (
    sk_marca    INT PRIMARY KEY,
    nome_marca  VARCHAR(100),
    fabricante  VARCHAR(100)
);
-- Snowflake e justificado quando o agregado evita JOIN com dim_produto completa
```

## Navegacao de Agregados

```sql
-- Aggregate Navigation: redirecionar queries ao nivel correto
-- Opcao 1: Views inteligentes
CREATE VIEW v_vendas_por_marca AS
SELECT m.nome_marca, a.total_receita, a.num_transacoes
FROM fato_vendas_marca_mes a
JOIN dim_marca m ON a.sk_marca = m.sk_marca;

-- Opcao 2: BI tool (Looker, Power BI, Tableau) configura o nivel automaticamente
-- Opcao 3: Materialized views (BigQuery, Redshift) gerenciam automaticamente

-- REGRA: usuario nunca deve precisar saber qual tabela usar
-- O middleware ou BI tool deve redirecionar automaticamente
```

## Regras de Agregacao

| Regra | Descricao |
|-------|-----------|
| **Nunca substitua o atomico** | Agregados complementam, nunca substituem |
| **Sempre inclua contagem** | Sem COUNT(linhas_atomicas) nao e possivel calcular medias |
| **Snowflake justificado** | Snowflake de hierarquia com agregado melhora performance |
| **Atualize junto** | ETL deve atualizar atomico + agregados na mesma carga |
| **Monitore uso** | Agregados nao consultados consomem espaco sem beneficio |

## Exemplos de Agregados Comuns no Varejo

| Grain Atomico | Grain Agregado | Dimensoes do Agregado | Uso |
|---------------|----------------|----------------------|-----|
| Item por cupom | Produto por dia por loja | dim_data, dim_produto, dim_loja | Dashboard operacional |
| Item por cupom | Categoria por mes por regiao | dim_data, dim_categoria, dim_regiao | Report gerencial |
| Item por cupom | Marca por trimestre | dim_data, dim_marca | Analise estrategica |
| Estoque diario por SKU | Estoque mensal por categoria | dim_data, dim_categoria, dim_loja | Indicadores de giro |

## Configuration

| Parametro | Recomendacao |
|-----------|-------------|
| Quando criar | Query frequente com >5s no atomico |
| Quantos niveis | 2-3 niveis de agregacao maximo |
| Retenção | Agregados podem ter retenção maior que atomicos |
| Storage | Agregados tipicamente <5% do tamanho do atomico |

## Common Pitfalls

| Nao Faca | Faca |
|----------|------|
| Criar agregado sem a fato atomica | Sempre construa o atomico primeiro |
| Omitir COUNT no agregado | Inclua para permitir calcular AVG |
| Forcar usuario a escolher tabela | Implemente aggregate navigation automatica |
| Criar muitos agregados | Monitore uso e elimine os nao utilizados |

## See Also

- [Tabelas Fato](../concepts/tabelas-fato.md)
- [Star Schema](../concepts/star-schema.md)
- [Granularidade](../concepts/granularidade.md)
- [Bus Matrix](../patterns/bus-matrix.md)
