# Bridge Tables

> **Purpose**: Resolver relacionamentos muitos-para-muitos entre fato e dimensao usando tabela ponte com fator de ponderacao
> **MCP Validated**: 2026-03-23

## When to Use

- Um fato se relaciona com multiplos valores de uma dimensao simultaneamente
- Exemplo: um produto pertence a multiplas categorias promocionais
- Exemplo: um paciente tem multiplos diagnosticos
- Exemplo: uma conta bancaria tem multiplos titulares
- Necessidade de distribuir metricas proporcionalmente

## Implementation

```sql
-- =====================================================
-- PROBLEMA: Produto participa de multiplas promocoes
-- Um item pode estar em 2+ promocoes ao mesmo tempo
-- JOIN direto causaria duplicacao de metricas
-- =====================================================

-- BRIDGE TABLE: ponte entre grupo e promocoes individuais
CREATE TABLE bridge_promocao (
    sk_grupo_promocao   INT,       -- agrupa as promocoes de 1 produto
    sk_promocao         INT,       -- FK para dim_promocao
    fator_ponderacao    DECIMAL(5,4),  -- peso (soma = 1.0 por grupo)
    PRIMARY KEY (sk_grupo_promocao, sk_promocao)
);

-- Exemplo de dados:
-- Produto "Arroz 5kg" participa de 2 promocoes:
-- sk_grupo=10, sk_promocao=1, fator=0.6  (60% atribuido a promo 1)
-- sk_grupo=10, sk_promocao=2, fator=0.4  (40% atribuido a promo 2)

-- Na fato, referencia o GRUPO (nao a promocao individual)
CREATE TABLE fato_vendas (
    sk_data              INT,
    sk_produto           INT,
    sk_loja              INT,
    sk_grupo_promocao    INT,   -- FK para bridge_promocao
    valor_liquido        DECIMAL(12,2),
    quantidade           DECIMAL(10,2)
);

-- CONSULTA com bridge table (metricas ponderadas)
SELECT
    p.nome_promocao,
    SUM(f.valor_liquido * b.fator_ponderacao) AS receita_atribuida,
    SUM(f.quantidade * b.fator_ponderacao) AS qtd_atribuida
FROM fato_vendas f
JOIN bridge_promocao b ON f.sk_grupo_promocao = b.sk_grupo_promocao
JOIN dim_promocao p ON b.sk_promocao = p.sk_promocao
GROUP BY p.nome_promocao;
```

## Outro Exemplo: Multiplas Categorias

```sql
-- Produto classificado em multiplas categorias (cross-merchandising)
-- Ex: "Queijo Ralado" -> Laticinios E Mercearia

CREATE TABLE bridge_categoria (
    sk_grupo_categoria  INT,
    sk_categoria        INT,
    fator_ponderacao    DECIMAL(5,4)
);

-- Dados:
-- sk_grupo=5, sk_categoria=10 (Laticinios), fator=0.7
-- sk_grupo=5, sk_categoria=20 (Mercearia),  fator=0.3
```

## Configuration

| Parametro | Recomendacao | Descricao |
|-----------|-------------|-----------|
| `fator_ponderacao` | Soma = 1.0 por grupo | Evita dupla contagem |
| Distribuicao | Igualitaria ou por negocio | 1/N ou proporcional ao impacto |
| Grupo default | sk_grupo = -1 | Para itens sem associacao multi-valued |
| Cardinalidade | Monitorar crescimento | Bridge pode crescer muito rapido |

## Alternativas

| Abordagem | Pro | Contra | Quando Usar |
|-----------|-----|--------|-------------|
| Bridge Table | Ponderacao precisa | Complexidade | Metricas precisam de distribuicao |
| Multivalued Dimension | Simples | Sem ponderacao | Apenas listagem, sem metricas |
| Junk Dimension | Simples | Combinacoes limitadas | Poucos valores possiveis |
| Array/JSON | Flexivel | Sem JOIN padrao | Delta Lake / BigQuery |

## Common Pitfalls

| Nao Faca | Faca |
|----------|------|
| Omitir fator_ponderacao | Sempre inclua (mesmo que 1/N) |
| Somar metricas sem ponderar | Multiplique por fator no SELECT |
| Criar bridge para 1:N simples | Use FK normal na dimensao |
| Ignorar grupo default (-1) | Inclua para itens sem multi-value |

## See Also

- [Tabelas Fato](../concepts/tabelas-fato.md)
- [Tabelas Dimensao](../concepts/tabelas-dimensao.md)
- [Bus Matrix](../patterns/bus-matrix.md)
- [Modelo Vendas Varejo](../patterns/modelagem-vendas-varejo.md)
