# Enterprise Bus Matrix

> **Purpose**: Ferramenta de planejamento que mapeia processos de negocio contra dimensoes conformadas para garantir consistencia do DW
> **MCP Validated**: 2026-03-23

## When to Use

- Planejar a arquitetura do data warehouse antes de modelar
- Garantir conformidade de dimensoes entre multiplos data marts
- Priorizar quais processos (fatos) construir primeiro
- Comunicar escopo do DW com stakeholders de negocio

## Implementation

```text
ENTERPRISE BUS MATRIX — VAREJO
==========================================================================
                          DIMENSOES CONFORMADAS
                    ┌────┬────┬────┬────┬────┬────┬────┬────┐
                    │Data│Prod│Loja│Clie│Prom│Forn│Func│F.Pg│
PROCESSOS DE        │    │uto │    │nte │ocao│eced│iona│mto │
NEGOCIO (FATOS)     │    │    │    │    │    │or  │rio │    │
────────────────────┼────┼────┼────┼────┼────┼────┼────┼────┤
Vendas PDV          │ X  │ X  │ X  │ X  │ X  │    │ X  │ X  │
Estoque             │ X  │ X  │ X  │    │    │ X  │    │    │
Compras/Pedidos     │ X  │ X  │    │    │    │ X  │ X  │ X  │
Recebimento Mercad. │ X  │ X  │ X  │    │    │ X  │ X  │    │
Promocoes           │ X  │ X  │ X  │    │ X  │    │    │    │
Fidelidade          │ X  │ X  │ X  │ X  │ X  │    │    │    │
Devolucoes          │ X  │ X  │ X  │ X  │    │    │ X  │    │
==========================================================================

LEITURA:
- Linhas = processos de negocio (cada um vira uma tabela fato)
- Colunas = dimensoes conformadas (compartilhadas entre fatos)
- X = esta dimensao participa deste processo
- Dimensoes com mais X = maior prioridade de conformidade
```

## Regras de Conformidade

```text
DIMENSAO CONFORMADA: mesma estrutura, mesmos valores, mesma semantica

CORRETO:
  fato_vendas.sk_produto  -> dim_produto (sk, gtin, nome, categoria...)
  fato_estoque.sk_produto -> dim_produto (MESMA tabela dim_produto)

ERRADO:
  fato_vendas   -> dim_produto_vendas  (copia parcial)
  fato_estoque  -> dim_produto_estoque (copia parcial)
  -- Resultado: "categoria" pode divergir entre os dois!
```

## Configuration

| Criterio | Recomendacao | Motivo |
|----------|-------------|--------|
| Primeira dimensao | dim_data | Presente em 100% dos fatos |
| Segunda dimensao | dim_produto | Core do varejo, alta reutilizacao |
| Primeiro fato | Vendas | Maior valor de negocio, mais dimensoes |
| Prioridade | Mais X na coluna = mais urgente | Maximiza reuso |

## Processo de Construcao

| Etapa | Acao | Resultado |
|-------|------|-----------|
| 1 | Listar processos de negocio | Linhas da matrix |
| 2 | Listar dimensoes candidatas | Colunas da matrix |
| 3 | Marcar participacao (X) | Mapa completo |
| 4 | Priorizar dimensoes com mais X | Conformar primeiro |
| 5 | Priorizar fatos com mais valor | Construir primeiro |
| 6 | Validar com negocio | Confirmar semantica |

## Example Usage

```sql
-- Validar conformidade: mesma dim_produto em vendas e estoque
-- Se a query abaixo retorna resultados consistentes, a dimensao esta conformada

-- Vendas por categoria
SELECT p.categoria, SUM(fv.valor_liquido) AS receita
FROM fato_vendas fv
JOIN dim_produto p ON fv.sk_produto = p.sk_produto
GROUP BY p.categoria;

-- Estoque por categoria (MESMA dim_produto)
SELECT p.categoria, SUM(fe.qtd_em_estoque) AS estoque
FROM fato_estoque fe
JOIN dim_produto p ON fe.sk_produto = p.sk_produto
GROUP BY p.categoria;

-- Cruzamento vendas x estoque (funciona porque dim_produto e conformada)
SELECT
    p.categoria,
    SUM(fv.valor_liquido) AS receita,
    AVG(fe.qtd_em_estoque) AS estoque_medio
FROM fato_vendas fv
JOIN dim_produto p ON fv.sk_produto = p.sk_produto
JOIN fato_estoque fe ON fe.sk_produto = fv.sk_produto AND fe.sk_data = fv.sk_data
GROUP BY p.categoria;
```

## See Also

- [Star Schema](../concepts/star-schema.md)
- [Tabelas Dimensao](../concepts/tabelas-dimensao.md)
- [Modelo Vendas Varejo](../patterns/modelagem-vendas-varejo.md)
- [Bridge Tables](../patterns/bridge-tables.md)
