# Checklist de Revisao de Modelo Dimensional

> **Purpose**: Guidelines para revisar e validar um modelo dimensional existente — baseado no IBM Redbook SG24-7138 Cap. 8
> **Confidence**: 0.90
> **MCP Validated**: 2026-03-23

## When to Use

- Antes de aprovar um modelo dimensional para implementacao
- Ao auditar um modelo existente para melhorias
- Como etapa de quality gate em projetos de data warehouse
- Para treinar equipes em boas praticas de modelagem

## Checklist Completo

### 1. Grain (Granularidade)

| # | Verificacao | Status |
|---|------------|--------|
| 1.1 | O grain esta **explicitamente declarado** em texto? | |
| 1.2 | O grain e **atomico** (nao pode ser subdividido)? | |
| 1.3 | Todos os fatos sao **verdadeiros** para o grain declarado? | |
| 1.4 | Todas as dimensoes sao **verdadeiras** para o grain declarado? | |
| 1.5 | Existem multiplos grains que devem estar em **fatos separadas**? | |
| 1.6 | O grain permite responder perguntas **futuras** (nao so as atuais)? | |

### 2. Dimensoes

| # | Verificacao | Status |
|---|------------|--------|
| 2.1 | Todas as dimensoes usam **surrogate keys** (nao natural keys como PK)? | |
| 2.2 | As natural keys estao preservadas como **atributos** na dimensao? | |
| 2.3 | As dimensoes estao **desnormalizadas** (sem snowflake desnecessario)? | |
| 2.4 | Hierarquias pertencem a dimensao (nao separadas em tabelas)? | |
| 2.5 | Dimensoes conformadas estao **compartilhadas** entre fatos? | |
| 2.6 | A dim_data esta separada (nao misturada com outras dims)? | |
| 2.7 | dim_data e dim_hora estao em dimensoes **separadas**? | |
| 2.8 | Multiplas datas usam **role-playing** (views) em vez de tabelas duplicadas? | |
| 2.9 | Existe **linha default** (sk=-1) para valores desconhecidos/nulos? | |
| 2.10 | Flags/indicadores estao em **junk dimension** (nao na fato)? | |
| 2.11 | Atributos de mudanca rapida estao em **mini-dimensions**? | |
| 2.12 | Atributos descritivos incluem **descricao** (nao so codigos)? | |
| 2.13 | Nomes de atributos sao **unicos** no modelo? | |
| 2.14 | Dimensoes degenerate estao na fato (sem tabela propria desnecessaria)? | |
| 2.15 | Multi-valued dimensions usam **bridge tables** com fator de ponderacao? | |

### 3. Fatos e Metricas

| # | Verificacao | Status |
|---|------------|--------|
| 3.1 | A fato contem **apenas** FKs, degenerate dims e metricas numericas? | |
| 3.2 | Nao ha textos descritivos na fato (devem estar em dimensoes)? | |
| 3.3 | Metricas estao classificadas: aditiva, semi-aditiva, nao-aditiva? | |
| 3.4 | Precos unitarios sao armazenados como **valor estendido** (preco x qtd)? | |
| 3.5 | Ratios/percentuais armazenam **numerador e denominador** separados? | |
| 3.6 | Fatos derivados estao documentados com formula? | |
| 3.7 | Fatos YTD sao calculados na consulta (nao armazenados na fato)? | |
| 3.8 | O tipo de fato esta correto (transacional, periodica, acumulada)? | |
| 3.9 | Fatos conformados tem **mesma definicao** em todos os data marts? | |
| 3.10 | Tamanho e crescimento da fato estao **estimados**? | |

### 4. SCD (Slowly Changing Dimensions)

| # | Verificacao | Status |
|---|------------|--------|
| 4.1 | Cada atributo de dimensao tem **tipo SCD definido** (0, 1, 2, 3, 6)? | |
| 4.2 | SCD Tipo 2 tem data_inicio, data_fim e flag_corrente? | |
| 4.3 | SCD Tipo 2 usa **surrogate key** (nao natural key como PK)? | |
| 4.4 | Atributos que mudam rapido estao em **mini-dimensions** (nao SCD 2)? | |

### 5. Performance e Fisico

| # | Verificacao | Status |
|---|------------|--------|
| 5.1 | Agregados estao planejados para queries frequentes? | |
| 5.2 | Estrategia de **aggregate navigation** definida? | |
| 5.3 | Particionamento da fato esta planejado (por data, tipicamente)? | |
| 5.4 | Indexacao das FKs na fato e PKs nas dims esta planejada? | |

### 6. Documentacao

| # | Verificacao | Status |
|---|------------|--------|
| 6.1 | Grain esta documentado por escrito? | |
| 6.2 | Bus Matrix esta atualizada com o novo fato/dims? | |
| 6.3 | Metadata (nomes, descricoes, fontes) esta documentada? | |
| 6.4 | Perguntas de negocio que o modelo responde estao listadas? | |

## Erros Mais Comuns em Revisoes

| Erro | Correcao |
|------|---------|
| Dimensao com tantas linhas quanto a fato | Provavelmente e **degenerate dimension** — mova para coluna na fato |
| Hierarquias snowflaked em tabelas separadas | **Desnormalize** de volta para a dimensao |
| Natural key como PK da dimensao | Crie **surrogate key**, mantenha natural key como atributo |
| Datas armazenadas dentro de outra dimensao | Separe em **dim_data** propria ou use **role-playing** |
| Flags/codigos na fato | Mova para **junk dimension** |
| Modelo desenhado em grain agregado | Redesenhe no **grain atomico** |
| Fatos de grains diferentes na mesma tabela | Separe em **fatos independentes** |

## See Also

- [Granularidade](../concepts/granularidade.md)
- [Star Schema](../concepts/star-schema.md)
- [Tabelas Fato](../concepts/tabelas-fato.md)
- [Tabelas Dimensao](../concepts/tabelas-dimensao.md)
- [Bus Matrix](../patterns/bus-matrix.md)
