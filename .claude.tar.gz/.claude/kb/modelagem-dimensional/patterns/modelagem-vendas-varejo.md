# Modelagem Vendas Varejo

> **Purpose**: Modelo dimensional completo para vendas no varejo — fato vendas + dimensoes produto, loja, tempo, cliente, promocao
> **MCP Validated**: 2026-03-23

## When to Use

- Modelar processo de vendas em PDV (ponto de venda) para analytics
- Criar data mart de vendas seguindo metodologia Kimball
- Integrar dados de vendas com estoque, promocoes e clientes
- Base para dashboards de performance comercial

## Implementation

```sql
-- =====================================================
-- MODELO DIMENSIONAL: VENDAS VAREJO (Star Schema)
-- Grain: 1 linha = 1 item vendido em 1 transacao
-- =====================================================

-- TABELA FATO: fato_vendas
CREATE TABLE fato_vendas (
    -- Surrogate keys (FKs para dimensoes)
    sk_data          INT NOT NULL,
    sk_hora          INT NOT NULL,
    sk_produto       INT NOT NULL,
    sk_loja          INT NOT NULL,
    sk_cliente       INT NOT NULL,  -- -1 para venda sem identificacao
    sk_promocao      INT NOT NULL,  -- -1 para sem promocao
    sk_forma_pagto   INT NOT NULL,

    -- Degenerate dimensions
    nro_cupom_fiscal VARCHAR(20),
    nro_item         INT,

    -- Metricas aditivas
    quantidade       DECIMAL(10,3),
    valor_unitario   DECIMAL(10,2),
    valor_bruto      DECIMAL(12,2),
    valor_desconto   DECIMAL(10,2),
    valor_liquido    DECIMAL(12,2),
    custo_unitario   DECIMAL(10,2),
    custo_total      DECIMAL(12,2),
    margem_bruta     DECIMAL(12,2),  -- valor_liquido - custo_total

    -- Constraints
    PRIMARY KEY (sk_data, sk_loja, nro_cupom_fiscal, nro_item)
);

-- DIMENSAO: dim_produto
CREATE TABLE dim_produto (
    sk_produto       INT PRIMARY KEY,
    cod_gtin         VARCHAR(14),      -- natural key GS1 (ref: gs1-varejo)
    cod_interno      VARCHAR(20),      -- codigo do ERP
    nome_produto     VARCHAR(200),
    marca            VARCHAR(100),
    fabricante       VARCHAR(100),
    categoria        VARCHAR(100),
    subcategoria     VARCHAR(100),
    departamento     VARCHAR(100),
    secao            VARCHAR(100),
    unidade_medida   VARCHAR(10),
    peso_liquido_kg  DECIMAL(8,3),
    flag_perecivel   BOOLEAN,
    ncm              VARCHAR(10),
    -- SCD Tipo 2
    data_inicio      DATE,
    data_fim         DATE,
    flag_corrente    BOOLEAN
);

-- DIMENSAO: dim_loja
CREATE TABLE dim_loja (
    sk_loja          INT PRIMARY KEY,
    cod_loja         VARCHAR(10),
    cod_gln          VARCHAR(13),     -- natural key GS1 (ref: gs1-varejo)
    nome_loja        VARCHAR(100),
    tipo_loja        VARCHAR(30),     -- hipermercado, supermercado, express
    bandeira         VARCHAR(50),
    cidade           VARCHAR(100),
    estado           VARCHAR(2),
    regiao           VARCHAR(20),
    area_venda_m2    DECIMAL(10,2),
    data_inauguracao DATE
);

-- DIMENSAO: dim_data (pre-populada)
CREATE TABLE dim_data (
    sk_data          INT PRIMARY KEY,  -- formato YYYYMMDD
    data_completa    DATE,
    dia_semana       VARCHAR(15),
    dia_mes          INT,
    semana_ano       INT,
    mes              INT,
    nome_mes         VARCHAR(15),
    trimestre        INT,
    semestre         INT,
    ano              INT,
    flag_feriado     BOOLEAN,
    flag_fim_semana  BOOLEAN,
    nome_feriado     VARCHAR(100)
);

-- DIMENSAO: dim_cliente
CREATE TABLE dim_cliente (
    sk_cliente       INT PRIMARY KEY,  -- -1 = desconhecido
    cod_cliente      VARCHAR(20),
    nome             VARCHAR(200),
    cpf_hash         VARCHAR(64),      -- hash do CPF (LGPD)
    faixa_etaria     VARCHAR(20),
    genero           VARCHAR(1),
    cidade           VARCHAR(100),
    estado           VARCHAR(2),
    data_cadastro    DATE,
    flag_programa_fidelidade BOOLEAN,
    -- SCD Tipo 2
    data_inicio      DATE,
    data_fim         DATE,
    flag_corrente    BOOLEAN
);

-- DIMENSAO: dim_promocao
CREATE TABLE dim_promocao (
    sk_promocao      INT PRIMARY KEY,  -- -1 = sem promocao
    cod_promocao     VARCHAR(20),
    nome_promocao    VARCHAR(200),
    tipo_promocao    VARCHAR(50),      -- desconto_pct, leve_pague, combo
    data_inicio_promo DATE,
    data_fim_promo   DATE,
    desconto_pct     DECIMAL(5,2)
);
```

## Configuration

| Parametro | Valor | Descricao |
|-----------|-------|-----------|
| Grain | Item do cupom | 1 linha por item vendido |
| Atualizacao | Diaria (batch) | Carga incremental do PDV |
| SCD Tipo 2 | dim_produto, dim_cliente | Historico de mudancas |
| SCD Tipo 1 | dim_loja | Sobrescreve (sem historico) |
| Linha default | sk = -1 | Para dimensoes opcionais |

## Example Usage

```sql
-- Top 10 produtos por receita no mes atual
SELECT
    p.nome_produto,
    p.categoria,
    SUM(f.valor_liquido) AS receita,
    SUM(f.quantidade) AS qtd_vendida,
    SUM(f.margem_bruta) AS margem
FROM fato_vendas f
JOIN dim_produto p ON f.sk_produto = p.sk_produto AND p.flag_corrente = true
JOIN dim_data d ON f.sk_data = d.sk_data
WHERE d.ano = 2026 AND d.mes = 3
GROUP BY p.nome_produto, p.categoria
ORDER BY receita DESC
LIMIT 10;

-- Vendas por loja e dia da semana
SELECT
    l.nome_loja,
    d.dia_semana,
    SUM(f.valor_liquido) AS receita,
    COUNT(DISTINCT f.nro_cupom_fiscal) AS num_transacoes
FROM fato_vendas f
JOIN dim_loja l ON f.sk_loja = l.sk_loja
JOIN dim_data d ON f.sk_data = d.sk_data
GROUP BY l.nome_loja, d.dia_semana;
```

## See Also

- [Star Schema](../concepts/star-schema.md)
- [Tabelas Fato](../concepts/tabelas-fato.md)
- [Granularidade](../concepts/granularidade.md)
- [Bus Matrix](../patterns/bus-matrix.md)
- [GTIN para dim_produto](../../gs1-varejo/concepts/gtin.md)
- [GLN para dim_loja](../../gs1-varejo/concepts/gln.md)
