# SCD Tipo 2 com Delta Lake

> **Purpose**: Implementacao de Slowly Changing Dimension Tipo 2 usando Delta Lake MERGE para historico completo
> **MCP Validated**: 2026-03-23

## When to Use

- Manter historico completo de mudancas em dimensoes no lakehouse
- Implementar SCD Tipo 2 sem banco relacional (usando Delta Lake no GCS)
- Integrar com pipeline PySpark no Dataproc Serverless
- Substituir UPDATE/INSERT do SQL tradicional por MERGE do Delta

## Implementation

```python
"""
SCD Tipo 2 com Delta Lake MERGE.
Padrao: compara registros novos com correntes, fecha versoes antigas
e insere novas versoes para registros que mudaram.
"""
from delta.tables import DeltaTable
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import (
    col, lit, current_date, to_date, md5, concat_ws, coalesce
)


def apply_scd_type2(
    spark: SparkSession,
    target_path: str,
    source_df: DataFrame,
    business_key: str,
    tracked_columns: list[str],
) -> dict:
    """
    Aplica SCD Tipo 2 em tabela Delta.

    Args:
        spark: SparkSession ativa
        target_path: Caminho GCS da tabela Delta de dimensao
        source_df: DataFrame com dados novos/atualizados
        business_key: Coluna da natural key (ex: 'cod_gtin')
        tracked_columns: Colunas monitoradas para detectar mudanca

    Returns:
        dict com contadores de inserts e updates
    """
    today = current_date()

    # Gerar hash das colunas rastreadas para detectar mudanca
    source_with_hash = source_df.withColumn(
        "_hash", md5(concat_ws("|", *[coalesce(col(c).cast("string"), lit("NULL")) for c in tracked_columns]))
    )

    if not DeltaTable.isDeltaTable(spark, target_path):
        # Primeira carga: inserir tudo como corrente
        initial_df = (
            source_with_hash
            .withColumn("data_inicio", today)
            .withColumn("data_fim", to_date(lit("9999-12-31")))
            .withColumn("flag_corrente", lit(True))
        )
        initial_df.write.format("delta").save(target_path)
        return {"inserted": initial_df.count(), "updated": 0}

    target_table = DeltaTable.forPath(spark, target_path)

    # Detectar registros que mudaram
    target_df = target_table.toDF().filter(col("flag_corrente") == True)
    target_with_hash = target_df.withColumn(
        "_hash_target", md5(concat_ws("|", *[coalesce(col(c).cast("string"), lit("NULL")) for c in tracked_columns]))
    )

    # Registros que mudaram: mesmo business_key, hash diferente
    changed = (
        source_with_hash.alias("src")
        .join(target_with_hash.alias("tgt"), col(f"src.{business_key}") == col(f"tgt.{business_key}"))
        .filter(col("src._hash") != col("tgt._hash_target"))
        .select("src.*")
    )

    # Registros novos: nao existem no target
    new_records = (
        source_with_hash.alias("src")
        .join(target_with_hash.alias("tgt"), col(f"src.{business_key}") == col(f"tgt.{business_key}"), "left_anti")
        .select("src.*")
    )

    # Preparar novas versoes (changed + new)
    to_insert = (
        changed.union(new_records)
        .withColumn("data_inicio", today)
        .withColumn("data_fim", to_date(lit("9999-12-31")))
        .withColumn("flag_corrente", lit(True))
    )

    num_updates = changed.count()
    num_inserts = new_records.count()

    if num_updates > 0:
        # Fechar versoes antigas dos registros alterados
        changed_keys = [row[business_key] for row in changed.select(business_key).collect()]

        target_table.update(
            condition=(col("flag_corrente") == True) & (col(business_key).isin(changed_keys)),
            set={"data_fim": today, "flag_corrente": lit(False)},
        )

    if to_insert.count() > 0:
        to_insert.write.format("delta").mode("append").save(target_path)

    return {"inserted": num_inserts + num_updates, "updated": num_updates}
```

## Configuration

| Parametro | Valor Padrao | Descricao |
|-----------|-------------|-----------|
| `business_key` | (obrigatorio) | Natural key da dimensao (ex: `cod_gtin`) |
| `tracked_columns` | (obrigatorio) | Colunas que disparam nova versao |
| `data_fim` default | `9999-12-31` | Valor sentinela para registro corrente |
| `flag_corrente` | `true` | Filtro rapido para versao atual |

## Example Usage

```python
# Aplicar SCD Tipo 2 na dim_produto
result = apply_scd_type2(
    spark=spark,
    target_path="gs://bucket/trusted/dim_produto",
    source_df=df_produtos_novos,
    business_key="cod_gtin",
    tracked_columns=["nome_produto", "marca", "categoria", "subcategoria"],
)
print(f"Inseridos: {result['inserted']}, Atualizados: {result['updated']}")
```

## See Also

- [Slowly Changing Dimensions](../concepts/slowly-changing-dimensions.md)
- [Surrogate Keys](../concepts/surrogate-keys.md)
- [Tabelas Dimensao](../concepts/tabelas-dimensao.md)
- [GTIN como Business Key](../../gs1-varejo/concepts/gtin.md)
