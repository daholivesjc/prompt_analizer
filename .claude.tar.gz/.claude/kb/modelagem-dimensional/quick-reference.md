# Modelagem Dimensional Quick Reference

> Tabelas de consulta rapida. Para exemplos de codigo, veja os arquivos linkados.
> **MCP Validated**: 2026-03-23

## Tipos de Tabela Fato

| Tipo | Grain | Exemplo | Uso |
|------|-------|---------|-----|
| Transacional | 1 evento | Venda de item | Maioria dos casos |
| Periodica (Snapshot) | 1 periodo | Saldo mensal estoque | Acumulos regulares |
| Acumulada (Accumulating) | Ciclo de vida | Pedido ate entrega | Processos com etapas |
| Sem Fato (Factless) | Evento sem metrica | Aluno matriculado | Cobertura/elegibilidade |

## Tipos de Dimensao

| Tipo | Descricao | Exemplo |
|------|-----------|---------|
| Conformed | Compartilhada entre fatos | dim_produto, dim_tempo |
| Junk (Garbage) | Agrupa flags/indicadores de baixa cardinalidade | dim_flags_pedido |
| Degenerate | Atributo na fato (sem tabela) | numero_nota_fiscal |
| Role-Playing | Mesma dimensao, papeis diferentes (via views) | dim_data (pedido, envio, pagamento) |
| Outrigger | Sub-dimensao referenciada por dimensao | dim_geografia -> dim_pais |
| Mini-Dimension | Atributos que mudam rapido (fast changing) | dim_perfil_cliente |
| Hot-Swappable | Views especializadas de uma dimensao base | dim_produto_bens, dim_produto_servicos |
| Multi-Valued | Resolvida via bridge table com ponderacao | bridge_diagnostico, bridge_promocao |

## SCD Decision Matrix

| Tipo | Comportamento | Historico? | Quando Usar |
|------|---------------|------------|-------------|
| 0 | Nunca altera | Nao | Atributos fixos (data nascimento) |
| 1 | Sobrescreve | Nao | Correcoes, dados sem historico |
| 2 | Nova linha | Sim | Historico completo necessario |
| 3 | Coluna anterior | Parcial | Apenas valor anterior importa |
| 4 | Tabela historico | Sim | Volume alto de mudancas |
| 6 | Hibrido 1+2+3 | Sim | Historico + valor atual na mesma linha |

## Surrogate vs Natural Key

| Criterio | Surrogate | Natural |
|----------|-----------|---------|
| Formato | Inteiro sequencial | Codigo do negocio (GTIN, CPF) |
| Independencia | Total | Depende do fonte |
| SCD Tipo 2 | Essencial | Insuficiente |
| Performance JOIN | Otima | Variavel |
| Recomendacao | **Sempre usar** | Manter como atributo |

## Classificacao de Metricas

| Tipo | Pode Somar? | Exemplo | Agregacao |
|------|-------------|---------|-----------|
| Aditiva | Em todas as dims | valor_total, quantidade | SUM |
| Semi-Aditiva | Em todas exceto tempo | saldo_estoque, saldo_conta | SUM (dims); AVG (tempo) |
| Nao-Aditiva | Em nenhuma | margem_pct, preco_unitario | Recalcular componentes |
| Derivada | Depende dos componentes | lucro = receita - custo | Armazenar ou calcular |

## Common Pitfalls

| Nao Faca | Faca |
|----------|------|
| Definir grain vagamente | Declare grain explicito antes de qualquer coluna |
| Usar chave natural como PK da dimensao | Use surrogate key + natural key como atributo |
| Normalizar dimensoes (snowflake sem motivo) | Desnormalize dimensoes para performance |
| Colocar atributos textuais na fato | Mova para dimensao; fato so tem FK + metricas |
| Ignorar dimensao conformada | Planeje via Bus Matrix desde o inicio |
| Misturar grains diferentes na mesma fato | Crie fatos separadas para grains diferentes |
| Armazenar preco unitario como fato | Armazene valor estendido (preco x qtd) |
| Criar dims separadas para cada flag | Agrupe em junk/garbage dimension |
| Snowflakar hierarquias sem motivo | Snowflake so com agregados ou grains diferentes |
| Armazenar YTD na fato | Calcule via window functions ou OLAP |
| Evoluir schema sem analisar impacto | Use checklist de evolucao (causa, tipo, impacto) |
| Mudar grain sem criar nova fato | Crie fato separada para grain diferente |
| Deletar dimensao sem depreciar | Deprecie primeiro, remova apos validacao de queries |

## Related Documentation

| Topico | Path |
|--------|------|
| Star Schema | `concepts/star-schema.md` |
| Tabelas Fato | `concepts/tabelas-fato.md` |
| SCD Completo | `concepts/slowly-changing-dimensions.md` |
| Modelo Varejo | `patterns/modelagem-vendas-varejo.md` |
| Agregados | `patterns/aggregate-tables.md` |
| Review Checklist | `patterns/model-review-checklist.md` |
| Schema Evolution | `concepts/schema-evolution.md` |
| GS1 (GTIN) | `../gs1-varejo/concepts/gtin.md` |
| Indice | `index.md` |
