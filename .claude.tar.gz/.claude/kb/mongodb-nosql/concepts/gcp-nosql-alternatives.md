# Alternativas NoSQL no GCP

> **Purpose**: Comparacao entre servicos NoSQL do GCP e MongoDB para escolha de banco de dados
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-20

## Overview

O Google Cloud oferece varios servicos NoSQL gerenciados, cada um otimizado para diferentes
casos de uso. Esta referencia compara Firestore, Bigtable e Datastore com MongoDB para ajudar
na escolha da tecnologia certa para cada cenario de dados.

## Comparacao Detalhada

```text
                 MongoDB        Firestore      Bigtable       Datastore
                 (Atlas)        (Native)       (HBase API)    (Legacy)
─────────────────────────────────────────────────────────────────────────
Modelo           Documento      Documento      Wide-column    Entidade
Esquema          Flexivel       Flexivel       Fixo (famils)  Flexivel
Escala           Ilimitada      10 TB/db       Petabytes      Ilimitada
Latencia         ~5ms           ~10ms          ~5ms           ~10ms
Transacoes       Multi-doc      Multi-doc      Single-row     Multi-entity
Consultas        Rica (MQL)     Limitada       Scan/Get       GQL
Serverless       Atlas Srvless  Sim            Nao            Sim
Integracao GCP   Via peering    Nativa         Nativa         Nativa
Custo            Por vCPU/RAM   Por ops+arm    Por no+arm     Por ops+arm
```

## Quando Usar Cada Servico

### Firestore (recomendado para novos projetos GCP)
- Apps mobile e web com sync em tempo real
- Dados hierarquicos (colecoes/subcolecoes)
- Volume < 10 TB por banco
- Necessidade de listeners em tempo real

### Bigtable
- Dados de IoT e time-series em alta escala
- Volumes > 1 TB com leitura de baixa latencia
- Workloads de analytics com scan sequencial
- Integracao com Apache HBase API

### Datastore (modo legado do Firestore)
- Aplicacoes existentes ja em Datastore
- **Novos projetos devem usar Firestore Native**

### MongoDB (Atlas ou self-hosted)
- Esquema altamente flexivel e mutavel
- Consultas complexas com aggregation framework
- Necessidade de indices compostos avancados
- Multi-cloud ou ambiente hibrido

## Integracao com Spark/Dataproc

| Servico | Conector Spark | Facilidade |
|---------|---------------|------------|
| MongoDB | `mongo-spark-connector` | Alta — conector oficial maduro |
| Firestore | `spark-bigquery` (via export) | Media — requer export para BigQuery/GCS |
| Bigtable | `bigtable-hbase-spark` | Media — API HBase |
| Datastore | N/A (export para GCS) | Baixa — export manual |

## Para o Projeto FDM-Dados

O projeto utiliza MongoDB Atlas como fonte de dados, com ingestao via Dataproc Serverless:

```text
MongoDB Atlas  -->  Dataproc Serverless  -->  GCS (Parquet)
   (origem)         (spark connector)         (raw layer)
```

A escolha de MongoDB e adequada quando:
- Os dados ja estao no MongoDB (migracao de sistemas existentes)
- O esquema dos documentos varia entre registros
- Aggregation pipelines sao necessarios para filtrar na origem

## Common Mistakes

### Errado

```text
Usar Firestore para volumes > 10 TB
Usar Bigtable para dados com consultas ad-hoc complexas
Usar MongoDB sem VPC peering para conectividade privada
```

### Correto

```text
Firestore para apps < 10 TB com real-time sync
Bigtable para time-series e IoT em alta escala
MongoDB com VPC peering e Secret Manager para credenciais
```

## Related

- [MongoDB Fundamentals](mongodb-fundamentals.md)
- [Connection Security](../patterns/connection-security.md)
