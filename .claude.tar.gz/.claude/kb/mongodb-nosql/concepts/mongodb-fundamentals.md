# MongoDB Fundamentals

> **Purpose**: Conceitos basicos de MongoDB — documentos, colecoes, BSON e esquema flexivel
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-20

## Overview

MongoDB e um banco de dados NoSQL orientado a documentos que armazena dados em formato BSON
(Binary JSON). Diferente de bancos relacionais, documentos na mesma colecao podem ter estruturas
diferentes, oferecendo flexibilidade para dados semi-estruturados.

## O Modelo de Dados

```text
MongoDB                          SQL Equivalente
────────────────────────────────────────────────
Database                         Database
Collection                       Table
Document                         Row
Field                            Column
Embedded Document                JOIN (desnormalizado)
Array                            Tabela auxiliar
ObjectId (_id)                   Primary Key (auto)
```

## Documento BSON

```json
{
  "_id": ObjectId("507f1f77bcf86cd799439011"),
  "title": "MongoDB Guide",
  "year": 2024,
  "tags": ["nosql", "database"],
  "author": {
    "name": "Jane Doe",
    "email": "jane@example.com"
  },
  "ratings": [
    {"user": "alice", "score": 5},
    {"user": "bob", "score": 4}
  ]
}
```

## Quick Reference

| Conceito | Descricao | Impacto no Spark |
|----------|-----------|------------------|
| `_id` (ObjectId) | Identificador unico automatico | Convertido para StringType |
| Embedded Document | Documento dentro de documento | Mapeado para StructType |
| Array | Lista de valores ou documentos | Mapeado para ArrayType |
| Schema Flexivel | Campos variam entre documentos | Requer inferencia de schema |
| BSON Types | 20+ tipos (string, int, date...) | Mapeados para Spark types |

## Esquema Flexivel — Implicacoes

O esquema flexivel do MongoDB significa que:

1. **Documentos na mesma colecao podem ter campos diferentes**
2. **Um campo pode ter tipos diferentes** entre documentos
3. **Campos podem ser adicionados/removidos** sem migracao

Para pipelines de dados, isso exige:
- Inferencia de schema com amostragem adequada (`sampleSize`)
- Tratamento de campos nulos (`nullable=True`)
- Flatten de documentos aninhados quando necessario

## Common Mistakes

### Errado

```python
# Assumir que todos os documentos tem os mesmos campos
df = spark.read.format("mongodb").load()
df.select("campo_que_nao_existe")  # AnalysisException
```

### Correto

```python
# Verificar schema inferido antes de selecionar colunas
df = spark.read.format("mongodb").option("sampleSize", "5000").load()
print(df.schema)  # Verificar campos disponiveis
available_cols = [f.name for f in df.schema.fields]
```

## Related

- [Spark MongoDB Connector](spark-mongodb-connector.md)
- [Schema Evolution](schema-evolution.md)
- [Schema Inference](../patterns/schema-inference.md)
