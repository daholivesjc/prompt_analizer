# Schema Evolution em Dados NoSQL

> **Purpose**: Estrategias para lidar com esquema dinamico em pipelines de ingestao de dados NoSQL
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-20

## Overview

Em bancos NoSQL como MongoDB, o esquema dos documentos pode mudar ao longo do tempo sem
migracao formal. Novos campos aparecem, tipos mudam e campos antigos deixam de existir.
Pipelines de dados precisam lidar com essa evolucao sem quebrar.

## Tipos de Mudanca de Esquema

```text
Tipo de Mudanca          Exemplo                          Risco
────────────────────────────────────────────────────────────────
Adicao de campo          Novo campo "tags" adicionado     Baixo
Remocao de campo         Campo "legacy_id" removido       Medio
Mudanca de tipo          "year": "2024" -> "year": 2024   Alto
Renomeacao               "nome" -> "full_name"            Alto
Mudanca de aninhamento   "address" string -> object       Alto
Adicao de subdocumento   Novo embedded document           Medio
```

## Estrategias de Tratamento

### 1. Schema-on-Read (Inferencia)

O Spark infere o schema a partir de uma amostra de documentos:

```python
# Aumentar amostra para capturar mais variacao de schema
df = (
    spark.read.format("mongodb")
    .option("sampleSize", "5000")  # Padrao: 1000
    .load()
)
```

**Pros**: Simples, automatico
**Contras**: Pode perder campos raros, tipos podem ser incorretos

### 2. Schema Explicito

Definir o schema esperado no codigo:

```python
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

schema = StructType([
    StructField("title", StringType(), nullable=True),
    StructField("year", IntegerType(), nullable=True),
    StructField("rated", StringType(), nullable=True),
])

df = spark.read.format("mongodb").schema(schema).load()
```

**Pros**: Previsivel, documentado, rapido
**Contras**: Novos campos ignorados, requer manutencao

### 3. Hibrido (Schema + Colunas Extras)

Combinar schema explicito com captura de campos desconhecidos:

```python
# Ler com schema inferido
df_full = spark.read.format("mongodb").load()

# Comparar com schema esperado
expected_cols = {"title", "year", "rated"}
actual_cols = set(df_full.columns)
new_cols = actual_cols - expected_cols

if new_cols:
    logger.warning("Novas colunas detectadas: %s", new_cols)
```

## No Projeto FDM-Dados

O job `ingest_mongodb_to_parquet.py` suporta ambas as estrategias:

```bash
# Inferencia automatica (padrao)
--sample-size 1000

# Schema explicito
--schema-json '{"title":"string","year":"integer","rated":"string"}'
```

## Quick Reference

| Estrategia | Quando Usar | Flag no Job |
|------------|-------------|-------------|
| Inferencia | Schema desconhecido ou muito variavel | `--sample-size 5000` |
| Explicito | Schema estavel e documentado | `--schema-json '{...}'` |
| Hibrido | Monitorar mudancas ao longo do tempo | Implementacao custom |

## Impacto na Camada Trusted (Delta Lake)

Quando o schema muda na raw layer, a camada Trusted precisa tratar:

1. **mergeSchema**: Delta Lake pode fazer merge automatico de schemas
2. **overwriteSchema**: Substituir schema inteiro (perigoso)
3. **Schema enforcement**: Rejeitar dados com schema incompativel

```python
# Delta Lake com merge de schema
df.write.format("delta").option("mergeSchema", "true").save(path)
```

## Common Mistakes

### Errado

```python
# sampleSize muito baixo para colecoes com schema variavel
.option("sampleSize", "10")  # Pode perder campos raros
```

### Correto

```python
# Amostra adequada para capturar variacao
.option("sampleSize", "5000")  # Mais documentos = melhor inferencia
```

## Related

- [MongoDB Fundamentals](mongodb-fundamentals.md)
- [Schema Inference](../patterns/schema-inference.md)
- [NoSQL to Parquet](../patterns/nosql-to-parquet.md)
