# MongoDB Connector for Spark

> **Purpose**: Configuracao e uso do MongoDB Spark Connector oficial para leitura de dados
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-20

## Overview

O MongoDB Spark Connector e o driver oficial que permite ler e escrever dados entre Apache Spark
e MongoDB. Na versao 10.x, utiliza o formato `mongodb` (nao mais `mongo` ou `com.mongodb.spark`)
e requer JARs especificos do driver MongoDB.

## Configuracao Basica

```python
# Leitura com MongoDB Spark Connector 10.x
df = (
    spark.read
    .format("mongodb")
    .option("connection.uri", "mongodb+srv://user:pass@cluster.mongodb.net/mydb")
    .option("database", "sample_mflix")
    .option("collection", "movies")
    .option("readPreference.name", "secondaryPreferred")
    .option("sampleSize", "1000")
    .load()
)
```

## JARs Necessarios

Para Dataproc Serverless 2.2 (Scala 2.12):

```text
mongo-spark-connector_2.12-10.4.0.jar    # Conector principal
mongodb-driver-sync-5.1.0.jar            # Driver sincrono
mongodb-driver-core-5.1.0.jar            # Core do driver
bson-5.1.0.jar                           # Serializacao BSON
```

**ATENCAO**: Dataproc Serverless 2.2 usa Scala 2.12. Usar JARs `_2.13` causa
`AbstractMethodError` por incompatibilidade binaria.

## Quick Reference

| Opcao | Tipo | Descricao |
|-------|------|-----------|
| `connection.uri` | String | URI de conexao completa |
| `database` | String | Nome do banco |
| `collection` | String | Nome da colecao |
| `readPreference.name` | String | Preferencia de leitura |
| `sampleSize` | Int | Docs para inferencia de schema |
| `aggregation.pipeline` | JSON | Pipeline de agregacao |

## Construcao da URI

```python
def build_connection_uri(base_uri: str, database: str) -> str:
    """Constroi URI completa com nome do banco.

    Suporta mongodb:// e mongodb+srv://
    Substitui banco existente na URI se houver.
    """
    uri = base_uri.rstrip("/")
    if "?" in uri:
        base, params = uri.split("?", 1)
        if base.count("/") > 2:
            base = "/".join(base.rsplit("/", 1)[:-1])
        return f"{base}/{database}?{params}"
    if uri.count("/") > 2:
        uri = "/".join(uri.rsplit("/", 1)[:-1])
    return f"{uri}/{database}"
```

## Particionamento

O connector particiona a leitura automaticamente baseado em:
- **SamplePartitioner** (padrao): amostra documentos e cria ranges
- **PaginateBySizePartitioner**: particiona por tamanho em MB
- **SinglePartitionPartitioner**: leitura single-thread

Para colecoes grandes (>1M docs), configurar particionamento explicito:

```python
reader = (
    spark.read.format("mongodb")
    .option("partitioner", "com.mongodb.spark.sql.connector.read.partitioner.SamplePartitioner")
    .option("partitionerOptions.partitionSizeMB", "64")
)
```

## Common Mistakes

### Errado

```python
# Formato antigo (pre-10.x) — nao funciona com connector 10.x
spark.read.format("com.mongodb.spark.sql.DefaultSource").load()
```

### Correto

```python
# Formato correto para connector 10.x
spark.read.format("mongodb").option("connection.uri", uri).load()
```

## Related

- [MongoDB Fundamentals](mongodb-fundamentals.md)
- [Spark MongoDB Ingestion](../patterns/spark-mongodb-ingestion.md)
- [Connection Security](../patterns/connection-security.md)
