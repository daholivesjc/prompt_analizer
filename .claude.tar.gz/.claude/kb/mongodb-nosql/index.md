# MongoDB e NoSQL para GCP — Knowledge Base

> **Purpose**: Referencia para ingestao de dados MongoDB e bancos NoSQL no contexto GCP com PySpark/Dataproc Serverless
> **MCP Validated**: 2026-03-20

## Quick Navigation

### Conceitos (< 150 linhas cada)

| Arquivo | Proposito |
|---------|-----------|
| [concepts/mongodb-fundamentals.md](concepts/mongodb-fundamentals.md) | Documentos, colecoes, esquema flexivel, BSON |
| [concepts/spark-mongodb-connector.md](concepts/spark-mongodb-connector.md) | Driver oficial, configuracao URI, particionamento |
| [concepts/gcp-nosql-alternatives.md](concepts/gcp-nosql-alternatives.md) | Firestore, Bigtable, Datastore — comparacoes |
| [concepts/schema-evolution.md](concepts/schema-evolution.md) | Esquema dinamico em pipelines de dados |

### Padroes (< 200 linhas cada)

| Arquivo | Proposito |
|---------|-----------|
| [patterns/spark-mongodb-ingestion.md](patterns/spark-mongodb-ingestion.md) | Padrao de leitura MongoDB com PySpark |
| [patterns/nosql-to-parquet.md](patterns/nosql-to-parquet.md) | Conversao de documentos NoSQL para formato colunar |
| [patterns/schema-inference.md](patterns/schema-inference.md) | Inferencia e merge de esquemas semi-estruturados |
| [patterns/connection-security.md](patterns/connection-security.md) | Secret Manager, IAM, VPC peering para conectividade |

### Specs (Machine-Readable)

| Arquivo | Proposito |
|---------|-----------|
| [specs/mongodb-connector-config.yaml](specs/mongodb-connector-config.yaml) | Configuracao do MongoDB Spark Connector |

---

## Quick Reference

- [quick-reference.md](quick-reference.md) - Tabelas de consulta rapida

---

## Conceitos-Chave

| Conceito | Descricao |
|----------|-----------|
| **Documento** | Unidade basica de dados no MongoDB (equivalente a uma linha em SQL) |
| **Colecao** | Agrupamento de documentos (equivalente a uma tabela em SQL) |
| **BSON** | Formato binario do JSON usado internamente pelo MongoDB |
| **Schema Flexivel** | Documentos na mesma colecao podem ter campos diferentes |
| **Spark Connector** | Driver oficial para leitura/escrita MongoDB via Spark |

---

## Trilha de Aprendizado

| Nivel | Arquivos |
|-------|----------|
| **Iniciante** | concepts/mongodb-fundamentals.md, concepts/spark-mongodb-connector.md |
| **Intermediario** | patterns/spark-mongodb-ingestion.md, patterns/nosql-to-parquet.md |
| **Avancado** | patterns/schema-inference.md, patterns/connection-security.md |

---

## Uso por Agentes

| Agente | Arquivos Primarios | Caso de Uso |
|--------|-------------------|-------------|
| pyspark-developer | patterns/spark-mongodb-ingestion.md | Implementar job de ingestao MongoDB |
| infra-agent | patterns/connection-security.md | Configurar rede e seguranca |
| data-architect | concepts/gcp-nosql-alternatives.md | Escolher banco NoSQL no GCP |

---

## Contexto do Projeto

Este KB suporta o pipeline Medallion do projeto FDM-Dados:

| Componente | Servico/Tecnologia |
|------------|-------------------|
| Job de ingestao | `jobs/raw/ingest_mongodb_to_parquet.py` |
| Workflow | `workflows/wf_ingest_mongodb.yaml` |
| Infra Terraform | `terraform/envs/jobs/ingest-mongodb/` |
| Credenciais | Secret Manager (MongoDB connection URI) |
| Processamento | Dataproc Serverless 2.2 |
| Armazenamento | GCS (raw layer, formato Parquet) |
