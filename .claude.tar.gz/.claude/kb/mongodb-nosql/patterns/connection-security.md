# Connection Security para MongoDB no GCP

> **Purpose**: Padroes de seguranca para conectividade MongoDB no GCP — Secret Manager, IAM, VPC peering
> **MCP Validated**: 2026-03-20

## Quando Usar

- Conectar Dataproc Serverless a MongoDB Atlas ou self-hosted
- Gerenciar credenciais de banco de dados de forma segura
- Configurar rede privada entre GCP e MongoDB
- Implementar principio de menor privilegio para jobs de ingestao

## Implementacao

### 1. Secret Manager para Credenciais

A URI de conexao MongoDB (com usuario/senha) e armazenada no Secret Manager:

```python
from google.cloud import secretmanager


def get_secret(project_id: str, secret_name: str) -> str:
    """Obtem o valor mais recente de um secret do Secret Manager.

    A URI de conexao MongoDB segue o formato:
    mongodb+srv://user:password@cluster.mongodb.net/?retryWrites=true

    Nunca logue ou imprima a URI — contem credenciais.
    """
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
    return client.access_secret_version(name=name).payload.data.decode("UTF-8")
```

### 2. IAM — Permissoes Necessarias

A Service Account do Dataproc Serverless precisa de:

```text
Papel IAM                              Recurso
──────────────────────────────────────────────────────────
roles/secretmanager.secretAccessor     Secret especifico
roles/dataproc.worker                  Projeto
roles/storage.objectAdmin              Bucket GCS de destino
```

Terraform para conceder acesso ao secret:

```hcl
resource "google_secret_manager_secret_iam_member" "mongodb_uri" {
  project   = var.project_id
  secret_id = google_secret_manager_secret.mongodb_uri.secret_id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${var.service_account_email}"
}
```

### 3. VPC Peering com MongoDB Atlas

Para conectividade privada (sem transito pela internet publica):

```text
GCP VPC                     MongoDB Atlas
┌─────────────┐             ┌─────────────┐
│  Dataproc   │             │   Cluster   │
│  Serverless │◄──peering──►│   MongoDB   │
│  (subnet)   │             │   (Atlas)   │
└─────────────┘             └─────────────┘

Requisitos:
1. VPC peering entre GCP e Atlas
2. Subnetwork com IP range compativel
3. Firewall rules para porta 27017 (ou 27015-27017)
```

### 4. Firewall Rules

```hcl
resource "google_compute_firewall" "allow_mongodb" {
  name    = "allow-mongodb-egress"
  network = var.vpc_network

  allow {
    protocol = "tcp"
    ports    = ["27015-27017"]
  }

  direction          = "EGRESS"
  destination_ranges = ["10.0.0.0/8"]  # Range do Atlas peering
}
```

### 5. Subnetwork para Dataproc

O Dataproc Serverless precisa de uma subnetwork com:
- Private Google Access habilitado
- IP range suficiente para workers Spark

```hcl
resource "google_compute_subnetwork" "dataproc" {
  name                     = "dataproc-subnet"
  ip_cidr_range            = "10.1.0.0/24"
  region                   = var.region
  network                  = var.vpc_network
  private_ip_google_access = true
}
```

## Configuracao

| Setting | Descricao |
|---------|-----------|
| `--project-id` | Projeto GCP com o Secret Manager |
| `--secret-name` | Nome do secret com a URI MongoDB |
| `subnetworkUri` | URI da subnetwork para Dataproc |
| `serviceAccount` | SA com permissoes necessarias |

## Checklist de Seguranca

```text
[ ] URI MongoDB armazenada no Secret Manager (nunca em codigo)
[ ] Service Account com menor privilegio (secretAccessor apenas no secret necessario)
[ ] VPC peering configurado (sem IP publico)
[ ] Firewall permite apenas portas MongoDB (27015-27017)
[ ] Private Google Access habilitado na subnet
[ ] Logs de auditoria habilitados no Secret Manager
[ ] Rotacao de credenciais programada
```

## Fluxo de Autenticacao no Job

```text
1. Dataproc inicia job com Service Account
2. Job chama Secret Manager API (IAM verifica permissao)
3. Secret Manager retorna URI MongoDB
4. Job conecta ao MongoDB via VPC peering (rede privada)
5. MongoDB autentica com usuario/senha da URI
6. Dados trafegam pela rede privada (sem internet publica)
```

## See Also

- [Spark MongoDB Ingestion](spark-mongodb-ingestion.md)
- [Spark MongoDB Connector](../concepts/spark-mongodb-connector.md)
- [GCP NoSQL Alternatives](../concepts/gcp-nosql-alternatives.md)
