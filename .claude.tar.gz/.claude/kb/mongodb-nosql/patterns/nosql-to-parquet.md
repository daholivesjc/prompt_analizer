# NoSQL to Parquet

> **Purpose**: Padrao de conversao de documentos NoSQL para formato colunar Parquet
> **MCP Validated**: 2026-03-20

## Quando Usar

- Converter documentos MongoDB/Firestore para Parquet na raw layer
- Transformar dados semi-estruturados (JSON-like) em formato colunar otimizado
- Preparar dados NoSQL para analytics em ferramentas como BigQuery, Spark SQL

## Implementacao

### Flatten de Documentos Aninhados

Documentos NoSQL frequentemente contem subdocumentos e arrays que precisam ser
achatados para formato colunar:

```python
from pyspark.sql import DataFrame
from pyspark.sql.types import StructType
import pyspark.sql.functions as F


def flatten_dataframe(df: DataFrame) -> DataFrame:
    """Achata todos os StructType aninhados em colunas planas.

    Itera ate nao restar mais StructType. Colunas aninhadas
    recebem nome no formato: pai_filho (underscore como separador).
    """
    has_struct = True
    while has_struct:
        has_struct = False
        columns = []
        for field in df.schema.fields:
            if isinstance(field.dataType, StructType):
                has_struct = True
                for nested_field in field.dataType.fields:
                    columns.append(
                        F.col(f"`{field.name}`.`{nested_field.name}`")
                        .alias(f"{field.name}_{nested_field.name}")
                    )
            else:
                columns.append(F.col(f"`{field.name}`"))
        df = df.select(columns)
    return df
```

### Tratamento de Arrays

Arrays precisam de estrategia diferente — explodir ou manter:

```python
from pyspark.sql.types import ArrayType


def explode_arrays(df: DataFrame, columns: list[str] | None = None) -> DataFrame:
    """Explode colunas de array em linhas individuais.

    Args:
        df: DataFrame com colunas de array.
        columns: Lista de colunas para explodir. Se None, explode todas.
    """
    if columns is None:
        columns = [
            f.name for f in df.schema.fields
            if isinstance(f.dataType, ArrayType)
        ]

    for col_name in columns:
        df = df.withColumn(col_name, F.explode_outer(F.col(col_name)))

    return df
```

### Tratamento de ObjectId

O campo `_id` do MongoDB (ObjectId) e convertido para string automaticamente pelo
connector, mas pode precisar de limpeza:

```python
def clean_object_id(df: DataFrame) -> DataFrame:
    """Remove ou converte o campo _id do MongoDB."""
    if "_id" in df.columns:
        # ObjectId vem como struct {oid: string} no connector 10.x
        if isinstance(df.schema["_id"].dataType, StructType):
            df = df.withColumn("_id", F.col("_id.oid"))
    return df
```

## Configuracao

| Setting | Default | Descricao |
|---------|---------|-----------|
| `compression` | `snappy` | Algoritmo de compressao Parquet |
| `write.mode` | `overwrite` | Modo de escrita (overwrite/append) |
| `flatten_nested` | `false` | Achatar subdocumentos |
| `coalesce` | `auto` | Numero de arquivos de saida |

## Mapeamento de Tipos

```text
Documento NoSQL          Parquet/Spark
────────────────────────────────────────
String                   STRING
Integer (32/64)          INT / LONG
Double                   DOUBLE
Boolean                  BOOLEAN
Date                     TIMESTAMP
ObjectId                 STRING
Embedded Doc             STRUCT (ou flatten)
Array de primitivos      ARRAY<tipo>
Array de docs            ARRAY<STRUCT>
Null                     nullable=true
```

## Exemplo de Uso

```python
# Pipeline completo: MongoDB -> flatten -> metadados -> Parquet
df = read_mongodb_collection(spark, uri, "mydb", "users")

# Achatar documentos aninhados
df = flatten_dataframe(df)

# Limpar ObjectId
df = clean_object_id(df)

# Adicionar metadados de linhagem
df = add_metadata_columns(df, "users", "mydb")

# Gravar como Parquet
df.write.mode("overwrite").option("compression", "snappy").parquet(output_path)
```

## See Also

- [Spark MongoDB Ingestion](spark-mongodb-ingestion.md)
- [Schema Inference](schema-inference.md)
- [Schema Evolution](../concepts/schema-evolution.md)
