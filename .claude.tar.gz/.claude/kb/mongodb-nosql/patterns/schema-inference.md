# Schema Inference para Dados Semi-Estruturados

> **Purpose**: Estrategias de inferencia e merge de esquemas em dados NoSQL e semi-estruturados
> **MCP Validated**: 2026-03-20

## Quando Usar

- Colecoes MongoDB com schema desconhecido ou variavel
- Primeira ingestao de uma fonte de dados NoSQL
- Deteccao automatica de mudancas de schema entre execucoes
- Merge de schemas de multiplas fontes de dados

## Implementacao

### Inferencia via MongoDB Spark Connector

O connector infere o schema amostrando documentos da colecao:

```python
def read_with_inference(
    spark: SparkSession,
    uri: str,
    database: str,
    collection: str,
    sample_size: int = 1000,
) -> DataFrame:
    """Le colecao com inferencia automatica de schema.

    O connector amostra `sample_size` documentos para construir
    o StructType resultante. Campos presentes em pelo menos 1
    documento amostrado sao incluidos como nullable.
    """
    return (
        spark.read
        .format("mongodb")
        .option("connection.uri", uri)
        .option("database", database)
        .option("collection", collection)
        .option("sampleSize", str(sample_size))
        .load()
    )
```

### Schema Explicito via JSON

O job `ingest_mongodb_to_parquet.py` suporta schema explicito via CLI:

```python
from pyspark.sql.types import (
    DoubleType, IntegerType, LongType,
    StringType, StructField, StructType,
)

TYPE_MAP = {
    "string": StringType(),
    "integer": IntegerType(),
    "int": IntegerType(),
    "long": LongType(),
    "bigint": LongType(),
    "double": DoubleType(),
    "float": DoubleType(),
}


def parse_schema_json(schema_json: str) -> StructType:
    """Converte JSON simplificado em StructType do Spark.

    Formato de entrada: '{"col_name": "type", ...}'
    Tipos suportados: string, integer, int, long, bigint, double, float
    """
    import json
    mapping = json.loads(schema_json)
    fields = []
    for col_name, col_type in mapping.items():
        spark_type = TYPE_MAP.get(col_type.lower())
        if spark_type is None:
            raise ValueError(
                f"Tipo nao suportado '{col_type}' para coluna '{col_name}'. "
                f"Suportados: {list(TYPE_MAP.keys())}"
            )
        fields.append(StructField(col_name, spark_type, nullable=True))
    return StructType(fields)
```

### Comparacao de Schemas entre Execucoes

```python
def compare_schemas(
    previous: StructType,
    current: StructType,
) -> dict:
    """Compara dois schemas e retorna diferencas.

    Retorna dict com campos adicionados, removidos e alterados.
    """
    prev_fields = {f.name: f for f in previous.fields}
    curr_fields = {f.name: f for f in current.fields}

    return {
        "added": [
            n for n in curr_fields if n not in prev_fields
        ],
        "removed": [
            n for n in prev_fields if n not in curr_fields
        ],
        "type_changed": [
            n for n in curr_fields
            if n in prev_fields
            and curr_fields[n].dataType != prev_fields[n].dataType
        ],
    }
```

## Configuracao

| Setting | Default | Descricao |
|---------|---------|-----------|
| `sampleSize` | `1000` | Documentos amostrados para inferencia |
| `--schema-json` | `None` | Schema explicito (bypassa inferencia) |
| `sql.sources.partitionColumnTypeInference.enabled` | `true` | Inferencia de tipos em particoes |

## Recomendacoes por Cenario

| Cenario | Estrategia | sampleSize |
|---------|------------|------------|
| Schema estavel e documentado | Explicito (`--schema-json`) | N/A |
| Schema desconhecido, colecao pequena (<10K) | Inferencia | 5000 |
| Schema variavel, colecao grande (>100K) | Inferencia | 10000 |
| Schema critico (financeiro, compliance) | Explicito + validacao | N/A |
| Primeira exploracao | Inferencia + log do schema | 1000 |

## Exemplo de Uso

```bash
# Inferencia com amostra grande
python ingest_mongodb_to_parquet.py \
    --project-id my-project \
    --secret-name mongodb-uri \
    --database analytics \
    --collection events \
    --destination gs://bucket/raw/mongodb/events \
    --sample-size 5000

# Schema explicito
python ingest_mongodb_to_parquet.py \
    --project-id my-project \
    --secret-name mongodb-uri \
    --database analytics \
    --collection events \
    --destination gs://bucket/raw/mongodb/events \
    --schema-json '{"event_type":"string","timestamp":"long","user_id":"string"}'
```

## See Also

- [Schema Evolution](../concepts/schema-evolution.md)
- [MongoDB Fundamentals](../concepts/mongodb-fundamentals.md)
- [NoSQL to Parquet](nosql-to-parquet.md)
