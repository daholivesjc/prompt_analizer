# Spark MongoDB Ingestion

> **Purpose**: Padrao completo de leitura de dados MongoDB com PySpark no Dataproc Serverless
> **MCP Validated**: 2026-03-20

## Quando Usar

- Ingestao batch de colecoes MongoDB para o data lakehouse
- Necessidade de converter documentos BSON para formato colunar (Parquet)
- Pipeline Medallion: MongoDB -> GCS raw layer (Parquet)
- Filtragem na origem via aggregation pipeline

## Implementacao

Baseado no job real `jobs/raw/ingest_mongodb_to_parquet.py`:

```python
"""Padrao de ingestao MongoDB -> Parquet."""
import argparse
import json
import time
from typing import NamedTuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import StructType
import pyspark.sql.functions as F


class JobMetrics(NamedTuple):
    input_rows: int
    output_rows: int
    duration_seconds: float


def get_secret(project_id: str, secret_name: str) -> str:
    """Obtem URI de conexao do Secret Manager."""
    from google.cloud import secretmanager
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
    return client.access_secret_version(name=name).payload.data.decode("UTF-8")


def read_mongodb_collection(
    spark: SparkSession,
    connection_uri: str,
    database: str,
    collection: str,
    aggregation_pipeline: str | None = None,
    read_preference: str = "secondaryPreferred",
    schema: StructType | None = None,
    sample_size: int = 1000,
) -> DataFrame:
    """Le colecao MongoDB em DataFrame Spark."""
    reader = (
        spark.read
        .format("mongodb")
        .option("connection.uri", connection_uri)
        .option("database", database)
        .option("collection", collection)
        .option("readPreference.name", read_preference)
    )

    if schema is not None:
        reader = reader.schema(schema)
    else:
        reader = reader.option("sampleSize", str(sample_size))

    if aggregation_pipeline:
        reader = reader.option("aggregation.pipeline", aggregation_pipeline)

    return reader.load()


def add_metadata_columns(df: DataFrame, collection: str, database: str) -> DataFrame:
    """Adiciona colunas de metadados para rastreabilidade."""
    return (
        df
        .withColumn("_source_database", F.lit(database))
        .withColumn("_source_collection", F.lit(collection))
        .withColumn("_ingestion_timestamp", F.current_timestamp())
    )


def write_parquet(df: DataFrame, path: str, mode: str = "overwrite") -> None:
    """Grava DataFrame como Parquet com compressao Snappy."""
    df.write.mode(mode).option("compression", "snappy").parquet(path)
```

## Configuracao

| Setting | Default | Descricao |
|---------|---------|-----------|
| `--project-id` | - | ID do projeto GCP (Secret Manager) |
| `--secret-name` | - | Nome do secret com URI MongoDB |
| `--database` | - | Nome do banco MongoDB |
| `--collection` | - | Nome da colecao |
| `--destination` | - | Caminho GCS para Parquet de saida |
| `--aggregation-pipeline` | `None` | Pipeline de agregacao JSON |
| `--read-preference` | `secondaryPreferred` | Preferencia de leitura |
| `--schema-json` | `None` | Schema explicito em JSON |
| `--sample-size` | `1000` | Docs para inferencia de schema |
| `--flatten-nested` | `false` | Achatar documentos aninhados |
| `--write-mode` | `overwrite` | Modo de escrita Parquet |

## Exemplo de Uso

```bash
# Ingestao basica
gcloud dataproc batches submit pyspark \
    gs://BUCKET/landing/scripts_pyspark/ingest_mongodb_to_parquet.py \
    --region=us-central1 --version=2.2 \
    --jars=gs://BUCKET/jars/mongo-spark-connector_2.12-10.4.0.jar,\
gs://BUCKET/jars/mongodb-driver-sync-5.1.0.jar,\
gs://BUCKET/jars/mongodb-driver-core-5.1.0.jar,\
gs://BUCKET/jars/bson-5.1.0.jar \
    -- \
    --project-id my-project \
    --secret-name mongodb-connection-uri \
    --database sample_mflix \
    --collection movies \
    --destination gs://BUCKET/raw/mongodb/movies

# Com filtro e flatten
... -- \
    --aggregation-pipeline '[{"$match": {"year": {"$gte": 2000}}}]' \
    --flatten-nested true
```

## Fluxo de Execucao

```text
1. parse_args()          -> Argumentos CLI
2. get_secret()          -> URI do Secret Manager
3. build_connection_uri() -> URI + database
4. read_mongodb_collection() -> DataFrame
5. flatten_dataframe()   -> (opcional) achatar nested
6. add_metadata_columns() -> _source_database, _source_collection, _ingestion_timestamp
7. write_parquet()       -> GCS raw layer
8. return JobMetrics     -> input_rows, output_rows, duration
```

## See Also

- [MongoDB Fundamentals](../concepts/mongodb-fundamentals.md)
- [Spark MongoDB Connector](../concepts/spark-mongodb-connector.md)
- [NoSQL to Parquet](nosql-to-parquet.md)
- [Connection Security](connection-security.md)
