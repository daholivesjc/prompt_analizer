# MongoDB NoSQL Quick Reference

> Tabelas de consulta rapida. Para exemplos de codigo, veja os arquivos linkados.
> **MCP Validated**: 2026-03-20

## Tipos de Dados BSON vs Spark

| Tipo BSON | Tipo Spark | Notas |
|-----------|------------|-------|
| `String` | `StringType` | Mapeamento direto |
| `Int32` | `IntegerType` | 32-bit signed |
| `Int64` / `Long` | `LongType` | 64-bit signed |
| `Double` | `DoubleType` | 64-bit IEEE 754 |
| `Boolean` | `BooleanType` | true/false |
| `Date` | `TimestampType` | Milissegundos desde epoch |
| `ObjectId` | `StringType` | Convertido para string hex |
| `Array` | `ArrayType` | Tipo do elemento inferido |
| `Document` | `StructType` | Mapeamento recursivo |

## Opcoes do MongoDB Spark Connector

| Opcao | Padrao | Descricao |
|-------|--------|-----------|
| `connection.uri` | - | URI completa com credenciais |
| `database` | - | Nome do banco de dados |
| `collection` | - | Nome da colecao |
| `readPreference.name` | `primaryPreferred` | Preferencia de leitura |
| `sampleSize` | `1000` | Documentos para inferencia de schema |
| `aggregation.pipeline` | - | Pipeline de agregacao JSON |

## Read Preferences

| Preferencia | Quando Usar |
|-------------|-------------|
| `primary` | Dados mais recentes, consistencia forte |
| `primaryPreferred` | Preferir primary, fallback para secondary |
| `secondary` | Reduzir carga no primary, aceita leitura stale |
| `secondaryPreferred` | **Recomendado para ETL** — minimiza impacto |
| `nearest` | Menor latencia, qualquer no |

## Alternativas NoSQL no GCP

| Servico | Modelo | Melhor Para |
|---------|--------|-------------|
| Firestore | Documento | Apps mobile/web, < 1 TB |
| Bigtable | Wide-column | IoT, time-series, > 1 TB |
| Datastore | Entidade | Apps simples, consultas basicas |
| MongoDB Atlas | Documento | Flexibilidade total, multi-cloud |

## Decision Matrix

| Caso de Uso | Escolha |
|-------------|---------|
| Ingestao batch MongoDB para lakehouse | `ingest_mongodb_to_parquet.py` |
| Schema desconhecido/variavel | Inferencia + `sampleSize` alto |
| Schema conhecido e fixo | `--schema-json` explicito |
| Documentos profundamente aninhados | `--flatten-nested true` |
| Filtrar dados na origem | `--aggregation-pipeline` |
| Minimizar impacto no MongoDB | `readPreference=secondaryPreferred` |

## JARs Necessarios (Dataproc 2.2)

| JAR | Versao | Nota |
|-----|--------|------|
| `mongo-spark-connector_2.12` | 10.4.0 | Conector principal |
| `mongodb-driver-sync` | 5.1.0 | Driver sincrono |
| `mongodb-driver-core` | 5.1.0 | Core do driver |
| `bson` | 5.1.0 | Serializacao BSON |

## Common Pitfalls

| Nao Faca | Faca |
|----------|------|
| Usar `_2.13` JARs com Dataproc 2.2 | Usar `_2.12` para Scala 2.12 |
| Ler colecoes grandes sem filtro | Usar aggregation pipeline para filtrar |
| Inferir schema com poucos documentos | Aumentar `sampleSize` para 5000+ |
| Hardcodar credenciais no codigo | Usar Secret Manager |
| Ler do primary em horario de pico | Usar `secondaryPreferred` |

## Documentacao Relacionada

| Topico | Caminho |
|--------|---------|
| Conceitos | `concepts/` |
| Padroes | `patterns/` |
| Indice Completo | `index.md` |
