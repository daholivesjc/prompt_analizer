# Competency Questions (Questoes de Competencia)

> **Purpose**: Questoes em linguagem natural que uma ontologia deve responder, usadas como artefato de requisitos e avaliacao
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

**Competency Questions (CQs)** sao perguntas em linguagem natural que uma
ontologia deve ser capaz de responder usando seus axiomas. Propostas por
Gruninger & Fox (1995), funcionam como **especificacao de requisitos** da
ontologia — analogas a user stories no desenvolvimento agil de software. CQs
delimitam o escopo, guiam a modelagem e servem como criterio objetivo de
avaliacao: se a ontologia nao responde a CQ, falta axioma; se responde, esta
adequada para esse caso de uso.

## Papel no Ciclo de Vida da Ontologia

```text
┌─────────────────┐
│ 1. Especificar  │  → Levantar CQs com domain experts
└────────┬────────┘
         v
┌─────────────────┐
│ 2. Conceituar   │  → Mapear conceitos/relacoes mencionados nas CQs
└────────┬────────┘
         v
┌─────────────────┐
│ 3. Formalizar   │  → Codificar em OWL/DL
└────────┬────────┘
         v
┌─────────────────┐
│ 4. Avaliar      │  → Testar cada CQ via SPARQL ou reasoner
└────────┬────────┘     Falhou? Voltar a etapa 2 (iterativo)
         v
┌─────────────────┐
│ 5. Manter       │  → Adicionar CQs novas conforme dominio evolui
└─────────────────┘
```

## Tipos de CQs

| Tipo | Exemplo | Verificavel via |
|------|---------|-----------------|
| **Is-a** | "Vinho tinto e um vinho?" | Reasoner (subclass) |
| **Property value** | "Chardonnay tem cor branca?" | Reasoner (assertion) |
| **Existence** | "Quais vinhos existem?" | SPARQL SELECT |
| **Cardinality** | "Quantos paragrafos tem o artigo?" | SPARQL COUNT |
| **Temporal** | "Que normas vigiam em 2020?" | Requer extensao temporal |

## Metodo Iterativo Baseado em CQs (Malheiros & Freitas)

O sistema **CQOntoBuilder** automatiza a evolucao da ontologia via CQs:

```text
1. Usuario faz uma CQ em lingua natural
2. Sistema converte CQ para Description Logic (DL)
3. Reasoner (HermiT) tenta responder usando OWL atual
4. Se OK -> retorna resposta
5. Se NAO OK ->
   a. Sistema gera CQs auxiliares para o usuario
      (ex.: "Grama e Carne sao disjuntos?")
   b. Usuario responde -> sistema adiciona axiomas
   c. Reinicia ate responder a CQ original
```

Resultado: usuario "ensina" axiomas via dialogo natural, sem precisar conhecer
sintaxe OWL/DL.

## Exemplo Pratico

```text
Ontologia inicial:
  Herbivoro ≡ Animal ⊓ ∀eats.¬meat
  Vaca       ≡ Animal ⊓ ∀eats.grass

CQ: "Vacas sao herbivoras?" (esperado: true)

Sistema falha — nao infere Vaca ⊑ Herbivoro porque falta:
  Grass ⊓ Meat = ⊥  (sao disjuntos)

Sistema pergunta: "Grama e carne sao disjuntos?"
Usuario responde: "Sim"
Sistema adiciona axioma: Grass ⊑ ¬Meat
Agora reasoner infere: Vaca ⊑ Herbivoro -> CQ respondida.
```

## CQs como Especificacao de Escopo

CQs **delimitam o que esta dentro e fora** do dominio:

| CQ | Decisao de modelagem |
|----|----------------------|
| "Quais clientes compraram > R$ 1k em janeiro?" | Modelar Cliente, Compra, valor, data |
| "Qual a temperatura ambiente as 14h?" | Modelar Sensor, Medicao, Tempo |
| "Quem e o vovo do Joao?" | Adicionar regra transitiva grandparentOf |

CQs **fora do escopo** sinalizam dominio nao coberto — decisao consciente.

## Boas Praticas

- Coletar 20-50 CQs antes de iniciar modelagem; categorizar por tipo
- Versionar CQs no mesmo repo da ontologia; rodar como regressao em CI
- Documentar CQs FORA do escopo (evita expectativa indevida)
- Domain experts validam em linguagem natural; engenheiros codificam

## Common Mistakes

### Wrong

```text
- Iniciar modelagem antes de ter CQs (escopo difuso)
- CQs vagas: "Como funciona o cliente?" (impossivel verificar)
- Tratar CQs como FAQ estatico (deveriam evoluir)
- Validar CQs apenas manualmente em ontologias grandes
```

### Correct

```text
- CQs especificas e binarias: "Cliente Premium tem desconto > 10%?" -> SIM/NAO
- Automatizar via SPARQL ou reasoner em CI/CD
- Manter rastro: cada axioma justifica >= 1 CQ
- Revisar CQs trimestralmente com domain experts
```

## Quick Reference

| Pergunta | Tipo | Como validar |
|----------|------|--------------|
| "X e um Y?" | is-a | Reasoner subClassOf |
| "X tem propriedade Z=valor?" | property value | Reasoner ou SPARQL ASK |
| "Quais X existem?" | existence | SPARQL SELECT |
| "Quantos X cumprem Z?" | cardinality | SPARQL COUNT + filtro |

## Related

- [Modelagem de Ontologia de Dominio](../patterns/modelagem-ontologia-dominio.md)
- [SPARQL](sparql.md)
- [OWL](owl.md)

## Fontes

- Malheiros, Y., Freitas, F. (2013). **A Method to Develop Description Logic Ontologies
  Iteratively Based on Competency Questions: an Implementation**.
  In: ONTOBRAS 2013, p. 142-153. UFPE/UFPB.
- Gruninger, M., Fox, M. S. (1995). *Methodology for the Design and Evaluation of Ontologies*.
  IJCAI Workshop on Basic Ontological Issues in Knowledge Sharing.
- Uschold, M. (1996). Building Ontologies: Towards A Unified Methodology. Expert Systems.
