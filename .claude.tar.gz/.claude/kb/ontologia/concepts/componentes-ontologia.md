# Componentes de uma Ontologia

> **Purpose**: Descricao dos blocos construtivos de uma Ontologia (classes, slots, relacoes, axiomas, instancias e operacoes)
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

Toda Ontologia e composta por seis blocos basicos. Quem conhece programacao
orientada a objetos (POO) reconhecera o paralelo: conceitos sao classes, slots
sao atributos, relacoes sao associacoes e instancias sao objetos.

## Os Seis Componentes

| Componente | Analogo POO | Descricao | Exemplo |
|------------|-------------|-----------|---------|
| **Conceitos (Classes)** | Classe | Entidades genericas do dominio | `Pessoa`, `Funcionario`, `Produto` |
| **Slots (Properties)** | Atributo | Propriedades das entidades | `genero`, `dataNascimento`, `gtin` |
| **Relacoes** | Associacao | Interacoes entre conceitos (`is-a`, `has-a`) | `Funcionario is-a Pessoa` |
| **Axiomas** | Invariante | Afirmacoes sempre verdadeiras | "Pessoa e Funcionario se empregada por Empregador" |
| **Instancias** | Objeto | Representacao especifica de um conceito | `joao instance-of Funcionario` |
| **Operacoes** | Metodo | Funcoes/regras que governam os componentes | `calcularSalario()`, regras de inferencia |

## Processo de Construcao

A construcao de uma ontologia segue uma ordem natural:

1. **Definir classes** que representam entidades do mundo real
2. **Organizar em hierarquia taxonomica** (superclasse / subclasse)
3. **Definir slots e relacoes** entre as classes
4. **Preencher valores de slots e instancias** para completar o dominio
5. **Adicionar axiomas e regras** de inferencia

Exemplo (texto livre, sintaxe ilustrativa):

```text
Class: Animal
Class: Cat subClassOf Animal
  slot: nome (string)
  slot: idade (integer)
  axiom: idade >= 0
Instance: garfield instanceOf Cat
  nome = "Garfield"
  idade = 4
Relation: pertenceA(Pessoa, Cat)
```

## Quick Reference

| Termo Ontologia | Termo POO | Termo BD Relacional |
|-----------------|-----------|---------------------|
| Concept (Class) | Class | Tabela / Entidade |
| Slot (Property) | Field/Attribute | Coluna |
| Relation (is-a) | Inheritance | FK + JOIN |
| Relation (has-a) | Composition | FK |
| Instance | Object | Linha (tupla) |
| Axiom | Invariant | CHECK constraint |
| Operation | Method | Stored procedure |

## Diferenca-Chave: Ontologia nao e BD

Embora componentes se assemelhem, existem diferencas fundamentais:

- Ontologias sao **semanticamente mais ricas** que esquemas relacionais
- Representacao baseada em **texto natural semi-estruturado**, nao tabular
- Foco em **terminologia globalmente consistente** entre dominios e organizacoes
- Modelam **conhecimento generico de dominio**, nao apenas containers de dados

## Common Mistakes

### Wrong

```text
- Comecar definindo slots antes de identificar classes
- Confundir Instancia com Classe (joao e instancia de Pessoa, nao classe)
- Usar Relacoes apenas para is-a, esquecendo has-a, parte-de, depende-de, etc.
- Ignorar axiomas (regras que devem sempre ser verdadeiras)
```

### Correct

```text
1. Identificar Classes (substantivos)
2. Hierarquizar via subclassOf
3. Adicionar slots (atributos) a cada classe
4. Definir relacoes (verbos/predicados) entre classes
5. Codificar regras de negocio como axiomas
6. Validar populando instancias reais
```

## Related

- [O que e Ontologia](o-que-e-ontologia.md)
- [Propriedades de uma Ontologia](propriedades-ontologia.md)
- [OWL - Web Ontology Language](owl.md)
- [Modelagem de Ontologia de Dominio (pattern)](../patterns/modelagem-ontologia-dominio.md)

## Fontes

- `book_artificial_intelligence_for_big_data/Components of Ontologies`
- `book_artificial_intelligence_for_big_data/Advantages of Ontologies`
- `ontologia/Ontologies for lawyers (Margaret Hagan)`
