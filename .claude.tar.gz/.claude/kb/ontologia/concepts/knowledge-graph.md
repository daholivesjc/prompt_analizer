# Knowledge Graph (Grafo de Conhecimento)

> **Purpose**: Estrutura de dados em grafo que representa conhecimento de um dominio com entidades, relacoes e contexto semantico
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

Um **Knowledge Graph (KG)** e uma rede de entidades reais (pessoas, lugares,
produtos) conectadas por relacoes tipadas, frequentemente ancorada em uma
**Ontologia**. A diferenca entre buscar "strings" e buscar "things" — o salto
do Google quando lancou seu Knowledge Graph em 2012 — vem dessa estrutura.

> "Knowledge Graph e uma Ontologia muito grande que descreve formalmente
> objetos do mundo real."
> -- AI for Big Data, cap. The role Ontology plays in Big Data

## Anatomia

```text
            (Leonardo da Vinci) --[pintou]--> (Mona Lisa)
                    |                              |
                  [tipo]                         [tipo]
                    v                              v
                (Pessoa)                        (Quadro)
                                                   |
                                                [esta em]
                                                   v
                                             (Louvre) --[tipo]--> (Museu)
```

| Elemento | O que representa |
|----------|------------------|
| **No (vertice)** | Entidade do mundo real |
| **Aresta (relacao)** | Conexao tipada entre entidades |
| **Label/Tipo** | Classe da Ontologia subjacente |
| **Propriedade** | Atributo do no ou da aresta |

## Knowledge Graph vs. Outros Modelos

| Modelo | Estrutura | Forca | Fraqueza |
|--------|-----------|-------|----------|
| Tabela relacional | Linhas/colunas | Performance OLTP | Relacoes via JOIN custosas |
| Documento (NoSQL) | JSON/BSON | Flexibilidade schema | Relacoes pobres |
| Tripla RDF | (s,p,o) | Padrao W3C, semantica formal | Performance variavel |
| Property Graph | Nos com propriedades + arestas | Flexivel, performance | Nao-padronizado |
| **Knowledge Graph** | RDF ou LPG + Ontologia | Semantica + conexoes | Custo de modelagem inicial |

## Onde KGs Brilham

- **Buscadores** (Google, Bing): "things, not strings"
- **Recomendacoes** (Amazon, Netflix): conexoes entre produtos/usuarios
- **Fraude** (bancos, seguros): padroes anomalos em redes
- **Bio/Saude**: descoberta de drogas, prontuarios conectados
- **Compliance e legal**: relacoes regulatorias, ontologias juridicas (FIBO, MISLA)
- **Agentes de IA**: GraphRAG ancorado em ontologia corporativa

## Knowledge Graph + LLMs (GraphRAG)

O **GraphRAG** combina LLM com Knowledge Graph: ao receber uma pergunta, a IA
**primeiro consulta a Ontologia/KG** para entender o contexto, depois gera a
resposta. Diferenca em relacao ao RAG tradicional:

| RAG tradicional | GraphRAG |
|-----------------|----------|
| Busca por palavras-chave em chunks | Busca por padroes no grafo |
| Resposta baseada em similaridade | Resposta baseada em relacoes explicitas |
| Suscetivel a alucinacoes | Mais preciso, ancorado em ontologia |
| Difere por embedding | Difere por estrutura semantica |

## Construindo um KG (Visao Geral)

1. **Ontologia primeiro** — defina classes e relacoes do dominio
2. **Ingestao** — extraia entidades de fontes (texto, BD, APIs)
3. **Linking** — associe entidades duplicadas (ex: "Joao Silva" vs "J. Silva")
4. **Enriquecimento** — adicione contexto via fontes externas (DBpedia, Wikidata)
5. **Inferencia** — derive fatos novos via reasoner OWL ou regras
6. **Consumo** — exponha via SPARQL, Cypher ou API

## Quick Reference

| Tecnologia | Tipo | Quando usar |
|------------|------|-------------|
| **Neo4j** | Property Graph | App-driven, queries em Cypher, performance |
| **Apache Jena** | Triplestore RDF | Reasoning OWL, padrao W3C estrito |
| **Stardog** | Triplestore + reasoning | Empresarial, OWL/SPARQL |
| **AllegroGraph** | Quintuplestore | Geoespacial + temporal + grafo |
| **GraphDB (Ontotext)** | Triplestore | Reasoning RDFS+/OWL escalavel |
| **Amazon Neptune** | RDF + Property Graph | Managed AWS |

## Wrong vs. Correct

### Wrong

```text
"Vamos jogar tudo em um grafo Neo4j sem definir Ontologia primeiro."
=> Cada equipe usa labels diferentes para o mesmo conceito;
   reasoning impossivel; integracao quebra.
```

### Correct

```text
1. Definir Ontologia (OWL ou minimo schema documentado)
2. Mapear fontes para a Ontologia
3. Carregar dados respeitando o schema (n10s para Neo4j; Jena para RDF puro)
4. Validar com SPARQL/Cypher consultas tipicas do dominio
```

## Related

- [O que e Ontologia](o-que-e-ontologia.md)
- [RDF](rdf.md)
- [SPARQL](sparql.md)
- [OWL](owl.md)
- [Ontologia em Knowledge Graph Neo4j (pattern)](../patterns/ontologia-em-knowledge-graph-neo4j.md)

## Fontes

- `book_artificial_intelligence_for_big_data/The role Ontology plays in Big Data`
- `ontologia/O que e Ontologia? E por que precisamos dela na era da IA?` (GraphRAG)
- `ontologia/Ontologies and Graphs - Semantic Knowledge Graphs in Neo4j`
- `ontologia/Chapter 6 Graph Databases`
