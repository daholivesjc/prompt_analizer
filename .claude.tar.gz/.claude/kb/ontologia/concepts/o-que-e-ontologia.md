# O que e Ontologia

> **Purpose**: Definicao formal de Ontologia como representacao de conhecimento estruturada, formal, explicita e compartilhada de um dominio
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

Uma **Ontologia** e uma especificacao formal e explicita de uma conceitualizacao
compartilhada de um dominio. Em termos praticos: e um "dicionario mestre" que define
o que as coisas sao, como se relacionam e quais regras as governam, de forma que tanto
humanos quanto maquinas possam interpreta-las sem ambiguidade. E o esqueleto semantico
que transforma dados ("strings") em conhecimento ("things").

## Definicao Formal

> "A formal naming and definition of types, properties, and interrelationships of
> the entities that fundamentally exist for a particular domain."
> -- Ontology of Information Sciences (Gruber, adaptado)

> "Um conjunto de conceitos e categorias em uma area ou dominio, mostrando suas
> propriedades e os relacionamentos entre eles."
> -- AI for Big Data, cap. Ontology for Big Data

## Tres Caracteristicas Essenciais

| Caracteristica | Descricao |
|----------------|-----------|
| **Formal** | Representacao machine-readable, com sintaxe estruturada (RDF, OWL) |
| **Explicita** | Enumera entidades, relacoes e regras (nao texto em linguagem natural) |
| **Compartilhada** | Vocabulario consensuado por uma comunidade (ex: schema.org, FIBO) |

Essas tres propriedades sao o que diferenciam uma Ontologia de um simples modelo
relacional (que e formal, mas nao necessariamente compartilhado), de um glossario
(que e compartilhado mas nao formal) ou de um diagrama em quadro branco (que e
explicito mas nao machine-readable).

## Strings vs. Things (Dados vs. Conhecimento)

| Nivel | Exemplo | O que e |
|-------|---------|---------|
| Dado | `66` | String sem significado |
| Informacao | `66 F` | Mede temperatura |
| Conhecimento | `66 F em Nova York em 03/10/2017 as 20h` | Contexto + entidades + relacoes |

Ontologias adicionam o contexto que converte dado em conhecimento. Para o computador,
a informacao e string; quando enriquecida com metadados ontologicos, ela vira "thing".

## Por que Importa

- **Significado unificado**: elimina divergencias (ex: "venda" para Marketing vs. Financeiro)
- **Reuso e interoperabilidade**: sistemas heterogeneos conversam pelo vocabulario comum
- **Reducao de alucinacoes em IA**: agentes ancorados em ontologia evitam respostas inconsistentes
- **Integracao escalavel**: padroniza significado na origem, ao inves de centralizar tudo num data lake
- **"Build once, use many times"**: definicao reutilizavel entre aplicacoes

## Wrong vs. Correct

### Wrong

```text
"Vamos centralizar todos os dados em um data lake e a IA vai entender."
=> Sem semantica explicita, a IA gera respostas inconsistentes; cada area
   calcula "lucro" diferente; agentes operam no escuro.
```

### Correct

```text
"Vamos definir uma Ontologia: 'Cliente e entidade unica por CPF/CNPJ. Pedido
 vira Venda apenas apos pagamento confirmado.' Depois aplicar a Camada Semantica
 e construir Data Products."
=> IA opera sobre vocabulario consensuado; resultados consistentes; reuso entre projetos.
```

## Related

- [Componentes de uma Ontologia](componentes-ontologia.md)
- [Propriedades de uma Ontologia](propriedades-ontologia.md)
- [Ontologia vs. Taxonomia vs. Vocabulario](ontologia-vs-taxonomia-vs-vocabulario.md)
- [Ontologia em Big Data](ontologia-em-big-data.md)
- [Knowledge Graph](knowledge-graph.md)

## Fontes

- `book_artificial_intelligence_for_big_data/Ontology for Big Data`
- `book_artificial_intelligence_for_big_data/Ontology of information science`
- `ontologia/O que e Ontologia? E por que precisamos dela na era da IA?.html`
- `ontologia/The Value of Ontology - Complete Business Process Handbook`
- `ontologia/Ontologies and Graphs: Semantic Knowledge Graphs in Neo4j` (Jesus Barrasa)
