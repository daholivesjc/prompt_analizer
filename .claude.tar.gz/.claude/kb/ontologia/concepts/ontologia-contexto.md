# Ontologia de Contexto e Qualidade de Contexto (QoC)

> **Purpose**: Modelar contexto e dimensoes de qualidade de contexto (QoC) em sistemas pervasivos/IoT, com aplicacao em data quality
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

**Ontologia de Contexto** representa formalmente as informacoes que descrevem
a situacao de entidades (pessoas, lugares, dispositivos) em sistemas
sensiveis ao contexto (computacao ubiqua, IoT, mobile). Quando essas
informacoes vem de sensores ou fontes heterogeneas, surge o problema de
**Qualidade de Contexto (QoC)**: a propria informacao de contexto pode estar
incompleta, desatualizada ou imprecisa. Uma ontologia de QoC permite
quantificar essa qualidade e tomar decisoes (descartar dado, alertar,
escolher provedor alternativo).

## Definicoes

- **Contexto** (Dey 2000): qualquer informacao que caracteriza a situacao
  de entidades relevantes para a interacao usuario-aplicacao.
- **QoC** (Buchholz et al. 2003): qualquer informacao que descreve a
  qualidade da informacao usada como contexto.

## Dimensoes do Contexto (Chen & Kotz)

```text
┌─────────────┐
│  Contexto   │
└──────┬──────┘
       ├─── Computational  (CPU, rede, recursos)
       ├─── Physical       (localizacao, temperatura, ruido)
       ├─── Time           (dia, hora, estacao)
       └─── User           (perfil, social, atividade, saude)
```

## Parametros de QoC

| Parametro | Pergunta que responde |
|-----------|----------------------|
| **Up-to-dateness** (Atualidade) | A informacao esta atualizada? |
| **Coverage** (Validade) | A leitura cobre a area/periodo correto? |
| **Significance** (Significancia) | Esta informacao deve disparar alerta? |
| **Completeness** (Completude) | Faltam atributos? |
| **Precision** (Precisao) | Qual a margem de erro do sensor? |

## Estrutura da Ontologia (Nazario et al.)

```text
Thing
├── User
├── Context
│   ├── User_context  (Health, Profile, Preference, Activity)
│   ├── Computation   (Device, Network, Resource)
│   ├── Physical      (Humidity, Location, Temperature)
│   └── Time          (Day, Hour, Month, Year)
├── QoC
└── Parameter (UpToDateness, Coverage, Significance,
                Completeness, Precision)

Object Properties: hasUserContext, hasTime, hasQoC,
                   hasParameter, hasSignificance
```

## Aplicacao em Data Quality

A mesma ontologia que modela QoC em IoT pode ser **adaptada para qualidade
de dados em pipelines de ingestao** — cada batch/tabela carrega metadados:

| QoC param (IoT) | Equivalente em data engineering |
|-----------------|---------------------------------|
| Up-to-dateness | Freshness (lag entre evento e ingestao) |
| Coverage | Completude por particao/periodo |
| Significance | Alerta de DQ (anomalia detectada) |
| Completeness | % de atributos nao-nulos |
| Precision | Conformidade com schema/tipo |

Mapeamento direto para [DQV (W3C Data Quality Vocabulary)](https://www.w3.org/TR/vocab-dqv/).

## Exemplo SPARQL (deteccao de anomalia)

```sparql
SELECT ?name ?user_temp ?valueQoC ?P ?value
WHERE {
  ?user ont:hasUserContext ?temp .
  ?user ont:name ?name .
  ?temp ont:f_value ?user_temp .
  ?temp ont:hasQoC ?QoC .
  ?QoC ont:f_value ?valueQoC .
  ?QoC ont:hasParameter ?P .
  ?P ont:f_value ?value
  FILTER (?valueQoC < 0.5)
}
```

Resultado: instancias com QoC baixa -> aplicacao decide descartar, alertar
ou ativar sensor backup.

## Cenarios de Uso

| Cenario | Como QoC ajuda |
|---------|----------------|
| Smart healthcare | Descarta leitura com `precision < threshold` |
| Logistica | Alerta se `up-to-dateness` > 5 min |
| Data lake (medallion) | Quarantena registros com `completeness < 0.95` |
| ML feature store | Marca features com baixa qualidade como nao-utilizaveis |

## Common Mistakes

### Wrong

```text
- Tratar dado de sensor como sempre confiavel
- Usar so 1 dimensao de qualidade (ex.: completude) ignorando precisao/atualidade
- Computar QoC ad-hoc por aplicacao (sem ontologia compartilhada)
- Descartar QoC ao mover dado entre camadas (Landing -> Raw -> Trusted)
```

### Correct

```text
- Anexar QoC como metadado em todos os registros desde a Landing
- Usar ontologia padronizada (Nazario, DQV) para comparar qualidade entre fontes
- Aplicar reasoner para inferir significance a partir de outros parametros
- Versionar a ontologia QoC junto com o pipeline
```

## Quick Reference

| Conceito | Definicao curta |
|----------|-----------------|
| Contexto | Info que caracteriza situacao de entidade |
| QoC | Qualidade da info de contexto |
| Up-to-dateness / Coverage | Quao recente / abrangente |
| Significance / Completeness / Precision | Relevante / completa / precisa |

## Related

- [Ontologia em Big Data](ontologia-em-big-data.md)
- [Ontologia para Governanca de Dados](../patterns/ontologia-para-governanca-dados.md)
- [SPARQL](sparql.md)

## Fontes

- Nazario, D. C., Dantas, M. A. R., Todesco, J. L. (2013).
  **Ontologia de Contexto e Qualidade de Contexto**.
  In: ONTOBRAS 2013, p. 179-184. UFSC/UDESC.
- Dey, A. K. (2000). *Providing Architectural Support for Building Context-Aware Applications*.
- Buchholz, T., Kupper, A., Schiffers, M. (2003). *Quality of Context: What It Is And Why We Need It*.
- W3C. *Data Quality Vocabulary (DQV)*. https://www.w3.org/TR/vocab-dqv/
