# Ontologia vs. Taxonomia vs. Vocabulario

> **Purpose**: Diferenciar artefatos de organizacao de conhecimento ao longo do espectro de maturidade
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

Existe um espectro de maturidade entre artefatos que organizam conhecimento.
Confundir "taxonomia" com "ontologia" e um erro comum: taxonomia e apenas
hierarquia, ontologia inclui relacoes ricas e regras.

## O Espectro de Maturidade

```text
[INFORMAL] ---------------------------------------> [FORMAL]

Vocabulario  Glossario  Folksonomia  Tesauro  Taxonomia  Esquema  Ontologia
Controlado                                              Classifica  (OWL/RDF)
```

## Comparacao Detalhada

| Artefato | Estrutura | Relacoes | Inferencia | Exemplo |
|----------|-----------|----------|------------|---------|
| **Vocabulario Controlado** | Lista finita de termos | Nenhuma explicita | Nao | Lista de paises ISO |
| **Glossario** | Termos + definicoes em linguagem natural | Implicitas | Nao | Glossario de TI |
| **Folksonomia** | Tags colaborativas | Coocorrencia | Nao | Tags do Flickr/Stack Overflow |
| **Tesauro** | Termos + sinonimos/relacionados | Sinonimos, BT/NT | Nao | WordNet |
| **Taxonomia** | Hierarquia is-a (especializacao) | subClassOf | Limitada (heranca) | Reino > Filo > Classe |
| **Esquema de Classificacao** | Hierarquia estrita | subClassOf + instanceOf | Heranca de atributos | Library of Congress |
| **Ontologia (frame)** | Classes + propriedades + relacoes | Multipla | Sim, basica | Schema.org |
| **Ontologia (axiomatica)** | + axiomas + restricoes | Logica formal completa | Sim, DL | FIBO (financas) |

## Quick Reference

| Voce precisa de... | Use... |
|--------------------|--------|
| Lista padronizada de termos | Vocabulario controlado |
| Termos com definicao | Glossario |
| Organizacao colaborativa de baixo custo | Folksonomia |
| Sinonimos e termos relacionados | Tesauro |
| Hierarquia de categorias | Taxonomia |
| Vocabulario + relacoes ricas | Ontologia leve (frame) |
| Reasoning automatizado e regras formais | Ontologia OWL DL |

## Quando "subir" no Espectro

A maturacao da Ontologia e iterativa e tem custo. Suba apenas quando o caso
de uso exigir:

- **Compartilhamento com terceiros** → minimo Tesauro/Taxonomia
- **Catalogacao consistente interna** → Taxonomia
- **Integracao automatica entre sistemas** → Ontologia frame
- **Reasoning, consistencia formal, validacao automatica** → Ontologia DL (OWL)

## Erro Comum: chamar Taxonomia de "Ontologia"

Empresas frequentemente dizem "criamos a ontologia de produtos" quando
construiram uma **Taxonomia** (hierarquia de categorias). Diferenca:

```text
TAXONOMIA:
  Eletronicos
    └── Computadores
        └── Notebooks

ONTOLOGIA (mesmos dados, expressao maior):
  Class Notebook subClassOf Computer subClassOf Electronics
  ObjectProperty hasProcessor (Notebook -> Processor)
  ObjectProperty isManufacturedBy (Notebook -> Manufacturer)
  Axiom: Notebook hasProcessor exactly 1 Processor
  Axiom: Notebook disjointWith Desktop
  Inference: se notebook X hasProcessor Y, e Y isType IntelI7,
             entao X isCompatibleWith Windows11
```

## Common Mistakes

### Wrong

```text
- Pular do nada para OWL DL sem maturacao iterativa
- Considerar Taxonomia como suficiente para reasoning automatico
- Misturar Vocabulario Controlado com Ontologia (perda de governanca)
```

### Correct

```text
- Comecar pelo Glossario consensuado (linguagem natural)
- Maturar para Taxonomia quando hierarquia agregar valor
- Migrar para Ontologia quando reasoning ou integracao exigir
- Documentar maturidade atual e estrategia de evolucao
```

## Related

- [O que e Ontologia](o-que-e-ontologia.md)
- [Componentes de uma Ontologia](componentes-ontologia.md)
- [Ontology Learning](ontology-learning.md)
- [Ontologia para Governanca de Dados (pattern)](../patterns/ontologia-para-governanca-dados.md)

## Fontes

- `ontologia/The Value of Ontology - Complete Business Process Handbook`
  (esp. secao "Ontology Maturity and the Maturing Process")
- `book_artificial_intelligence_for_big_data/The role Ontology plays in Big Data`
- `ontologia/Ontologies for lawyers (Margaret Hagan)`
