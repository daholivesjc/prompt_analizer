# Ontology Alignment (Alinhamento de Ontologias)

> **Purpose**: Processo de mapear e correlacionar entidades entre ontologias heterogeneas
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

**Ontology Alignment** (ou Ontology Matching) e o processo de determinar
correspondencia um-para-um entre entidades de ontologias diferentes. Permite
inferir tipos e derivar significado de fontes heterogeneas de forma consistente
e semantica. E essencial quando duas organizacoes (ou sistemas) precisam
trocar dados mas modelaram o mesmo dominio com vocabularios distintos.

## Por que Alinhar

Cenario tipico: sua empresa tem ontologia interna `:Cliente`, parceiro tem
`schema:Customer`, regulador exige `fibo:RetailCustomer`. Sem alinhamento:

- Integracao por codigo customizado a cada parceiro
- Semantica perdida em traducoes ad-hoc
- Reasoning impossivel entre dominios

Com alinhamento:

```text
:Cliente owl:equivalentClass schema:Customer .
:Cliente rdfs:subClassOf fibo:RetailCustomer .
```

A partir dai, queries SPARQL atravessam ontologias e reasoners derivam
fatos consistentes.

## Tipos de Mapeamento

| Tipo | OWL | Significado |
|------|-----|-------------|
| Equivalencia exata | `owl:equivalentClass` / `owl:equivalentProperty` | A == B |
| Hierarquica | `rdfs:subClassOf` | A e subtipo de B |
| Sinonimia de instancia | `owl:sameAs` | x1 == x2 (mesma entidade) |
| Diferenca de instancia | `owl:differentFrom` | x1 != x2 |
| Disjuncao | `owl:disjointWith` | A e B nunca compartilham instancias |
| Inversa | `owl:inverseOf` | propA e inversa de propB |

## Estrategias de Alinhamento

| Estrategia | Como funciona |
|------------|---------------|
| **String matching** | Compara nomes (Cliente ~ Customer) — baseline rapido |
| **Estrutural** | Compara hierarquias e propriedades |
| **Semantico** | Usa thesaurus/wordnets para sinonimos |
| **Logico** | Aplica reasoner para derivar equivalencias (OWL DL) |
| **Machine Learning** | Aprende mapeamentos por exemplos (volume grande) |
| **Crowdsourced** | Especialistas validam (dominio critico — saude, financas) |

## Ferramentas

- **AgreementMaker** — alinhamento manual + automatico, OWL
- **LogMap** — focado em escalabilidade e logica
- **AML (AgreementMakerLight)** — biomedicina, OAEI
- **PROMPT / Anchor-PROMPT** — Protege plugin
- **Karma** — modelagem semantica de fontes (Web)
- **FOAM (Framework for Ontology Alignment and Mapping)** — usado no OntoAlign++

## OntoAlign++ (Estrategia Combinada)

**OntoAlign++** (Carvalho et al., UFRJ/UFF, 2013) combina **duas estrategias
complementares** antes do matcher FOAM:

1. **Enriquecimento lexico** (Carvalho 2011) — usa NLP (GATE, NLTK) para
   extrair termos/relacoes implicitas das *definicoes textuais*, enriquecendo
   a ontologia com conhecimento "escondido" em comentarios.
2. **Extensao top-level** (Silva 2011) — associa os 3 niveis superiores da
   ontologia de dominio a uma fundacional (BFO), evitando matches espurios
   entre conceitos com mesmo nome mas naturezas ontologicas distintas.

Resultado experimental (BPO vs INOH biomedicas): **49 alinhamentos corretos
combinando** vs 37 sem estrategia; relacoes fracas caem de 7 para 1. As
estrategias sao **complementares**, nao redundantes.

## Workflow Tipico

```text
1. Carregar ontologia A e B
2. Aplicar matchers automaticos (string, estrutural, logico)
3. Reviewer humano valida candidatos com confianca baixa
4. Gerar arquivo de alinhamento (formato EDOAL ou triplas OWL)
5. Aplicar alinhamento como "ponte" entre ontologias
6. Reasoner usa o alinhamento para inferencia cross-ontology
```

## Desafios

- **Heterogeneidade real**: dois conceitos com mesmo nome podem ter semantica diferente
- **Granularidade**: classe ampla em A vs. varias classes especificas em B
- **Evolucao**: ontologias mudam; alinhamento precisa ser mantido
- **Confianca**: como validar que o mapeamento esta correto?

## Quick Reference

| Cenario | Solucao |
|---------|---------|
| Empresa adota schema.org publico | Alinhar ontologia interna -> schema.org via equivalentClass |
| Fusao de empresas com 2 ERPs | Alinhar 2 ontologias de produto, gerar visao unificada |
| Ingestao de dados de varios fornecedores | Alinhar cada fornecedor a ontologia canonica |
| Federacao de KGs publicos (DBpedia + Wikidata) | sameAs entre URIs equivalentes |

## Common Mistakes

### Wrong

```text
- Mapear apenas por nome de classe (false positives garantidos)
- Ignorar contexto/dominio das ontologias (Cliente em banking != Cliente em retail)
- Considerar alinhamento como projeto unico (nao e: e continuo)
```

### Correct

```text
- Combinar string + estrutural + revisao humana
- Documentar premissas de cada mapeamento (notas, scores de confianca)
- Versionar alinhamentos junto com as ontologias
- Validar via queries cross-ontology esperadas
```

## Related

- [O que e Ontologia](o-que-e-ontologia.md)
- [OWL](owl.md)
- [Ontology Learning](ontology-learning.md)
- [Ontologia em Big Data](ontologia-em-big-data.md)

## Fontes

- `book_artificial_intelligence_for_big_data/Ontology alignment`
- `ontologia/The Value of Ontology - Complete Business Process Handbook`
  (secao sobre semantic mappings)
- Carvalho, M. G. P., Campos, M. L. M., Campos, L. M. M., Cavalcanti, M. C. (2013).
  **OntoAlign++: a Combined Strategy for Improving Ontologies Alignment**.
  In: ONTOBRAS 2013, p. 221-226. UFRJ/UFF/IME.
