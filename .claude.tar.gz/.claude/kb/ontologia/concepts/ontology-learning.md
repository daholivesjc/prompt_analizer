# Ontology Learning (Aprendizado de Ontologias)

> **Purpose**: Geracao automatizada de Ontologias a partir de texto, dados ligados ou outras fontes
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

**Ontology Learning** automatiza a criacao de Ontologias usando algoritmos
sobre fontes em escala (texto na internet, RDF publicado, ontologias
existentes). Atende ao gargalo manual de modelagem ontologica, que e custoso,
exige especialistas e nao escala para todos os dominios.

## Abordagens

| Abordagem | Como funciona | Quando aplicar |
|-----------|---------------|----------------|
| **Ontology learning from text** | NLP extrai keywords, classifica por co-ocorrencia, padroes e sequencias | Grande corpus textual (artigos, manuais, paginas web) |
| **Linked Data Mining** | Identifica padroes em grafos RDF publicados; deriva ontologias por raciocinio implicito | Dominios com Linked Open Data (LOD) maduro |
| **Concept Learning from OWL** | Aproveita ontologias existentes para expandir novos dominios algoritmicamente | Existe ontologia parcial e quer-se enriquecer |
| **Crowdsourcing** | Combina extracao automatica + validacao por especialistas humanos | Dominio critico, exige precisao |
| **LLM-assisted** | LLMs propoem classes/relacoes a partir de descricoes; humanos validam | Acelerador moderno (2024+) |

## Pipeline Tipico (de texto)

```text
1. Coleta de corpus
   └── PDFs, HTMLs, transcricoes, manuais

2. Pre-processamento
   └── Tokenizacao, lematizacao, POS-tagging

3. Extracao de termos candidatos
   └── Frequencia, TF-IDF, n-grams

4. Identificacao de relacoes
   └── Padroes Hearst ("X is a Y"), dependency parsing

5. Construcao da hierarquia
   └── Clustering de termos, agrupamento por sinonimia

6. Formalizacao
   └── Mapeamento para OWL/RDF (Protege, n10s)

7. Validacao por especialistas
   └── Refinamento iterativo
```

## Methontology (metodologia classica)

Desenvolvida pelo Laboratorio de IA da Universidade Politecnica de Madrid
(1997), **Methontology** e uma metodologia para padronizar criacao de
ontologias em estagios:

1. **Especificacao** — proposito, escopo, granularidade
2. **Conceitualizacao** — modelo conceitual em linguagem nativa
3. **Formalizacao** — passa para representacao semi-formal
4. **Implementacao** — codifica em OWL/RDF (ferramenta Protege)
5. **Manutencao** — versionamento e evolucao

Methontology e referencia em projetos ontologicos academicos e em sistemas
juridicos como **MISLA** e **OntoFake/OntoJuris**.

## Desafios

| Desafio | Detalhe |
|---------|---------|
| **Heterogeneidade de fontes** | Forma e representacao variam (HTML, PDF, BD); extracao consistente e dificil |
| **Incerteza e baixa precisao** | Inconsistencia das fontes leva a baixa acuracia; exige humano para validar |
| **Escalabilidade** | Internet cresce constantemente; processamento distribuido (Hadoop/Spark) ajuda |
| **Pos-processamento** | Saida automatica precisa revisao para qualidade — nao e 100% automatico |

## Ferramentas

| Ferramenta | Capacidade |
|------------|-----------|
| **Protege** | Editor visual de ontologias; integra reasoners |
| **Text2Onto** | Aprendizado de ontologia a partir de texto |
| **OntoLearn** | Pipeline NLP -> ontologia |
| **NeOn Toolkit** | Editor + reasoning |
| **WebProtege** | Versao colaborativa cloud |
| **LLM-based (Neo4j MCP, etc.)** | Geracao assistida por GPT/Claude |

## Quick Reference

| Voce tem... | Faca... |
|-------------|---------|
| Corpus textual grande | Ontology learning from text + NLP |
| Dataset RDF publico | Linked data mining |
| Ontologia parcial existente | Concept learning expansivo |
| Dominio critico (saude) | Crowdsourcing + revisao especialista |
| Equipe pequena, acelerar prototipagem | LLM-assisted + Protege |

## Common Mistakes

### Wrong

```text
- Confiar 100% em saida automatizada sem revisao especialista
- Ignorar "data drift" (corpus muda mas ontologia fica congelada)
- Aplicar uma unica abordagem sem combinar tecnicas
```

### Correct

```text
- Combinar abordagens (texto + LOD + crowdsourcing)
- Iterar com especialistas em ciclos curtos (Methontology)
- Versionar a ontologia (semver) e documentar evolucao
- Avaliar com metricas de cobertura, precisao e consistencia
```

## Related

- [O que e Ontologia](o-que-e-ontologia.md)
- [Componentes de uma Ontologia](componentes-ontologia.md)
- [Ontology Alignment](ontology-alignment.md)
- [Modelagem de Ontologia de Dominio (pattern)](../patterns/modelagem-ontologia-dominio.md)

## Fontes

- `book_artificial_intelligence_for_big_data/Ontology learning`
- `21571-1081-17512-1-10-20220905.pdf` (OntoFake/OntoJuris + Methontology)
- `18267-949-14739-1-10-20211207.pdf` (MISLA — sistema jurídico)
