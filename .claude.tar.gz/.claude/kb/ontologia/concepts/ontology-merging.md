# Ontology Merging (Fusao de Ontologias)

> **Purpose**: Combinar duas ou mais ontologias em uma unica, resolvendo inconsistencias e incoerencias logicas
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

**Ontology Merging** une dois ou mais corpos de conhecimento em uma unica
ontologia consolidada. Diferente do alignment (que mantem ontologias separadas
ligadas por mapeamentos), o merging produz uma terceira ontologia composta.
Esse processo herda problemas classicos de Belief Revision: a uniao pode
gerar inconsistencias (axiomas contraditorios) ou incoerencias (classes
insatisfaziveis), exigindo operadores formais para restaurar consistencia
preservando o maximo de informacao possivel.

## Alignment vs. Merging

| Dimensao | Alignment | Merging |
|----------|-----------|---------|
| Resultado | Mapeamentos (pontes) | Nova ontologia unificada |
| Ontologias originais | Permanecem separadas | Sao consumidas (uniao + revisao) |
| Custo computacional | Baixo | Alto (precisa resolver conflitos) |
| Reasoning | Federado (lento) | Local (rapido) |
| Quando usar | Federacao temporaria | Consolidacao permanente |

## Kernel Contraction

Tecnica formal (Hansson 1999) usada para **remover axiomas minimos** que causam
inconsistencia, preservando o restante. Conceitos centrais:

- **Kernel** (`B ⊥ α`): conjunto de subconjuntos minimos de `B` que implicam `α`
- **Incision function** (`σ`): seleciona ao menos um axioma de cada kernel para remover
- **Kernel contraction**: `B -σ α = B \ σ(B ⊥ α)`

Para merging, usa-se uma variante: encontram-se os subconjuntos minimamente
inconsistentes (MIPS — Minimal Incoherence Preserving Sub-ontologies) ou
TBoxes (MUPS) e aplica-se uma funcao de incisao para "cortar" o conflito.

## Fases do Merging (Cobe & Wassermann)

```text
┌────────────────────┐
│  1. Kernel Building│  Identifica sub-ontologias minimas inconsistentes
└─────────┬──────────┘
          v
┌────────────────────┐
│  2. Stratification │  Ordena axiomas por prioridade (frequencia,
└─────────┬──────────┘  especificidade, relevancia semantica)
          v
┌────────────────────┐
│  3. Axiom Weakening│  Modifica axioma para reduzir restricao (ex.: ≤1P → ≤3P)
└─────────┬──────────┘
          v
┌────────────────────┐
│  4. Axiom Removal  │  Ultimo recurso — remove axioma de menor prioridade
└────────────────────┘
```

## Estrategias de Stratification

| Estrategia | Criterio | Quando usar |
|------------|----------|-------------|
| **Frequency-based** | Axiomas que aparecem em mais kernels | Maximizar reuso |
| **Specific-first** | Preserva axiomas mais especificos | Manter detalhe semantico |
| **General-first** | Preserva axiomas mais gerais | Conservar abstracoes |
| **Semantic relevance** | Mede entailments perdidos/ganhos | Minimizar impacto inferencial |

## Quando Aplicar

| Cenario | Recomendacao |
|---------|--------------|
| Fusao de empresas com 2 ontologias de produto | Merging (resultado permanente) |
| Federacao temporaria de KGs publicos | Alignment (sameAs, sem merge) |
| Adocao de vocabulario padrao + ontologia interna | Alignment + import OWL |
| Consolidacao de modulos ontologicos do mesmo time | Merging com axiom weakening |
| Importacao de ontologia externa nao confiavel | Alignment primeiro; merge so apos validacao |

## Common Mistakes

### Wrong

```text
- Fazer uniao "naive" das ontologias e ignorar inconsistencias
- Remover axiomas a esmo ate parar de quebrar reasoner
- Tratar inconsistencia (ABox) como se fosse incoerencia (TBox)
```

### Correct

```text
- Identificar formalmente os kernels antes de qualquer remocao
- Usar axiom weakening antes de remocao completa (preserva informacao)
- Versionar a ontologia merged separadamente das originais
- Documentar quais axiomas foram alterados/removidos e por que
```

## Ferramentas

- **BContractor** (USP) — framework Java extensivel para Belief Change com suporte a OWL/SROIQ
- **Protege Revision Plug-in** (Ribeiro & Wassermann) — UI para revisao em DL
- **HermiT / Pellet** — reasoners usados na fase de validacao

## Quick Reference

| Conceito | Significado |
|----------|-------------|
| Inconsistency | ABox contraditorio (instancia viola axiomas) |
| Incoherence | TBox contem classe insatisfaziavel (concept C com interpretacao vazia) |
| Kernel | Subconjunto minimo conflitante |
| Incision | Funcao que escolhe o que cortar |
| Weakening | Relaxar restricao (≤ 1 → ≤ N) em vez de remover |

## Related

- [Ontology Alignment](ontology-alignment.md)
- [OWL](owl.md)
- [Componentes de Ontologia](componentes-ontologia.md)

## Fontes

- Cóbe, R., Resina, F., Wassermann, R. (2013). **Merging Ontologies via Kernel Contraction**.
  In: VI Seminar on Ontology Research in Brazil (ONTOBRAS 2013), p. 94-105.
  Universidade de Sao Paulo (USP/IME).
- Hansson, S. O. (1999). *A Textbook of Belief Dynamics*. Kluwer.
- Alchourron, Gardenfors, Makinson (1985). On the logic of theory change. AGM paradigm.
