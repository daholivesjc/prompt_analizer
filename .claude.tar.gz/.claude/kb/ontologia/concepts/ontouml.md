# OntoUML

> **Purpose**: Linguagem de modelagem conceitual ontologicamente bem-fundamentada (perfil UML baseado em UFO)
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

**OntoUML** e um perfil da UML proposto por Giancarlo Guizzardi (2005) baseado
na **Unified Foundational Ontology (UFO)**. Diferente de UML padrao (que e
apenas sintatico), OntoUML carrega meta-propriedades ontologicas (principio de
identidade, rigidez, dependencia existencial) que permitem distinguir tipos de
classes do mundo real e validar a qualidade do modelo. E usado na fase de
**modelagem conceitual** da engenharia de ontologias, antes da transformacao
para OWL ou outras linguagens computacionais.

## UFO em Resumo

UFO classifica entidades em duas grandes categorias:

```text
┌─────────────────────────────────────────────────────┐
│                      Thing                          │
│   ┌──────────────────┐   ┌──────────────────────┐   │
│   │  Object Class    │   │   Moment Class       │   │
│   │  (substancial)   │   │ (existencialmente    │   │
│   │                  │   │  dependente)         │   │
│   └──────┬───────────┘   └────────┬─────────────┘   │
│          │                        │                 │
│   ┌──────┴───────┐         ┌──────┴────────┐        │
│   │ Sortal Class │         │  Mode/Relator │        │
│   │ (com identi- │         │  (qualidade,  │        │
│   │  dade unica) │         │   relacional) │        │
│   └──────┬───────┘         └───────────────┘        │
│          │                                          │
│   ┌──────┴───────┐                                  │
│   │  Mixin Class │  (agrega tipos com identidades   │
│   │              │   diferentes — ex: Animal)       │
│   └──────────────┘                                  │
└─────────────────────────────────────────────────────┘
```

## Estereotipos Principais

| Estereotipo | Categoria | Caracteristica | Exemplo |
|-------------|-----------|----------------|---------|
| **Kind** | Sortal rigido | Provem principio de identidade | Pessoa, TV, Carro |
| **Subkind** | Sortal rigido | Especializacao rigida de Kind | Homem, LED TV |
| **Phase** | Sortal anti-rigido | Fase contingente (muda com tempo) | Crianca, Adulto |
| **Role** | Sortal anti-rigido | Papel que entidade desempenha em relacao | Estudante, Motorista |
| **Category** | Mixin rigido | Agrega rigid types com identidades distintas | Animal (humano + cavalo) |
| **RoleMixin** | Mixin anti-rigido | Papel agregando entidades de tipos diferentes | Cliente |
| **Relator** | Moment relacional | Materializa relacao entre objetos | Casamento, Licenca |
| **Mode** | Moment intrinseco | Qualidade que depende de um portador | Dor de cabeca |
| **Quantity** | Substancial nao-atomico | Materia mensuravel | Agua, Areia |
| **Collective** | Substancial coletivo | Conjunto uniforme | Floresta, Time |

## Meta-Propriedades

| Propriedade | Significado | Aplicacao |
|-------------|-------------|-----------|
| **Identity Principle** | Define como instancias sao individuadas | Sortals sempre tem; Mixins agregam diferentes |
| **Rigidity** | Classe e parte essencial da identidade da instancia? | Pessoa e rigid; Estudante e anti-rigid |
| **Dependency** | Existencia de A requer existencia de B? | Casamento depende de 2 pessoas |
| **isCovering** / **isDisjoint** | Generalizations completas/disjuntas | Pessoa = Homem + Mulher |

## Transformacao OntoUML -> OWL/SWRL

A transformacao **OntoUML2OWL+SWRL** (Barcelos et al. 2013) implementa MDA
(Model Driven Architecture):

```text
OntoUML (CIM)  ─── transformacao ──→  OWL + SWRL (PIM)  ──→  Codigo (PSM)
   ↑                                       ↓
Modelagem                             Reasoning
conceitual                            computacional
```

Mapeamentos chave:

- Classes OntoUML -> classes OWL (sem estereotipos no resultado)
- Substance Sortals disjuntos entre si (Kind A disjoint Kind B)
- Generalizations isDisjoint -> `owl:disjointWith` entre filhas
- Generalizations isCovering -> classe pai equivalente a uniao das filhas
- Associacoes -> object properties + propriedade inversa
- Material relations (derivadas de Relator) -> regras SWRL
- Part-whole (componentOf, memberOf, subQuantityOf, subCollectionOf) -> sub-object properties + transitividade via SWRL
- DataTypes -> data properties

Limitacoes:
- `isEssential` / `isInseparable` (dependencia existencial) nao representavel em OWL
- Cardinalidade `0..*` nao tratada (assumida em OWL por default)

## Ferramentas

- **OLED (OntoUML Lightweight Editor)** — editor + validacao + transformacao
- **Sparx Enterprise Architect / Astah** — modelagem profissional, exporta XMI
- **MOVE (OntoUML Model Validation Environment)** — anti-pattern detection + Alloy simulation
- **Protege 4.x+** — visualizacao do OWL gerado

## Quando Usar OntoUML

- Engenharia de ontologias de **referencia** (vs lightweight)
- Dominios complexos (saude, juridico, telecom, oil & gas)
- Quando rastreabilidade ontologica e exigida (compliance, governanca)
- Antes de gerar OWL — para evitar anti-patterns semanticos

## Common Mistakes

### Wrong

```text
- Usar UML padrao para "ontologia" — sem semantica formal
- Omitir estereotipos (Kind, Role, etc.) — perde validacao
- Confundir Role com Subkind (ambos especializam, mas Role e anti-rigid)
- Modelar Dependency Existencial sem Relator
```

### Correct

```text
- Sempre usar estereotipos OntoUML em todas as classes
- Validar com OLED antes de exportar para OWL
- Usar Relator para materializar relacoes complexas (Casamento, Contrato)
- Documentar identity principle em cada Kind
```

## Related

- [OWL](owl.md)
- [Componentes de Ontologia](componentes-ontologia.md)
- [Ontologia vs. Taxonomia vs. Vocabulario](ontologia-vs-taxonomia-vs-vocabulario.md)

## Fontes

- Barcelos, P. P. F., Santos, V. A., Silva, F. B., Monteiro, M. E., Garcia, A. S. (2013).
  **An Automated Transformation from OntoUML to OWL and SWRL**.
  In: ONTOBRAS 2013, p. 130-141. UFES/IFES.
- Guizzardi, G. (2005). *Ontological Foundations for Structural Conceptual Models*.
  University of Twente (PhD thesis introducing UFO and OntoUML).
- Guizzardi, G. (2007). On Ontology, ontologies, Conceptualizations, Modeling Languages and (Meta)Models.
