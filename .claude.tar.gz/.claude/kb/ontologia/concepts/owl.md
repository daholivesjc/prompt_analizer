# OWL - Web Ontology Language

> **Purpose**: Linguagem W3C para autoria de Ontologias com semantica formal e logica de descricao
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

OWL (Web Ontology Language) e a familia de linguagens W3C para autoria de
Ontologias. Estende RDF/RDFS adicionando semantica formal, suporte a
inferencia automatica e logica de descricao (Description Logic). Foi desenhada
para que sistemas inteligentes possam **raciocinar** sobre conhecimento
estruturado, nao apenas armazena-lo.

> Curiosidade: OWL nao e acronimo real. O grupo de trabalho rejeitou "WOL" e
> escolheu OWL pela pronuncia e pela associacao com sabedoria (coruja).

## Por que OWL e nao apenas RDFS

RDFS nao consegue:

- Cardinalidade (one-to-one, one-to-many)
- Ranges localizados de atributos
- Relacoes transitivas, inversas, simetricas
- Logica de inferencia complexa
- Restricoes de existencia/inexistencia

OWL resolve cada limitacao com vocabulario adicional e semantica formal.

## Tres Especies de OWL

| Especie | Foco | Caracteristica |
|---------|------|----------------|
| **OWL Lite** | Taxonomia simples | Cardinalidade 0..1; baixa expressividade, alta performance |
| **OWL DL** | Description Logic | Maxima expressividade com decidibilidade; reasoning algoritmico |
| **OWL Full** | Compativel RDFS | Maximo poder, mas software nao consegue raciocinar completamente |

OWL DL e o sweet spot para a maioria dos casos: rico o suficiente para modelar
conhecimento real, formal o bastante para reasoners decidirem inferencias.

## Construcoes Principais

### Definicao de Classes

```xml
<owl:Class rdf:ID="PlayGround"/>

<owl:Class rdf:ID="FootballGround">
  <rdfs:subClassOf rdf:resource="#PlayGround"/>
</owl:Class>
```

### Relacionamentos entre Classes

| Construcao | Significado | Exemplo |
|------------|-------------|---------|
| `equivalentClass` | Classes sinonimas (entre ontologias/dominios) | `PrivatelyHeldCompany equivalent ClosedCorporation` |
| `disjointWith` | Instancia de uma classe nao pode ser de outra | `FootballGround disjoint HockeyGround` |
| `subClassOf` | Hierarquia de generalizacao | `Cat subClassOf Animal` |
| `unionOf` | Classe contem coisas de varias classes | `Vehicle unionOf (Car, Truck, Bike)` |
| `intersectionOf` | Coisas em ambas as classes | `WorkingMother intersectionOf (Worker, Mother)` |
| `complementOf` | Coisas que NAO sao de outra classe | `NonHuman complementOf Human` |

### Propriedades

```turtle
:hasParent a owl:ObjectProperty ;
           rdfs:domain :Person ;
           rdfs:range :Person ;
           a owl:TransitiveProperty .   # se A hasParent B e B hasParent C => A hasAncestor C

:hasFather a owl:FunctionalProperty .   # cada Person tem no maximo 1 pai
:isMarriedTo a owl:SymmetricProperty .  # se A casado-com B, entao B casado-com A
:hasChild owl:inverseOf :hasParent .
```

## Inferencia (Reasoning)

A grande forca do OWL e a capacidade de **derivar fatos novos** a partir dos
declarados. Exemplo: se ontologia define `loan subClassOf financialProduct`
e voce consulta "todos os financialProducts", o reasoner retorna os loans
**mesmo sem fato explicito** ligando-os.

Reasoners populares:

- **Pellet** / **Openllet** — OWL 2 completo
- **HermiT** — OWL 2, focado em performance
- **RacerPro** — comercial
- **FaCT++** — academico

## Limitacoes Praticas

- Reasoning em ontologias muito grandes (milhoes de triplas) pode ser custoso
- OWL Full e indecidivel: software nao consegue garantir inferencia completa
- Bancos de grafos (Neo4j) **nao sao reasoners DL** nativos — armazenam grafos
  decorados com semantica OWL, nao executam inferencia DL completa

## Quick Reference

| Quando voce precisa de... | Use... |
|---------------------------|--------|
| Apenas vocabulario controlado | RDFS |
| Hierarquia + cardinalidade simples | OWL Lite |
| Inferencia + restricoes complexas | OWL DL |
| Maxima expressividade (sem reasoning) | OWL Full |
| Reasoning OWL completo em producao | Apache Jena + Pellet/HermiT |
| Armazenar e consultar grafo | Neo4j + Neosemantics (n10s) |

## Related

- [RDF](rdf.md)
- [SPARQL](sparql.md)
- [Componentes de uma Ontologia](componentes-ontologia.md)
- [Ontologia em Knowledge Graph Neo4j (pattern)](../patterns/ontologia-em-knowledge-graph-neo4j.md)

## Fontes

- `book_artificial_intelligence_for_big_data/Using OWL, the Web Ontology Language`
- `ontologia/Neo4j encontra OWL - graficos, semantica e a lacuna de raciocinio`
- `ontologia/Ontologies and Graphs - Semantic Knowledge Graphs in Neo4j`
