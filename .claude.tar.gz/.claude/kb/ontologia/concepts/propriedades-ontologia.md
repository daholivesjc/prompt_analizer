# Propriedades de uma Ontologia

> **Purpose**: Caracteristicas de qualidade que uma Ontologia bem-projetada deve apresentar
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

Uma Ontologia bem-projetada precisa atender a um conjunto de propriedades
qualitativas para servir como representacao confiavel de conhecimento. Sem
essas propriedades, a Ontologia falha em entregar interoperabilidade,
reutilizacao e raciocinio automatizado.

## As Seis Propriedades Essenciais

| Propriedade | Significado | O que evita |
|-------------|-------------|-------------|
| **Completa** | Cobre todos os aspectos relevantes das entidades do dominio | Lacunas semanticas, dados orfaos |
| **Inequivoca** | Cada termo tem interpretacao unica | Confusao entre humanos e softwares |
| **Consistente** | Adere a terminologia formal estabelecida do dominio | Conflito com normas tecnicas (ex: medicina) |
| **Generica** | Reusavel em diferentes contextos e aplicacoes | Re-trabalho a cada novo projeto |
| **Extensivel** | Permite adicionar novos conceitos sem quebrar os existentes | Engessamento, retrabalho de migracao |
| **Machine-readable e Interoperavel** | Formato padronizado consumivel por software | Silos, traducoes ad-hoc |

## Beneficios Resultantes

Quando uma Ontologia atende essas propriedades, ela viabiliza:

- **Loose coupling + tight integration**: conceitos sao independentes de
  linguagem de programacao, plataforma e protocolo de comunicacao, mas se
  integram fortemente entre si
- **Reuso de conhecimento como modulos**: software reaproveita base de
  conhecimento sem reescrever logica
- **Estudo de conceitos independente da implementacao**: domain experts
  podem trabalhar sem saber programar
- **Reducao de erros de IA**: agentes ancorados em ontologia evitam
  alucinacoes e mantem respostas consistentes

## Sinais de Qualidade

| Indicador | O que verificar |
|-----------|-----------------|
| Cobertura | Toda entidade do dominio tem classe correspondente? |
| Ambiguidade | Termos sinonimos foram declarados via `equivalentClass`? |
| Conflito | Definicoes batem com o vocabulario oficial do dominio? |
| Reuso | A ontologia ja foi adotada em outro projeto sem mudancas? |
| Extensibilidade | Adicionar uma nova subclasse exige mudar classes existentes? |
| Interoperabilidade | Outras ferramentas conseguem ler o arquivo (RDF/OWL)? |

## Common Mistakes

### Wrong

```text
- Criar Ontologia "para sempre" sem prever extensibilidade
- Usar terminologia interna que conflita com padrao publico (ex: schema.org, FIBO)
- Documentar so em PDF/Word (nao machine-readable)
- Definir os mesmos conceitos com nomes diferentes em projetos da mesma empresa
```

### Correct

```text
- Adotar/estender vocabulario publico (schema.org, FIBO, GS1) quando aplicavel
- Publicar a ontologia em RDF/OWL/Turtle para consumo por agentes
- Usar equivalentClass para mapear sinonimos
- Versionar a ontologia (semver) e documentar breaking changes
- Validar com domain experts: "uma instancia desta classe pode existir? como?"
```

## Related

- [O que e Ontologia](o-que-e-ontologia.md)
- [Componentes de uma Ontologia](componentes-ontologia.md)
- [OWL - Web Ontology Language](owl.md)
- [Ontology Alignment](ontology-alignment.md)

## Fontes

- `book_artificial_intelligence_for_big_data/Ontology properties`
- `book_artificial_intelligence_for_big_data/Advantages of Ontologies`
- `ontologia/The Value of Ontology - Complete Business Process Handbook`
