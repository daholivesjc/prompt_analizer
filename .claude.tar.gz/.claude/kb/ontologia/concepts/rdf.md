# RDF - Resource Description Framework

> **Purpose**: Padrao W3C para descricao de recursos via triplas Sujeito-Predicado-Objeto
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

RDF (Resource Description Framework) e o framework universal para representar
ontologias e dados semanticos. Recomendacao W3C desde 2004, RDF descreve
recursos identificados por URIs em forma de **triplas**
(Sujeito, Predicado, Objeto). Um conjunto de triplas forma um **grafo RDF**.

## A Tripla RDF

```text
        Sujeito              Predicado              Objeto
   ┌─────────────┐    ┌──────────────────┐    ┌──────────────┐
   │ {1: Hit     │ -- │ {Author}         │ -> │ {Satya       │
   │  Refresh}   │    │                  │    │  Nadella}    │
   └─────────────┘    └──────────────────┘    └──────────────┘
   (Entity Name)      (Attribute Name)        (Attribute Value)
```

| Posicao | Papel | Tipo |
|---------|-------|------|
| Sujeito | Entidade descrita | URI |
| Predicado | Atributo / Relacao | URI |
| Objeto | Valor | URI ou literal |

## URIs vs URLs

- **URL** = endereco web (mapeado a IP)
- **URI** = identificador universal (pode ou nao ser uma pagina real)

URIs **nao podem** representar tanto recurso web quanto entidade do mundo real
ao mesmo tempo. Devem ser exclusivos para um ou outro.

## Sintaxes Comuns

### RDF/XML

```xml
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
         xmlns:book="http://example.org/book#">
  <rdf:Description rdf:about="http://example.org/book/1">
    <book:author>Satya Nadella</book:author>
    <book:company>Microsoft</book:company>
    <book:year>2017</book:year>
  </rdf:Description>
</rdf:RDF>
```

### Turtle (recomendado)

```turtle
@prefix book: <http://example.org/book#> .

book:1 book:Title   "Hit Refresh" ;
       book:Author  "Satya Nadella" ;
       book:Company "Microsoft" ;
       book:Year    "2017" .

book:2 book:Title   "Shoe Dog" ;
       book:Author  "Phil Knight" ;
       book:Company "Nike" ;
       book:Year    "2016" .
```

Turtle e a sintaxe mais legivel — compativel com SPARQL e amplamente preferida.

## Mapeamento Tabela Relacional -> RDF

| Tabela | RDF |
|--------|-----|
| Linha (PK) | Sujeito |
| Coluna | Predicado |
| Valor da celula | Objeto |

Toda tabela relacional pode ser representada como triplas RDF.

## Limitacoes do RDF/RDFS

RDFS (RDF Schema) adiciona estrutura basica (`rdfs:Class`, `rdfs:subClassOf`,
`rdfs:domain`, `rdfs:range`) mas nao consegue:

- Definir cardinalidade (one-to-one, one-to-many)
- Restringir ranges localizados de atributos
- Expressar relacoes transitivas, inversas, simetricas
- Logica de inferencia complexa (existencia/inexistencia de relacoes)

Para essas necessidades existe **OWL**.

## Quick Reference

| Conceito | Sintaxe Turtle | Significado |
|----------|----------------|-------------|
| Prefixo | `@prefix ex: <http://...> .` | Namespace abreviado |
| Tripla | `:s :p :o .` | Fato basico |
| Multiplos predicados | `:s :p1 :o1 ; :p2 :o2 .` | Mesmo sujeito |
| Multiplos objetos | `:s :p :o1 , :o2 .` | Mesma relacao |
| Literal tipado | `"42"^^xsd:integer` | Valor com tipo |
| Comentario | `# texto` | Linha de comentario |

## Validacao

W3C oferece validador online: <https://www.w3.org/RDF/Validator/> — verifica
sintaxe e gera visualizacao tabular/grafica de um documento RDF.

## Related

- [OWL - Web Ontology Language](owl.md)
- [SPARQL - Linguagem de Consulta](sparql.md)
- [Knowledge Graph](knowledge-graph.md)
- [Triplas RDF em Spark/GraphFrames (pattern)](../patterns/triplas-rdf-em-spark-graphframes.md)

## Fontes

- `book_artificial_intelligence_for_big_data/RDF - the universal data format`
- `book_artificial_intelligence_for_big_data/SPARQL query language`
- `ontologia/Chapter 6 Graph Databases`
