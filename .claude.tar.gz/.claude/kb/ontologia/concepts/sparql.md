# SPARQL - SPARQL Protocol and RDF Query Language

> **Purpose**: Linguagem padrao W3C para consultar grafos RDF, equivalente semantico do SQL para o mundo de triplas
> **Confidence**: 0.90
> **MCP Validated**: 2026-04-17

## Overview

SPARQL e o padrao W3C para consultas em grafos RDF. Acronimo recursivo de
"SPARQL Protocol and RDF Query Language", foi desenhada com foco em
**interoperabilidade**: permite que qualquer agente consulte qualquer
endpoint RDF sem precisar conhecer o esquema interno do triplestore.

## Sintaxe Basica

```sparql
PREFIX book: <http://www.example.org/book#>

SELECT ?books
WHERE {
    ?books book:year "2017" .
}
```

Resultado:

```text
?books
book:1
```

Multiplas triplas no `WHERE` formam um padrao composto:

```sparql
PREFIX book: <http://www.example.org/book#>

SELECT ?books ?bookName ?company
WHERE {
    ?books book:year  "2017"     .
    ?books book:title ?bookName  .
    ?books book:company ?company .
}
```

Resultado:

```text
?books   ?bookName    ?company
book:1   Hit Refresh  Microsoft
```

## Tipos de Consulta

| Tipo | Proposito | Equivalente SQL |
|------|-----------|-----------------|
| `SELECT` | Retorna conjunto de variaveis | `SELECT` |
| `CONSTRUCT` | Constroi novo grafo RDF | `INSERT INTO ... SELECT` |
| `ASK` | Retorna boolean (existe?) | `EXISTS` |
| `DESCRIBE` | Retorna grafo RDF descrevendo recurso | -- |
| `INSERT DATA` | Adiciona triplas | `INSERT` |
| `DELETE DATA` | Remove triplas | `DELETE` |

## Padroes Comuns

### Filtros

```sparql
SELECT ?book ?year
WHERE {
    ?book book:year ?year .
    FILTER(?year > "2015")
}
ORDER BY DESC(?year)
LIMIT 10
```

### OPTIONAL (LEFT JOIN) e UNION

```sparql
SELECT ?person ?email
WHERE {
    ?person a foaf:Person .
    OPTIONAL { ?person foaf:mbox ?email }
}

# UNION
SELECT ?title WHERE {
    { ?x book:title ?title } UNION { ?x movie:title ?title }
}
```

## Endpoints SPARQL Publicos

| Endpoint | Conteudo |
|----------|----------|
| `dbpedia.org/sparql` | DBpedia (Wikipedia estruturada) |
| `query.wikidata.org/sparql` | Wikidata |
| `linkeddata.uriburner.com/sparql` | LOD Cloud |

## Comparacao SPARQL vs SQL vs Cypher

| Aspecto | SPARQL | SQL | Cypher (Neo4j) |
|---------|--------|-----|----------------|
| Modelo | Grafo (triplas) | Tabular | Grafo (LPG) |
| Padronizacao | W3C | ANSI | Proprietario (openCypher emergente) |
| Federacao | Nativa (`SERVICE`) | Limitada | Limitada |
| Reasoning | Sim (com OWL) | Nao | Limitado |
| Projeto | `SELECT ?var` | `SELECT col` | `RETURN var` |

## Quick Reference

| Operador | Uso |
|----------|-----|
| `?var` | Variavel a ser ligada |
| `.` | Termina tripla |
| `;` | Mesmo sujeito, novo predicado |
| `,` | Mesmo sujeito + predicado, novo objeto |
| `a` | Atalho para `rdf:type` |
| `FILTER` | Restringe valores |
| `OPTIONAL` | Padrao opcional (left join) |
| `UNION` | Combina padroes alternativos |

## Common Mistakes

```sparql
# Wrong: URI completa repetida em toda tripla
SELECT ?b WHERE { ?b <http://www.example.org/book#year> "2017" . }

# Correct: usar PREFIX
PREFIX book: <http://www.example.org/book#>
SELECT ?b WHERE { ?b book:year "2017" . }
```

## Related

- [RDF](rdf.md)
- [OWL](owl.md)
- [Knowledge Graph](knowledge-graph.md)

## Fontes

- `book_artificial_intelligence_for_big_data/SPARQL query language`
- `book_artificial_intelligence_for_big_data/Building intelligent machines with Ontologies`
- `ontologia/Chapter 6 Graph Databases`
