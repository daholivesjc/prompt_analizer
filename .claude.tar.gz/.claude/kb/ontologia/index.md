# Ontologia Knowledge Base

> **Purpose**: Ontologias para Big Data, Semantic Web, Knowledge Graphs e engenharia de dados — RDF, OWL, SPARQL e aplicacao em arquitetura medallion (lakehouse GCP)
> **MCP Validated**: 2026-04-17

## Quick Navigation

### Concepts

| Arquivo | Proposito |
|---------|-----------|
| [concepts/o-que-e-ontologia.md](concepts/o-que-e-ontologia.md) | Definicao formal, strings vs things |
| [concepts/componentes-ontologia.md](concepts/componentes-ontologia.md) | Conceitos, slots, relacoes, axiomas, instancias |
| [concepts/propriedades-ontologia.md](concepts/propriedades-ontologia.md) | Completa, inequivoca, consistente, extensivel |
| [concepts/rdf.md](concepts/rdf.md) | RDF, triplas e Turtle |
| [concepts/owl.md](concepts/owl.md) | OWL: Lite, DL, Full, reasoning |
| [concepts/sparql.md](concepts/sparql.md) | Linguagem de consulta de grafos RDF |
| [concepts/knowledge-graph.md](concepts/knowledge-graph.md) | KG, GraphRAG, comparativo de tecnologias |
| [concepts/ontologia-vs-taxonomia-vs-vocabulario.md](concepts/ontologia-vs-taxonomia-vs-vocabulario.md) | Espectro de maturidade |
| [concepts/ontology-alignment.md](concepts/ontology-alignment.md) | Mapeamento entre ontologias (inclui OntoAlign++) |
| [concepts/ontology-merging.md](concepts/ontology-merging.md) | Fusao via kernel contraction (Belief Revision) |
| [concepts/ontology-learning.md](concepts/ontology-learning.md) | Geracao via NLP, LOD, methontology, LLM |
| [concepts/ontouml.md](concepts/ontouml.md) | Perfil UML fundamentado em UFO; transformacao OWL+SWRL |
| [concepts/competency-questions.md](concepts/competency-questions.md) | Questoes de competencia como requisitos de ontologia |
| [concepts/ontologia-contexto.md](concepts/ontologia-contexto.md) | Contexto + QoC para data quality em IoT/lakehouse |
| [concepts/ontologia-em-big-data.md](concepts/ontologia-em-big-data.md) | Papel em pipelines de dados |

### Patterns

| Arquivo | Proposito |
|---------|-----------|
| [patterns/modelagem-ontologia-dominio.md](patterns/modelagem-ontologia-dominio.md) | Methontology aplicada: especificacao -> formalizacao -> manutencao |
| [patterns/ontologia-em-knowledge-graph-neo4j.md](patterns/ontologia-em-knowledge-graph-neo4j.md) | Neo4j + Neosemantics (n10s) com limites de reasoning OWL |
| [patterns/integracao-ontologia-data-lakehouse.md](patterns/integracao-ontologia-data-lakehouse.md) | Conexao com medallion GCP (Landing -> Raw -> Trusted -> Refined) |
| [patterns/triplas-rdf-em-spark-graphframes.md](patterns/triplas-rdf-em-spark-graphframes.md) | Processamento RDF em escala via Apache Spark |
| [patterns/ontologia-para-governanca-dados.md](patterns/ontologia-para-governanca-dados.md) | PROV-O, DQV, SHACL, DCAT como ancora de governance |

### Specs (Machine-Readable)

| Arquivo | Proposito |
|---------|-----------|
| [specs/exemplo-ontologia-dominio.yaml](specs/exemplo-ontologia-dominio.yaml) | Ontologia exemplo de Cliente-Produto-Pedido + SHACL + governanca |

---

## Quick Reference

- [quick-reference.md](quick-reference.md) - Tabelas de consulta rapida

---

## Trilha de Aprendizado

| Nivel | Arquivos |
|-------|----------|
| **Iniciante** | o-que-e-ontologia, ontologia-vs-taxonomia-vs-vocabulario, componentes-ontologia |
| **Intermediario** | rdf, sparql, owl, knowledge-graph, propriedades-ontologia, competency-questions |
| **Avancado** | ontology-alignment, ontology-merging, ontouml, ontology-learning, ontologia-contexto, ontologia-em-big-data |
| **Aplicacao** | modelagem-ontologia-dominio, ontologia-em-knowledge-graph-neo4j, integracao-ontologia-data-lakehouse |
| **Governanca** | ontologia-para-governanca-dados, triplas-rdf-em-spark-graphframes |

---

## Uso por Agentes

| Agente | Arquivos Primarios |
|--------|---------------------|
| Data Architect | integracao-ontologia-data-lakehouse, specs/ |
| Data Engineer | triplas-rdf-em-spark-graphframes |
| Data Modeler | modelagem-ontologia-dominio, ontouml, concepts/* |
| Data Steward | ontologia-para-governanca-dados |

---

## Casos Brasileiros (ONTOBRAS 2013)

| Caso | Aplicacao | Arquivo na KB |
|------|-----------|---------------|
| Ontocloud (USP) | Integracao de dados clinicos via ontologia | patterns/integracao-ontologia-data-lakehouse.md |
| OntoAlign++ (UFRJ/UFF) | Alinhamento combinado de ontologias | concepts/ontology-alignment.md |
| Ontology Merging (USP) | Fusao via kernel contraction | concepts/ontology-merging.md |
| OntoUML2OWL+SWRL (UFES) | Transformacao MDA OntoUML -> OWL | concepts/ontouml.md |
| CQOntoBuilder (UFPE/UFPB) | Construcao iterativa via competency questions | concepts/competency-questions.md |
| QoC Ontology (UFSC/UDESC) | Qualidade de contexto em ubiquos | concepts/ontologia-contexto.md |
| Atos Normativos (UFES) | Modelo de referencia para normas juridicas | patterns/ontologia-para-governanca-dados.md |
| Rede de Pesquisadores (UFSC) | Analise de rede social da comunidade brasileira | (contexto) |

> Fonte: Bax, Almeida & Wassermann (Eds.), VI Seminar on Ontology Research in Brazil — ONTOBRAS 2013, UFMG, Belo Horizonte. 226p.

## Referencias Cruzadas

| KB Relacionada | Conexao |
|----------------|---------|
| [modelagem-dimensional](../modelagem-dimensional/index.md) | Star schema vs ontologia |
| [gs1-varejo](../gs1-varejo/index.md) | GTIN/GLN como natural keys |
| [gcp-data-architecture](../gcp-data-architecture/index.md) | Lakehouse + camada semantica |
| [dataproc](../dataproc/index.md) | Spark para RDF/GraphFrames |
| [mongodb-nosql](../mongodb-nosql/index.md) | Fontes NoSQL para KG |
