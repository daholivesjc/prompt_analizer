# Integracao Ontologia + Data Lakehouse (Medallion GCP)

> **Purpose**: Conectar a Ontologia corporativa as camadas Landing/Raw/Trusted/Refined do projeto fdm-dados (Dataproc Serverless + GCS + Delta Lake)
> **MCP Validated**: 2026-04-17

## When to Use

- Projeto adota arquitetura medallion (lakehouse) e quer adicionar camada semantica
- Multiplas fontes (TXT, JSON, XML, Excel, Avro, Postgres, MongoDB) precisam de vocabulario unificado
- Quer-se publicar Knowledge Graph corporativo a partir de dados Trusted/Refined
- Compliance/governanca exige rastreabilidade entre dados fisicos e conceitos de negocio
- Agente de IA (GraphRAG) consultara dados curados via ontologia

## Mapeamento Medallion -> Camadas Semanticas

```text
┌──────────────┐   ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│   LANDING    │   │     RAW      │   │   TRUSTED    │   │   REFINED    │
│  (raw files) │ → │  (Parquet)   │ → │ (Delta Lake) │ → │  (KG/marts)  │
└──────────────┘   └──────────────┘   └──────────────┘   └──────────────┘
   strings           + metadata          + tipos canon.      = things
                     _source_file        + chaves natur.     (RDF/LPG)
                     _ingestion_ts       + ontologia link     ontologia
                                                              completa
```

## Implementation

### 1. Anotar Schema Spark com URIs Ontologicos

```python
# jobs/raw/ingest_json_to_parquet.py (extensao conceitual)
from pyspark.sql.types import StructType, StructField, StringType, DecimalType

# Schema "anotado" com URIs ontologicos via metadados
schema = StructType([
    StructField("gtin", StringType(),
                metadata={"ontology_uri": "https://gs1.org/voc/gtin"}),
    StructField("nome_produto", StringType(),
                metadata={"ontology_uri": "http://schema.org/name"}),
    StructField("preco_unitario", DecimalType(10, 2),
                metadata={"ontology_uri": "http://schema.org/price"}),
])
```

### 2. Coluna de Linhagem Semantica na Camada Raw

```python
# Adicionar URI da classe Ontologica como metadado de linhagem
df_raw = (df_raw
    .withColumn("_source_file", F.lit(source_file))
    .withColumn("_ingestion_timestamp", F.current_timestamp())
    .withColumn("_ontology_class",
                F.lit("http://empresa.com/ontologia/produto#Produto"))
)
```

### 3. Validacao Semantica na Camada Trusted (Delta MERGE)

```python
# jobs/raw/produto_parquet_to_delta.py (conceitual)
from delta.tables import DeltaTable

# Antes do MERGE: validar conformidade com ontologia
df_validated = df_raw.filter(
    # GTIN deve ter 13 ou 14 digitos (axioma da ontologia)
    F.length(F.col("gtin")).isin([13, 14]) &
    F.col("nome_produto").isNotNull() &
    (F.col("preco_unitario") > 0)
)

# Quarentena para registros invalidos
df_quarantine = df_raw.subtract(df_validated)
df_quarantine.write.mode("append").parquet("gs://bucket/quarantine/produto/")
```

### 4. Exportar Trusted para Knowledge Graph

```python
# jobs/refined/export_produto_para_kg.py
import pyspark.sql.functions as F

# Carregar Delta trusted
df = spark.read.format("delta").load("gs://bucket/trusted/produto/")

# Construir triplas Turtle
triples = df.select(
    F.concat(F.lit(":produto-"), F.col("gtin")).alias("subject"),
    F.lit("a").alias("p1"), F.lit(":Produto").alias("o1"),
    F.lit(";gs1:gtin").alias("p2"), F.col("gtin").alias("o2"),
    F.lit(";schema:name").alias("p3"), F.col("nome_produto").alias("o3"),
)

# Gerar arquivo Turtle e enviar para triplestore (Jena Fuseki / GraphDB)
triples.coalesce(1).write.mode("overwrite").text("gs://bucket/refined/kg/produto.ttl")
```

### 5. Catalog Integration (Data Catalog GCP)

```yaml
# Tag template: associar tabela Delta a classe Ontologica
display_name: "Ontologia Empresarial"
fields:
  ontology_class:   { type: STRING }
  ontology_version: { type: STRING }
  data_steward:     { type: STRING }
tag:
  ontology_class: "http://empresa.com/ontologia/produto#Produto"
  ontology_version: "1.2.0"
  data_steward: "data-team@empresa.com"
```

## Caso pratico: Ontocloud (USP / A.C. Camargo Cancer Center)

**Ontocloud** (Patrao, Brentani, Finger, Wassermann, 2013) e um sistema de
integracao dinamica de bases clinicas usando ontologia como camada de
mediacao. A arquitetura ilustra um padrao replicavel para lakehouses:

```text
Source DBs (EHR, Pathology, Image, Prescriptions)
     │
     ▼ D2R-Server (SQL → SPARQL endpoint por fonte)
     │
     ▼ Federation Ontology (lista quais conceitos cada fonte expoe)
     │
     ▼ Query Federator (adiciona SERVICE clauses na SPARQL)
     │
     ▼ Query Expansion (Mediation/EDOAL — substitui derived → base concepts)
     │
     ▼ Inference Ontology (regras tipo Smoker ⊓ Female → IncreasedRiskBC)
     │
     ▼ Global Ontology (visao unificada para o usuario)
```

Quatro ontologias compoem a solucao: **global** (visao publica), **federation**
(quem expoe o que), **mapping** (tabela/coluna → conceito) e **inference**
(regras de derivacao). Vantagens vs ETL tradicional: dados sempre
atualizados (acesso dinamico), inferencia separada do codigo de integracao
(domain experts mantem regras), tolerancia a *semantic mismatch* (ontologia
unifica granularidades — ex.: "smoker" vs "packs/day"). Trade-off: SPARQL
com agregacao/datas e mais lento que SQL nativo.

> **Tecnica auxiliar de ingestao:** Correa et al. (2013) propoem **NECOW**,
> ferramenta que extrai instancias de portais Web semi-estruturados via
> analise navegacional/estrutural guiada por ontologia, gerando triplas RDF
> para popular um portal semantico. Util como camada de ingestao alternativa
> a APIs/databases formais.

## Configuration

| Configuracao | Recomendacao | Onde |
|--------------|--------------|------|
| URI ontologia | `https://ontologia.empresa.com/v1/{dominio}#` | URL estavel + versionada |
| Coluna linhagem | `_ontology_class` em todas as tabelas Trusted | Padrao |
| Triplestore alvo | Apache Jena Fuseki ou GraphDB Free (POC) / Stardog (prod) | Decidir por reasoning |
| Catalog | Google Data Catalog ou DataHub | Visibilidade |
| Validacao | SHACL shapes versionadas no repo | CI/CD |

## Anti-Patterns

| Wrong | Correct |
|-------|---------|
| Carregar Knowledge Graph direto da Landing | Sempre via Trusted (dados confiaveis) |
| Hardcode URIs na ingestao | Usar variavel de ambiente / arquivo config |
| Reasoner OWL no caminho critico (latencia) | Reasoning offline; Trusted ja contem inferencias |
| Ontologia tratada como "doc tecnico" do TI | Ontologia e DNA do negocio; envolve dominio + dados + IA |
| Esquecer LGPD ao publicar como RDF aberto | Anonimizar/hashar PII antes de exportar para KG |

## See Also

- [Modelagem de Ontologia de Dominio](modelagem-ontologia-dominio.md)
- [Triplas RDF em Spark/GraphFrames](triplas-rdf-em-spark-graphframes.md)
- [Ontologia para Governanca de Dados](ontologia-para-governanca-dados.md)
- [Ontologia em Big Data](../concepts/ontologia-em-big-data.md)
- KB irmas: [`gcp-data-architecture`](../../gcp-data-architecture/index.md), [`modelagem-dimensional`](../../modelagem-dimensional/index.md)

## Fontes

- `book_artificial_intelligence_for_big_data/The role Ontology plays in Big Data`
- `book_artificial_intelligence_for_big_data/Goals of Ontology in big data`
- `ontologia/O que e Ontologia? E por que precisamos dela na era da IA?`
- `CLAUDE.md` (arquitetura medallion fdm-dados)
- Patrao, D. F. C., Brentani, H., Finger, M., Wassermann, R. (2013).
  **Ontocloud — a Clinical Information Ontology Based Data Integration System**.
  ONTOBRAS 2013, p. 118-129. USP / A.C. Camargo Cancer Center.
- Correa, D. A., Moura, A. M. C., Cavalcanti, M. C. (2013). **A Navigational and
  Structural Approach for Extracting Contents from Web Portals**. ONTOBRAS 2013,
  p. 23-34. IME / LNCC.
