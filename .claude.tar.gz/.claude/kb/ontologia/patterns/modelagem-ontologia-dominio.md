# Modelagem de Ontologia de Dominio

> **Purpose**: Processo iterativo para construir uma Ontologia de dominio com qualidade, alinhamento de negocio e suporte a reasoning
> **MCP Validated**: 2026-04-17

## When to Use

- Projeto de KG corporativo (cliente, produto, supply chain) precisa de um vocabulario consensuado
- Empresa adota Data Mesh / Data Products e precisa de "linguagem comum"
- Multiplos sistemas modelam o mesmo dominio com termos divergentes
- Agente de IA / GraphRAG precisa de ancoragem semantica
- Compliance exige rastreabilidade conceitual (saude, financas, juridico)

## Implementation

### Fase 1 — Especificacao (Methontology)

```text
1. Definir proposito da Ontologia (caso de uso de negocio)
2. Definir escopo (subdominio: ex. Produto, nao "tudo")
3. Listar competency questions (perguntas que a Ontologia deve responder)
4. Identificar fontes de conhecimento (especialistas, documentos, BD)
5. Avaliar reuso (schema.org? FIBO? GS1? GoodRelations?)
```

### Fase 2 — Conceitualizacao

```text
1. Brainstorm de termos (post-its / Mural / Miro)
2. Classificar termos: Classes (substantivos), Properties (verbos)
3. Construir hierarquia (subClassOf)
4. Mapear relacoes entre Classes (ObjectProperties)
5. Definir DataProperties (atributos com valor literal)
6. Identificar instancias canonicas para validacao
```

### Fase 3 — Formalizacao em OWL

```turtle
@prefix : <http://empresa.com/ontologia/produto#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix gs1: <https://gs1.org/voc/> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .

:Produto a owl:Class ;
    rdfs:label "Produto"@pt ;
    rdfs:comment "Item comercializado pela empresa"@pt .

:ProdutoPerecivel a owl:Class ;
    rdfs:subClassOf :Produto ;
    rdfs:label "Produto Perecivel"@pt .

:gtin a owl:DatatypeProperty ;
    rdfs:domain :Produto ;
    rdfs:range xsd:string ;
    owl:equivalentProperty gs1:gtin ;
    rdfs:comment "Codigo GTIN-13/14 do produto"@pt .

:pertenceACategoria a owl:ObjectProperty ;
    rdfs:domain :Produto ;
    rdfs:range :Categoria .

:Produto rdfs:subClassOf [
    a owl:Restriction ;
    owl:onProperty :gtin ;
    owl:cardinality 1
] .
```

### Fase 4 — Validacao

```text
1. Carregar em Protege e rodar reasoner (HermiT)
2. Verificar consistencia (sem inferencias contraditorias)
3. Validar competency questions com SPARQL
4. Apresentar a especialistas de dominio (revisao iterativa)
5. Testar com instancias reais (carga de exemplo)
```

### Fase 5 — Manutencao

```text
1. Versionar (semver: 1.0.0 -> 1.1.0 (compativel) | 2.0.0 (breaking))
2. Documentar changelog
3. Publicar em URI estavel (ex: ontologia.empresa.com/produto/v1)
4. Notificar consumidores em breaking changes
5. Manter alinhamentos com ontologias publicas atualizados
```

## Configuration

| Configuracao | Recomendacao | Razao |
|--------------|--------------|-------|
| Editor | Protege Desktop ou WebProtege | Padrao de mercado |
| Reasoner | HermiT (geral) ou Pellet (OWL 2 completo) | Inferencia |
| Repositorio | Git + URI versionada | Rastreabilidade |
| Sintaxe canonica | Turtle | Legibilidade humana |
| Validacao | SHACL ou ShEx | Integridade de instancias |
| Naming | PascalCase para Classes, camelCase para Properties | Convencao W3C |
| Idioma rdfs:label | `@pt` + `@en` | Internacionalizacao |

## Example Usage

```sparql
# Competency question: "quais produtos perceciveis tem GTIN comecando com 789?"
PREFIX : <http://empresa.com/ontologia/produto#>
SELECT ?p ?gtin
WHERE {
    ?p a :ProdutoPerecivel ;
       :gtin ?gtin .
    FILTER(STRSTARTS(?gtin, "789"))
}
```

## Anti-Patterns

| Wrong | Correct |
|-------|---------|
| Modelar ontologia de "toda a empresa" de uma vez | Comecar por 1 dominio (Cliente OU Produto OU Pedido) |
| Inventar URIs internos sem alinhamento publico | Buscar reuso (schema.org, FIBO, GS1) primeiro |
| Pular reasoner check | Sempre rodar HermiT/Pellet antes de publicar |
| Sem versionamento | Aplicar semver e changelog |
| Modelar sem competency questions | Sempre escrever as perguntas que a ontologia DEVE responder |
| Ignorar especialistas de dominio | Validacao continua com negocio |

## See Also

- [Ontologia em Knowledge Graph Neo4j](ontologia-em-knowledge-graph-neo4j.md)
- [Integracao Ontologia + Data Lakehouse](integracao-ontologia-data-lakehouse.md)
- [Ontologia para Governanca de Dados](ontologia-para-governanca-dados.md)
- [O que e Ontologia](../concepts/o-que-e-ontologia.md)
- [Componentes de uma Ontologia](../concepts/componentes-ontologia.md)
- [OWL](../concepts/owl.md)

## Fontes

- `21571-1081-17512-1-10-20220905.pdf` (Methontology)
- `book_artificial_intelligence_for_big_data/Components of Ontologies`
- `ontologia/Ontologies for lawyers (Margaret Hagan)` — abordagem user-centered
- `ontologia/The Value of Ontology - Complete Business Process Handbook`
