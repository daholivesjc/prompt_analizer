# Ontologia em Knowledge Graph Neo4j

> **Purpose**: Usar ontologias OWL/RDF dentro do Neo4j combinando performance de property graph com semantica via Neosemantics (n10s)
> **MCP Validated**: 2026-04-17

## When to Use

- Ja existe Knowledge Graph em Neo4j e quer-se importar/exportar ontologias OWL
- Precisa expor dados Neo4j como RDF para sistemas externos
- Quer ancorar agentes de IA (GraphRAG) em vocabulario controlado
- Inferencia leve (RDFS subClassOf, domain/range) e suficiente
- Performance de queries grafo importa mais que reasoning DL completo

## Limites Importantes

> Neo4j nao e reasoner OWL DL nativo. Armazena grafos **decorados** com
> semantica OWL, mas nao executa inferencia DL completa (sem `owl:sameAs`,
> `owl:inverseOf`, `owl:disjointWith`, restricoes de cardinalidade complexas).

Para reasoning OWL DL completo, use **Apache Jena + Pellet/HermiT** offline
e exporte triplas inferidas para o Neo4j para consultas rapidas.

## Implementation

### 1. Instalar Neosemantics (n10s)

```cypher
// No Neo4j Browser ou cypher-shell
CALL dbms.procedures() YIELD name WHERE name STARTS WITH 'n10s' RETURN name;

// Configurar n10s (uma vez por database)
CALL n10s.graphconfig.init({
    handleVocabUris: 'IGNORE',
    handleMultival: 'ARRAY',
    keepLangTag: true,
    keepCustomDataTypes: true
});
```

### 2. Importar Ontologia OWL

```cypher
// Importar ontologia de URI publica
CALL n10s.onto.import.fetch(
    "http://www.example.org/ontologia/produto.owl",
    "Turtle"
);

// Verificar classes importadas
MATCH (c:Class) RETURN c.name LIMIT 10;

// Hierarquia de subclasses
MATCH (sub:Class)-[:SCO]->(super:Class)
RETURN sub.name, super.name;
```

### 3. Mapear Dados Existentes para Ontologia

```cypher
// Definir mapping de label local -> classe OWL
CALL n10s.nsprefixes.add('schema', 'http://schema.org/');

CALL n10s.mapping.add('http://schema.org/Product', 'Produto');
CALL n10s.mapping.add('http://schema.org/name', 'nome');
CALL n10s.mapping.add('http://schema.org/gtin', 'gtin');

// Conectar grafo local a ontologia
MATCH (p:Produto), (c:Class {uri: 'http://schema.org/Product'})
MERGE (p)-[:rdf__type]->(c);
```

### 4. Exportar para RDF

```cypher
// Exportar Produto como RDF/Turtle
CALL n10s.rdf.export.spo(null, 'gtin', '7891000000000', false)
YIELD subject, predicate, object
RETURN subject, predicate, object;

// Endpoint HTTP para exportacao continua
// GET /rdf/neo4j/cypher?cypher=MATCH(n:Produto) RETURN n
// Accept: text/turtle
```

### 5. Inferencia Basica RDFS

```cypher
// "Quais sao todos os Produtos (incluindo subtipos como ProdutoPerecivel)?"
MATCH (p)-[:rdf__type]->(c:Class)-[:SCO*0..]->(super:Class {name: 'Produto'})
RETURN p;

// Equivale ao SPARQL:
// SELECT ?p WHERE { ?p a/rdfs:subClassOf* :Produto }
```

## Arquitetura Recomendada (Hibrida)

```text
                    ┌────────────────────────────┐
                    │  Apache Jena + Pellet       │
                    │  (Reasoning OWL DL)         │
                    └─────────────┬──────────────┘
                                  │ triplas inferidas (Turtle)
                                  v
   ┌────────────┐         ┌──────────────────┐         ┌─────────────┐
   │ Ontologia  │ ----->  │  Neo4j + n10s    │ <-----  │  Aplicacao  │
   │ OWL (.ttl) │  carga  │  (KG operacional) │ Cypher  │  + GraphRAG │
   └────────────┘         └──────────────────┘         └─────────────┘
                                  ^
                                  │ ETL ingestao (CSV, JSON, Parquet)
                                  │
                          ┌───────┴──────┐
                          │ Lakehouse    │
                          │ (Delta/raw)  │
                          └──────────────┘
```

## Configuration

| Setting | Default | Recomendado | Razao |
|---------|---------|-------------|-------|
| `handleVocabUris` | `SHORTEN` | `IGNORE` | Mais leve para apps ja existentes |
| `handleMultival` | `OVERWRITE` | `ARRAY` | Preservar listas RDF |
| `keepLangTag` | `false` | `true` | Multi-idioma (`@pt`, `@en`) |
| `applyNeo4jNaming` | `false` | `true` | Compatibilidade com Cypher |
| Plano Neo4j | Community | Enterprise + APOC + n10s | Producao |

## Comparacao: Caminhos de Implementacao

| Caminho | Stack | Quando |
|---------|-------|--------|
| **Gratuito (experimental)** | Neo4j + n10s + Jena | POC, prototipos, R&D |
| **Pago (producao)** | Neo4j + GraphAware Hume | Reasoning + governanca + UI |
| **Cloud-native** | Amazon Neptune (RDF + LPG) | Eliminar ops |
| **Triplestore puro** | Stardog ou GraphDB | Reasoning OWL DL completo, sem LPG |

## Anti-Patterns

| Wrong | Correct |
|-------|---------|
| Esperar reasoning OWL DL completo do Neo4j | Use Jena/Pellet para reasoning, Neo4j para queries |
| Misturar nodes de instancia com nodes de schema | Separe labels (`:Produto` vs `:Class`) |
| Importar ontologia gigante de uma vez | Importe modular, por subdominio |
| Esquecer de configurar `n10s.graphconfig.init` | Sempre configure antes do primeiro import |

## See Also

- [Modelagem de Ontologia de Dominio](modelagem-ontologia-dominio.md)
- [Integracao Ontologia + Data Lakehouse](integracao-ontologia-data-lakehouse.md)
- [OWL](../concepts/owl.md)
- [Knowledge Graph](../concepts/knowledge-graph.md)
- [SPARQL](../concepts/sparql.md)

## Fontes

- `ontologia/Ontologies and Graphs - Semantic Knowledge Graphs in Neo4j`
  (Jesus Barrasa)
- `ontologia/Neo4j encontra OWL - graficos, semantica e a lacuna de raciocinio`
- `ontologia/Chapter 6 Graph Databases`
