# Ontologia para Governanca de Dados

> **Purpose**: Usar Ontologia como ancora para Data Governance — catalogo, linhagem, qualidade, propriedade e compliance — em arquitetura moderna de dados
> **MCP Validated**: 2026-04-17

## When to Use

- Catalogo de dados existe mas e "lista plana" sem semantica
- Multiplas equipes calculam mesma metrica de formas diferentes (ex: "lucro")
- Compliance (LGPD/GDPR) exige rastreabilidade de PII com base em conceitos
- Data Mesh exige contratos de dados (data contracts) entre dominios
- Agentes de IA precisam de "fonte unica da verdade" semantica
- Auditoria pergunta: "o que e Cliente neste relatorio?"

## Architectural View

```text
┌────────────────────────────────────────────────────────┐
│           Ontologia Corporativa (OWL/RDF)              │
│  Cliente, Produto, Pedido, Funcionario, Localizacao   │
└──────────────────────────┬─────────────────────────────┘
                           │
       ┌───────────────────┼───────────────────┐
       │                   │                   │
       v                   v                   v
┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│  Catalogo    │   │ Linhagem     │   │ Qualidade    │
│  (Data       │   │ (PROV-O)     │   │ (DQV +       │
│   Catalog)   │   │              │   │  SHACL)      │
└──────────────┘   └──────────────┘   └──────────────┘
       │                   │                   │
       └───────────────────┼───────────────────┘
                           v
                  ┌────────────────┐
                  │  Camada        │
                  │  Semantica     │
                  │  (metricas)    │
                  └────────────────┘
                           │
                  ┌────────┴───────┐
                  │  Data Products │
                  │  (consumo)     │
                  └────────────────┘
```

## Implementation

### 1. Roles + Vocabulario de Governanca (PROV-O + DQV)

```turtle
@prefix : <http://empresa.com/governanca#> .
@prefix prov: <http://www.w3.org/ns/prov#> .
@prefix dqv: <http://www.w3.org/ns/dqv#> .

:DataSteward      a prov:Role .  # Qualidade/definicao do dominio
:DataOwner        a prov:Role .  # Responsavel ultimo
:OntologyEngineer a prov:Role .  # Mantem a ontologia corporativa
```

### 2. Linhagem Semantica (PROV-O)

```turtle
:tabela_dim_cliente_v3 a prov:Entity ;
    prov:wasDerivedFrom :tabela_dim_cliente_v2 ;
    prov:wasGeneratedBy :pipeline_2026_04_17 ;
    :ontologyClass <http://empresa.com/ontologia/cliente#Cliente> ;
    :ontologyVersion "1.2.0" .

:pipeline_2026_04_17 a prov:Activity ;
    prov:startedAtTime "2026-04-17T03:00:00Z"^^xsd:dateTime ;
    prov:wasAssociatedWith :data_engineer_joao .
```

### 3. Qualidade (DQV) ancorada em axiomas

```turtle
:dimensao_completude    a dqv:Dimension .
:metrica_cli_completude a dqv:Metric ; dqv:inDimension :dimensao_completude .
:medicao_2026_04_17     a dqv:QualityMeasurement ;
    dqv:isMeasurementOf :metrica_cli_completude ;
    dqv:value "0.987"^^xsd:decimal ;
    dqv:computedOn :tabela_dim_cliente_v3 .
```

### 4. SHACL Shapes para validacao

```turtle
:ClienteShape a sh:NodeShape ; sh:targetClass :Cliente ;
    sh:property [ sh:path :cpf ; sh:pattern "^\\d{11}$" ;
                  sh:minCount 1 ; sh:maxCount 1 ;
                  sh:message "CPF de Cliente PF deve ter 11 digitos"@pt ] ;
    sh:property [ sh:path :email ; sh:pattern "^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]+$" ] .
```

### 5. Catalog Tag Template (GCP Data Catalog)

```yaml
display_name: "Ontologia Empresarial"
fields:
  ontology_class:   { type: STRING }
  ontology_version: { type: STRING }
  data_steward:     { type: STRING }
  pii_level:        { type: ENUM, values: [NONE, INTERNAL, RESTRICTED, CONFIDENTIAL] }
  retention_policy: { type: STRING }
```

## LGPD/GDPR via Ontologia

```turtle
:cpf a owl:DatatypeProperty ;
    rdfs:domain :Cliente ;
    :piiLevel :CONFIDENTIAL ;
    :anonymizationStrategy "SHA-256" ;
    :retentionDays 1825 .  # 5 anos
# Reasoner aplica politica LGPD a todos os atributos de Cliente
```

## Atos Normativos (UFES — modelo de referencia)

Para governanca de dados em **dominios juridicos/regulatorios**, Barcelos,
Guizzardi & Garcia (2013) propoem uma **ontologia de referencia para Atos
Normativos brasileiros (NAs)** baseada na Constituicao Federal e no Manual de
Redacao da Presidencia. Modelada em **OntoUML** (perfil UML fundamentado em
UFO), divide-se em 3 subdominios:

| Subdominio | Conceitos principais |
|------------|----------------------|
| Atos e Articulos | Constitution Amendment, Complementary Law, Ordinary Law, Decree, Resolution; Preamble, Epigraph, Brief |
| Discrimination Elements | Paragraph, Item, Letter, Letter Discriminator |
| Grouping Elements | Part, Book, Charter, Chapter, Section |

Estereotipos OntoUML usados: `Kind` (Article), `SubKind` (Ordinary Article,
Revocation Clause, Duration Clause), `Collective` (Chapter, Book), com
relacoes `componentOf` essenciais e inseparaveis. Restricoes OCL garantem,
por exemplo, numeracao unica de articulos por NA. A ontologia atende a
**Lei de Acesso a Informacao (12.527/2011)**, que exige formatos abertos e
estruturados — RDF/OWL e citado pelo W3C como pratica desejavel.

> **Governanca de processos:** Souza, Falbo & Vijaykumar (2013) realizam SLR
> de ontologias em **Software Testing** (12 ontologias avaliadas — STOWS,
> OntoTest, TaaS) e mostram que a maioria carece de fundacionais e relacoes
> nao-taxonomicas, comprometendo seu uso em KM. Licao para governanca:
> ontologia operacional sem fundacao = taxonomia disfarcada.

## Configuration

| Configuracao | Recomendacao |
|--------------|--------------|
| Vocabularios base | PROV-O, DQV, SHACL, DCAT (W3C) |
| Versionamento | Semver na URI: `/ontologia/v1/`, `/v2/` |
| Repositorio | Git + CI validando consistencia OWL (reasoner em PR) |
| Catalog | DataHub ou OpenMetadata + GCP Data Catalog |
| Reasoner CI | HermiT ou Pellet (containerizado) |
| Frequencia DQV | Diaria/horaria conforme criticidade |

## Anti-Patterns

| Wrong | Correct |
|-------|---------|
| Governanca em wiki/Confluence | Machine-readable via ontologia |
| Linhagem em ferramenta proprietaria | PROV-O federavel |
| Qualidade ad-hoc em SQL | DQV padroniza dimensions/metrics |
| Sem `:dataSteward` por classe | Steward declarado na ontologia |
| LGPD por instinto | `:piiLevel` na ontologia + ferramentas |

## Beneficios

Auditoria (rastreia conceito por coluna), reuso (novos pipelines herdam LGPD),
onboarding acelerado, compliance automatico (relatorio de PII), confianca em
IA (agentes consultam ontologia antes do insight).

## See Also

- [Modelagem de Ontologia de Dominio](modelagem-ontologia-dominio.md)
- [Integracao Ontologia + Data Lakehouse](integracao-ontologia-data-lakehouse.md)
- [Ontologia em Big Data](../concepts/ontologia-em-big-data.md)
- [Ontologia vs. Taxonomia vs. Vocabulario](../concepts/ontologia-vs-taxonomia-vs-vocabulario.md)
- KB irma: [`devops`](../../devops/index.md), [`gcp-data-architecture`](../../gcp-data-architecture/index.md)

## Fontes

- `ontologia/The Value of Ontology - Complete Business Process Handbook`
- `ontologia/O que e Ontologia? E por que precisamos dela na era da IA?`
- `book_artificial_intelligence_for_big_data/Goals of Ontology in big data`
- W3C: PROV-O, DQV, SHACL, DCAT
- Barcelos, P. P. F., Guizzardi, R. S. S., Garcia, A. S. (2013). **An Ontology
  Reference Model for Normative Acts**. ONTOBRAS 2013, p. 35-46. UFES.
- Souza, E. F., Falbo, R. A., Vijaykumar, N. L. (2013). **Ontologies in Software
  Testing: A Systematic Literature Review**. ONTOBRAS 2013, p. 71-82. INPE/UFES.
