# Triplas RDF em Spark / GraphFrames

> **Purpose**: Processar e analisar grafos RDF em escala usando Apache Spark e GraphFrames, integrando ontologias com pipelines de Big Data
> **MCP Validated**: 2026-04-17

## When to Use

- Volumes de triplas RDF excedem capacidade de triplestore unico (>1B triplas)
- Pipeline ja usa Spark/Dataproc — quer-se reusar infra
- Precisa rodar algoritmos de grafo (PageRank, Connected Components) em KG
- Carga em batch para triplestore precisa de pre-processamento distribuido
- Necessario juntar RDF com dados tabulares (Parquet/Delta) em pipeline unico

## Implementation

### 1. Ler Triplas RDF como DataFrame

```python
# jobs/refined/process_rdf_triples.py
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType
import re

spark = (SparkSession.builder
    .appName("RDF Processing")
    .config("spark.sql.adaptive.enabled", "true")
    .getOrCreate())

# Parsear NT (N-Triples — formato linha-a-linha mais simples)
def parse_ntriple(line):
    # <subject> <predicate> <object> .
    pattern = r'^(<[^>]+>|_:[\w-]+)\s+(<[^>]+>)\s+(<[^>]+>|"[^"]*"(?:@\w+)?(?:\^\^<[^>]+>)?|_:[\w-]+)\s*\.\s*$'
    m = re.match(pattern, line)
    return m.groups() if m else None

triples_schema = StructType([
    StructField("subject", StringType(), False),
    StructField("predicate", StringType(), False),
    StructField("object", StringType(), False),
])

# Ler arquivo .nt do GCS
rdd = spark.sparkContext.textFile("gs://bucket/refined/kg/produto.nt") \
    .map(parse_ntriple) \
    .filter(lambda x: x is not None)

triples_df = spark.createDataFrame(rdd, schema=triples_schema)
```

### 2. Construir GraphFrame a partir de Triplas

```python
from graphframes import GraphFrame
import pyspark.sql.functions as F

# Vertices: todos os subjects e objects que sao URIs
vertices = (triples_df
    .select(F.col("subject").alias("id"))
    .union(triples_df.filter(F.col("object").startswith("<"))
                     .select(F.col("object").alias("id")))
    .distinct())

# Edges: predicate vira tipo da aresta
edges = triples_df.select(
    F.col("subject").alias("src"),
    F.col("object").alias("dst"),
    F.col("predicate").alias("relationship")
)

g = GraphFrame(vertices, edges)
```

### 3. Algoritmos de Grafo sobre KG

```python
# PageRank: identificar entidades mais "centrais" do KG
results = g.pageRank(resetProbability=0.15, maxIter=10)
top_entities = (results.vertices
    .orderBy(F.col("pagerank").desc())
    .limit(20))

# Connected Components: clusters de entidades relacionadas
components = g.connectedComponents()

# Triangle Count: redundancia/triangulos no grafo
triangles = g.triangleCount()
```

### 4. Inferencia Simples (subClassOf transitiva)

```python
# Calcular fechamento transitivo de subClassOf via BFS
sub_class_edges = edges.filter(
    F.col("relationship") == "<http://www.w3.org/2000/01/rdf-schema#subClassOf>"
)

# BFS de profundidade limitada (ou Pregel para casos complexos)
g_classes = GraphFrame(vertices, sub_class_edges)
result = g_classes.bfs(
    fromExpr="id = '<http://empresa.com/ontologia/produto#ProdutoPerecivel>'",
    toExpr="id = '<http://empresa.com/ontologia/produto#Produto>'",
    maxPathLength=10
)
```

### 5. Exportar Triplas para Triplestore

```python
# Gerar Turtle particionado para carga em Jena Fuseki / GraphDB
turtle_lines = triples_df.select(
    F.concat_ws(" ", "subject", "predicate", "object", F.lit(".")).alias("line")
)

(turtle_lines
    .coalesce(1)  # ou particionar para carga paralela
    .write.mode("overwrite")
    .text("gs://bucket/refined/kg-export/turtle/"))
```

## Configuration

| Configuracao | Valor | Razao |
|--------------|-------|-------|
| Formato preferido | N-Triples (`.nt`) | Linha-a-linha, paralelizavel |
| GraphFrames version | `>= 0.8.3` (Spark 3.x) | Compativel com Dataproc 2.2 |
| JAR | `graphframes-0.8.3-spark3.5-s_2.13.jar` | Scala 2.13 (Dataproc) |
| Particionamento | Por hash do subject URI | Distribuir join load |
| Storage | Delta Lake (mutable) ou Parquet (imutavel) | Reuso na trusted |
| Reasoning complexo | Externo (Jena + Pellet) | Spark nao e reasoner DL |

## Limitacoes

- Spark nao executa reasoning OWL DL — use Jena/Pellet offline e ingira inferencias
- GraphFrames carece de queries Cypher/SPARQL nativas (use DataFrame API)
- Joins recursivos ilimitados sao caros — limite profundidade
- Volume muito grande (>10B triplas) pode requerer triplestore distribuido (AnzoGraph, Stardog cluster)

## Anti-Patterns

| Wrong | Correct |
|-------|---------|
| Tentar OWL reasoning em Spark direto | Reasoning externo, importar inferencias |
| Carregar todo o KG em driver | Operar sempre em DataFrames distribuidos |
| Esquecer de cachear vertices/edges | `g.cache()` antes de PageRank/CC |
| Formato RDF/XML em batch | Use N-Triples ou Turtle |

## See Also

- [Integracao Ontologia + Data Lakehouse](integracao-ontologia-data-lakehouse.md)
- [Ontologia em Knowledge Graph Neo4j](ontologia-em-knowledge-graph-neo4j.md)
- [RDF](../concepts/rdf.md)
- [SPARQL](../concepts/sparql.md)
- KB irma: [`dataproc`](../../dataproc/index.md)

## Fontes

- `book_artificial_intelligence_for_big_data/RDF - the universal data format`
- `book_artificial_intelligence_for_big_data/Ontology learning`
  (recomenda Hadoop para ontology learning escalavel)
- `ontologia/Chapter 6 Graph Databases` (parametros de performance)
- Documentacao GraphFrames + experiencia em Dataproc Serverless 2.2
