# Ontologia Quick Reference

> Tabelas de consulta rapida. Para detalhes, veja arquivos linkados.
> **MCP Validated**: 2026-04-17

## Espectro de Maturidade

| Artefato | Estrutura | Reasoning |
|----------|-----------|-----------|
| Vocabulario controlado | Lista | Nao |
| Glossario | Termos + definicoes | Nao |
| Folksonomia | Tags coletivas | Nao |
| Tesauro | Sinonimos / relacionados | Nao |
| Taxonomia | Hierarquia is-a | Heranca |
| Ontologia frame | + propriedades + relacoes | Basica |
| Ontologia OWL DL | + axiomas formais | Sim, completa |

## Componentes de uma Ontologia

| Componente | Equivalente POO |
|------------|-----------------|
| Concept (Class) | Class |
| Slot (Property) | Atributo |
| Relation (is-a / has-a) | Heranca / Composicao |
| Axiom | Invariante |
| Instance | Objeto |
| Operation | Metodo |

## Decision Matrix: Linguagem

| Use Case | Tecnologia |
|----------|------------|
| Vocabulario controlado | RDFS |
| Hierarquia + cardinalidade simples | OWL Lite |
| Reasoning + restricoes | OWL DL |
| Maxima expressividade | OWL Full |
| Consultas em RDF | SPARQL |
| Validacao de instancias | SHACL |
| Linhagem | PROV-O |
| Qualidade | DQV |
| Catalogo | DCAT |

## Decision Matrix: Storage

| Use Case | Tecnologia |
|----------|------------|
| Reasoning OWL DL completo | Apache Jena + Pellet/HermiT |
| KG operacional + queries | Neo4j + n10s |
| Triplestore puro | Stardog, GraphDB, AllegroGraph |
| Cloud-native managed | Amazon Neptune |
| Spark scale (>1B triplas) | GraphFrames + Delta Lake |

## SPARQL Atalhos

| Operador | Uso |
|----------|-----|
| `?var` | Variavel |
| `.` | Termina tripla |
| `;` | Mesmo sujeito, novo predicado |
| `,` | Mesmo sujeito + predicado, novo objeto |
| `a` | Atalho para `rdf:type` |
| `OPTIONAL` | Padrao opcional (LEFT JOIN) |
| `FILTER` | Restringe valores |

## Common Pitfalls

| Nao Faca | Faca |
|----------|------|
| Modelar ontologia da empresa toda de uma vez | Comecar por 1 dominio prioritario |
| Confundir Taxonomia com Ontologia | Taxonomia e hierarquia; Ontologia tem axiomas |
| Esperar reasoning OWL DL no Neo4j | Use Jena/Pellet offline; Neo4j para queries |
| Pular Methontology / iteracao com dominio | Validacao continua com especialistas |
| Hardcode URIs no codigo Spark | Configurar via variavel/arquivo |
| Tratar Ontologia como projeto de TI | Negocio + dados + IA conjuntos |
| Esquecer LGPD ao publicar como RDF aberto | Anotar piiLevel, anonimizar antes |
| Confiar 100% em ontology learning automatico | Sempre revisao humana |

## Mapeamento Lakehouse Medallion

| Camada | Estado Semantico |
|--------|------------------|
| Landing | Strings (raw files) |
| Raw | + metadata (`_source_file`, `_ingestion_timestamp`) |
| Trusted | + tipos canonicos + chaves naturais + `_ontology_class` |
| Refined / KG | Things (RDF/LPG, ontologia completa, GraphRAG) |

## Related Documentation

| Topico | Path |
|--------|------|
| Indice geral | `index.md` |
| O que e Ontologia | `concepts/o-que-e-ontologia.md` |
| RDF | `concepts/rdf.md` |
| OWL | `concepts/owl.md` |
| Modelagem | `patterns/modelagem-ontologia-dominio.md` |
| Lakehouse | `patterns/integracao-ontologia-data-lakehouse.md` |
| Neo4j | `patterns/ontologia-em-knowledge-graph-neo4j.md` |
| Governanca | `patterns/ontologia-para-governanca-dados.md` |
| Spec exemplo | `specs/exemplo-ontologia-dominio.yaml` |
| KBs irmas | `../gs1-varejo/index.md`, `../modelagem-dimensional/index.md` |
