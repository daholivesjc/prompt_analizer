# Ambiguity e Clarity

> **Purpose**: Identificar e resolver ambiguidade em prompts para respostas precisas
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-20

## Overview

Prompts ambiguos geram respostas imprevisiveis porque o modelo interpreta o contexto
de forma nao deterministica. Tecnicas de clareza incluem: linguagem especifica,
formatos estruturados, variaveis de template e contexto explicito.

## The Pattern

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Prompt AMBIGUO: "bank" pode ser banco financeiro ou margem de rio
ambiguous = "Tell me about the bank."

# Prompt CLARO: contexto resolve a ambiguidade
clear = (
    "Explique como funciona um banco comercial no Brasil, "
    "incluindo: tipos de conta, taxas de juros e regulamentacao "
    "pelo Banco Central. Formato: topicos com 2-3 frases cada."
)

response = llm.invoke([HumanMessage(content=clear)])
```

## Tipos de Ambiguidade

| Tipo | Exemplo Ambiguo | Resolucao |
|------|----------------|-----------|
| Lexica | "Manga" (fruta ou camisa?) | Adicionar contexto do dominio |
| Referencial | "Ele fez isso" (quem? o que?) | Nomear sujeitos e acoes |
| Escopo | "Analise os dados" (quais?) | Especificar dataset e metricas |
| Formato | "Resuma" (em quantas linhas?) | Definir tamanho e formato |

## Tecnicas para Clareza

```python
# Tecnica 1: linguagem especifica
vague = "Faca algo com esses dados."
clear = "Calcule a media movel de 7 dias da coluna 'vendas' agrupada por 'loja'."

# Tecnica 2: formato estruturado
vague = "Me de informacoes sobre o produto."
clear = """Descreva o produto no formato abaixo:
- Nome:
- Categoria:
- Preco (R$):
- Principais caracteristicas (max 3):
- Publico-alvo:"""

# Tecnica 3: variaveis de template
from string import Template

prompt_template = Template(
    "Analise o $tipo_analise para o periodo de $data_inicio "
    "a $data_fim, focando em $metricas. "
    "Formato de saida: $formato."
)

prompt = prompt_template.substitute(
    tipo_analise="desempenho de vendas",
    data_inicio="2024-01-01",
    data_fim="2024-03-31",
    metricas="faturamento, ticket medio, volume",
    formato="tabela Markdown"
)
```

## Checklist de Clareza

```python
def check_prompt_clarity(prompt: str) -> list[str]:
    """Verifica possiveis problemas de clareza no prompt."""
    issues = []
    ambiguous_terms = ["isso", "aquilo", "ele", "ela", "os dados", "o resultado"]

    for term in ambiguous_terms:
        if term.lower() in prompt.lower():
            issues.append(f"Referencia ambigua: '{term}' -- especifique o sujeito")

    if "?" not in prompt and not any(
        w in prompt.lower() for w in ["liste", "calcule", "explique", "descreva"]
    ):
        issues.append("Sem verbo de acao claro ou pergunta direta")

    if len(prompt.split()) < 10:
        issues.append("Prompt muito curto -- considere adicionar contexto")

    return issues if issues else ["Prompt parece claro"]
```

## Common Mistakes

### Wrong

```python
# Pronomes sem referente claro
prompt = "Pegue isso e faca aquilo com os dados."
```

### Correct

```python
# Sujeitos e acoes explicitos
prompt = (
    "Leia o arquivo vendas_2024.csv, "
    "calcule o total por categoria de produto "
    "e exporte o resultado em formato JSON."
)
```

## Related

- [negative-prompting.md](negative-prompting.md) -- exclusoes complementam clareza
- [prompt-templates.md](prompt-templates.md) -- templates garantem consistencia
- [../patterns/instruction-engineering.md](../patterns/instruction-engineering.md)
