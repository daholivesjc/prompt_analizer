# Chain-of-Thought (CoT)

> **Purpose**: Incentivar raciocinio passo a passo para problemas complexos
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-20

## Overview

Chain-of-Thought prompting forca o LLM a explicitar etapas intermediarias de raciocinio
antes de chegar a resposta final. Melhora significativamente a precisao em problemas
matematicos, logicos e multi-etapa. O trigger classico e "Pense passo a passo".

## The Pattern

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

llm = ChatOpenAI(model="gpt-4o", temperature=0)

# CoT basico: trigger "passo a passo"
prompt_cot = """Resolva o problema abaixo. Pense passo a passo.

Problema: Uma loja vende 3 tipos de produto. Tipo A custa R$25
e vendeu 40 unidades. Tipo B custa R$50 e vendeu 20 unidades.
Tipo C custa R$100 e vendeu 10 unidades. Qual o faturamento total?

Resolucao passo a passo:"""

response = llm.invoke([HumanMessage(content=prompt_cot)])

# CoT avancado: formato estruturado
prompt_advanced = """Analise o problema usando o formato abaixo.

ESTADO INICIAL: [descreva os dados]
FORMULA: [identifique a formula]
CALCULO: [execute passo a passo]
RESULTADO: [resposta final]
VERIFICACAO: [confira o resultado]

Problema: Se um investimento rende 12% ao ano com juros compostos,
qual o valor de R$10.000 apos 3 anos?"""

response = llm.invoke([HumanMessage(content=prompt_advanced)])
```

## Quick Reference

| Variante | Formato | Melhor Para |
|----------|---------|-------------|
| Basico | "Pense passo a passo" | Problemas simples |
| Estruturado | Estado/Formula/Calculo | Matematica e logica |
| Few-shot CoT | Exemplos com raciocinio | Dominio especifico |
| Zero-shot CoT | Apenas o trigger | Uso rapido |

## Comparacao: Prompt Padrao vs. CoT

```python
# SEM CoT: resposta direta (pode errar)
prompt_standard = "Quanto e 17 * 28 + 156 / 4?"
# Modelo pode responder incorretamente com calculo mental

# COM CoT: raciocinio explicito (mais preciso)
prompt_cot = """Quanto e 17 * 28 + 156 / 4?
Mostre cada etapa do calculo:
1. Primeiro calcule 17 * 28
2. Depois calcule 156 / 4
3. Some os resultados"""
# Modelo decompoe e acerta com mais frequencia
```

## Common Mistakes

### Wrong

```python
# CoT para tarefas triviais -- desperdicio de tokens
prompt = "Pense passo a passo: Qual a capital do Brasil?"
```

### Correct

```python
# CoT para problemas que requerem raciocinio
prompt = """Pense passo a passo:
Um trem sai de SP as 8h a 120km/h. Outro sai do RJ as 9h
a 150km/h na direcao contraria. A distancia SP-RJ e 430km.
A que horas se encontram?"""
```

## Quando Usar CoT

| Tipo de Problema | CoT Necessario? |
|------------------|-----------------|
| Classificacao simples | Nao |
| Aritmetica multi-etapa | Sim |
| Logica com condicoes | Sim |
| Extracao de entidades | Nao |
| Analise comparativa | Sim |
| Planejamento de tarefas | Sim |

## Tabela Completa de Variacoes de CoT

| Variacao | Instrucao | Quando Usar |
|----------|-----------|-------------|
| Zero-shot generico | "Think step by step." | Qualquer problema moderado |
| Zero-shot especifico | "Follow steps: 1) X. 2) Y. 3) Z." | Processo com etapas conhecidas |
| Zero-shot com rationale | "Explain your reasoning before answering." | Auditoria de raciocinio |
| One-shot CoT | Exemplo com passos explicitos + pergunta real | Formato nao-obvio de raciocinio |
| Tree-of-Thought | "List N approaches, evaluate each, then choose." | Trade-offs entre alternativas |
| Self-Ask | "Identify sub-questions first." | Perguntas compostas/multi-fator |
| Multi-Agent | "Analyze from perspectives: A, B, C." | Decisoes com multiplos stakeholders |

## Quando NAO Usar CoT

| Situacao | Por que Nao |
|----------|-------------|
| Classificacao simples (positivo/negativo) | CoT nao melhora — desperdicou tokens |
| Tarefas criativas (escrever poema) | CoT pode restringir criatividade |
| Perguntas factuais diretas | Zero-shot suficiente |
| Pipeline com custo de tokens critico | Reduzir CoT economiza 30%+ de tokens |

## Rastreabilidade e Auditoria

CoT gera raciocinio intermediario auditavel — util em dominios criticos:

```python
PROMPT = """Analise o risco de credito do cliente.

Antes de concluir:
1. Liste os fatores de risco identificados
2. Cite os criterios que cada fator viola ou atende
3. Justifique o nível de risco com base nos fatores acima

Conclusao final em <risk_assessment> tags com: nivel (BAIXO/MEDIO/ALTO),
justificativa e criterios de revisao."""
# O raciocinio intermediario pode ser logado para auditoria regulatoria
```

## Related

- [zero-shot-prompting.md](zero-shot-prompting.md) -- alternativa para tarefas simples
- [self-consistency.md](self-consistency.md) -- multiplos CoT + votacao
- [tree-of-thought.md](tree-of-thought.md) -- extensao com multiplos caminhos paralelos
- [self-ask-prompting.md](self-ask-prompting.md) -- modelo gera as proprias sub-perguntas
- [../patterns/task-decomposition.md](../patterns/task-decomposition.md)
