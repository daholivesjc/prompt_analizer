# Few-Shot Learning

> **Purpose**: Fornecer poucos exemplos no prompt para guiar o modelo em tarefas especificas
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-20

## Overview

Few-shot learning insere 2-5 exemplos diretamente no prompt para que o LLM aprenda o
padrao esperado. Funciona quando zero-shot nao captura nuances suficientes. Os exemplos
devem ser diversos, claros e representativos do dominio.

## The Pattern

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Few-shot para classificacao de sentimento
prompt = """Classifique o sentimento como POSITIVO, NEGATIVO ou NEUTRO.

Exemplo 1:
Texto: "Adorei o produto, superou expectativas!"
Sentimento: POSITIVO

Exemplo 2:
Texto: "Produto ok, nada de especial."
Sentimento: NEUTRO

Exemplo 3:
Texto: "Pessimo atendimento, nao recomendo."
Sentimento: NEGATIVO

Agora classifique:
Texto: "A entrega foi rapida mas o produto veio com defeito."
Sentimento:"""

response = llm.invoke([HumanMessage(content=prompt)])

# Multi-task few-shot: sentimento + deteccao de idioma
prompt_multi = """Analise o texto e retorne sentimento e idioma.

Texto: "I love this product!"
Sentimento: POSITIVO | Idioma: ingles

Texto: "Ce produit est terrible."
Sentimento: NEGATIVO | Idioma: frances

Texto: "El servicio fue excelente."
Sentimento:"""

response = llm.invoke([HumanMessage(content=prompt_multi)])
```

## Quick Reference

| Parametro | Recomendacao | Motivo |
|-----------|--------------|--------|
| Num. exemplos | 3-5 | Equilibrio custo/qualidade |
| Diversidade | Alta | Cobrir edge cases |
| Balanceamento | Igual por classe | Evitar vies |
| Ordem | Aleatorio | Reduzir recency bias |

## In-Context Learning

```python
# Ensinar tarefa customizada via exemplos
prompt = """Extraia dados do recibo no formato estruturado.

Recibo: "Cafe R$5.50 - Padaria Central - 15/03/2024"
Resultado: {"item": "Cafe", "valor": 5.50, "local": "Padaria Central", "data": "2024-03-15"}

Recibo: "Almoco R$32.00 - Restaurante Bom Sabor - 16/03/2024"
Resultado: {"item": "Almoco", "valor": 32.00, "local": "Restaurante Bom Sabor", "data": "2024-03-16"}

Recibo: "Gasolina R$250.00 - Posto Shell - 17/03/2024"
Resultado:"""
```

## Common Mistakes

### Wrong

```python
# Exemplos desbalanceados (4 positivos, 1 negativo)
# Exemplos sem diversidade (todos do mesmo dominio)
# Muitos exemplos (>10) desperdicando tokens
```

### Correct

```python
# Exemplos balanceados, diversos e concisos
# 3-5 exemplos cobrindo diferentes cenarios
# Formato consistente entre exemplos
```

## Metricas de Avaliacao

```python
def evaluate_few_shot(predictions: list, ground_truth: list) -> dict:
    """Avalia qualidade do few-shot comparando com ground truth."""
    correct = sum(1 for p, g in zip(predictions, ground_truth) if p == g)
    return {
        "accuracy": correct / len(ground_truth),
        "total": len(ground_truth),
        "correct": correct
    }
```

## Custo de Tokens por Formato

Few-shot tem custo de tokens variavel conforme o formato escolhido:

```python
# Formato verbose (38 tokens):
"Label the following item as edible or inedible.\nInput: chickpea\nOutput: edible\nInput: box\nOutput: inedible\nInput: pizza\nOutput:"

# Formato compacto (27 tokens) -- mesmo resultado, 29% menos tokens:
"Label as edible or inedible.\nchickpea --> edible\nbox --> inedible\npizza -->"
```

Equipes reduzem consumo em 30%+ simplesmente reformulando exemplos verbose
em instrucoes compactas.

## Achado Microsoft 2023 (GPT-4)

> Few-shot tem impacto limitado em tarefas gerais com GPT-4, mas e critico em
> dominios de nicho onde o modelo nao tem dados de treinamento suficientes
> (terminologia medica especializada, jargao corporativo interno, esquemas
> de dados proprietarios).

Implicacao pratica:
- Para tarefas gerais: teste zero-shot primeiro — pode ser suficiente
- Para dominios de nicho: few-shot e frequentemente indispensavel

## Marcador de Fim de Input

Sem marcador explicito, o modelo pode "continuar o input" em vez de responder:

```python
# Problema: modelo pode adicionar mais texto ao exemplo
PROMPT_ERRADO = """Extraia o nome do recibo:
Recibo: "Cafe R$5.50 - Padaria Central"
Nome: Cafe
Recibo: "Almoco R$32.00 - Restaurante Bom Sabor"
Nome: Almoco
Recibo: {novo_recibo}
Nome:"""
# Modelo pode adicionar "Nome: Almoco\nRecibo: ..." continuando o padrao

# Solucao: marcador de fim de input
PROMPT_CORRETO = """Extraia o nome do recibo:
Recibo: "Cafe R$5.50 - Padaria Central"
Nome: Cafe
---
Recibo: "Almoco R$32.00 - Restaurante Bom Sabor"
Nome: Almoco
---
Recibo: {novo_recibo}
Nome:"""
# O "---" sinaliza que cada exemplo e uma unidade independente
```

## Related

- [zero-shot-prompting.md](zero-shot-prompting.md) -- alternativa mais simples
- [chain-of-thought.md](chain-of-thought.md) -- combina com few-shot para CoT
- [in-context-learning.md](in-context-learning.md) -- ICL como continual learning
- [../patterns/specific-task-prompts.md](../patterns/specific-task-prompts.md)
