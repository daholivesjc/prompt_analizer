# In-Context Learning (ICL)

> **Purpose**: ICL como forma de ensinar o modelo via contexto, alem de formato — inclui schemas novos, terminologia e documentacao recente
> **Confidence**: 0.95
> **MCP Validated**: 2026-05-10

## Overview

In-Context Learning (ICL) vai alem de "dar exemplos de formato" — e uma forma de ensinar o
modelo via contexto, sem retreinamento. Um modelo treinado em documentacao antiga pode
responder a perguntas sobre versoes novas se a documentacao nova for incluida no contexto.
Isso tem implicacoes praticas importantes: schemas, terminologia e regras de dominio podem
ser injetados no prompt para adaptar o comportamento sem fine-tuning.

**Fonte:** AI Engineering — Chip Huyen (2026), Cap. 5

## ICL como Continual Learning

| Uso Tradicional (Formato) | ICL Avancado (Conhecimento) |
|---------------------------|------------------------------|
| Mostrar padrao de output | Injetar documentacao nova |
| Definir estrutura de JSON | Ensinar schema v2.1 vs v1.0 |
| Exemplos de classificacao | Explicar terminologia de dominio |
| Formato de resposta | Regras de negocio especificas |

## Diferenca de Few-Shot como Formato

Few-Shot tradicional ensina o formato de resposta.
ICL como continual learning ensina *conhecimento* que o modelo nao tem.

```python
# Few-Shot tradicional: ensina formato
PROMPT = """Classifique o email:
Exemplo: "Produto quebrado" → (B) Defeito
Agora: {email}"""

# ICL como continual learning: ensina conhecimento novo
SYSTEM = """Voce e um extrator de dados de faturas.

Schema atual de extracao (versao 2.1):
<schema>
{schema_json}
</schema>

Mudancas em relacao a versao anterior:
- Campo 'subtotal' agora e 'net_amount'
- Campo 'tax' agora inclui breakdown por categoria
- Novo campo obrigatorio: 'payment_method'
"""
```

## Implementacao

```python
import anthropic
import json

client = anthropic.Anthropic()

def icl_with_new_schema(invoice_text: str, current_schema: dict) -> dict:
    """Extrai dados com schema novo injetado via ICL."""

    system = f"""Voce e um extrator de dados de faturas.

Schema de extracao (versao atual):
<schema>
{json.dumps(current_schema, indent=2, ensure_ascii=False)}
</schema>

Instrucoes de migracao:
- Use os nomes de campos do schema acima
- Se o documento usa nomenclatura antiga, mapeie para os novos campos
- Campos marcados como 'required' nao podem ser null"""

    prompt = f"""Extraia os dados da fatura abaixo seguindo o schema injetado.
Retorne JSON valido.

<fatura>
{invoice_text}
</fatura>"""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1000,
        temperature=0.0,
        system=system,
        messages=[{"role": "user", "content": prompt}]
    )
    return json.loads(message.content[0].text)
```

## Casos de Uso de Alto Valor

| Caso | O que Injetar via ICL |
|------|-----------------------|
| API nova nao vista no treino | Documentacao da API no system prompt |
| Terminologia corporativa interna | Glossario de termos no contexto |
| Schema de dados v2.0 | JSON Schema completo + notas de migracao |
| Regras de negocio especificas | Tabela de regras + exemplos de aplicacao |
| Idioma tecnico de dominio | Definicoes + exemplos de uso correto |

## Limitacoes

- ICL nao persiste entre sessoes — e injetado a cada chamada
- Conflitos entre conhecimento de treino e ICL podem causar comportamento hibrido inesperado
- Contextos muito longos de ICL aumentam custo e latencia
- Para conhecimento persistente e complexo, fine-tuning pode ser mais eficiente

## Principio de Custo de Tokens

Dados empiricos sobre ICL e custo de tokens:

```python
# Formato menos eficiente (38 tokens):
"Label the following item as edible or inedible.\nInput: chickpea\nOutput: edible\nInput: box\nOutput: inedible\nInput: pizza\nOutput:"

# Formato mais eficiente (27 tokens):
"Label as edible or inedible.\nchickpea --> edible\nbox --> inedible\npizza -->"
```

Equipes reduzem consumo em 30%+ reformulando prompts vagos em instrucoes especificas.
Em workflows de geracao de codigo, prompts estruturados reduziram consumo em 90%+.

## Related

- [few-shot-learning.md](few-shot-learning.md) — ICL como formato (subconjunto)
- [../patterns/prompt-length-management.md](../patterns/prompt-length-management.md) — gerenciar contexto longo
- [../patterns/specific-task-prompts.md](../patterns/specific-task-prompts.md) — templates por tarefa
