# Multi-Agent Prompting (Simulacao de Perspectivas)

> **Purpose**: Instrui um unico LLM a simular dialogo entre multiplos agentes com perspectivas distintas para mitigar overconfidence
> **Confidence**: 0.95
> **MCP Validated**: 2026-05-10

## Overview

Multi-Agent Prompting instrui um unico LLM a simular perspectivas de agentes com papeis e
prioridades distintos. Mitiga overconfidence ao forcar articulacao de posicoes em tensao.
Nao e o mesmo que sistemas multi-agente reais (como CrewAI) — e uma simulacao dentro de
uma unica chamada de modelo.

**Fonte:** AI Engineering — Chip Huyen (2026), Cap. 5; Prompt Engineering for Everyone — Iman Tavakoli (2026)

## Template Basico

```python
import anthropic

client = anthropic.Anthropic()

def multi_agent_analysis(decision_context: str) -> str:
    prompt = f"""Analise esta decisao de arquitetura com tres perspectivas:

Arquiteto de Dados: foco em escalabilidade e manutenibilidade
Engenheiro de Plataforma: foco em custo operacional e latencia
Gerente de Produto: foco em tempo de entrega e experiencia do usuario

Para cada perspectiva, apresente os principais argumentos.
Entao sintetize uma recomendacao equilibrada.

Decisao: {decision_context}"""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1500,
        temperature=0.2,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text
```

## Exemplos de Configuracoes de Roles

### Decisao Tecnica (3 perspectivas)

```python
ROLES_TECH = """
- Arquiteto de Dados: escalabilidade, manutenibilidade, debito tecnico
- Engenheiro de Plataforma: custo operacional, latencia, SLA
- Gerente de Produto: time-to-market, UX, roadmap de negocio
"""
```

### Analise de Risco (4 perspectivas)

```python
ROLES_RISK = """
- Auditor de Seguranca: surface de ataque, conformidade, vulnerabilidades
- Advogado de Privacidade: LGPD, retencao de dados, consentimento
- Engenheiro de Confiabilidade: SLA, failover, recuperacao de desastres
- Economista: custo de risco, ROI de mitigacao, seguros
"""
```

### Politica Publica (3 perspectivas)

```python
ROLES_POLICY = """
- Especialista em Implementacao: viabilidade operacional, custo de rollout
- Representante de Comunidade: impacto em populacoes vulneraveis
- Analista Economico: custo-beneficio, externalidades de longo prazo
"""
```

## Boas Praticas

1. **Ancore em arquetipos profissionais** — use "economista", "auditor de seguranca", nao identidades pessoais ou culturais
2. **Defina prioridades por role** — cada agente deve ter um foco claro e potencialmente conflitante
3. **Peca sintese explicita** — sempre termine com "sintetize uma recomendacao equilibrada"
4. **Use 3-4 perspectivas** — mais que isso gera respostas fragmentadas e superficiais
5. **Mantenha roles em tensao** — roles sem conflito de prioridade geram simulacao inutil

## Consideracoes Eticas

- Nao instrua o modelo a simular identidades de pessoas reais
- Evite roles baseados em demografias (genero, etnia, nacionalidade)
- Use roles funcionais ou profissionais, nao identidades pessoais
- Em decisoes que afetam grupos vulneraveis, inclua explicitamente uma perspectiva de advocacy

## Quando Usar

| Situacao | Por que Multi-Agent |
|----------|---------------------|
| Decisoes arquiteturais com trade-offs | Forca articulacao de tensoes reais |
| Policies com impacto em multiplos stakeholders | Evita perspectiva unica dominante |
| Analise de risco multidimensional | Cobre angulos que prompt simples omite |
| Reunioes de design com multiple personas | Simula dinamica de grupo antes da reuniao |

## Quando NAO Usar

- Problemas com resposta tecnica objetiva — use CoT ou Self-Ask
- Tarefas criativas — o conflito de perspectivas nao agrega valor
- Quando latencia e critica — gera outputs maiores

## Related

- [tree-of-thought.md](tree-of-thought.md) — multiplos caminhos sem roles distintos
- [role-prompting.md](role-prompting.md) — role unico, sem simulacao de multiplos
- [reflection-prompting.md](reflection-prompting.md) — auto-revisao em vez de multiplos agentes
