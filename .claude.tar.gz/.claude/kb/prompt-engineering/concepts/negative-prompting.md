# Negative Prompting

> **Purpose**: Especificar o que NAO incluir nas respostas para controlar o output
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-20

## Overview

Negative prompting define exclusoes explicitas no prompt -- o que o modelo deve evitar,
nao mencionar ou nao usar. Complementa instrucoes positivas e e util para restringir
respostas verbose ou fora do escopo. Pode ser validado automaticamente com regex.

## The Pattern

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
import re

llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Exemplos negativos: "Do NOT include..."
response = llm.invoke([
    SystemMessage(content=(
        "Voce e um redator tecnico. "
        "NAO inclua: opiniao pessoal, jargao excessivo, analogias. "
        "NAO use emojis ou linguagem informal. "
        "NAO exceda 3 paragrafos."
    )),
    HumanMessage(content="Explique o conceito de API REST.")
])

# Exclusoes explicitas de conteudo
response = llm.invoke([
    HumanMessage(content=(
        "Liste 5 beneficios de Python para data engineering.\n\n"
        "RESTRICOES:\n"
        "- Nao mencione machine learning\n"
        "- Nao compare com outras linguagens\n"
        "- Nao use a palavra 'simples'\n"
        "- Nao inclua exemplos de codigo"
    ))
])
```

## Quick Reference

| Tipo de Restricao | Exemplo | Validacao |
|-------------------|---------|-----------|
| Conteudo proibido | "Nao mencione X" | Verificar ausencia de X |
| Palavras excluidas | "Nao use a palavra Y" | Regex `\bY\b` |
| Formato vedado | "Nao use bullet points" | Regex para `^[-*]` |
| Tamanho maximo | "Nao exceda N palavras" | `len(text.split())` |

## Validacao Automatizada

```python
def validate_negative_constraints(
    response: str,
    excluded_words: list[str] = None,
    max_words: int = None,
    forbidden_patterns: list[str] = None
) -> dict:
    """Valida se a resposta respeita restricoes negativas."""
    violations = []

    if excluded_words:
        for word in excluded_words:
            if re.search(rf'\b{re.escape(word)}\b', response, re.IGNORECASE):
                violations.append(f"Palavra proibida encontrada: '{word}'")

    if max_words and len(response.split()) > max_words:
        violations.append(
            f"Excedeu limite: {len(response.split())}/{max_words} palavras"
        )

    if forbidden_patterns:
        for pattern in forbidden_patterns:
            if re.search(pattern, response):
                violations.append(f"Padrao proibido encontrado: '{pattern}'")

    return {
        "valid": len(violations) == 0,
        "violations": violations
    }

# Uso
result = validate_negative_constraints(
    response=response.content,
    excluded_words=["simples", "facil", "obvio"],
    max_words=200,
    forbidden_patterns=[r"^[-*]\s"]  # sem bullet points
)
```

## Common Mistakes

### Wrong

```python
# Restricoes vagas ou contraditorias
"Nao seja muito tecnico mas explique em detalhes tecnicos."
```

### Correct

```python
# Restricoes claras e nao contraditorias
"Use vocabulario acessivel (nivel ensino medio). "
"Explique termos tecnicos entre parenteses quando necessario."
```

## Related

- [ambiguity-clarity.md](ambiguity-clarity.md) -- clareza complementa negative prompting
- [../patterns/constrained-generation.md](../patterns/constrained-generation.md)
- [../patterns/prompt-security.md](../patterns/prompt-security.md)
