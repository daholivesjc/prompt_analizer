# Prompt Robustness

> **Purpose**: Propriedade de manter outputs consistentes diante de pequenas variacoes no input — teste de perturbacao e implicacoes praticas
> **Confidence**: 0.95
> **MCP Validated**: 2026-05-10

## Overview

Robustez e a propriedade de um prompt de manter outputs consistentes diante de pequenas
variacoes no input: trocar "5" por "five", adicionar uma linha em branco, mudar capitalizacao,
parafrasear ligeiramente a instrucao. Um prompt fragil gera respostas radicalmente diferentes
para inputs semanticamente equivalentes — o que e inaceitavel em producao.

**Fonte:** AI Engineering — Chip Huyen (2026), Cap. 5

## Teste de Perturbacao

```python
import anthropic

client = anthropic.Anthropic()

def robustness_test(sample_text: str) -> dict:
    """Testa robustez do prompt contra perturbacoes minimas."""

    perturbations = [
        "Classifique o sentimento: {text}",
        "Classifique o sentimento: \n{text}",
        "Classifique o sentimento: {text_lower}",
        "classifique o sentimento: {text}",   # sem capitalizacao
        "Por favor, classifique o sentimento: {text}",   # preambulo
    ]

    outputs = []
    for template in perturbations:
        prompt = template.format(
            text=sample_text,
            text_lower=sample_text.lower()
        )
        message = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=50,
            temperature=0.0,
            messages=[{"role": "user", "content": prompt}]
        )
        outputs.append(message.content[0].text.strip())

    # Verificar se todos os outputs sao iguais
    unique_outputs = set(outputs)
    is_robust = len(unique_outputs) == 1

    return {
        "is_robust": is_robust,
        "unique_outputs": list(unique_outputs),
        "outputs": outputs,
        "perturbations_tested": len(perturbations),
    }
```

## Checklist de Perturbacoes para Testar

| Tipo de Perturbacao | Exemplo | Por que Testar |
|---------------------|---------|----------------|
| Numeros vs palavras | "5" → "five" | Modelos mais fracos falham |
| Capitalizacao | "Classifique" → "classifique" | Sensibilidade a maiusculas |
| Espaco em branco | Sem linha → com linha em branco | Parsing interno |
| Sinonimos na instrucao | "classifique" → "categorize" | Overfit a palavra especifica |
| Preambulo adicionado | "Por favor, ..." | Verbosidade indesejada |
| Parafraseamento | Instrucao reordenada | Fragilidade estrutural |

## Iterative Variation como Diagnostico

```python
def variation_test(base_prompt: str, test_input: str) -> dict:
    """Detecta fragilidade via variacoes de fraseamento."""

    variations = [
        f"Classifique o sentimento como positivo ou negativo.\n\n{test_input}",
        f"Indique se o sentimento e positivo ou negativo.\n\n{test_input}",
        f"O sentimento e: (A) positivo (B) negativo.\n\n{test_input}",
        f"Positivo ou negativo? {test_input}",
    ]

    results = []
    for v in variations:
        message = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=50,
            temperature=0.0,
            messages=[{"role": "user", "content": v}]
        )
        results.append(message.content[0].text.strip())

    # Se os resultados diferem para o mesmo input, o prompt esta fragil
    unique = set(results)
    return {
        "fragil": len(unique) > 1,
        "resultados_unicos": list(unique),
    }
```

## Correlacao Robustez-Capacidade do Modelo

| Modelo | Robustez | Implicacao |
|--------|----------|------------|
| Modelos maiores (Opus, GPT-4) | Alta | Menos tempo de ajuste fino |
| Modelos medios (Sonnet, GPT-3.5) | Media | Testar perturbacoes principais |
| Modelos menores (Haiku, Phi) | Baixa | Guia de prompting especifico necessario |

> Trabalhar com modelos mais capazes frequentemente reduz o tempo de ajuste fino ("fiddling").
> Para modelos menores, o guia de prompting especifico do modelo e essencial.

## Sinais de Prompt Fragil

```
- Output muda radicalmente com linha em branco adicional
- Adicionar "por favor" muda o comportamento
- Capitalizacao afeta o resultado
- Sinonimos na instrucao geram outputs diferentes
- Ordem de palavras na instrucao importa mais que o conteudo
```

## Praticas para Aumentar Robustez

1. **Especificar o formato de saida explicitamente** — reduz variancia de interpretacao
2. **Usar XML tags para separar instrucao de dados** — clareza estrutural
3. **Incluir exemplos (few-shot)** — ancora o comportamento esperado
4. **Testar com multiplas perturbacoes antes de produzir** — detectar fragilidade cedo
5. **Temperatura 0 para tarefas deterministas** — elimina aleatoriedade desnecessaria

## Robustez como Metrica de Qualidade

Robustez deve ser incluida na suite de avaliacao de prompts em producao:

```python
METRICS = {
    "accuracy": 0.92,          # corretude do output
    "consistency": 0.95,       # mesma entrada = mesma saida
    "robustness": 0.88,        # estabilidade sob perturbacao
    "latency_p95_ms": 2100,    # performance
}
# Um prompt com accuracy alta mas robustez baixa nao e confiavel em producao
```

## Related

- [../patterns/prompt-optimization.md](../patterns/prompt-optimization.md) — A/B testing e refinamento
- [../patterns/evaluation-metrics.md](../patterns/evaluation-metrics.md) — metricas de qualidade
- [../patterns/prompt-debug-protocol.md](../patterns/prompt-debug-protocol.md) — diagnostico estruturado
