# Prompt Templates e Variaveis

> **Purpose**: Templates reutilizaveis com Jinja2 para prompts parametrizados
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-20

## Overview

Prompt templates permitem criar prompts reutilizaveis com variaveis dinamicas. Usando
Jinja2, e possivel construir prompts com condicionais, loops e conteudo parametrizado,
garantindo consistencia entre execucoes e facilitando manutencao.

## The Pattern

```python
from jinja2 import Template

# Template basico com variaveis
prompt_template = Template("""Voce e um {{ role }}.
Analise o seguinte {{ content_type }}:

{{ content }}

{% if constraints %}
Restricoes:
{% for c in constraints %}
- {{ c }}
{% endfor %}
{% endif %}

Formato de saida: {{ output_format }}""")

prompt = prompt_template.render(
    role="analista de dados senior",
    content_type="relatorio de vendas",
    content="Faturamento Q1: R$1.2M, Q2: R$950K, Q3: R$1.5M",
    constraints=["Maximo 200 palavras", "Inclua tendencias", "Use percentuais"],
    output_format="3 paragrafos com conclusao"
)
```

## Quick Reference

| Sintaxe Jinja2 | Funcao | Exemplo |
|----------------|--------|---------|
| `{{ var }}` | Variavel | `{{ nome }}` |
| `{% if %}` | Condicional | `{% if verbose %}...{% endif %}` |
| `{% for %}` | Loop | `{% for item in lista %}` |
| `{{ var\|default("X") }}` | Valor padrao | Fallback se variavel ausente |
| `{{ var\|upper }}` | Filtro | Transformacao de texto |

## Classe PromptTemplate Reutilizavel

```python
from jinja2 import Template, Environment, BaseLoader

class PromptTemplate:
    """Template de prompt reutilizavel com validacao."""

    def __init__(self, template_str: str, required_vars: list[str] = None):
        self.env = Environment(loader=BaseLoader())
        self.template = self.env.from_string(template_str)
        self.required_vars = required_vars or []

    def render(self, **kwargs) -> str:
        missing = [v for v in self.required_vars if v not in kwargs]
        if missing:
            raise ValueError(f"Variaveis obrigatorias ausentes: {missing}")
        return self.template.render(**kwargs)

# Uso
analysis_prompt = PromptTemplate(
    template_str="""Tarefa: {{ task }}
Contexto: {{ context }}
{% if examples %}Exemplos: {{ examples }}{% endif %}
Formato: {{ format }}""",
    required_vars=["task", "context", "format"]
)

result = analysis_prompt.render(
    task="Classificar sentimento",
    context="Reviews de produtos eletronicos",
    format="JSON com campos: texto, sentimento, confianca"
)
```

## Dynamic Instructions

```python
# Template com instrucoes dinamicas por tipo de tarefa
task_templates = {
    "summarization": Template(
        "Resuma o texto abaixo em {{ num_sentences }} frases.\n\n"
        "Texto: {{ text }}\n\nResumo:"
    ),
    "qa": Template(
        "Contexto: {{ context }}\n\n"
        "Pergunta: {{ question }}\n\n"
        "Responda baseado APENAS no contexto acima."
    ),
    "code_generation": Template(
        "Escreva codigo {{ language }} que {{ task }}.\n"
        "{% if constraints %}Restricoes: {{ constraints }}{% endif %}"
    ),
}

# Selecionar e renderizar dinamicamente
prompt = task_templates["qa"].render(
    context="Python foi criado por Guido van Rossum em 1991.",
    question="Em que ano Python foi criado?"
)
```

## Common Mistakes

### Wrong

```python
# String concatenation manual (fragil e dificil de manter)
prompt = "Voce e " + role + ". Analise " + content + " em " + format
```

### Correct

```python
# Template parametrizado (manutenivel e testavel)
template = Template("Voce e {{ role }}. Analise {{ content }} em {{ format }}")
prompt = template.render(role=role, content=content, format=fmt)
```

## Related

- [ambiguity-clarity.md](ambiguity-clarity.md) -- templates reduzem ambiguidade
- [role-prompting.md](role-prompting.md) -- roles como variavel de template
- [../patterns/specific-task-prompts.md](../patterns/specific-task-prompts.md)
