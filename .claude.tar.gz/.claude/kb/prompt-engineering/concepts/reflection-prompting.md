# Reflection Prompting e Refinamento Iterativo

> **Purpose**: Instrui o modelo a criticar e reescrever seu proprio output em ciclos de qualidade
> **Confidence**: 0.95
> **MCP Validated**: 2026-05-10

## Overview

Reflection Prompting instrui o modelo a gerar uma resposta inicial, avaliar essa resposta
contra criterios especificos e reescreve-la antes de entregar o output final. Diferente do
Best-of-N (executar N vezes e comparar), aqui o modelo refina uma unica resposta em ciclos.
O Iterative Refinement e uma extensao onde cada prompt ataca uma dimensao especifica de
qualidade de forma independente.

**Fonte:** Prompt Engineering for Everyone — Iman Tavakoli (2026); Anthropic Claude Docs

## Padrao Answer → Reflect → Revise

```python
import anthropic

client = anthropic.Anthropic()

def reflection_prompt(document: str, task: str) -> str:
    prompt = f"""Escreva um resumo executivo do documento abaixo.

Apos escrever o rascunho, verifique se ele:
(a) cobre todas as conclusoes principais do documento,
(b) mantem tom consistentemente formal,
(c) usa terminologia adequada sem jargao desnecessario.

Entao revise o rascunho com base nesses criterios.

<document>
{document}
</document>

Retorne apenas a versao revisada final em <summary> tags."""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1000,
        temperature=0.0,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text
```

## Iterative Refinement: Fixed-Step Sequence

Cada etapa ataca uma dimensao especifica. Isola erros sem introduzir novos.

```python
def iterative_refinement(task: str, tone: str) -> str:
    # Estagio 1: Estrutura
    prompt_1 = f"Escreva um rascunho de {task}. Foco: estrutura e cobertura de conteudo."
    response_1 = get_completion(prompt_1)

    # Estagio 2: Tom
    prompt_2 = f"""Aqui esta o rascunho:
<draft>{response_1}</draft>

Ajuste o tom para {tone}. Nao altere o conteudo, apenas a forma de expressao."""
    response_2 = get_completion(prompt_2)

    # Estagio 3: Concisao
    prompt_3 = f"""Aqui esta a versao:
<draft>{response_2}</draft>

Reduza em 30% sem perder nenhuma informacao essencial."""
    return get_completion(prompt_3)
```

## Iterative Refinement: Adaptive (Baseado em Diagnostico)

```python
def adaptive_refinement(draft: str) -> str:
    # Estagio 1: Diagnostico
    diagnose_prompt = f"""Avalie este texto em 3 dimensoes: clareza, completude, tom.
Para cada dimensao, nota de 1-5 e o principal problema identificado.

<text>{draft}</text>

Retorne JSON: {{"clareza": {{"nota": N, "problema": "..."}},
               "completude": {{"nota": N, "problema": "..."}},
               "tom": {{"nota": N, "problema": "..."}}}}"""
    diagnosis = get_completion(diagnose_prompt)

    # Estagio 2: Patch direcionado
    patch_prompt = f"""Com base no diagnostico abaixo, corrija APENAS os problemas
identificados. Nao altere partes que ja estao boas.

Diagnostico: {diagnosis}
Rascunho: <draft>{draft}</draft>"""
    return get_completion(patch_prompt)
```

## Instrucoes Eficazes de Refinamento

| Instrucao Fraca | Instrucao Especifica |
|-----------------|----------------------|
| "Melhore isso." | "Simplifique a estrutura das frases sem alterar o significado." |
| "Revise." | "Reduza em 30% sem perder informacao essencial." |
| "Torne melhor." | "Ajuste o tom para formal sem adicionar jargao." |
| "Corrija os problemas." | "Identifique afirmacoes sem suporte textual e remova-as." |

## Riscos Conhecidos

- O modelo pode "supercorrigir" — simplificando ou hedging excessivamente
- Pode identificar apenas problemas superficiais sem capturar erros conceituais
- Supervisao humana e essencial em dominios criticos (saude, legal, financeiro)
- Ciclos excessivos (>3) raramente melhoram o output e aumentam custo

## Quando Usar

| Situacao | Tipo de Refinamento |
|----------|---------------------|
| Escrita executiva com tom critico | Answer → Reflect → Revise |
| Pipeline de qualidade por etapa | Fixed-Step Sequence |
| Diagnostico de qualidade desconhecido | Adaptive Refinement |
| Verificacao de fatos em documento | Chaining com verificacao |

## Related

- [chain-of-thought.md](chain-of-thought.md) — raciocinio antes da resposta inicial
- [self-ask-prompting.md](self-ask-prompting.md) — sub-perguntas antes da resposta
- [../patterns/prompt-optimization.md](../patterns/prompt-optimization.md) — A/B testing de versoes
- [../patterns/prompt-chaining.md](../patterns/prompt-chaining.md) — chaining entre etapas
