# Role Prompting

> **Purpose**: Atribuir personas e papeis ao LLM para controlar tom, profundidade e estilo
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-20

## Overview

Role prompting define uma persona para o modelo, influenciando vocabulario, nivel de
detalhe e perspectiva da resposta. Um "cientista de dados senior" responde diferente
de um "professor do ensino medio". Essencial para respostas com expertise especifica.

## The Pattern

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

llm = ChatOpenAI(model="gpt-4o", temperature=0.7)

# Role basico: definir persona no system message
response = llm.invoke([
    SystemMessage(content=(
        "Voce e um consultor financeiro senior com 20 anos de "
        "experiencia em investimentos de renda variavel. "
        "Sempre cite riscos e nunca de recomendacoes de compra direta."
    )),
    HumanMessage(content="Explique ETFs para um iniciante.")
])

# Role detalhado: experiencia + abordagem + restricoes
role_description = """Voce e um arquiteto de dados senior com as seguintes caracteristicas:
- Experiencia: 15 anos em data engineering, GCP, Spark
- Abordagem: pragmatica, orientada a custo-beneficio
- Formato: use diagramas ASCII quando relevante
- Restricoes: nao sugira servicos AWS, foque em GCP
- Tom: tecnico mas acessivel"""

response = llm.invoke([
    SystemMessage(content=role_description),
    HumanMessage(content="Projete uma pipeline de ingestao de dados JSON.")
])
```

## Quick Reference

| Role | Tom | Profundidade | Caso de Uso |
|------|-----|--------------|-------------|
| Escritor tecnico | Formal, preciso | Media | Documentacao |
| Professor | Didatico, paciente | Gradual | Explicacoes |
| Consultor | Pragmatico, direto | Alta | Decisoes |
| Cientista | Analitico, cauteloso | Alta | Pesquisa |
| Jornalista | Acessivel, objetivo | Media | Resumos |

## Craft de Role Descriptions

```python
# Template para role description completa
role_template = """Voce e um {titulo} com as seguintes caracteristicas:
- Experiencia: {anos} anos em {dominio}
- Especializacao: {areas}
- Abordagem: {estilo}
- Formato preferido: {formato}
- Restricoes: {restricoes}
- Publico-alvo: {publico}"""

# Exemplo instanciado
role = role_template.format(
    titulo="engenheiro de ML senior",
    anos=10,
    dominio="NLP e LLMs",
    areas="fine-tuning, RAG, prompt engineering",
    estilo="hands-on, orientado a codigo",
    formato="exemplos de codigo Python com comentarios",
    restricoes="use apenas bibliotecas open-source",
    publico="desenvolvedores pleno"
)
```

## Common Mistakes

### Wrong

```python
# Role generico demais
SystemMessage(content="Voce e um especialista.")
# Resultado: resposta generica sem direcao clara
```

### Correct

```python
# Role especifico com contexto e restricoes
SystemMessage(content=(
    "Voce e um DBA PostgreSQL com 10 anos de experiencia. "
    "Responda com queries SQL otimizadas. "
    "Sempre inclua EXPLAIN ANALYZE quando relevante. "
    "Nao sugira solucoes NoSQL."
))
```

## Comparacao de Roles

```python
# Mesmo prompt, diferentes roles = diferentes respostas
question = "O que e machine learning?"

roles = {
    "professor_fundamental": "Explique para criancas de 10 anos",
    "pesquisador_phd": "Discuta formalismos matematicos",
    "gerente_negocio": "Foque em ROI e casos de uso empresariais",
}
# Cada role gera resposta com vocabulario e profundidade distintos
```

## Role vs. Tone: Diferenca Critica

Role e Tone sao distintos e frequentemente confundidos:

| Aspecto | Role | Tone |
|---------|------|------|
| Definicao | Perspectiva e identidade atribuida | Qualidade emocional da linguagem |
| Exemplo | "Voce e um auditor de seguranca" | "Tom direto e sem rodeios" |
| Efeito | Muda o que o modelo prioriza | Muda como o modelo se expressa |
| Ambos juntos | "Voce e um coach executivo. Tom encorajador mas direto." | — |

Combinar Role + Tone gera controle fino sobre perspectiva E expressao.

## Limites de Role Fidelity

O modelo executa **simulacao linguistica**, nao expertise real:

```python
# O modelo "como cardiologista" usa linguagem e raciocinio de cardiologista,
# mas NAO tem acesso a conhecimento clinico nao presente no treinamento.
# Para decisoes criticas, role prompting nao substitui especialista humano.

SYSTEM = """Voce e um cardiologista sênior.
IMPORTANTE: Voce e um assistente de referencia geral.
Recomende sempre consulta medica para decisoes clinicas especificas.
Nao forneca diagnosticos — apenas informacao educacional."""
```

> Quanto mais especifico o role, mais o modelo ativa padroes linguisticos
> associados aquele dominio. Mas limitacoes de treinamento do modelo nao
> sao superadas pelo role.

## Vantagem do System Prompt vs User Prompt

| Localizacao | Quando Usar | Vantagem |
|-------------|-------------|----------|
| **System Prompt** | Persona persistente ao longo de toda a sessao | Nao pode ser sobrescrita por user prompt facilmente |
| **User Prompt** | Role especifico para uma unica tarefa | Flexibilidade por request |

Para manutencao de persona em chatbots de producao, use **sempre o system prompt**.
Roles definidos no user prompt sao mais facilmente contornados por usuarios.

## Related

- [zero-shot-prompting.md](zero-shot-prompting.md) -- role complementa zero-shot
- [multi-agent-prompting.md](multi-agent-prompting.md) -- multiplos roles simultaneos
- [../patterns/castroff-framework.md](../patterns/castroff-framework.md) -- Role como dimensao CASTROFF
- [../patterns/instruction-engineering.md](../patterns/instruction-engineering.md)
- [../patterns/specific-task-prompts.md](../patterns/specific-task-prompts.md)
