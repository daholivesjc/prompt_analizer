# Self-Ask Prompting

> **Purpose**: O modelo gera suas proprias sub-perguntas antes de responder, mapeando autonomamente o que precisa descobrir
> **Confidence**: 0.95
> **MCP Validated**: 2026-05-10

## Overview

No Self-Ask, o modelo identifica autonomamente quais sub-perguntas precisa responder para chegar
a resposta final. Diferente do CoT, onde o usuario define os passos, aqui o modelo descobre
e responde as proprias perguntas intermediarias. Especialmente util em perguntas compostas
ou multi-fator onde as dependencias entre informacoes nao sao obvias.

**Fonte:** AI Engineering — Chip Huyen (2026), Cap. 5; Prompt Engineering for Everyone — Iman Tavakoli (2026)

## Diferenca de Chain-of-Thought

| Aspecto | CoT | Self-Ask |
|---------|-----|----------|
| Quem define os passos | Usuario | Modelo |
| Estrutura | Passos predefinidos | Sub-perguntas geradas no momento |
| Melhor para | Processo com etapas conhecidas | Perguntas compostas/multi-fator |
| Autonomia | Baixa | Alta |

## Prompt de Ativacao

```python
PROMPT = """Antes de responder, identifique quais sub-perguntas voce precisa
responder para chegar a resposta final. Responda cada sub-pergunta explicitamente,
depois de sua resposta final.

Pergunta: {question}"""
```

## Fraseamentos de Ativacao

```
"Begin by identifying what you need to find out."
"Start with the questions you need answered first."
"What sub-questions must you answer to solve this?"
"Identifique as perguntas intermediarias antes de responder."
```

## Exemplo de Output Self-Ask

```
Pergunta: Qual o custo mensal de erros no processamento de faturas?

Sub-pergunta 1: Qual e o total de faturas processadas por mes?
Resposta: 12.500 faturas/mes

Sub-pergunta 2: Qual a taxa de erro atual?
Resposta: 3,2% (dados do sistema de monitoramento)

Sub-pergunta 3: Qual o custo medio por erro de processamento?
Resposta: R$ 45 (custo de retrabalho + validacao manual)

Calculo: 12.500 x 0,032 x R$ 45 = R$ 18.000/mes

Resposta final: O custo mensal de erros e aproximadamente R$ 18.000.
```

## Implementacao Python

```python
import anthropic

client = anthropic.Anthropic()

def self_ask(question: str) -> str:
    system = """Voce e um analista que resolve perguntas complexas de forma estruturada.
Ao receber uma pergunta composta, sempre:
1. Liste as sub-perguntas que precisa responder
2. Responda cada uma com dados especificos
3. Integre as respostas na resposta final"""

    prompt = f"""Resolva a pergunta abaixo usando o metodo Self-Ask:
identifique as sub-perguntas necessarias, responda cada uma,
depois formule a resposta final integrada.

Pergunta: {question}"""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1000,
        temperature=0.0,
        system=system,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text
```

## Casos de Uso Ideais

| Caso | Por que Self-Ask |
|------|-----------------|
| Perguntas sobre custo total (multiplos fatores) | Modelo decompoe fatores automaticamente |
| Analise de viabilidade de projeto | Identifica dependencias ocultas |
| Perguntas historicas com multiplas causas | Mapeia antecedentes necessarios |
| Decisoes com varios criterios de avaliacao | Estrutura criterios antes de recomendar |

## Quando NAO Usar

- Perguntas simples com resposta direta — overhead desnecessario
- Tarefas criativas sem perguntas factuais intermediarias
- Contextos onde o usuario ja definiu os passos (use CoT estruturado)

## Related

- [chain-of-thought.md](chain-of-thought.md) — alternativa com passos definidos pelo usuario
- [tree-of-thought.md](tree-of-thought.md) — multiplos caminhos paralelos
- [reflection-prompting.md](reflection-prompting.md) — revisao do output gerado
