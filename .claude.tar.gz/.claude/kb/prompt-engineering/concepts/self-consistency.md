# Self-Consistency

> **Purpose**: Gerar multiplos caminhos de raciocinio e agregar para respostas mais confiaveis
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-20

## Overview

Self-consistency gera N respostas independentes para a mesma pergunta e agrega os
resultados (votacao majoritaria ou analise por LLM). Reduz erros aleatorios e aumenta
confiabilidade, especialmente em problemas matematicos e factuais.

## The Pattern

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from collections import Counter

llm = ChatOpenAI(model="gpt-4o", temperature=0.7)  # temp > 0 para variar

def self_consistent_answer(question: str, n_paths: int = 5) -> dict:
    """Gera N respostas e agrega por votacao majoritaria."""

    # Etapa 1: gerar multiplos caminhos de raciocinio
    prompt = f"""Resolva o problema abaixo. Pense passo a passo.
Ao final, responda com RESPOSTA FINAL: [sua resposta]

Problema: {question}"""

    responses = []
    for _ in range(n_paths):
        result = llm.invoke([HumanMessage(content=prompt)])
        responses.append(result.content)

    # Etapa 2: extrair respostas finais
    answers = []
    for resp in responses:
        if "RESPOSTA FINAL:" in resp:
            answer = resp.split("RESPOSTA FINAL:")[-1].strip()
            answers.append(answer)

    # Etapa 3: votacao majoritaria
    counter = Counter(answers)
    best_answer, count = counter.most_common(1)[0]

    return {
        "answer": best_answer,
        "confidence": count / len(answers),
        "total_paths": n_paths,
        "agreement": count,
        "all_answers": dict(counter)
    }

result = self_consistent_answer(
    "Se 3 maquinas produzem 3 pecas em 3 minutos, "
    "quantas pecas 100 maquinas produzem em 100 minutos?"
)
```

## Quick Reference

| Parametro | Recomendado | Efeito |
|-----------|-------------|--------|
| `n_paths` | 5-10 | Mais paths = mais confiavel (mais caro) |
| `temperature` | 0.5-0.9 | Deve ser > 0 para gerar diversidade |
| Agregacao | Votacao majoritaria | Simples e eficaz para respostas curtas |

## Agregacao via LLM

```python
def aggregate_via_llm(question: str, responses: list[str]) -> str:
    """Usa o proprio LLM para sintetizar multiplas respostas."""
    aggregation_prompt = f"""Analise as {len(responses)} respostas abaixo
para a pergunta: "{question}"

{chr(10).join(f"Resposta {i+1}: {r}" for i, r in enumerate(responses))}

Determine a resposta mais provavel considerando:
1. Consenso entre as respostas
2. Qualidade do raciocinio
3. Correcao logica

Resposta final consolidada:"""

    result = llm.invoke([HumanMessage(content=aggregation_prompt)])
    return result.content
```

## Common Mistakes

### Wrong

```python
# Temperature = 0: todas as respostas iguais (inutil)
llm = ChatOpenAI(temperature=0)
# Nao ha diversidade para agregar
```

### Correct

```python
# Temperature > 0 para diversidade, multiplos paths
llm = ChatOpenAI(temperature=0.7)
# 5+ paths com votacao majoritaria
```

## Quando Usar Self-Consistency

| Cenario | Recomendado? | Motivo |
|---------|-------------|--------|
| Calculo matematico | Sim | Reduz erros de aritmetica |
| Pergunta factual critica | Sim | Aumenta confiabilidade |
| Geracao criativa | Nao | Nao ha resposta "correta" |
| Classificacao simples | Talvez | Custo alto para ganho marginal |

## Related

- [chain-of-thought.md](chain-of-thought.md) -- base para cada path de raciocinio
- [../patterns/evaluation-metrics.md](../patterns/evaluation-metrics.md)
- [../patterns/prompt-optimization.md](../patterns/prompt-optimization.md)
