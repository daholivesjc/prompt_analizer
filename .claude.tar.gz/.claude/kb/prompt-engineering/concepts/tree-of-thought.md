# Tree-of-Thought (ToT)

> **Purpose**: Exploracao de multiplos caminhos de raciocinio paralelos antes de convergir para uma conclusao
> **Confidence**: 0.95
> **MCP Validated**: 2026-05-10

## Overview

Tree-of-Thought e uma extensao do Chain-of-Thought onde o modelo explora N ramos de raciocinio
simultaneamente antes de sintetizar uma conclusao. E analogo a explorar varias ramificacoes de
uma arvore de decisao, em vez de seguir um unico caminho linear. Util em problemas onde nao ha
uma resposta unica correta e o espaco de solucoes precisa ser mapeado.

**Fonte:** AI Engineering — Chip Huyen (2026), Cap. 5; Prompt Engineering for Everyone — Iman Tavakoli (2026)

## Diferenca em relacao ao CoT

| Tecnica | Estrutura | Melhor Para |
|---------|-----------|-------------|
| **CoT** | Linear: passo 1 → 2 → 3 | Problemas com solucao unica |
| **ToT** | Ramificado: N caminhos → sintese | Trade-offs, analise de opcoes |
| **Self-Ask** | Auto-perguntas → respostas → conclusao | Perguntas compostas multi-etapa |

## Casos de Uso

- Politicas publicas e decisoes com stakeholders multiplos
- Design de sistemas com alternativas arquiteturais
- Analise de trade-offs sem resposta objetiva
- Qualquer situacao onde nao ha solucao unica correta

## Prompt

```
"O que sao tres estrategias viaveis para reduzir custos operacionais?
Para cada estrategia, liste beneficios e desvantagens.
Entao escolha a mais efetiva e justifique sua escolha."
```

## Template Python com Claude

```python
import anthropic

client = anthropic.Anthropic()

def tree_of_thought(decision_context: str, n_branches: int = 3) -> str:
    prompt = f"""Analise o problema abaixo usando Tree-of-Thought.

Problema: {decision_context}

Passo 1: Gere {n_branches} abordagens distintas e viaveis.
Para cada abordagem, apresente:
- Descricao em 2 frases
- Beneficios principais (2-3 pontos)
- Desvantagens e riscos (2-3 pontos)
- Condicoes em que esta opcao e superior

Passo 2: Compare as abordagens em uma tabela concisa.

Passo 3: Recomende uma abordagem com justificativa de 3 frases,
citando explicitamente os trade-offs que a tornam preferivel."""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1500,
        temperature=0.3,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text
```

## Instrucoes de Ativacao

| Fraseamento | Efeito |
|-------------|--------|
| "List N approaches, evaluate each, then choose." | ToT direto |
| "O que sao tres estrategias viaveis para X?" | ToT implicito |
| "Compare as alternativas e recomende a melhor." | ToT com sintese |
| "Explore multiple paths before concluding." | ToT generico |

## Limitacoes

- Sem instrucao de convergencia clara, a sintese pode ser superficial
- Muitos ramos sem hierarquia consomem tokens excessivos
- Para problemas com resposta objetiva, use CoT linear — ToT e desperdicio
- Nao garante que todos os ramos sao igualmente validos

## Quando NAO Usar ToT

| Situacao | Tecnica Melhor |
|----------|----------------|
| Problema matematico | CoT linear |
| Classificacao de sentimento | Zero-Shot ou Few-Shot |
| Tarefa criativa livre | Sem restricao de estrutura |
| Mais de 5 alternativas | Task Decomposition + Prompt Chaining |

## Related

- [chain-of-thought.md](chain-of-thought.md) — predecessor linear do ToT
- [self-ask-prompting.md](self-ask-prompting.md) — variacao com auto-perguntas
- [multi-agent-prompting.md](multi-agent-prompting.md) — perspectivas por roles
- [../patterns/task-decomposition.md](../patterns/task-decomposition.md)
