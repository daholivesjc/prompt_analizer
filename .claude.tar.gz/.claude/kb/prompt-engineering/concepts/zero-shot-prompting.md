# Zero-Shot Prompting

> **Purpose**: Executar tarefas sem exemplos previos -- depende apenas de instrucoes claras
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-20

## Overview

Zero-shot prompting permite que o LLM execute tarefas sem receber exemplos no prompt.
O modelo utiliza apenas as instrucoes e seu conhecimento pre-treinado. Funciona bem
para tarefas simples onde a descricao e suficiente para o modelo entender o esperado.

## The Pattern

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Zero-shot basico: especificacao direta da tarefa
response = llm.invoke([
    HumanMessage(content=(
        "Classifique o sentimento do texto abaixo como "
        "POSITIVO, NEGATIVO ou NEUTRO.\n\n"
        "Texto: 'O produto chegou rapido e funciona perfeitamente!'\n\n"
        "Sentimento:"
    ))
])

# Zero-shot com role-based prompting
response = llm.invoke([
    SystemMessage(content=(
        "Voce e um analista de sentimentos especialista. "
        "Responda apenas com: POSITIVO, NEGATIVO ou NEUTRO."
    )),
    HumanMessage(content="Texto: 'Entrega atrasada, produto com defeito.'")
])

# Zero-shot com format specification
response = llm.invoke([
    HumanMessage(content=(
        "Extraia as entidades do texto abaixo.\n\n"
        "Texto: 'Maria comprou 3 notebooks Dell na loja de SP.'\n\n"
        "Responda em JSON com as chaves: "
        "pessoa, quantidade, produto, marca, local."
    ))
])
```

## Quick Reference

| Variante | Descricao | Uso |
|----------|-----------|-----|
| Direta | Instrucao simples sem contexto | Tarefas triviais |
| Role-based | System message define persona | Tom/expertise especifica |
| Format spec | Exige formato de saida | Output estruturado |
| Multi-step | Solicita raciocinio em etapas | Tarefas compostas |

## Common Mistakes

### Wrong

```python
# Prompt vago sem formato de saida
response = llm.invoke([
    HumanMessage(content="Fale sobre o texto: 'O servico foi horrivel'")
])
# Resultado: resposta livre e imprevisivel
```

### Correct

```python
# Prompt claro com tarefa, formato e restricao
response = llm.invoke([
    HumanMessage(content=(
        "Classifique o sentimento como POSITIVO, NEGATIVO ou NEUTRO.\n"
        "Responda APENAS com a classificacao, sem explicacao.\n\n"
        "Texto: 'O servico foi horrivel'\n"
        "Sentimento:"
    ))
])
# Resultado: "NEGATIVO"
```

## Quando Usar vs. Quando Evitar

| Cenario | Recomendacao |
|---------|--------------|
| Classificacao binaria/ternaria | Zero-shot funciona bem |
| Extracao de entidades simples | Zero-shot com format spec |
| Tarefas com nuances de dominio | Prefira few-shot |
| Problemas matematicos complexos | Prefira chain-of-thought |

## Related

- [few-shot-learning.md](few-shot-learning.md) -- quando zero-shot nao e suficiente
- [role-prompting.md](role-prompting.md) -- complementa zero-shot com personas
- [../patterns/instruction-engineering.md](../patterns/instruction-engineering.md)
