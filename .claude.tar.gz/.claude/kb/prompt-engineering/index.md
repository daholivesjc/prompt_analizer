# Prompt Engineering Knowledge Base

> **Purpose**: Tecnicas de prompt engineering para LLMs -- zero-shot, few-shot, CoT, seguranca, otimizacao e templates
> **MCP Validated**: 2026-05-10

## Quick Navigation

### Concepts (< 150 linhas cada)

| Arquivo | Proposito |
|---------|-----------|
| [concepts/zero-shot-prompting.md](concepts/zero-shot-prompting.md) | Execucao de tarefas sem exemplos previos |
| [concepts/few-shot-learning.md](concepts/few-shot-learning.md) | Aprendizado com poucos exemplos; custo de tokens; achado Microsoft 2023 |
| [concepts/chain-of-thought.md](concepts/chain-of-thought.md) | Raciocinio passo a passo; tabela de todas as variacoes; quando nao usar |
| [concepts/role-prompting.md](concepts/role-prompting.md) | Atribuicao de personas; Role vs Tone; limites de role fidelity |
| [concepts/self-consistency.md](concepts/self-consistency.md) | Multiplos caminhos de raciocinio com agregacao |
| [concepts/negative-prompting.md](concepts/negative-prompting.md) | Especificar exclusoes e restricoes negativas |
| [concepts/ambiguity-clarity.md](concepts/ambiguity-clarity.md) | Identificar e resolver ambiguidade em prompts |
| [concepts/prompt-templates.md](concepts/prompt-templates.md) | Templates reutilizaveis com Jinja2 |
| [concepts/tree-of-thought.md](concepts/tree-of-thought.md) | ToT: multiplos caminhos paralelos → sintese; diferenca de CoT |
| [concepts/self-ask-prompting.md](concepts/self-ask-prompting.md) | Modelo gera sub-perguntas; diferenca de CoT; ativacao |
| [concepts/multi-agent-prompting.md](concepts/multi-agent-prompting.md) | Simulacao de perspectivas multiplas; papeis profissionais; etica |
| [concepts/reflection-prompting.md](concepts/reflection-prompting.md) | Answer→Reflect→Revise; Iterative Refinement fixed e adaptive; riscos |
| [concepts/in-context-learning.md](concepts/in-context-learning.md) | ICL como continual learning; diferenca de few-shot; schemas novos |
| [concepts/prompt-robustness.md](concepts/prompt-robustness.md) | Teste de perturbacao; correlacao robustez-capacidade; implicacoes praticas |

### Patterns (< 200 linhas cada)

| Arquivo | Proposito |
|---------|-----------|
| [patterns/prompt-chaining.md](patterns/prompt-chaining.md) | Encadear prompts; paralelizacao; modelo por etapa; GoDaddy case |
| [patterns/task-decomposition.md](patterns/task-decomposition.md) | Decompor tarefas complexas em subtarefas |
| [patterns/constrained-generation.md](patterns/constrained-generation.md) | Controlar saidas com restricoes de formato |
| [patterns/instruction-engineering.md](patterns/instruction-engineering.md) | Craft de instrucoes claras e efetivas |
| [patterns/prompt-formatting.md](patterns/prompt-formatting.md) | Impacto de formatos; lost-in-the-middle; posicionamento |
| [patterns/prompt-optimization.md](patterns/prompt-optimization.md) | A/B testing; robustez como metrica; Iterative Refinement por dimensao |
| [patterns/evaluation-metrics.md](patterns/evaluation-metrics.md) | Metricas de qualidade; Violation Rate; False Refusal Rate; red-teaming |
| [patterns/prompt-security.md](patterns/prompt-security.md) | Prevencao de prompt injection; sanitizacao; Instruction Hierarchy |
| [patterns/multilingual-prompting.md](patterns/multilingual-prompting.md) | Design de prompts multi-idioma |
| [patterns/prompt-length-management.md](patterns/prompt-length-management.md) | Gerenciar tamanho e contexto longo |
| [patterns/ethical-prompting.md](patterns/ethical-prompting.md) | Mito dos prompts neutros; 4 principios; reframing inclusivo; epistemic care |
| [patterns/specific-task-prompts.md](patterns/specific-task-prompts.md) | Templates SOP, Analise Comparativa, Pipeline Modular, Intent Chain |
| [patterns/castroff-framework.md](patterns/castroff-framework.md) | 8 dimensoes de design e auditoria; Ladder de Constraints; repair before/after |
| [patterns/prompt-debug-protocol.md](patterns/prompt-debug-protocol.md) | 6 etapas Reproduce→Document; tecnicas complementares; bug report template |
| [patterns/advanced-security.md](patterns/advanced-security.md) | Taxonomia completa de ataques; PAIR; Indirect Injection; defesas de sistema |
| [patterns/prompt-production-management.md](patterns/prompt-production-management.md) | Versionamento; Pydantic schema; lifecycle; riscos de ferramentas automatizadas |
| [patterns/lost-in-the-middle.md](patterns/lost-in-the-middle.md) | Posicionamento estrategico; tabela de posicoes ideais; variacao por modelo |

### Specs (Machine-Readable)

| Arquivo | Proposito |
|---------|-----------|
| [specs/technique-catalog.yaml](specs/technique-catalog.yaml) | Catalogo completo de tecnicas com metadados |
| [specs/attack-taxonomy.yaml](specs/attack-taxonomy.yaml) | Taxonomia machine-readable de ataques (3 tipos; metricas; ferramentas) |

---

## Quick Reference

- [quick-reference.md](quick-reference.md) - Tabelas de consulta rapida

---

## Conceitos Chave

| Conceito | Descricao |
|----------|-----------|
| **Zero-Shot** | Tarefa sem exemplos -- depende de instrucoes claras |
| **Few-Shot** | 2-5 exemplos no prompt guiam o modelo |
| **Chain-of-Thought** | "Pense passo a passo" melhora raciocinio |
| **Tree-of-Thought** | N caminhos paralelos → sintese -- melhor para trade-offs |
| **Self-Ask** | Modelo gera suas proprias sub-perguntas |
| **Role Prompting** | Persona define tom, profundidade e estilo |
| **CASTROFF** | 8 dimensoes para design e auditoria de prompts |
| **Reflection** | Answer → Reflect → Revise em ciclo |

---

## Trilha de Aprendizado

| Nivel | Arquivos |
|-------|----------|
| **Iniciante** | concepts/zero-shot-prompting.md, concepts/few-shot-learning.md |
| **Intermediario** | concepts/chain-of-thought.md, patterns/instruction-engineering.md, patterns/castroff-framework.md |
| **Avancado** | patterns/prompt-optimization.md, patterns/advanced-security.md, concepts/reflection-prompting.md |
| **Producao** | patterns/prompt-production-management.md, patterns/prompt-debug-protocol.md |

---

## Uso por Agentes

| Agente | Arquivos Primarios | Caso de Uso |
|--------|---------------------|-------------|
| llm-developer | patterns/prompt-chaining.md, patterns/castroff-framework.md | Construir e auditar pipelines |
| qa-engineer | patterns/evaluation-metrics.md, concepts/prompt-robustness.md | Avaliar qualidade de prompts |
| security-reviewer | patterns/advanced-security.md, specs/attack-taxonomy.yaml | Auditar seguranca de prompts |
| ai-prompt-specialist | concepts/tree-of-thought.md, concepts/self-ask-prompting.md | Tecnicas avancadas de raciocinio |

---

## Versao

| Data | Mudancas |
|------|----------|
| 2026-04-20 | Versao inicial (8 concepts, 12 patterns) |
| 2026-05-10 | +6 concepts, +5 patterns, +1 spec; enriquecimento de 10 arquivos existentes |
