# CASTROFF Framework

> **Purpose**: Framework de 8 dimensoes para design e auditoria profissional de prompts
> **Confidence**: 0.95
> **MCP Validated**: 2026-05-10

## Overview

CASTROFF e um framework de auditoria e design de prompts com 8 dimensoes. Util tanto para
escrever prompts novos quanto para diagnosticar prompts com performance abaixo do esperado.
Cada letra representa uma dimensao critica que, se ausente, causa um tipo especifico de falha.

**C**onstraints — **A**udience — **S**tructure — **T**one — **R**ole — **O**utput Format — **F**ocus — **F**unction

**Fonte:** Prompt Engineering for Everyone — Iman Tavakoli (2026)

## Tabela de Dimensoes

| Dimensao | Definicao | Bom Exemplo | Fraco Exemplo | Armadilha |
|----------|-----------|-------------|---------------|-----------|
| **Constraints** | Limites de comprimento, escopo ou formato | "Em 150 palavras, usando bullet points." | "Explique brevemente." | Limites vagos geram verbosidade |
| **Audience** | Contexto do leitor/usuario | "Para gestores sem background tecnico." | "Resuma isso." | Voz generalista como padrao |
| **Structure** | Organizacao interna das instrucoes | "Primeiro liste causas, depois efeitos." | "Explique causas e efeitos." | Instrucoes planas geram incoerencia |
| **Tone** | Qualidade emocional da linguagem | "Tom empatico e direto." | "Escreva isso." | Tom padrao neutro e verboso |
| **Role** | Identidade/perspectiva atribuida ao modelo | "Aja como auditor de seguranca." | "De conselhos." | Ambiguidade de role confunde voz |
| **Output Format** | Forma de entrega da resposta | "Tabela com 3 colunas: X, Y, Z." | "Liste pontos." | Prosa quando dado estruturado e necessario |
| **Focus** | Prioridade tematica da resposta | "Enfatize riscos, nao beneficios." | "Discuta o topico." | Deriva para tangentes |
| **Function** | Proposito comunicativo da saida | "Critique para conformidade legal." | "Escreva sobre isso." | Proposito desalinhado reduz valor |

## CASTROFF como Diagnostico de Prompt Fraco

Quando um prompt falha, mapeie cada dimensao:

```
Output verboso sem foco   → Constraints e Focus ausentes
Tom inadequado            → Tone nao especificado ou Role ambiguo
Conteudo correto mas inutil → Function nao foi explicitada
Resposta para audiencia errada → Audience nao especificado
Estrutura desconexa       → Structure nao definida
Formato incorreto         → Output Format ausente
```

## Template de Auditoria CASTROFF

```python
def castroff_audit(prompt: str) -> dict:
    """Audita prompt contra as 8 dimensoes CASTROFF."""
    dimensions = {
        "constraints": "O prompt especifica limites de comprimento/escopo/formato?",
        "audience": "O prompt define para quem a resposta e direcionada?",
        "structure": "O prompt organiza as instrucoes com sequencia logica?",
        "tone": "O prompt especifica qualidade emocional/estilo da linguagem?",
        "role": "O prompt atribui uma identidade ou perspectiva ao modelo?",
        "output_format": "O prompt especifica o formato exato da saida?",
        "focus": "O prompt define prioridade tematica ou o que enfatizar?",
        "function": "O prompt deixa claro o proposito comunicativo da resposta?",
    }

    missing = []
    for dim, question in dimensions.items():
        # Logica de verificacao por dimensao
        # (implementacao especifica ao contexto de uso)
        pass

    return {
        "prompt": prompt,
        "missing_dimensions": missing,
        "recommendation": f"Adicione: {', '.join(missing)}" if missing else "Completo"
    }
```

## Exemplos de Repair Antes/Depois

### Proposito Ambiguo

```
Antes: "Pode me ajudar a escrever algo sobre mudancas climaticas para uma escola?"

Depois: "Escreva um resumo de 300 palavras sobre as causas das mudancas climaticas
para alunos do ensino medio, usando linguagem simples, tom neutro e um exemplo
do mundo real."
[Dimensoes adicionadas: Constraints, Audience, Tone, Function]
```

### Tom Inadequado em Contexto Sensivel

```
Antes: "Escreva uma mensagem para alguem que perdeu o emprego dizendo para
manter o positivo."

Depois: "Componha uma mensagem curta e empatica oferecendo apoio a um colega
que foi demitido recentemente. Evite cliches e mantenha tom de respeito e
solidariedade."
[Dimensoes adicionadas: Constraints, Audience, Tone, Function]
```

### Formato Ausente em Contexto Profissional

```
Antes: "Compare fontes de energia renovavel."

Depois: "Crie uma tabela de duas colunas comparando energia solar, eolica e
hidreletrica com base em custo, disponibilidade e impacto ambiental, usando
frases concisas adequadas para um briefing de politica publica."
[Dimensoes adicionadas: Output Format, Constraints, Audience, Focus, Function]
```

## Ladder de Constraints (Escala de Restricoes)

| Nivel | Descricao | Exemplo | Quando Usar |
|-------|-----------|---------|-------------|
| **Soft** | Preferencias gerais | "Use linguagem simples" | Exploracao criativa |
| **Medium** | Limites definidos | "Maximo 200 palavras; estilo formal" | Uso padrao |
| **Hard** | Estrutura obrigatoria | "Retorne apenas JSON com esses campos exatos" | Alto risco, parsing automatico |

## Checklist de Producao

Antes de colocar um prompt em producao, verifique cada dimensao:

```
[ ] C — Limites de comprimento e escopo definidos?
[ ] A — Audiencia especificada?
[ ] S — Sequencia de instrucoes logica?
[ ] T — Tom especificado?
[ ] R — Role definido?
[ ] O — Formato de output especificado?
[ ] F (Focus) — Prioridade tematica definida?
[ ] F (Function) — Proposito comunicativo claro?
```

## Related

- [../patterns/prompt-debug-protocol.md](../patterns/prompt-debug-protocol.md) — protocolo de debugging que usa CASTROFF
- [../concepts/role-prompting.md](../concepts/role-prompting.md) — dimensao Role em detalhe
- [../patterns/instruction-engineering.md](../patterns/instruction-engineering.md) — craft de instrucoes
