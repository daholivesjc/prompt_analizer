# Constrained Generation

> **Purpose**: Controlar saidas do LLM com restricoes de tom, formato, tamanho e conteudo
> **MCP Validated**: 2026-04-20

## When to Use

- Output precisa seguir formato rigido (JSON, YAML, tabela)
- Restricoes de negocio no conteudo (tom profissional, sem opiniao)
- Geracao de documentos com estrutura obrigatoria (job posting, contrato)
- Validacao pos-geracao necessaria para garantir conformidade

## Implementation

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
import re
import json

llm = ChatOpenAI(model="gpt-4o", temperature=0)


def constrained_generate(
    task: str,
    constraints: dict,
    max_retries: int = 2
) -> dict:
    """Gera output com restricoes e valida automaticamente.

    Args:
        task: descricao da tarefa de geracao
        constraints: dict com restricoes (tone, max_words, format, excluded_words)
        max_retries: tentativas de regeneracao se validacao falhar

    Returns:
        dict com output validado e metadata
    """
    # Construir prompt com restricoes explicitas
    constraint_text = "\n".join([
        f"- Tom: {constraints.get('tone', 'profissional')}",
        f"- Maximo de palavras: {constraints.get('max_words', 500)}",
        f"- Formato: {constraints.get('format', 'texto livre')}",
    ])

    if constraints.get("excluded_words"):
        excluded = ", ".join(constraints["excluded_words"])
        constraint_text += f"\n- Palavras PROIBIDAS: {excluded}"

    if constraints.get("required_sections"):
        sections = ", ".join(constraints["required_sections"])
        constraint_text += f"\n- Secoes OBRIGATORIAS: {sections}"

    prompt = f"""{task}

RESTRICOES OBRIGATORIAS:
{constraint_text}

Resposta:"""

    for attempt in range(max_retries + 1):
        response = llm.invoke([HumanMessage(content=prompt)])
        output = response.content

        # Validar restricoes
        validation = _validate_constraints(output, constraints)
        if validation["valid"]:
            return {"output": output, "valid": True, "attempt": attempt + 1}

        # Adicionar feedback para retry
        prompt += f"\n\n[TENTATIVA {attempt + 1} FALHOU: {validation['issues']}]\nCorreija:"

    return {"output": output, "valid": False, "issues": validation["issues"]}


def _validate_constraints(text: str, constraints: dict) -> dict:
    """Valida se o texto atende todas as restricoes."""
    issues = []

    max_words = constraints.get("max_words")
    if max_words and len(text.split()) > max_words:
        issues.append(f"Excedeu {max_words} palavras ({len(text.split())})")

    for word in constraints.get("excluded_words", []):
        if re.search(rf'\b{re.escape(word)}\b', text, re.IGNORECASE):
            issues.append(f"Palavra proibida: '{word}'")

    for section in constraints.get("required_sections", []):
        if section.upper() not in text.upper():
            issues.append(f"Secao ausente: '{section}'")

    return {"valid": len(issues) == 0, "issues": issues}
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `tone` | `"profissional"` | Tom da escrita |
| `max_words` | `500` | Limite de palavras |
| `format` | `"texto livre"` | Formato de saida |
| `excluded_words` | `[]` | Palavras proibidas |
| `required_sections` | `[]` | Secoes obrigatorias |
| `max_retries` | `2` | Tentativas de correcao |

## Example Usage

```python
# Gerar job posting com restricoes
result = constrained_generate(
    task="Escreva uma vaga para Engenheiro de Dados Senior",
    constraints={
        "tone": "profissional e inclusivo",
        "max_words": 300,
        "format": "secoes com headers",
        "excluded_words": ["ninja", "rockstar", "guru"],
        "required_sections": [
            "EMPRESA", "RESPONSABILIDADES", "QUALIFICACOES", "BENEFICIOS"
        ],
    }
)

if result["valid"]:
    print(result["output"])
else:
    print(f"Nao passou na validacao: {result['issues']}")

# Gerar review estruturado
result = constrained_generate(
    task="Escreva uma review do produto 'Headphone XYZ'",
    constraints={
        "tone": "objetivo e tecnico",
        "max_words": 200,
        "required_sections": ["RATING", "PROS", "CONTRAS", "RECOMENDACAO"],
        "excluded_words": ["incrivel", "perfeito", "lixo"],
    }
)
```

## RegexParser para Validacao de Estrutura

```python
def parse_structured_output(text: str, pattern: str) -> dict | None:
    """Extrai campos de output estruturado usando regex."""
    match = re.search(pattern, text, re.DOTALL)
    return match.groupdict() if match else None

# Exemplo: extrair rating e recomendacao
pattern = r"RATING:\s*(?P<rating>\d+/\d+).*?RECOMENDACAO:\s*(?P<rec>.+?)$"
parsed = parse_structured_output(result["output"], pattern)
```

## See Also

- [../concepts/negative-prompting.md](../concepts/negative-prompting.md) -- restricoes negativas
- [instruction-engineering.md](instruction-engineering.md) -- instrucoes claras
- [evaluation-metrics.md](evaluation-metrics.md) -- medir conformidade
