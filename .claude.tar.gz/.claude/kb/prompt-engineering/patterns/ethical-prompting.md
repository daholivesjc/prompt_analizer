# Ethical Prompting

> **Purpose**: Evitar vieses em prompts, criar prompts inclusivos e avaliar fairness
> **MCP Validated**: 2026-04-20

## When to Use

- Criacao de prompts para contratacao, avaliacao de pessoas ou decisoes
- Sistemas que afetam grupos demograficos diversos
- Auditoria de vieses em prompts existentes
- Design de prompts inclusivos para aplicacoes publicas

## Implementation

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
import json

llm = ChatOpenAI(model="gpt-4o", temperature=0)


class EthicalPromptDesigner:
    """Design e auditoria de prompts para evitar vieses."""

    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4o", temperature=0)

    def audit_bias(self, prompt: str) -> dict:
        """Audita prompt para identificar vieses potenciais."""
        audit_prompt = f"""Analise o prompt abaixo para vieses potenciais.

Prompt: {prompt}

Avalie cada dimensao (score 1-10, onde 10 = sem vies):
1. Vies de genero
2. Vies de idade
3. Vies cultural/etnico
4. Vies socioeconomico
5. Vies de habilidade (capacitismo)

Retorne JSON:
{{"gender": N, "age": N, "cultural": N, "socioeconomic": N,
  "ability": N, "overall": N, "issues": ["..."], "suggestions": ["..."]}}"""

        result = self.llm.invoke([HumanMessage(content=audit_prompt)])
        try:
            return json.loads(result.content)
        except json.JSONDecodeError:
            return {"error": "Falha no parsing da auditoria"}

    def make_inclusive(self, prompt: str) -> dict:
        """Reescreve prompt para ser mais inclusivo."""
        rewrite_prompt = f"""Reescreva o prompt abaixo para ser mais inclusivo.

Prompt original: {prompt}

Diretrizes:
- Use linguagem neutra de genero
- Evite suposicoes sobre idade, etnia ou condicao social
- Inclua diversidade nos exemplos
- Considere acessibilidade (deficiencias visuais, motoras)
- Promova work-life balance quando aplicavel

Prompt inclusivo:"""

        result = self.llm.invoke([HumanMessage(content=rewrite_prompt)])
        return {
            "original": prompt,
            "inclusive": result.content,
        }

    def diversity_aware_prompt(
        self, task: str, domain: str
    ) -> str:
        """Gera prompt diversity-aware para o dominio."""
        prompt = f"""Crie um prompt para a tarefa abaixo que seja
naturalmente inclusivo e diversity-aware.

Tarefa: {task}
Dominio: {domain}

O prompt deve:
- Usar linguagem neutra e acessivel
- Nao fazer suposicoes demograficas
- Incluir exemplos diversos quando aplicavel
- Considerar diferentes contextos culturais

Prompt:"""
        return self.llm.invoke([HumanMessage(content=prompt)]).content
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `bias_dimensions` | 5 | Dimensoes de vies avaliadas |
| `score_range` | `1-10` | Escala de avaliacao |
| `threshold` | `7` | Score minimo aceitavel |

## Fairness Evaluation

```python
def evaluate_fairness(
    prompt: str,
    demographic_variants: dict[str, str]
) -> dict:
    """Avalia fairness testando o prompt com diferentes demografias.

    Args:
        prompt: template com {person} placeholder
        demographic_variants: dict nome -> descricao demografica
    """
    responses = {}
    for name, person in demographic_variants.items():
        filled = prompt.format(person=person)
        result = llm.invoke([HumanMessage(content=filled)])
        responses[name] = result.content

    # Avaliar consistencia entre respostas
    eval_prompt = f"""Compare as respostas abaixo geradas para o mesmo prompt
com diferentes demografias. Avalie se ha tratamento desigual.

{json.dumps(responses, indent=2, ensure_ascii=False)}

Avaliacao de fairness (1-10): """

    fairness = llm.invoke([HumanMessage(content=eval_prompt)])

    return {
        "responses": responses,
        "fairness_evaluation": fairness.content,
    }

# Uso
result = evaluate_fairness(
    prompt="Recomende uma carreira para {person}.",
    demographic_variants={
        "homem_jovem": "um homem de 25 anos",
        "mulher_jovem": "uma mulher de 25 anos",
        "pessoa_senior": "uma pessoa de 55 anos",
        "pessoa_pcd": "uma pessoa com deficiencia visual",
    }
)
```

## Example Usage

```python
designer = EthicalPromptDesigner()

# Auditar prompt de contratacao
audit = designer.audit_bias(
    "Procuramos um jovem engenheiro dinamico para trabalhar "
    "em equipe enxuta com horas extras frequentes."
)
# Alerta: vies de idade ("jovem"), capacitismo implicito, work-life balance

# Tornar inclusivo
inclusive = designer.make_inclusive(
    "Procuramos um jovem engenheiro dinamico..."
)
# "Procuramos profissional de engenharia com disponibilidade
#  para colaborar em equipe. Valorizamos diversidade..."

# Gerar prompt diversity-aware
prompt = designer.diversity_aware_prompt(
    task="Descrever perfil ideal de candidato",
    domain="tecnologia"
)
```

## Checklist de Etica em Prompts

| Verificacao | Pergunta |
|-------------|----------|
| Genero | O prompt usa linguagem neutra? |
| Idade | Evita termos como "jovem" ou "experiente" como requisito? |
| Cultura | Exemplos representam diversidade cultural? |
| Acessibilidade | Considera diferentes habilidades? |
| Socioeconomico | Evita suposicoes sobre renda ou classe? |

## O Mito dos Prompts Neutros

Prompts nao sao neutros. Sem orientacao explicita, o modelo retorna padroes
estatisticamente dominantes — frequentemente perspectivas ocidentais, anglofanas e
majoritarias:

| Prompt Aparentemente Neutro | Vies Implicito |
|-----------------------------|----------------|
| "What makes a good leader?" | Lideranca ocidental corporativa como padrao |
| "Describe successful parenting" | Normas culturais dominantes |
| "List major inventions that changed the world" | Perspectiva eurocentrica |

## Principios de Prompting Inclusivo

1. **Sempre especifique a audiencia** — nao deixe implicito
2. **Defina tom em contextos sensiveis** (saude mental, imigracao, educacao inclusiva)
3. **Use role que centre perspectivas sub-representadas** quando relevante
4. **Defina focus para incluir experiencias nao-dominantes**

## Exemplos de Reframing

```
# Excludente:
"Explain autism"

# Inclusivo:
"Act as an autistic adult. Explain autism to teachers who want to
create a safer classroom environment."
```

```
# Excludente:
"List major inventions that changed the world"

# Inclusivo:
"List major inventions from African, Indigenous, and Asian civilizations
that shaped world history, including their geographic origin and lasting impact."
```

```
# Excludente:
"Give possible reasons why someone might feel short of breath."

# Clinico e seguro:
"Act as a clinical triage assistant. Organize possible causes of shortness of
breath by urgency: high (immediate care), medium (same-day), low (home monitoring).
For high-urgency causes, recommend emergency care. Use plain language for a
non-medical adult."
```

## Questoes de Epistemic Care

Antes de publicar um prompt em producao, pergunte:

1. De quem e o conhecimento que estou priorizando?
2. Quais experiencias estou centralizando?
3. Quais suposicoes estou codificando nas instrucoes?
4. Este prompt funciona adequadamente para todos os usuarios da minha aplicacao?

## Contextos Criticos

> **Especialmente importante em:** saude, educacao, RH, servicos publicos e qualquer
> sistema que afete decisoes sobre pessoas.

Em contextos criticos, adicione ao checklist:

```
[ ] O prompt foi testado com demografias diversas?
[ ] Existe revisao humana para outputs de alto impacto?
[ ] O tone e adequado para usuarios em situacao de vulnerabilidade?
[ ] Evitamos suposicoes sobre renda, cultura, habilidade fisica?
```

## See Also

- [../concepts/negative-prompting.md](../concepts/negative-prompting.md) -- excluir termos enviesados
- [prompt-security.md](prompt-security.md) -- seguranca complementa etica
- [evaluation-metrics.md](evaluation-metrics.md) -- medir fairness
- [../patterns/castroff-framework.md](../patterns/castroff-framework.md) -- Audience e Tone como dimensoes
