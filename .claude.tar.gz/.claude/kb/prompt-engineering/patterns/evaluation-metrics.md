# Evaluation Metrics

> **Purpose**: Metricas e estrategias para avaliar qualidade de prompts e respostas de LLMs
> **MCP Validated**: 2026-04-20
> **Fonte adicional**: "Measuring the Unmeasurable" — Rohit Kulkarni (Medium, Sep 2025)

## When to Use

- Comparar prompts sistematicamente com dados numericos
- Monitorar qualidade de prompts em producao
- Definir baselines e targets para otimizacao
- Combinar avaliacao humana com automatizada (abordagem hibrida)
- Integrar avaliacao em pipelines CI/CD

## Taxonomia de Metricas

| Categoria | Metricas | Foco |
|-----------|----------|------|
| **N-gram (lexical)** | BLEU, ROUGE | Sobreposicao de palavras com referencia |
| **Semantica (learned)** | BERTScore, Perplexity | Similaridade vetorial contextual |
| **Via LLM (judge)** | Relevance, Faithfulness, Correctness | LLM avalia LLM com rubrica |
| **Customizadas** | Specificity, Consistency, Combined | Metricas proprias do projeto |

### Metricas Tradicionais (N-gram)

| Metrica | Definicao | Melhor Para |
|---------|-----------|-------------|
| **BLEU** | Precisao de n-grams entre candidato e referencia | Traducao, geracao controlada |
| **ROUGE-N** | Recall de n-grams entre gerado e referencia | Sumarizacao |
| **ROUGE-L** | Longest Common Subsequence (LCS) | Sumarizacao longa |
| **F1 Score** | Harmonica de precision/recall | Classificacao, QA |

### Metricas Aprendidas (Semantic)

| Metrica | Definicao | Vantagem |
|---------|-----------|----------|
| **BERTScore** | Similaridade coseno com embeddings BERT | Reconhece parafrases |
| **Perplexity** | Quao bem o modelo previu o texto | Menor = modelo mais confiante |

### LLM-as-a-Judge

Paradigma hibrido onde um LLM forte avalia output de outro LLM via rubrica estruturada.
Produz score numerico (1-5), ranking comparativo ou classificacao binaria + justificativa.

## Implementation

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
import json

llm = ChatOpenAI(model="gpt-4o", temperature=0)


class PromptEvaluator:
    """Avaliador de prompts com metricas automatizadas e LLM-as-a-Judge."""

    def __init__(self, evaluator_model: str = "gpt-4o"):
        self.evaluator = ChatOpenAI(model=evaluator_model, temperature=0)

    def relevance_score(self, question: str, response: str) -> float:
        """Avalia relevancia semantica (0-1) via LLM-as-a-Judge."""
        prompt = f"""Avalie a relevancia da resposta para a pergunta.
Retorne APENAS um numero de 0.0 a 1.0.

Pergunta: {question}
Resposta: {response}

Score:"""
        result = self.evaluator.invoke([HumanMessage(content=prompt)])
        try:
            return float(result.content.strip())
        except ValueError:
            return 0.5

    def consistency_score(self, question: str, responses: list[str]) -> float:
        """Mede consistencia entre multiplas respostas (0-1)."""
        if len(responses) < 2:
            return 1.0
        prompt = f"""Compare as {len(responses)} respostas abaixo.
Retorne APENAS um score 0.0-1.0 (1.0 = consistentes, 0.0 = contraditorias).

Pergunta: {question}
{chr(10).join(f"Resposta {i+1}: {r}" for i, r in enumerate(responses))}

Score:"""
        result = self.evaluator.invoke([HumanMessage(content=prompt)])
        try:
            return float(result.content.strip())
        except ValueError:
            return 0.5

    def llm_judge(self, question: str, response: str, criteria: list[str]) -> dict:
        """LLM-as-a-Judge multi-criterio com justificativa."""
        criteria_text = "\n".join(f"- {c}" for c in criteria)
        prompt = f"""Avalie a resposta nos criterios abaixo. Para cada um, de um
score de 1 a 5 e uma justificativa de 1 linha.
Retorne JSON: {{"criterio": {{"score": N, "reason": "..."}}}}

Criterios:
{criteria_text}

Pergunta: {question}
Resposta: {response}

JSON:"""
        result = self.evaluator.invoke([HumanMessage(content=prompt)])
        try:
            return json.loads(result.content.strip())
        except json.JSONDecodeError:
            return {c: {"score": 3, "reason": "parse error"} for c in criteria}

    def evaluate_prompt(self, question: str, response: str) -> dict:
        """Avaliacao completa: metricas custom + LLM-as-a-Judge."""
        judge_result = self.llm_judge(
            question, response,
            ["relevancia", "clareza", "completude", "factualidade"]
        )
        words = response.lower().split()
        unique = set(words) - {"a", "o", "e", "de", "do", "da", "the", "is", "and"}
        return {
            "judge_scores": judge_result,
            "specificity": len(unique) / len(words) if words else 0.0,
            "word_count": len(words),
        }
```

## Frameworks Open-Source

| Framework | Foco | Destaque |
|-----------|------|----------|
| **DeepEval** | Unit tests para LLMs (estilo Pytest) | 50+ metricas, RAG (Faithfulness, Relevancy) |
| **LangChain Eval** | Ciclo completo via LangSmith | QAEvalChain, CriteriaEvalChain, openevals |
| **TruLens** | Instrumentacao e tracing | Feedback functions, custo/latencia por run |
| **Promptfoo** | Test-driven via CLI/YAML | Assertions declarativas, sem codigo |
| **PromptLayer** | Versionamento de prompts | A/B testing, regressao automatica |
| **Evidently AI** | Observabilidade ML/LLM | LLM judges pre-construidos, monitoramento |

## Example Usage

```python
evaluator = PromptEvaluator()

# Avaliacao completa com LLM-as-a-Judge
question = "Quais as vantagens de Delta Lake?"
response = llm.invoke([HumanMessage(content=question)]).content
metrics = evaluator.evaluate_prompt(question, response)
for criterio, resultado in metrics["judge_scores"].items():
    print(f"  {criterio}: {resultado['score']}/5 - {resultado['reason']}")

# Comparar prompts com A/B testing
prompts = {
    "v1": "Fale sobre Delta Lake.",
    "v2": "Liste 5 vantagens tecnicas de Delta Lake sobre Parquet puro.",
}
for name, prompt in prompts.items():
    resp = llm.invoke([HumanMessage(content=prompt)]).content
    m = evaluator.evaluate_prompt(prompt, resp)
    avg = sum(v["score"] for v in m["judge_scores"].values()) / 4
    print(f"{name}: judge_avg={avg:.1f}/5, specificity={m['specificity']:.2f}")
```

## Best Practices (Kulkarni, 2025)

| Pratica | Descricao |
|---------|-----------|
| **Hibrido primeiro** | Combinar metricas automatizadas (velocidade) com LLM-as-a-Judge (nuance) |
| **Validar o juiz** | Testar o LLM-juiz contra golden dataset rotulado manualmente |
| **CI/CD integration** | Regressao automatica a cada mudanca de prompt (DeepEval/Promptfoo) |
| **Metricas certas** | Escolher metricas discriminativas para a tarefa, nao genericas |
| **Monitoramento continuo** | Avaliacao nao e checkpoint unico — rastrear em producao |
| **Robustez** | Rankings relativos sao estaveis, mas scores absolutos caem com parafrases |

## Metricas de Seguranca

Adicionar metricas de seguranca ao conjunto de avaliacao e obrigatorio para
sistemas em producao que recebem input de usuarios:

| Metrica | Definicao | Meta |
|---------|-----------|------|
| **Violation Rate** | % de ataques bem-sucedidos / total de ataques tentados | < 1% |
| **False Refusal Rate** | % de queries legitimas recusadas indevidamente | < 0.5% |

```python
# Avaliacao completa incluindo seguranca
FULL_EVAL_SUITE = {
    "quality": {
        "relevance": 0.90,
        "consistency": 0.95,
        "accuracy": 0.92,
    },
    "robustness": {
        "perturbation_stability": 0.88,
    },
    "security": {
        "violation_rate": 0.005,       # < 1%
        "false_refusal_rate": 0.003,   # < 0.5%
    },
    "performance": {
        "latency_p95_ms": 2100,
        "cost_per_call_usd": 0.002,
    }
}
```

## Ferramentas de Red-Teaming

| Ferramenta | Tipo | Foco |
|------------|------|------|
| **Azure/PyRIT** | Framework Python | Red-teaming automatizado |
| **garak** | Scanner CLI | Vulnerabilidades de LLM |
| **llm-security** | Research tools | Ataques PAIR e injection |
| **Advbench** | Benchmark | Prompts adversariais padrao |
| **PromptRobust** | Benchmark | Robustez a perturbacoes |

## Robustez como Metrica de Qualidade

```python
def evaluate_robustness(prompt_template: str, test_inputs: list[str]) -> float:
    """Score de robustez: fracao de outputs estaveis sob perturbacoes."""
    total_tests = 0
    stable_outputs = 0

    for test_input in test_inputs:
        baseline = get_completion(prompt_template.format(input=test_input))
        perturbed = get_completion(
            prompt_template.lower().format(input=test_input)  # perturbacao simples
        )
        if baseline.strip() == perturbed.strip():
            stable_outputs += 1
        total_tests += 1

    return stable_outputs / total_tests
```

## See Also

- [prompt-optimization.md](prompt-optimization.md) -- usar metricas para otimizar via A/B testing
- [../concepts/self-consistency.md](../concepts/self-consistency.md) -- multiplas respostas para consistency
- [constrained-generation.md](constrained-generation.md) -- validar constraints de formato
- [advanced-security.md](advanced-security.md) -- violation rate e false refusal rate em detalhe
- [../concepts/prompt-robustness.md](../concepts/prompt-robustness.md) -- teste de perturbacao
