# Instruction Engineering

> **Purpose**: Craft de instrucoes claras e efetivas que maximizam qualidade da resposta
> **MCP Validated**: 2026-04-20

## When to Use

- Prompts que retornam respostas vagas ou fora do esperado
- Necessidade de comparar diferentes formulacoes de instrucao
- Criacao de prompts reutilizaveis para producao
- Iteracao sobre prompts para melhorar output

## Implementation

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

llm = ChatOpenAI(model="gpt-4o", temperature=0)


def compare_instructions(
    task: str,
    instructions: dict[str, str]
) -> dict[str, dict]:
    """Compara diferentes formulacoes de instrucao para a mesma tarefa.

    Args:
        task: a tarefa base
        instructions: dict nome -> instrucao

    Returns:
        dict com resposta e metricas para cada instrucao
    """
    results = {}
    for name, instruction in instructions.items():
        prompt = f"{instruction}\n\nTarefa: {task}"
        response = llm.invoke([HumanMessage(content=prompt)])
        output = response.content

        results[name] = {
            "output": output,
            "word_count": len(output.split()),
            "has_structure": any(
                marker in output for marker in ["#", "-", "1.", "|"]
            ),
        }

    return results


# Comparar vago vs. claro
results = compare_instructions(
    task="Explique microsservicos",
    instructions={
        "vague": "Fale sobre microsservicos.",
        "clear": (
            "Explique microsservicos em 3 paragrafos para um "
            "desenvolvedor junior. Inclua: definicao, vantagens "
            "(max 3), e um exemplo pratico com Python. "
            "Nao mencione Kubernetes."
        ),
    }
)
```

## Estruturas de Instrucao

```python
# Estrutura 1: Bullet Points (tarefa + restricoes)
instruction_bullets = """Tarefa: Analise o dataset de vendas.

Instrucoes:
- Calcule o total por regiao
- Identifique os top 3 produtos
- Compare com o trimestre anterior
- Formato: tabela Markdown
- Maximo: 200 palavras"""

# Estrutura 2: Narrativa (contexto + tarefa + formato)
instruction_narrative = (
    "Voce esta preparando um relatorio executivo para a diretoria. "
    "Analise os dados de vendas do Q3, destacando tendencias de "
    "crescimento e areas de preocupacao. Use linguagem de negocios "
    "e inclua recomendacoes acionaveis em formato de bullet points."
)

# Estrutura 3: Step-by-step (sequencia explicita)
instruction_steps = """Execute as etapas abaixo na ordem:
1. Leia os dados de entrada
2. Identifique outliers (valores > 2 desvios padrao)
3. Calcule estatisticas descritivas (media, mediana, desvio)
4. Gere 3 insights acionaveis
5. Formate o resultado em JSON"""
```

## Refinamento Iterativo

```python
def iterative_refine(
    task: str,
    initial_instruction: str,
    iterations: int = 3
) -> list[dict]:
    """Refina instrucao iterativamente baseado no output."""
    history = []
    current_instruction = initial_instruction

    for i in range(iterations):
        # Gerar resposta
        response = llm.invoke([
            HumanMessage(content=f"{current_instruction}\n\nTarefa: {task}")
        ])

        # Avaliar e gerar feedback
        feedback_prompt = f"""Avalie a qualidade da resposta abaixo.

Instrucao original: {current_instruction}
Resposta gerada: {response.content}

Identifique:
1. Pontos fortes (max 2)
2. Pontos fracos (max 2)
3. Instrucao reformulada que corrige os pontos fracos"""

        feedback = llm.invoke([HumanMessage(content=feedback_prompt)])

        history.append({
            "iteration": i + 1,
            "instruction": current_instruction,
            "output_preview": response.content[:300],
            "feedback": feedback.content,
        })

        # Extrair instrucao refinada do feedback
        if "Instrucao reformulada:" in feedback.content:
            current_instruction = feedback.content.split(
                "Instrucao reformulada:"
            )[-1].strip()

    return history
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `iterations` | `3` | Rodadas de refinamento |
| `temperature` | `0` | Determinismo na comparacao |
| `eval_criteria` | `["clarity", "completeness"]` | Criterios de avaliacao |

## Checklist de Instrucao Efetiva

| Criterio | Pergunta de Verificacao |
|----------|-------------------------|
| Especificidade | A tarefa esta descrita sem ambiguidade? |
| Formato | O formato de saida esta explicito? |
| Restricoes | Limites de tamanho/tom estao definidos? |
| Exemplos | Ha exemplos quando necessario? |
| Publico | O publico-alvo esta claro? |
| Verificacao | A instrucao e testavel/validavel? |

## See Also

- [../concepts/ambiguity-clarity.md](../concepts/ambiguity-clarity.md) -- resolver ambiguidade
- [prompt-formatting.md](prompt-formatting.md) -- impacto do formato
- [prompt-optimization.md](prompt-optimization.md) -- otimizar via A/B testing
