# Lost-in-the-Middle: Posicionamento Estrategico

> **Purpose**: Tecnica de posicionamento de elementos criticos no prompt para contornar o efeito lost-in-the-middle
> **Confidence**: 0.95
> **MCP Validated**: 2026-05-10

## Overview

Pesquisas mostram que modelos processam instrucoes com muito mais eficacia quando colocadas
no **inicio e no fim** do prompt — nao no meio. O efeito "lost in the middle" (Liu et al., 2023)
foi validado pelo teste "Needle in a Haystack" (NIAH): informacoes criticas no centro de um
contexto longo sao frequentemente ignoradas ou processadas com menor precisao.

**Fonte:** AI Engineering — Chip Huyen (2026), Cap. 5; Liu et al. (2023)

## O Problema

```python
# Ruim: instrucao critica no meio de documento longo
PROMPT_RUIM = f"""
{long_document_part_1}
IMPORTANTE: Responda apenas com base no documento, sem inferencias.
{long_document_part_2}
Pergunta: {question}"""

# A instrucao "IMPORTANTE" sera ignorada ou esquecida
# O modelo pode usar conhecimento externo mesmo com a restricao
```

## A Solucao

```python
import anthropic

client = anthropic.Anthropic()

def safe_document_qa(document: str, question: str) -> str:
    # Instrucao critica no INICIO e no FIM
    prompt = f"""IMPORTANTE: Responda apenas com base no documento, sem inferencias.

<document>
{document}
</document>

Pergunta: {question}

LEMBRETE: Use apenas informacoes explicitas no documento acima."""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1000,
        temperature=0.0,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text
```

## Tabela de Posicionamento Ideal

| Elemento | Posicao Ideal | Posicao a Evitar |
|----------|---------------|------------------|
| Instrucoes criticas e restricoes | Inicio ou fim — nunca no meio | Centro do prompt |
| Restricao de conhecimento | Inicio E fim (duplicar) | Antes do documento apenas |
| Contexto de suporte (documentos longos) | Meio (aceitavel) | — |
| Pergunta ou tarefa final | Sempre ao final | Antes dos documentos |
| Exemplos few-shot | Antes da tarefa final | Apos os dados |
| Role/persona | Inicio (system prompt) | Depois dos dados |

## Variacao por Modelo

| Modelo | Descricao da Tarefa | Instrucoes |
|--------|---------------------|------------|
| LLaMA 3 | Performa melhor ao final | Final e inicio |
| GPT-4 | Performa melhor no inicio | Inicio e final |
| Claude | Inicio e final (robsto) | Inicio e final |

> **Regra pratica:** teste com seu modelo especifico. A posicao de instrucoes pode variar.
> Mas duplicar instrucoes criticas (inicio + fim) e seguro para todos os modelos testados.

## Template Robusto para Contexto Longo

```python
def build_long_context_prompt(
    critical_instruction: str,
    document: str,
    question: str
) -> str:
    """Prompt com instrucao critica no inicio e no fim."""
    return f"""{critical_instruction}

<document>
{document}
</document>

{question}

LEMBRETE: {critical_instruction}"""
```

## Exemplo com Multiplos Documentos (RAG)

```python
def rag_prompt(documents: list[str], question: str) -> str:
    """Em RAG, coloca documentos mais relevantes no inicio e no fim."""
    # Documentos mais relevantes: posicoes 0 e -1
    # Documentos menos relevantes: posicoes intermediarias
    docs_formatted = ""
    for i, doc in enumerate(documents):
        docs_formatted += f"<document id='{i+1}'>\n{doc}\n</document>\n\n"

    return f"""Responda a pergunta usando APENAS os documentos fornecidos.
Se a informacao nao estiver nos documentos, responda: "Nao encontrado."

{docs_formatted}

Pergunta: {question}

RESTRICAO: Use apenas informacoes dos documentos acima. Nao use conhecimento externo."""
```

## Relacao com Prompt Caching

Para prompts longos repetitivos, combine lost-in-the-middle com prompt caching:
o documento longo fica no meio (aceitavel), as instrucoes criticas ficam no inicio
e fim fora do cache, e o cache e aplicado ao conteudo estatico do meio.

```python
messages = [
    {
        "role": "user",
        "content": [
            {"type": "text", "text": "RESTRICAO: Use apenas o documento abaixo."},
            {
                "type": "text",
                "text": LONG_STATIC_DOCUMENT,
                "cache_control": {"type": "ephemeral"}  # cache por 5 minutos
            },
            {"type": "text", "text": f"Pergunta: {question}\nLEMBRETE: Apenas o documento acima."}
        ]
    }
]
```

## Related

- [../patterns/prompt-formatting.md](../patterns/prompt-formatting.md) — formatacao de prompts em geral
- [../patterns/prompt-length-management.md](../patterns/prompt-length-management.md) — gerenciar contexto longo
- [../concepts/prompt-robustness.md](../concepts/prompt-robustness.md) — robustez a perturbacoes
