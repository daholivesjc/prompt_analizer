# Multilingual Prompting

> **Purpose**: Design de prompts multi-idioma com deteccao, adaptacao e traducao cultural
> **MCP Validated**: 2026-04-20

## When to Use

- Aplicacoes com usuarios em multiplos idiomas
- Traducao e localizacao de conteudo
- Deteccao automatica de idioma do input
- Adaptacao cultural de expressoes idiomaticas

## Implementation

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

llm = ChatOpenAI(model="gpt-4o", temperature=0)


class MultilingualPromptEngine:
    """Engine de prompts multilíngue com deteccao e adaptacao."""

    SUPPORTED_LANGUAGES = {
        "pt": "portugues", "en": "ingles", "es": "espanhol",
        "fr": "frances", "de": "alemao", "it": "italiano",
        "ja": "japones", "zh": "chines", "ko": "coreano",
        "ar": "arabe", "hi": "hindi", "ru": "russo",
    }

    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4o", temperature=0)

    def detect_language(self, text: str) -> dict:
        """Detecta idioma do texto via LLM."""
        prompt = (
            f"Detecte o idioma do texto abaixo.\n"
            f"Retorne APENAS o codigo ISO 639-1 (ex: pt, en, es).\n\n"
            f"Texto: {text}\n\nCodigo:"
        )
        result = self.llm.invoke([HumanMessage(content=prompt)])
        code = result.content.strip().lower()[:2]
        return {
            "code": code,
            "name": self.SUPPORTED_LANGUAGES.get(code, "desconhecido"),
            "supported": code in self.SUPPORTED_LANGUAGES,
        }

    def respond_in_language(
        self, question: str, target_lang: str = None
    ) -> str:
        """Responde no idioma do usuario ou em idioma alvo."""
        if target_lang is None:
            detected = self.detect_language(question)
            target_lang = detected["code"]

        lang_name = self.SUPPORTED_LANGUAGES.get(target_lang, target_lang)

        messages = [
            SystemMessage(content=(
                f"Responda SEMPRE em {lang_name}. "
                f"Adapte expressoes e exemplos ao contexto cultural "
                f"do idioma. Use linguagem natural, nao traducao literal."
            )),
            HumanMessage(content=question),
        ]
        return self.llm.invoke(messages).content

    def translate(
        self,
        text: str,
        source_lang: str,
        target_lang: str,
        culturally_aware: bool = True,
    ) -> dict:
        """Traducao com adaptacao cultural opcional."""
        source_name = self.SUPPORTED_LANGUAGES.get(source_lang, source_lang)
        target_name = self.SUPPORTED_LANGUAGES.get(target_lang, target_lang)

        if culturally_aware:
            prompt = (
                f"Traduza o texto de {source_name} para {target_name}.\n"
                f"Adapte expressoes idiomaticas ao contexto cultural do "
                f"idioma alvo. NAO faca traducao literal de expressoes.\n\n"
                f"Texto: {text}\n\nTraducao:"
            )
        else:
            prompt = (
                f"Traduza fielmente de {source_name} para {target_name}:\n\n"
                f"{text}\n\nTraducao:"
            )

        result = self.llm.invoke([HumanMessage(content=prompt)])

        return {
            "original": text,
            "translated": result.content,
            "source": source_lang,
            "target": target_lang,
            "culturally_adapted": culturally_aware,
        }

    def transliterate(self, text: str, source_script: str) -> str:
        """Transliterar scripts nao-latinos para latino."""
        prompt = (
            f"Translitere o texto abaixo de {source_script} "
            f"para o alfabeto latino. Mantenha a pronuncia original.\n\n"
            f"Texto: {text}\n\nTransliteracao:"
        )
        return self.llm.invoke([HumanMessage(content=prompt)]).content
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `supported_languages` | 12 idiomas | Idiomas suportados |
| `culturally_aware` | `True` | Adaptacao cultural na traducao |
| `detect_on_input` | `True` | Auto-detectar idioma do input |

## Example Usage

```python
engine = MultilingualPromptEngine()

# Deteccao automatica
lang = engine.detect_language("Comment ca va aujourd'hui?")
# {"code": "fr", "name": "frances", "supported": True}

# Resposta no idioma do usuario
response = engine.respond_in_language(
    "What are the best practices for data pipelines?"
)

# Traducao culturalmente sensivel
result = engine.translate(
    text="It's raining cats and dogs!",
    source_lang="en",
    target_lang="pt",
    culturally_aware=True,
)
# "Esta chovendo canivetes!" (adaptado, nao literal)

# Transliteracao
latin = engine.transliterate("konnichiwa", "hiragana")
```

## See Also

- [../concepts/prompt-templates.md](../concepts/prompt-templates.md) -- templates por idioma
- [specific-task-prompts.md](specific-task-prompts.md) -- templates para traducao
- [ethical-prompting.md](ethical-prompting.md) -- inclusao linguistica
