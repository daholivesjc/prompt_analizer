# Prompt Chaining

> **Purpose**: Conectar saida de um prompt como entrada do proximo para pipelines multi-etapa
> **MCP Validated**: 2026-04-20

## When to Use

- Tarefas complexas que precisam de decomposicao sequencial
- Pipeline geracao -> sumarizacao -> refinamento
- Q&A com follow-ups automaticos baseados na resposta anterior
- Processos que exigem validacao entre etapas

## Implementation

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
import re
import json

llm = ChatOpenAI(model="gpt-4o", temperature=0)


def chain_prompts(steps: list[dict], initial_input: str) -> list[dict]:
    """Executa uma cadeia de prompts sequenciais com validacao.

    Args:
        steps: lista de dicts com 'name', 'prompt_template', 'validator' (opcional)
        initial_input: texto de entrada inicial

    Returns:
        lista com resultados de cada etapa
    """
    results = []
    current_input = initial_input

    for step in steps:
        # Montar prompt com input da etapa anterior
        prompt = step["prompt_template"].format(input=current_input)

        # Executar LLM
        response = llm.invoke([HumanMessage(content=prompt)])
        output = response.content

        # Validar output se validator definido
        if "validator" in step and step["validator"]:
            is_valid = step["validator"](output)
            if not is_valid:
                raise ValueError(
                    f"Validacao falhou na etapa '{step['name']}': {output[:100]}"
                )

        results.append({
            "step": step["name"],
            "input": current_input[:200],
            "output": output
        })

        # Output desta etapa vira input da proxima
        current_input = output

    return results


# Definir pipeline: tema -> conteudo -> resumo
pipeline = [
    {
        "name": "geracao",
        "prompt_template": (
            "Escreva um artigo tecnico de 3 paragrafos sobre: {input}"
        ),
        "validator": lambda x: len(x.split()) > 50
    },
    {
        "name": "sumarizacao",
        "prompt_template": (
            "Resuma o artigo abaixo em 3 bullet points:\n\n{input}"
        ),
        "validator": None
    },
    {
        "name": "takeaways",
        "prompt_template": (
            "Extraia os 3 principais takeaways do resumo:\n\n{input}\n\n"
            "Formato: JSON array de strings."
        ),
        "validator": lambda x: x.strip().startswith("[")
    },
]

results = chain_prompts(pipeline, "Delta Lake para data lakehouses")
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `temperature` | `0` | Determinismo entre etapas |
| `max_steps` | `10` | Limite de etapas na cadeia |
| `validator` | `None` | Funcao de validacao entre etapas |
| `error_strategy` | `"raise"` | `"raise"`, `"skip"`, `"retry"` |

## Chaining Dinamico com Follow-ups

```python
def dynamic_qa_chain(question: str, max_followups: int = 3) -> list[dict]:
    """Q&A com follow-ups gerados automaticamente."""
    conversation = []
    current_q = question

    for i in range(max_followups + 1):
        # Responder a pergunta
        answer = llm.invoke([HumanMessage(content=current_q)]).content
        conversation.append({"question": current_q, "answer": answer})

        if i < max_followups:
            # Gerar follow-up baseado na resposta
            followup_prompt = (
                f"Baseado na resposta abaixo, gere UMA pergunta "
                f"de follow-up relevante.\n\nResposta: {answer}\n\n"
                f"Follow-up:"
            )
            current_q = llm.invoke(
                [HumanMessage(content=followup_prompt)]
            ).content

    return conversation
```

## Error Handling

```python
def validate_json_between_steps(output: str) -> bool:
    """Valida se output e JSON valido entre etapas."""
    # Remover markdown code blocks se presente
    cleaned = re.sub(r'```(?:json)?\n?', '', output).strip()
    try:
        json.loads(cleaned)
        return True
    except json.JSONDecodeError:
        return False
```

## Paralelizacao de Passos Independentes

Passos sem dependencia entre si podem rodar em paralelo, reduzindo latencia:

```python
import asyncio
import anthropic

client = anthropic.Anthropic()

async def parallel_analysis(document: str) -> dict:
    """Executa analises independentes em paralelo."""

    async def run_module(prompt: str) -> str:
        message = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=400,
            temperature=0.0,
            messages=[{"role": "user", "content": prompt}]
        )
        return message.content[0].text

    # Modulos independentes rodam em paralelo
    results = await asyncio.gather(
        run_module(f"Como arquiteto de dados, analise escalabilidade de: {document}"),
        run_module(f"Como engenheiro de plataforma, analise custo operacional de: {document}"),
        run_module(f"Como gerente de produto, analise time-to-market de: {document}"),
    )

    # Sintese dos resultados (etapa dependente — roda depois)
    synthesis_prompt = f"""Integre os tres memos em briefing executivo de 300 palavras.
Include um trade-off principal e uma incognita que requer dados adicionais.

Memo 1 (Arquitetura): {results[0]}
Memo 2 (Plataforma): {results[1]}
Memo 3 (Produto): {results[2]}"""

    synthesis = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=600,
        temperature=0.0,
        messages=[{"role": "user", "content": synthesis_prompt}]
    )

    return {
        "architecture": results[0],
        "platform": results[1],
        "product": results[2],
        "synthesis": synthesis.content[0].text
    }
```

## Modelos Diferentes por Etapa

Use o modelo mais barato para etapas simples e o mais caro para etapas criticas:

```python
def cost_optimized_chain(document: str, question: str) -> str:
    """Classifica com modelo barato, gera resposta com modelo caro."""

    # Etapa 1: Classificacao de intent (modelo barato)
    classify_prompt = f"""Classifique a query em: factual | analise | criativo
Retorne apenas a categoria.
Query: {question}"""

    category_msg = client.messages.create(
        model="claude-haiku-4-5",   # barato, rapido
        max_tokens=10,
        temperature=0.0,
        messages=[{"role": "user", "content": classify_prompt}]
    )
    category = category_msg.content[0].text.strip()

    # Etapa 2: Resposta especializada (modelo adequado ao tipo)
    model_map = {
        "factual": "claude-haiku-4-5",       # barato para factual
        "analise": "claude-sonnet-4-6",      # medio para analise
        "criativo": "claude-sonnet-4-6",     # medio para criativo
    }
    model = model_map.get(category, "claude-sonnet-4-6")

    response_msg = client.messages.create(
        model=model,
        max_tokens=800,
        temperature=0.0,
        messages=[{"role": "user", "content": f"{question}\n\n<context>{document}</context>"}]
    )
    return response_msg.content[0].text
```

## Trade-off Latencia vs. Custo

| Estrategia | Latencia | Custo | Quando Usar |
|------------|----------|-------|-------------|
| Sequencial simples | Alta | Baixo | Pipeline pequeno |
| Paralelo (asyncio) | Baixa | Medio | Etapas independentes |
| Modelo por etapa | Media | Otimizado | Producao em escala |
| Decomposicao agressiva | Alta (mais etapas) | Baixo (modelos menores) | Tokens de input caros |

## Case Study: GoDaddy

GoDaddy reduziu prompts de 1500+ tokens decompondo em subtarefas:
- Classificacao de intent (modelo barato, < 50 tokens)
- Geracao de resposta especializada (modelo caro, contexto menor)
- Resultado: 60% de reducao de custo com qualidade equivalente

## See Also

- [task-decomposition.md](task-decomposition.md) -- decomposicao antes de encadear
- [../concepts/chain-of-thought.md](../concepts/chain-of-thought.md) -- raciocinio em cada etapa
- [prompt-optimization.md](prompt-optimization.md) -- otimizar cada elo da cadeia
- [../concepts/reflection-prompting.md](../concepts/reflection-prompting.md) -- refinamento iterativo
