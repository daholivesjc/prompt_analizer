# Prompt Formatting

> **Purpose**: Impacto de formatos na qualidade da resposta e escolha do melhor formato
> **MCP Validated**: 2026-04-20

## When to Use

- Definir a melhor estrutura de prompt para cada tipo de tarefa
- Comparar efetividade entre formatos (Q&A, instrucao, dialogo)
- Padronizar formatos dentro de uma equipe ou projeto
- Otimizar legibilidade e parsing de prompts

## Implementation

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

llm = ChatOpenAI(model="gpt-4o", temperature=0)


# Formato 1: Q&A (pergunta direta)
format_qa = """Pergunta: Quais sao as vantagens de Delta Lake sobre Parquet puro?
Resposta:"""

# Formato 2: Instrucao (comando direto)
format_instruction = """Liste as 5 principais vantagens de Delta Lake
sobre Parquet puro. Use bullet points com 1 frase cada."""

# Formato 3: Dialogo (conversacional)
format_dialogue = """Usuario: Estou escolhendo entre Delta Lake e Parquet
puro para meu data lakehouse. O que voce recomenda?
Assistente:"""

# Formato 4: Estruturado com headers
format_structured = """# Analise Comparativa: Delta Lake vs Parquet

## Contexto
Data lakehouse com 500GB de dados diarios.

## Perguntas
1. Quais as vantagens de Delta Lake?
2. Quando Parquet puro e suficiente?

## Formato de Resposta
Tabela comparativa + recomendacao em 1 paragrafo."""


def compare_formats(formats: dict[str, str]) -> dict:
    """Compara respostas de diferentes formatos de prompt."""
    results = {}
    for name, prompt in formats.items():
        response = llm.invoke([HumanMessage(content=prompt)])
        output = response.content
        results[name] = {
            "output": output,
            "word_count": len(output.split()),
            "has_bullets": bool(
                any(line.strip().startswith(("-", "*")) for line in output.split("\n"))
            ),
            "has_headers": "#" in output,
            "has_table": "|" in output,
        }
    return results

results = compare_formats({
    "qa": format_qa,
    "instruction": format_instruction,
    "dialogue": format_dialogue,
    "structured": format_structured,
})
```

## Elementos Estruturais

| Elemento | Sintaxe | Efeito no LLM |
|----------|---------|----------------|
| Headers `#` | `# Titulo` | Organiza resposta em secoes |
| Bullet points | `- item` | Forca respostas em lista |
| Numeracao | `1. item` | Implica sequencia/prioridade |
| Tabela | `\| col \| col \|` | Solicita dados tabulares |
| Code fence | `` ```python `` | Delimita blocos de codigo |
| Negrito | `**texto**` | Destaque sem efeito funcional |

## Configuration

| Formato | Melhor Para | Precisao | Verbosidade |
|---------|-------------|----------|-------------|
| Q&A | Respostas curtas e diretas | Alta | Baixa |
| Instrucao | Tarefas com formato definido | Alta | Media |
| Dialogo | Exploracoes abertas | Media | Alta |
| Estruturado | Analises complexas | Muito alta | Media |

## Template de Formato Otimizado

```python
def build_formatted_prompt(
    context: str,
    task: str,
    output_format: str = "bullet_points",
    constraints: list[str] = None
) -> str:
    """Constroi prompt com formato otimizado."""
    format_specs = {
        "bullet_points": "Responda em bullet points (max 5, 1 frase cada).",
        "table": "Responda em tabela Markdown com headers claros.",
        "json": "Responda em JSON valido.",
        "numbered": "Responda em lista numerada com explicacao por item.",
        "paragraph": "Responda em 2-3 paragrafos concisos.",
    }

    prompt_parts = [f"## Contexto\n{context}", f"\n## Tarefa\n{task}"]

    if constraints:
        parts = "\n".join(f"- {c}" for c in constraints)
        prompt_parts.append(f"\n## Restricoes\n{parts}")

    fmt = format_specs.get(output_format, output_format)
    prompt_parts.append(f"\n## Formato de Saida\n{fmt}")

    return "\n".join(prompt_parts)

prompt = build_formatted_prompt(
    context="Pipeline PySpark no Dataproc Serverless",
    task="Identifique gargalos de performance",
    output_format="table",
    constraints=["Foque em I/O e shuffle", "Max 5 gargalos"]
)
```

## Example Usage

```python
# Prompt formatado para extracao estruturada
prompt = """# Extracao de Entidades

## Input
"Maria Silva, 35 anos, engenheira na Petrobras em RJ desde 2015."

## Campos a Extrair
| Campo | Tipo | Obrigatorio |
|-------|------|-------------|
| nome | string | sim |
| idade | int | sim |
| profissao | string | sim |
| empresa | string | sim |
| cidade | string | sim |
| ano_inicio | int | nao |

## Output
JSON com os campos acima."""

response = llm.invoke([HumanMessage(content=prompt)])
```

## Lost-in-the-Middle: Posicionamento Estrategico

Pesquisas mostram que instrucoes criticas devem ser posicionadas no **inicio e no fim**
do prompt — nao no meio — para maxima eficacia (Liu et al., 2023).

```python
# Ruim: instrucao critica no meio do documento
PROMPT_RUIM = f"""
{long_document_part_1}
IMPORTANTE: Responda apenas com base no documento.
{long_document_part_2}
Pergunta: {question}"""

# Bom: instrucao no inicio E no fim
PROMPT_BOM = f"""IMPORTANTE: Responda apenas com base no documento, sem inferencias.

<document>
{long_document}
</document>

Pergunta: {question}

LEMBRETE: Use apenas informacoes explicitas no documento acima."""
```

## Tabela: Elemento → Posicao Ideal

| Elemento | Posicao Ideal | Posicao a Evitar |
|----------|---------------|------------------|
| Instrucoes criticas e restricoes | Inicio ou fim — duplicar se possivel | Centro do prompt |
| Contexto de suporte (documentos longos) | Meio (aceitavel) | — |
| Pergunta ou tarefa final | Sempre ao final | Antes dos documentos |
| Role/persona | Inicio (system prompt) | Apos os dados |
| Exemplos few-shot | Antes da tarefa final | Apos os dados |

## Variacao por Modelo

| Modelo | Posicionamento Recomendado |
|--------|---------------------------|
| LLaMA 3 | Descricao da tarefa ao final |
| GPT-4 | Descricao da tarefa no inicio |
| Claude | Inicio e final (robusto) |

> **Regra pratica:** para qualquer modelo, duplicar instrucoes criticas (inicio + fim)
> e seguro. Teste posicionamento com seu modelo especifico.

## See Also

- [instruction-engineering.md](instruction-engineering.md) -- craft de instrucoes
- [constrained-generation.md](constrained-generation.md) -- restricoes de formato
- [../concepts/prompt-templates.md](../concepts/prompt-templates.md) -- templates reutilizaveis
- [lost-in-the-middle.md](lost-in-the-middle.md) -- guia completo de posicionamento
