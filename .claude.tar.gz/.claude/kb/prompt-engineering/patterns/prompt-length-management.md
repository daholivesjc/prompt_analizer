# Prompt Length Management

> **Purpose**: Gerenciar tamanho de prompts e lidar com contextos longos
> **MCP Validated**: 2026-04-20

## When to Use

- Documentos que excedem a janela de contexto do modelo
- Otimizar custo reduzindo tokens desnecessarios
- Processar textos longos com chunking e sumarizacao
- Balancear detalhe vs. concisao no prompt

## Implementation

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
from langchain_text_splitters import RecursiveCharacterTextSplitter

llm = ChatOpenAI(model="gpt-4o", temperature=0)


class PromptLengthManager:
    """Gerencia tamanho de prompts com chunking e sumarizacao."""

    def __init__(self, max_tokens: int = 4000):
        self.max_tokens = max_tokens
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=2000,
            chunk_overlap=200,
            separators=["\n\n", "\n", ". ", " "],
        )

    def estimate_tokens(self, text: str) -> int:
        """Estima tokens (regra: ~4 chars por token em ingles)."""
        return len(text) // 4

    def chunk_and_process(
        self, long_text: str, instruction: str
    ) -> list[dict]:
        """Divide texto longo em chunks e processa cada um."""
        chunks = self.splitter.split_text(long_text)
        results = []

        for i, chunk in enumerate(chunks):
            prompt = (
                f"{instruction}\n\n"
                f"[Parte {i+1}/{len(chunks)}]\n"
                f"{chunk}"
            )
            response = llm.invoke([HumanMessage(content=prompt)])
            results.append({
                "chunk": i + 1,
                "total_chunks": len(chunks),
                "tokens_est": self.estimate_tokens(chunk),
                "result": response.content,
            })

        return results

    def summarize_long_text(self, long_text: str) -> str:
        """Sumariza texto longo com estrategia map-reduce."""
        chunks = self.splitter.split_text(long_text)

        # Map: sumarizar cada chunk
        summaries = []
        for chunk in chunks:
            prompt = (
                "Resuma o trecho abaixo em 3-5 frases, "
                "mantendo os pontos principais.\n\n"
                f"{chunk}\n\nResumo:"
            )
            result = llm.invoke([HumanMessage(content=prompt)])
            summaries.append(result.content)

        # Reduce: combinar sumarios
        combined = "\n\n".join(summaries)
        if self.estimate_tokens(combined) > self.max_tokens:
            # Recursao se ainda for longo demais
            return self.summarize_long_text(combined)

        final_prompt = (
            "Combine os resumos parciais abaixo em um resumo "
            "unico e coeso de 5-10 frases.\n\n"
            f"{combined}\n\nResumo final:"
        )
        final = llm.invoke([HumanMessage(content=final_prompt)])
        return final.content

    def compress_prompt(self, prompt: str) -> str:
        """Comprime prompt removendo redundancias."""
        compress_prompt = (
            "Reescreva o prompt abaixo de forma mais concisa, "
            "mantendo TODAS as instrucoes e restricoes. "
            "Remova redundancias e palavras desnecessarias.\n\n"
            f"Prompt original:\n{prompt}\n\n"
            "Prompt comprimido:"
        )
        result = llm.invoke([HumanMessage(content=compress_prompt)])
        return result.content
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `max_tokens` | `4000` | Limite de tokens por prompt |
| `chunk_size` | `2000` | Tamanho de cada chunk (chars) |
| `chunk_overlap` | `200` | Sobreposicao entre chunks |
| `separators` | `["\n\n", "\n", ". "]` | Prioridade de separacao |

## Estrategias de Gerenciamento

| Estrategia | Quando Usar | Trade-off |
|------------|-------------|-----------|
| Chunking | Documento > contexto do modelo | Perde visao global |
| Sumarizacao | Precisa de visao geral | Perde detalhes |
| Compressao | Prompt verboso | Pode perder nuances |
| Selecao | Sabe quais partes importam | Requer pre-conhecimento |

## Example Usage

```python
manager = PromptLengthManager(max_tokens=4000)

# Processar documento longo por chunks
with open("relatorio_anual.txt", "r") as f:
    long_text = f.read()

results = manager.chunk_and_process(
    long_text,
    instruction="Extraia todos os KPIs mencionados neste trecho."
)

# Sumarizar texto longo
summary = manager.summarize_long_text(long_text)

# Comprimir prompt verboso
compressed = manager.compress_prompt(
    "Eu gostaria que voce por favor pudesse analisar de forma "
    "detalhada e completa todos os aspectos do relatorio..."
)
```

## Processamento Iterativo

```python
def iterative_qa(document: str, questions: list[str]) -> dict:
    """Processa documento com multiplas perguntas iterativamente."""
    manager = PromptLengthManager()
    summary = manager.summarize_long_text(document)

    answers = {}
    for q in questions:
        prompt = (
            f"Contexto (resumo do documento):\n{summary}\n\n"
            f"Pergunta: {q}\n\nResposta:"
        )
        result = llm.invoke([HumanMessage(content=prompt)])
        answers[q] = result.content

    return answers
```

## See Also

- [task-decomposition.md](task-decomposition.md) -- decompor antes de processar
- [prompt-chaining.md](prompt-chaining.md) -- encadear chunks processados
- [prompt-optimization.md](prompt-optimization.md) -- otimizar tamanho vs. qualidade
