# Prompt Optimization

> **Purpose**: A/B testing e refinamento iterativo de prompts com metricas quantitativas
> **MCP Validated**: 2026-04-20

## When to Use

- Comparar duas ou mais variantes de prompt para a mesma tarefa
- Medir impacto de mudancas no prompt (adicionar exemplos, mudar tom)
- Otimizar prompts em producao com metricas de qualidade
- Refinamento sistematico baseado em feedback do LLM

## Implementation

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
import json

llm = ChatOpenAI(model="gpt-4o", temperature=0)
evaluator = ChatOpenAI(model="gpt-4o", temperature=0)


def ab_test_prompts(
    variants: dict[str, str],
    test_inputs: list[str],
    eval_criteria: list[str] = None
) -> dict:
    """A/B testing de prompts com avaliacao automatizada.

    Args:
        variants: dict nome -> template de prompt (use {input} como placeholder)
        test_inputs: lista de inputs de teste
        eval_criteria: criterios de avaliacao

    Returns:
        dict com scores e ranking por variante
    """
    if eval_criteria is None:
        eval_criteria = ["clarity", "informativeness", "engagement"]

    all_scores = {name: [] for name in variants}

    for test_input in test_inputs:
        for name, template in variants.items():
            prompt = template.format(input=test_input)
            response = llm.invoke([HumanMessage(content=prompt)])

            # Avaliar com LLM separado
            scores = _evaluate_response(
                response.content, eval_criteria, test_input
            )
            all_scores[name].append(scores)

    # Calcular medias
    summary = {}
    for name, score_list in all_scores.items():
        avg = {}
        for criterion in eval_criteria:
            values = [s[criterion] for s in score_list if criterion in s]
            avg[criterion] = sum(values) / len(values) if values else 0
        avg["overall"] = sum(avg.values()) / len(avg)
        summary[name] = avg

    # Ranking
    ranking = sorted(summary.items(), key=lambda x: x[1]["overall"], reverse=True)

    return {"scores": summary, "ranking": [r[0] for r in ranking]}


def _evaluate_response(
    response: str, criteria: list[str], original_input: str
) -> dict:
    """Avalia resposta via LLM com scoring 1-10."""
    criteria_text = "\n".join(f"- {c}: (1-10)" for c in criteria)

    eval_prompt = f"""Avalie a resposta abaixo nos criterios indicados.
Retorne JSON com scores de 1 a 10.

Input original: {original_input}
Resposta: {response}

Criterios:
{criteria_text}

JSON (apenas scores):"""

    result = evaluator.invoke([HumanMessage(content=eval_prompt)])
    try:
        return json.loads(result.content)
    except json.JSONDecodeError:
        return {c: 5 for c in criteria}
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `eval_criteria` | `["clarity", "informativeness"]` | Criterios de avaliacao |
| `test_inputs` | `[]` | Inputs de teste (min 3 recomendado) |
| `evaluator_model` | `"gpt-4o"` | Modelo para avaliacao |
| `score_range` | `1-10` | Escala de pontuacao |

## Refinamento Iterativo

```python
def iterative_optimization(
    task: str,
    initial_prompt: str,
    test_inputs: list[str],
    iterations: int = 3
) -> list[dict]:
    """Otimiza prompt iterativamente: gerar -> avaliar -> refinar."""
    history = []
    current_prompt = initial_prompt

    for i in range(iterations):
        # Gerar resposta com prompt atual
        response = llm.invoke([
            HumanMessage(content=current_prompt.format(input=test_inputs[0]))
        ])

        # Avaliar
        scores = _evaluate_response(
            response.content,
            ["clarity", "informativeness", "relevance"],
            test_inputs[0]
        )

        # Gerar prompt refinado
        refine_prompt = f"""O prompt abaixo gerou a resposta com scores indicados.
Reescreva o prompt para melhorar os scores mais baixos.

Prompt atual: {current_prompt}
Resposta: {response.content[:500]}
Scores: {json.dumps(scores)}

Prompt refinado (mantenha {{input}} como placeholder):"""

        refined = llm.invoke([HumanMessage(content=refine_prompt)])

        history.append({
            "iteration": i + 1,
            "prompt": current_prompt,
            "scores": scores,
            "overall": sum(scores.values()) / len(scores),
        })

        current_prompt = refined.content.strip()

    return history
```

## Example Usage

```python
# A/B testing: prompt conciso vs. detalhado
results = ab_test_prompts(
    variants={
        "concise": "Resuma: {input}",
        "detailed": (
            "Resuma o texto abaixo em 3 bullet points. "
            "Cada bullet deve ter no maximo 15 palavras. "
            "Foque nos pontos principais.\n\nTexto: {input}"
        ),
    },
    test_inputs=[
        "Python e uma linguagem de programacao versátil...",
        "O mercado de dados cresce 25% ao ano...",
        "Microsservicos permitem escalar componentes...",
    ],
    eval_criteria=["clarity", "informativeness", "conciseness"]
)

print(f"Vencedor: {results['ranking'][0]}")
```

## Robustez como Metrica de Qualidade

Robustez deve integrar a suite de avaliacao — um prompt preciso mas fragil nao e confiavel:

```python
def robustness_score(prompt_template: str, test_input: str) -> float:
    """Mede estabilidade do prompt sob perturbacoes minimas."""
    perturbations = [
        prompt_template.format(input=test_input),
        prompt_template.format(input=test_input + "\n"),  # linha extra
        prompt_template.lower().format(input=test_input),  # lowercase
        "Por favor, " + prompt_template.format(input=test_input),  # preambulo
    ]

    outputs = []
    for p in perturbations:
        message = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=100,
            temperature=0.0,
            messages=[{"role": "user", "content": p}]
        )
        outputs.append(message.content[0].text.strip())

    # Score: fracao de outputs identicos ao primeiro
    baseline = outputs[0]
    matches = sum(1 for o in outputs if o == baseline)
    return matches / len(outputs)


QUALITY_METRICS = {
    "accuracy": 0.92,       # corretude
    "consistency": 0.95,    # mesma entrada = mesma saida
    "robustness": 0.88,     # estabilidade sob perturbacao
    "latency_p95": 2100,    # ms
}
```

## Iterative Refinement por Dimensao

O Iterative Refinement ataca uma dimensao especifica de qualidade por vez,
isolando erros sem introduzir novos:

```python
def dimensional_refinement(task: str, tone: str, draft: str) -> str:
    """Refina resposta por dimensao: estrutura → tom → concisao."""

    # Dimensao 1: Estrutura (sem alterar conteudo)
    prompt_structure = f"""O texto abaixo tem problema de estrutura.
Reorganize os paragrafos para que a logica flua melhor.
Nao altere o conteudo, apenas a ordem e organizacao.

<texto>{draft}</texto>"""
    v2 = get_completion(prompt_structure)

    # Dimensao 2: Tom (sem alterar conteudo)
    prompt_tone = f"""Ajuste o tom do texto para {tone}.
Nao altere o conteudo, apenas a forma de expressao.

<texto>{v2}</texto>"""
    v3 = get_completion(prompt_tone)

    # Dimensao 3: Concisao (sem alterar conteudo)
    prompt_concisao = f"""Reduza o texto em 30% sem perder informacao essencial.

<texto>{v3}</texto>"""
    return get_completion(prompt_concisao)
```

## Answer → Reflect → Revise como Ciclo de Qualidade

```python
def reflect_and_revise(document: str, criteria: list[str]) -> str:
    """Padrao de auto-revisao antes do output final."""
    criteria_text = "\n".join(f"({chr(97+i)}) {c}" for i, c in enumerate(criteria))

    prompt = f"""Escreva um resumo executivo do documento abaixo.

Apos escrever o rascunho, verifique se ele:
{criteria_text}

Entao revise o rascunho com base nesses criterios.

<document>
{document}
</document>

Retorne apenas a versao revisada final em <summary> tags."""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=800,
        temperature=0.0,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text
```

## See Also

- [evaluation-metrics.md](evaluation-metrics.md) -- metricas detalhadas
- [instruction-engineering.md](instruction-engineering.md) -- melhorar instrucoes
- [../concepts/few-shot-learning.md](../concepts/few-shot-learning.md) -- testar com/sem exemplos
- [../concepts/prompt-robustness.md](../concepts/prompt-robustness.md) -- robustez como metrica
- [../concepts/reflection-prompting.md](../concepts/reflection-prompting.md) -- Answer→Reflect→Revise
