# Gestao de Prompts em Producao

> **Purpose**: Versionamento, schema de metadados, lifecycle completo e riscos de ferramentas automatizadas
> **Confidence**: 0.95
> **MCP Validated**: 2026-05-10

## Overview

Prompts de producao sao artefatos de engenharia, nao strings soltas no codigo. Exigem
versionamento, metadados estruturados, monitoramento continuo e um lifecycle definido
— do design ao deprecamento. Sem essa disciplina, mudancas de modelo causam regressoes
silenciosas e prompts nunca saem de "alpha".

**Fonte:** AI Engineering — Chip Huyen (2026), Cap. 5

## Separacao Codigo/Prompt

Prompts devem ser tratados como artefatos de primeira classe, separados do codigo de aplicacao:

```
project/
├── src/
│   └── application.py         # logica de aplicacao
├── prompts/
│   ├── extraction.prompt      # prompts versionados
│   ├── classification.prompt
│   └── summarization.prompt
└── pyproject.toml
```

## Schema de Prompt com Metadados (Pydantic)

```python
from pydantic import BaseModel
from datetime import datetime

class PromptArtifact(BaseModel):
    id: str                    # "extraction_v2.3"
    model_name: str            # "claude-sonnet-4-6"
    date_created: datetime
    prompt_text: str
    application: str           # "invoice_extractor"
    creator: str               # "daniel@team.com"
    temperature: float         # 0.0
    input_schema: dict         # campos esperados no input
    output_schema: dict        # campos esperados no output
    eval_score: float          # ultima acuracia medida
    notes: str                 # mudancas nesta versao

    def is_production_ready(self) -> bool:
        return self.eval_score >= 0.90 and self.notes != ""

    def to_file(self, path: str) -> None:
        with open(path, "w") as f:
            f.write(self.model_dump_json(indent=2))

    @classmethod
    def from_file(cls, path: str) -> "PromptArtifact":
        with open(path) as f:
            return cls.model_validate_json(f.read())
```

## Lifecycle de um Prompt de Producao

```text
Design → Evals → Deploy → Monitor → Revise → Retire
  |         |       |        |         |
CASTROFF  dataset  vX.0   metricas   patch    deprecate
          50+ casos        continuas  ou refactor
```

### Etapas com Criterios de Entrada/Saida

| Etapa | Criterio de Entrada | Criterio de Saida |
|-------|---------------------|-------------------|
| **Design** | Requisito ou falha identificada | CASTROFF completo |
| **Evals** | Prompt rascunho | Acuracia >= threshold definido |
| **Deploy** | Evals passam; revisao aprovada | Versao em producao |
| **Monitor** | Em producao | Metricas dentro do SLA |
| **Revise** | Metrica cai ou novo requisito | Novo patch ou refactoring |
| **Retire** | Modelo substituido ou funcao removida | Deprecado e arquivado |

## Versionamento Semantico de Prompts

```
extraction_v{major}.{minor}

major: mudanca no output schema ou comportamento fundamental
minor: ajuste de instrucao, adicao de exemplo, correcao de bug

Exemplo:
  extraction_v1.0 → baseline de producao
  extraction_v1.1 → adicionado exemplo para edge case de NF-e
  extraction_v2.0 → output schema mudou (campo 'subtotal' → 'net_amount')
```

## Riscos de Ferramentas Automatizadas de Prompt Engineering

Ferramentas como DSPy, Promptbreeder e TextGrad automatizam otimizacao de prompts.
Use com cuidado:

| Risco | Descricao |
|-------|-----------|
| **API calls ocultas** | 30 exemplos x 10 variacoes = 300+ calls nao monitoradas |
| **Templates incorretos** | Ferramenta pode usar templates errados para modelo especifico |
| **Typos em templates** | LangChain teve typos em critique prompts em 2023 |
| **Mudancas silenciosas** | Ferramentas atualizam templates sem aviso |

> **Principio "Show Me the Prompt":** comece sempre escrevendo prompts proprios.
> Se usar ferramenta automatizada, sempre inspecione os prompts gerados antes de
> confiar nos resultados.

## Chat Templates e Erros Silenciosos

Cada modelo tem um "chat template" que define como system prompt e user prompt sao
concatenados. Erros de template causam **falhas silenciosas** — o modelo responde algo
razoavel mas nao e o comportamento esperado.

```python
import anthropic

client = anthropic.Anthropic()

def debug_prompt(system: str, messages: list[dict]) -> None:
    """Imprime o prompt final antes de enviar ao modelo."""
    print("=== PROMPT FINAL ===")
    print(f"SYSTEM: {system[:200]}...")
    for msg in messages:
        role = msg["role"].upper()
        content = msg["content"]
        if isinstance(content, str):
            print(f"[{role}]: {content[:200]}...")
        else:
            print(f"[{role}]: [content complexo]")
    print("===================")

# Sempre debugar ao trocar de modelo
# Especialmente Gemini <-> Claude <-> OpenRouter
```

> **Atencao especial ao trocar de modelo** (ex.: Gemini para fallback OpenRouter):
> templates diferentes podem causar regressoes dificeis de depurar.

## Monitoramento Continuo em Producao

```python
from dataclasses import dataclass
from datetime import datetime

@dataclass
class PromptMetrics:
    prompt_id: str
    timestamp: datetime
    accuracy: float
    latency_ms: float
    token_count: int
    violation_rate: float   # seguranca
    false_refusal_rate: float

ALERT_THRESHOLDS = {
    "accuracy": 0.90,           # alertar se cair abaixo
    "latency_p95_ms": 5000,     # alertar se exceder
    "violation_rate": 0.01,     # alertar se exceder
    "false_refusal_rate": 0.005  # alertar se exceder
}
```

## Related

- [../patterns/evaluation-metrics.md](../patterns/evaluation-metrics.md) — metricas de qualidade
- [../patterns/castroff-framework.md](../patterns/castroff-framework.md) — auditoria na fase de design
- [../patterns/advanced-security.md](../patterns/advanced-security.md) — violation rate e false refusal rate
