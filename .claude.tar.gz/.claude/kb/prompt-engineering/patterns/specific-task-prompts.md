# Specific Task Prompts

> **Purpose**: Templates prontos para tarefas comuns -- sumarizacao, Q&A, codigo, escrita criativa
> **MCP Validated**: 2026-04-20

## When to Use

- Precisa de um template pronto para tarefa comum
- Padronizar prompts por tipo de tarefa em um time
- Ponto de partida para customizacao por dominio
- Referencia rapida de estruturas de prompt efetivas

## Implementation

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
from jinja2 import Template

llm = ChatOpenAI(model="gpt-4o", temperature=0)


# Template: Sumarizacao
SUMMARIZATION_TEMPLATE = Template("""Resuma o texto abaixo em {{ num_sentences }} frases.
Mantenha os pontos principais e dados numericos.

Texto:
{{ text }}

Resumo ({{ num_sentences }} frases):""")

# Template: Q&A com Contexto (RAG-style)
QA_TEMPLATE = Template("""Responda a pergunta baseado APENAS no contexto fornecido.
Se a resposta nao estiver no contexto, diga "Informacao nao disponivel no contexto."

Contexto:
{{ context }}

Pergunta: {{ question }}

Resposta:""")

# Template: Geracao de Codigo
CODE_GENERATION_TEMPLATE = Template("""Escreva codigo {{ language }} que {{ task }}.

Requisitos:
{% for req in requirements %}
- {{ req }}
{% endfor %}

{% if constraints %}
Restricoes:
{% for c in constraints %}
- {{ c }}
{% endfor %}
{% endif %}

Codigo:""")

# Template: Escrita Criativa
CREATIVE_WRITING_TEMPLATE = Template("""Escreva uma {{ genre }} com as caracteristicas:

- Cenario: {{ setting }}
- Tema central: {{ theme }}
- Tom: {{ tone }}
- Extensao: {{ length }}

{% if characters %}
Personagens:
{% for char in characters %}
- {{ char }}
{% endfor %}
{% endif %}

Texto:""")

# Template: Analise de Dados
DATA_ANALYSIS_TEMPLATE = Template("""Analise os dados abaixo e responda as perguntas.

Dados:
{{ data }}

Perguntas:
{% for q in questions %}
{{ loop.index }}. {{ q }}
{% endfor %}

Formato de resposta: {{ output_format }}""")


class TaskPromptLibrary:
    """Biblioteca de prompts por tipo de tarefa."""

    TEMPLATES = {
        "summarization": SUMMARIZATION_TEMPLATE,
        "qa": QA_TEMPLATE,
        "code_generation": CODE_GENERATION_TEMPLATE,
        "creative_writing": CREATIVE_WRITING_TEMPLATE,
        "data_analysis": DATA_ANALYSIS_TEMPLATE,
    }

    @classmethod
    def render(cls, task_type: str, **kwargs) -> str:
        """Renderiza template por tipo de tarefa."""
        template = cls.TEMPLATES.get(task_type)
        if not template:
            available = ", ".join(cls.TEMPLATES.keys())
            raise ValueError(
                f"Tipo '{task_type}' nao encontrado. "
                f"Disponiveis: {available}"
            )
        return template.render(**kwargs)

    @classmethod
    def list_tasks(cls) -> list[str]:
        """Lista tipos de tarefa disponiveis."""
        return list(cls.TEMPLATES.keys())
```

## Configuration

| Task Type | Parametros Obrigatorios | Opcionais |
|-----------|-------------------------|-----------|
| `summarization` | `text`, `num_sentences` | -- |
| `qa` | `context`, `question` | -- |
| `code_generation` | `language`, `task`, `requirements` | `constraints` |
| `creative_writing` | `genre`, `setting`, `theme`, `tone`, `length` | `characters` |
| `data_analysis` | `data`, `questions`, `output_format` | -- |

## Example Usage

```python
lib = TaskPromptLibrary()

# Sumarizacao
prompt = lib.render(
    "summarization",
    text="O mercado de dados no Brasil cresceu 30% em 2024...",
    num_sentences=3,
)
response = llm.invoke([HumanMessage(content=prompt)])

# Q&A
prompt = lib.render(
    "qa",
    context="Delta Lake suporta ACID, time travel e schema evolution.",
    question="O Delta Lake suporta transacoes ACID?",
)

# Geracao de codigo
prompt = lib.render(
    "code_generation",
    language="Python",
    task="leia um CSV e calcule estatísticas descritivas",
    requirements=["Use pandas", "Inclua media, mediana e desvio padrao"],
    constraints=["Sem dependencias externas alem de pandas"],
)

# Escrita criativa
prompt = lib.render(
    "creative_writing",
    genre="conto curto de ficcao cientifica",
    setting="estacao espacial em 2150",
    theme="inteligencia artificial e humanidade",
    tone="reflexivo e melancolico",
    length="500 palavras",
    characters=["Dra. Silva - cientista", "ARIA - IA da estacao"],
)

# Analise de dados
prompt = lib.render(
    "data_analysis",
    data="Vendas Jan: R$100K, Fev: R$120K, Mar: R$95K, Abr: R$140K",
    questions=[
        "Qual o mes com maior faturamento?",
        "Qual a tendencia de crescimento?",
        "Previsao para maio?"
    ],
    output_format="tabela com respostas + grafico ASCII de tendencia",
)
```

## Template 6: SOP a partir de Transcricao

Converte transcricoes de processo em documentacao estruturada.
O padrao `[VERIFICAR]` sinaliza gaps sem inventar informacao.

```python
import anthropic

client = anthropic.Anthropic()

def generate_sop(transcript: str) -> str:
    system = "Voce e um especialista em documentacao de processos."

    prompt = f"""Converta a transcricao abaixo em um SOP estruturado.

O SOP deve incluir:
1. Titulo (verbo-primeiro, orientado a acao)
2. Objetivo: uma frase sobre o que este SOP alcanca
3. Responsavel: quem executa a tarefa
4. Ferramentas necessarias
5. Pre-condicoes ou gatilhos
6. Instrucoes passo a passo, numeradas, com sub-passos onde util
7. Pontos de decisao: "Se X, entao Y"
8. Erros comuns e como evita-los
9. Criterios de sucesso

Regras:
- Linguagem direta e simples, sem jargao
- Cada passo = uma acao
- Preserve todos os detalhes mencionados (URLs, nomes, etapas exatas)
- NAO invente passos ausentes — marque lacunas com [VERIFICAR]
- Output em Markdown

<transcript>
{transcript}
</transcript>"""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1500,
        temperature=0.0,
        system=system,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text
```

## Template 7: Analise Comparativa com CoT em 3 Fases

```python
def comparative_analysis(
    domain: str,
    decision_context: str,
    options_list: str,
    context: str
) -> str:
    prompt = f"""Aja como um analista de {domain}.

Fase 1: Liste os criterios de avaliacao para {decision_context}.

Fase 2: Compare as seguintes opcoes contra esses criterios:
{options_list}

Fase 3: Recomende uma opcao com justificativa, explicitando os principais
trade-offs e uma incerteza que requer mais dados para ser resolvida.

Contexto: {context}"""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1200,
        temperature=0.0,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text
```

## Template 8: Pipeline Modular com Roles Distintos

```python
def modular_pipeline(aspect_1: str, aspect_2: str) -> str:
    """Cada modulo tem role distinto; sintese integra ao final."""

    # Modulo 1: Analise tecnica
    msg_1 = client.messages.create(
        model="claude-haiku-4-5",  # barato para analise especifica
        max_tokens=300,
        messages=[{"role": "user", "content":
            f"Como arquiteto de dados, produza analise de {aspect_1} "
            f"em no maximo 150 palavras. Declare 2 premissas e 1 incerteza."
        }]
    )

    # Modulo 2: Analise de impacto
    msg_2 = client.messages.create(
        model="claude-haiku-4-5",
        max_tokens=300,
        messages=[{"role": "user", "content":
            f"Como especialista em operacoes, avalie efeitos de {aspect_2} "
            f"em 150 palavras. Cite mitigacoes especificas de risco."
        }]
    )

    # Modulo 3: Sintese executiva
    synthesis = client.messages.create(
        model="claude-sonnet-4-6",  # mais caro apenas para sintese
        max_tokens=600,
        messages=[{"role": "user", "content":
            f"""Integre os dois memos em briefing de 300 palavras para reuniao executiva.
Inclua: um trade-off principal e uma incognita que requer dados adicionais.

Memo 1: <memo1>{msg_1.content[0].text}</memo1>
Memo 2: <memo2>{msg_2.content[0].text}</memo2>"""
        }]
    )
    return synthesis.content[0].text
```

## Template 9: Intent Classification + Response Chain

```python
def intent_routing(user_query: str) -> str:
    """Classifica intent com modelo barato, responde com especialista."""

    # Prompt 1: Classificacao
    classification = client.messages.create(
        model="claude-haiku-4-5",
        max_tokens=50,
        messages=[{"role": "user", "content":
            f"""Classifique a query em categoria primaria.
Retorne JSON: {{"primary": "billing|technical_support|account_management|general"}}
<query>{user_query}</query>"""
        }]
    )
    import json
    intent = json.loads(classification.content[0].text)

    # Prompt 2: Resposta especializada
    RESPONSE_PROMPTS = {
        "technical_support": f"""Voce e suporte tecnico especializado.
Ajude o usuario seguindo esta ordem:
1. Verifique conexoes basicas
2. Se persiste, pergunte o modelo do equipamento
3. Se nao resolver em 2 tentativas, retorne: {{"escalate": true}}
Query: {user_query}""",

        "billing": f"""Voce e especialista em faturamento.
Resolva com base nas politicas da empresa.
Se precisar de acesso ao sistema: {{"action_required": "billing_lookup"}}
Query: {user_query}""",
    }

    response_prompt = RESPONSE_PROMPTS.get(
        intent.get("primary", "general"),
        f"Voce e um assistente geral. Responda: {user_query}"
    )

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=500,
        messages=[{"role": "user", "content": response_prompt}]
    )
    return response.content[0].text
```

## See Also

- [../concepts/prompt-templates.md](../concepts/prompt-templates.md) -- criar templates custom
- [../concepts/few-shot-learning.md](../concepts/few-shot-learning.md) -- adicionar exemplos
- [constrained-generation.md](constrained-generation.md) -- restricoes de output
- [prompt-chaining.md](prompt-chaining.md) -- encadear templates em pipeline
