# Task Decomposition

> **Purpose**: Quebrar tarefas complexas em subtarefas gerenciaveis para melhor precisao
> **MCP Validated**: 2026-04-20

## When to Use

- Analises que combinam multiplas dimensoes (financeira + operacional + estrategica)
- Problemas que excedem a capacidade de um unico prompt
- Tarefas que exigem dados intermediarios para etapas posteriores
- Quando respostas monoliticas perdem qualidade

## Implementation

```python
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
import json

llm = ChatOpenAI(model="gpt-4o", temperature=0)


def decompose_and_execute(task: str, context: str = "") -> dict:
    """Decompoem tarefa complexa em subtarefas e executa cada uma.

    Args:
        task: descricao da tarefa complexa
        context: dados ou contexto adicional

    Returns:
        dict com subtarefas, resultados parciais e integracao final
    """
    # Etapa 1: decompor a tarefa
    decompose_prompt = f"""Decomponha a tarefa abaixo em 3-5 subtarefas independentes.
Retorne em JSON: {{"subtasks": ["subtarefa 1", "subtarefa 2", ...]}}

Tarefa: {task}
Contexto: {context}"""

    decomposition = llm.invoke([HumanMessage(content=decompose_prompt)])
    subtasks = json.loads(decomposition.content)["subtasks"]

    # Etapa 2: executar cada subtarefa
    partial_results = {}
    for i, subtask in enumerate(subtasks):
        sub_prompt = f"""Execute a subtarefa abaixo.
Contexto geral: {context}

Subtarefa {i+1}: {subtask}

Resultado:"""
        result = llm.invoke([HumanMessage(content=sub_prompt)])
        partial_results[subtask] = result.content

    # Etapa 3: integrar resultados
    integration_prompt = f"""Integre os resultados parciais abaixo
em uma analise coesa e completa.

Tarefa original: {task}

Resultados parciais:
{json.dumps(partial_results, indent=2, ensure_ascii=False)}

Analise integrada:"""

    final = llm.invoke([HumanMessage(content=integration_prompt)])

    return {
        "original_task": task,
        "subtasks": subtasks,
        "partial_results": partial_results,
        "integrated_result": final.content
    }


# Exemplo: analise financeira decomposta
result = decompose_and_execute(
    task="Analise completa da saude financeira da empresa",
    context=(
        "Receita: R$5M, Custos: R$3.2M, Divida: R$1.5M, "
        "Caixa: R$800K, Crescimento YoY: 15%"
    )
)
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `max_subtasks` | `5` | Limite de subtarefas na decomposicao |
| `parallel` | `False` | Executar subtarefas em paralelo |
| `integration` | `"llm"` | Estrategia de integracao: `"llm"`, `"concat"` |

## Decomposicao com Template por Dominio

```python
# Templates pre-definidos para dominios comuns
DECOMPOSITION_TEMPLATES = {
    "financial_analysis": [
        "Analise de profitabilidade (margem bruta, liquida, EBITDA)",
        "Analise de liquidez (corrente, seca, geral)",
        "Analise de fluxo de caixa (operacional, investimento, financiamento)",
        "Analise de endividamento (divida/patrimonio, cobertura de juros)",
    ],
    "market_research": [
        "Tamanho e crescimento do mercado (TAM, SAM, SOM)",
        "Analise competitiva (top 5 concorrentes, market share)",
        "Tendencias e oportunidades (tecnologia, regulacao, comportamento)",
        "Riscos e barreiras de entrada",
    ],
    "data_pipeline_review": [
        "Qualidade dos dados (completude, acuracia, consistencia)",
        "Performance (latencia, throughput, custo por GB)",
        "Resiliencia (retry, dead-letter, monitoramento)",
        "Seguranca (criptografia, acesso, auditoria)",
    ],
}

def decompose_with_template(task: str, domain: str, context: str) -> dict:
    """Usa template pre-definido para decomposicao."""
    subtasks = DECOMPOSITION_TEMPLATES.get(domain, [])
    if not subtasks:
        return decompose_and_execute(task, context)

    partial_results = {}
    for subtask in subtasks:
        prompt = f"Contexto: {context}\n\nAnalise: {subtask}\n\nResultado:"
        result = llm.invoke([HumanMessage(content=prompt)])
        partial_results[subtask] = result.content

    return {"subtasks": subtasks, "results": partial_results}
```

## See Also

- [prompt-chaining.md](prompt-chaining.md) -- encadear resultados das subtarefas
- [../concepts/chain-of-thought.md](../concepts/chain-of-thought.md) -- raciocinio dentro de cada subtarefa
- [specific-task-prompts.md](specific-task-prompts.md) -- templates para subtarefas
