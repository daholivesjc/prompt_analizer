# Prompt Engineering Quick Reference

> Tabelas de consulta rapida. Para exemplos de codigo, veja os arquivos linkados.
> **MCP Validated**: 2026-05-10

## Tecnicas Fundamentais

| Tecnica | Quando Usar | Complexidade |
|---------|-------------|--------------|
| Zero-Shot | Tarefas simples e diretas | Baixa |
| Few-Shot | Modelo precisa de padrao de referencia | Media |
| Chain-of-Thought | Problemas matematicos ou logicos | Media |
| Tree-of-Thought | Trade-offs entre alternativas | Media |
| Self-Ask | Perguntas compostas multi-fator | Media |
| Multi-Agent | Decisoes com multiplos stakeholders | Media |
| Role Prompting | Controlar tom e expertise | Baixa |
| Reflection | Ciclo de auto-revisao da resposta | Media |
| Self-Consistency | Respostas mais confiaveis (N paths) | Alta |
| Negative Prompting | Excluir conteudo indesejado | Baixa |

## Patterns de Producao

| Pattern | Problema que Resolve | Arquivo |
|---------|----------------------|---------|
| Prompt Chaining | Tarefas multi-etapa | `patterns/prompt-chaining.md` |
| Task Decomposition | Complexidade excessiva | `patterns/task-decomposition.md` |
| Constrained Generation | Formato rigido necessario | `patterns/constrained-generation.md` |
| CASTROFF Framework | Auditoria e design de prompt | `patterns/castroff-framework.md` |
| Prompt Debug Protocol | Prompt com falha sistematica | `patterns/prompt-debug-protocol.md` |
| Lost-in-the-Middle | Instrucoes ignoradas em contexto longo | `patterns/lost-in-the-middle.md` |
| Prompt Security | Prevenir injection basica | `patterns/prompt-security.md` |
| Advanced Security | Taxonomia completa + defesas sistema | `patterns/advanced-security.md` |
| Evaluation Metrics | Medir qualidade + seguranca | `patterns/evaluation-metrics.md` |
| Prompt Production Mgmt | Gestao de lifecycle em producao | `patterns/prompt-production-management.md` |

## Decision Matrix

| Caso de Uso | Tecnica Recomendada |
|-------------|---------------------|
| Classificacao simples | Zero-Shot com formato especifico |
| Classificacao com nuances | Few-Shot (3-5 exemplos) |
| Problema matematico | Chain-of-Thought |
| Trade-off entre alternativas | Tree-of-Thought |
| Pergunta com multiplos fatores | Self-Ask |
| Decisao com stakeholders conflitantes | Multi-Agent Prompting |
| Resposta tecnica detalhada | Role Prompting + CoT |
| Resposta critica/confiavel | Self-Consistency (N=5) |
| Auto-revisao de qualidade | Reflection (Answer→Reflect→Revise) |
| Output JSON estruturado | Constrained Generation |
| Pipeline multi-etapa | Prompt Chaining |
| Instrucoes ignoradas no meio | Lost-in-the-Middle |
| Input de usuario nao confiavel | Prompt Security + sanitizacao |
| Ataque PAIR ou injection indireta | Advanced Security |
| Prompt com falha sistematica | Prompt Debug Protocol |
| Audit de prompt existente | CASTROFF Framework |

## Erros Comuns

| Nao Faca | Faca |
|----------|------|
| Prompt vago: "Fale sobre X" | Prompt especifico com formato e restricoes |
| Muitos exemplos (>10) few-shot | 3-5 exemplos diversos e representativos |
| Ignorar formato de saida | Especificar JSON/Markdown/lista explicitamente |
| Instrucao critica no meio do prompt | Instrucao no inicio E no fim |
| Confiar em input de usuario | Sanitizar input antes de injetar no prompt |
| Prompt unico para tudo | Decompor em sub-prompts especializados |
| Avaliar prompts manualmente | Usar metricas automatizadas + LLM-as-Judge |
| Role apenas no user prompt | Role no system prompt para persona persistente |
| Otimizar sem medir robustez | Testar perturbacoes antes de producao |

## Formulas de Prompt

| Estrutura | Template |
|-----------|----------|
| Zero-Shot | `[Instrucao] + [Formato de saida]` |
| Few-Shot | `[Instrucao] + [Exemplos] + [Input]` |
| CoT | `[Instrucao] + "Pense passo a passo" + [Input]` |
| ToT | `[N opcoes] + "Avalie cada uma" + "Escolha a melhor"` |
| Self-Ask | `"Identifique sub-perguntas primeiro" + [Questao]` |
| Role | `"Voce e um [papel]..." + [Tarefa] + [Restricoes]` |
| Reflection | `[Tarefa] + [Criterios de revisao] + "Retorne versao revisada"` |
| CASTROFF | `[Constraints]+[Audience]+[Structure]+[Tone]+[Role]+[Output Format]+[Focus]+[Function]` |

## Seguranca Avancada

| Metrica | Definicao | Meta |
|---------|-----------|------|
| **Violation Rate** | % ataques bem-sucedidos / total tentados | < 1% |
| **False Refusal Rate** | % queries legitimas recusadas indevidamente | < 0.5% |

| Tipo de Ataque | Gravidade | Defesa Principal |
|---------------|-----------|-----------------|
| Prompt Extraction | Media | Tratar prompt como publico |
| Jailbreak Roleplaying | Alta | Preparacao proativa no system prompt |
| PAIR (automatizado) | Alta | Anomaly detection + rate limiting |
| Indirect Injection (RAG) | Critica | Instruction Hierarchy + isolamento |
| Divergence Attack | Media | Limite de tokens + deteccao de loops |

## Documentacao Relacionada

| Topico | Caminho |
|--------|---------|
| Inicio Rapido | `concepts/zero-shot-prompting.md` |
| Design de Prompt | `patterns/castroff-framework.md` |
| Debugging | `patterns/prompt-debug-protocol.md` |
| Seguranca Completa | `patterns/advanced-security.md` |
| Taxonomia de Ataques | `specs/attack-taxonomy.yaml` |
| Indice Completo | `index.md` |
