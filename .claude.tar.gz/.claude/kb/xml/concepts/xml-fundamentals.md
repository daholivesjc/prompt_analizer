# XML Fundamentals

> **Purpose**: Estrutura basica de documentos XML — elementos, atributos, namespaces e hierarquia
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-18

## Overview

XML (eXtensible Markup Language) e um formato de dados hierarquico amplamente usado em integracao de sistemas, notas fiscais eletronicas (NFe) e mensagens SAP IDoc. Diferente de JSON, XML suporta atributos em elementos, namespaces para evitar conflitos de nomes, e schemas formais (XSD/DTD) para validacao.

No projeto FDM Dados, XML e um dos formatos de entrada na camada landing, processado pelo job `ingest_xml_to_parquet.py` para gerar Parquet na camada raw.

## The Pattern

Um documento XML segue esta estrutura basica:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<root xmlns="http://example.com/ns">
  <record id="1" active="true">
    <name>Valor do Elemento</name>
    <nested>
      <child>Valor Aninhado</child>
    </nested>
  </record>
</root>
```

### Componentes Fundamentais

| Componente | Descricao | Exemplo |
|------------|-----------|---------|
| **Declaracao** | Versao e encoding do documento | `<?xml version="1.0" encoding="UTF-8"?>` |
| **Elemento** | Unidade basica de dados com tag de abertura e fechamento | `<name>Alice</name>` |
| **Atributo** | Metadado associado a um elemento | `<record id="1">` |
| **Namespace** | Prefixo URI que evita conflitos de nomes | `xmlns="http://example.com"` |
| **Elemento raiz** | Unico elemento de nivel superior | `<root>...</root>` |
| **Elemento vazio** | Elemento sem conteudo | `<empty/>` |

### Namespaces em Documentos Reais

NFe brasileira usa namespaces extensivamente:

```xml
<nfeProc xmlns="http://www.portalfiscal.inf.br/nfe">
  <NFe xmlns="http://www.portalfiscal.inf.br/nfe">
    <infNFe>
      <det nItem="1">
        <prod><cProd>001</cProd></prod>
      </det>
    </infNFe>
  </NFe>
</nfeProc>
```

O namespace `{http://www.portalfiscal.inf.br/nfe}` e prefixado em cada tag pelo parser, resultando em `{http://www.portalfiscal.inf.br/nfe}det`. O job remove esse prefixo com `strip_namespace()`.

## Quick Reference

| Caracteristica | XML | JSON |
|---------------|-----|------|
| Hierarquia | Sim | Sim |
| Atributos | Sim | Nao (usa campos) |
| Namespaces | Sim | Nao |
| Schema formal | XSD, DTD | JSON Schema |
| Elementos repetidos | Nomes iguais como irmaos | Array |
| Tipos nativos | Tudo e texto | string, number, boolean, null |
| Verbosidade | Alta (tags abertura+fechamento) | Baixa |

## Common Mistakes

| Erro | Consequencia | Solucao |
|------|-------------|---------|
| Ignorar namespaces | Tags nao sao encontradas pelo parser | Usar `strip_namespace()` ou busca com `{ns}tag` |
| Assumir ordem dos elementos | Parsing dependente de posicao quebra | Usar busca por tag name |
| Nao tratar elementos repetidos | Dados sobrescritos no dicionario | Indexar com sufixo `_0`, `_1` |
| Confundir atributo com elemento | Schema incorreto | Prefixar atributos com `_attr_` |
| Encoding incorreto | Caracteres corrompidos | Respeitar o encoding declarado no XML |

## Related

- [XML Parsing com Python](xml-parsing-python.md)
- [Conversao XML para DataFrame](xml-to-dataframe.md)
- [Tratamento de Namespaces](../patterns/namespace-handling.md)
