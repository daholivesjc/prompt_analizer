# XML Parsing com Python

> **Purpose**: Comparacao entre bibliotecas de parsing XML em Python e justificativa da escolha de ElementTree
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-18

## Overview

Python oferece multiplas bibliotecas para parsing XML. O projeto FDM Dados usa `xml.etree.ElementTree` (stdlib) por ser nativo, sem dependencias externas, e compativel com Dataproc Serverless sem necessidade de JARs ou pacotes adicionais.

## The Pattern

### Bibliotecas Disponíveis

| Biblioteca | Tipo | Stdlib | Velocidade | Uso Tipico |
|------------|------|--------|------------|------------|
| `xml.etree.ElementTree` | DOM (in-memory) | Sim | Moderada | Arquivos pequenos/medios (< 100 MB) |
| `xml.etree.ElementTree.iterparse` | SAX-like (streaming) | Sim | Alta | Arquivos grandes (> 100 MB) |
| `lxml.etree` | DOM + XPath completo | Nao | Muito alta | XPath complexo, validacao XSD |
| `xml.sax` | SAX (evento) | Sim | Alta | Streaming puro, baixa memoria |
| `xml.dom.minidom` | DOM completo | Sim | Lenta | Manipulacao DOM (raro em ETL) |

### Por que ElementTree no Projeto

1. **Sem JARs externos**: Dataproc Serverless nao requer configuracao de classpath
2. **Stdlib**: Nao precisa de `pip install` ou dependencias extras
3. **API simples**: `ET.fromstring()` + iteracao por `element.iter()`
4. **Suficiente para NFe/IDoc**: Documentos tipicamente < 10 MB

### DOM vs SAX

```text
DOM (ElementTree padrao):
  XML inteiro -> arvore na memoria -> navegacao livre
  Pro: Acesso aleatorio a qualquer no
  Con: Memoria proporcional ao tamanho do XML

SAX/iterparse (streaming):
  XML lido incrementalmente -> eventos por elemento -> processar e descartar
  Pro: Memoria constante independente do tamanho
  Con: So leitura sequencial, sem voltar atras
```

## Quick Reference

```python
import xml.etree.ElementTree as ET

# DOM — arquivo inteiro na memoria
root = ET.fromstring(xml_string)
for element in root.iter("det"):
    print(element.tag, element.attrib)

# iterparse — streaming com limpeza de memoria
for event, elem in ET.iterparse("large.xml", events=("end",)):
    if elem.tag == "det":
        process(elem)
        elem.clear()  # libera memoria

# Acessar texto e atributos
element.text          # conteudo textual
element.attrib        # dicionario de atributos
element.tag           # nome da tag (com namespace se houver)
list(element)         # filhos diretos
element.find("child") # primeiro filho com tag "child"
element.findall("child")  # todos os filhos com tag "child"
```

## Common Mistakes

| Erro | Consequencia | Solucao |
|------|-------------|---------|
| Usar `ET.parse()` com string | TypeError | Usar `ET.fromstring()` para strings |
| Esquecer `elem.clear()` no iterparse | Memory leak em arquivos grandes | Sempre limpar apos processar |
| Nao considerar namespaces em `find()` | Retorna None | Usar `{ns}tag` ou iterar com `strip_namespace()` |
| Usar lxml sem necessidade | Dependencia extra no Dataproc | ElementTree resolve a maioria dos casos |
| Comparar tags sem strip de namespace | Tags nao batem | `strip_namespace(element.tag) == row_tag` |

## Funcoes do Projeto

| Funcao | Descricao | Arquivo |
|--------|-----------|---------|
| `parse_xml_records()` | Extrai registros de uma string XML pelo row_tag | `ingest_xml_to_parquet.py` |
| `flatten_element()` | Achata elemento XML em dict plano recursivamente | `ingest_xml_to_parquet.py` |
| `strip_namespace()` | Remove prefixo de namespace de uma tag | `ingest_xml_to_parquet.py` |
| `read_gcs_file_content()` | Le conteudo de arquivo GCS via `wholeTextFiles` | `ingest_xml_to_parquet.py` |

## Related

- [XML Fundamentals](xml-fundamentals.md)
- [Padrao de Parsing com ElementTree](../patterns/etree-parsing.md)
- [Streaming de XML Grande](../patterns/large-xml-streaming.md)
