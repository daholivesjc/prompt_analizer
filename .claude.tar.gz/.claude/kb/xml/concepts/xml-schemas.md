# XML Schemas

> **Purpose**: XSD, DTD e validacao de documentos XML — contexto para ingestao de dados
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-18

## Overview

XML Schemas definem a estrutura valida de um documento XML: quais elementos sao permitidos, seus tipos, ordem, cardinalidade e restricoes. Os dois formatos principais sao XSD (XML Schema Definition) e DTD (Document Type Definition). No contexto de ingestao de dados, schemas ajudam a entender a estrutura esperada dos XMLs de entrada, mesmo que o job nao faca validacao formal.

## The Pattern

### XSD (XML Schema Definition)

XSD e o padrao moderno para validacao XML. Usa sintaxe XML e suporta tipos de dados, namespaces e heranca.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <xs:element name="catalog">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="product" maxOccurs="unbounded">
          <xs:complexType>
            <xs:sequence>
              <xs:element name="name" type="xs:string"/>
              <xs:element name="price" type="xs:decimal"/>
              <xs:element name="stock" type="xs:integer"
                          minOccurs="0" maxOccurs="unbounded"/>
            </xs:sequence>
            <xs:attribute name="sku" type="xs:string" use="required"/>
            <xs:attribute name="active" type="xs:boolean"/>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>
```

### DTD (Document Type Definition)

DTD e o formato legado, mais simples mas sem suporte a tipos de dados ou namespaces:

```xml
<!DOCTYPE catalog [
  <!ELEMENT catalog (product+)>
  <!ELEMENT product (name, price, stock*)>
  <!ATTLIST product sku CDATA #REQUIRED>
  <!ELEMENT name (#PCDATA)>
  <!ELEMENT price (#PCDATA)>
  <!ELEMENT stock (#PCDATA)>
]>
```

### Comparacao

| Caracteristica | XSD | DTD |
|---------------|-----|-----|
| Sintaxe | XML | Propria |
| Tipos de dados | 44+ tipos primitivos | Apenas texto |
| Namespaces | Suporte completo | Nao suporta |
| Cardinalidade | minOccurs/maxOccurs | `?`, `*`, `+` |
| Extensibilidade | Heranca, restricao | Limitada |
| Uso atual | Padrao moderno | Legado |

## Quick Reference

### Schemas Comuns no Projeto

| Formato | Schema | Row Tag | Observacao |
|---------|--------|---------|------------|
| NFe | XSD oficial da SEFAZ | `det` | Namespace obrigatorio |
| SAP IDoc | IDoc Documentation | `E1EDP01` | Segmentos com atributo SEGMENT |
| Catalogo generico | Sem schema formal | Variavel | Schema inferido pelo job |

### Relacao Schema XML -> Schema Spark

| XSD Type | Equivalente Spark | Mapeamento no Job |
|----------|------------------|-------------------|
| `xs:string` | StringType | `"string"` |
| `xs:integer` | IntegerType | `"integer"` |
| `xs:decimal` | DoubleType | `"double"` |
| `xs:long` | LongType | `"long"` |
| Todos os demais | StringType (padrao) | Inferencia automatica |

## Common Mistakes

| Erro | Consequencia | Solucao |
|------|-------------|---------|
| Validar XML contra XSD no job de ingestao | Overhead desnecessario e falhas em dados reais | Validacao e responsabilidade do produtor |
| Confiar que todos os campos existem | KeyError ou NullPointerException | Sempre usar `nullable=True` no schema |
| Ignorar `maxOccurs="unbounded"` | Elementos repetidos viram unico valor | Job trata com indexacao `tag_0`, `tag_1` |
| Assumir que XSD define todos os campos | XMLs reais podem ter extensoes | Schema inferido captura campos extras |

## Related

- [XML Fundamentals](xml-fundamentals.md)
- [XML para DataFrame](xml-to-dataframe.md)
- [Config de Ingestao](../specs/xml-ingestion-config.yaml)
