# XML para Spark DataFrame

> **Purpose**: Conversao de registros XML achatados (dicionarios) em Spark DataFrames com schema
> **Confidence**: 0.95
> **MCP Validated**: 2026-03-18

## Overview

Apos o parsing XML com ElementTree, os registros sao dicionarios Python planos (resultado do `flatten_element()`). A conversao para Spark DataFrame requer: (1) normalizar as chaves entre registros, (2) definir ou inferir o schema, e (3) criar o DataFrame via `spark.createDataFrame()`.

## The Pattern

### Fluxo de Conversao

```text
XML String
  |
  v
ET.fromstring() -> root Element
  |
  v
root.iter() -> filtrar por row_tag
  |
  v
flatten_element() -> list[dict[str, str]]
  |
  v
normalizar chaves (uniao de todas as keys)
  |
  v
spark.createDataFrame(records, schema) -> DataFrame
```

### Implementacao no Projeto

```python
# 1. Parsing: XML -> lista de dicts
records = parse_xml_records(xml_content, row_tag="det")
# [{"prod_cProd": "001", "prod_xProd": "Parafuso"}, ...]

# 2a. Schema inferido (padrao): todas as colunas como StringType
all_keys = sorted({k for r in records for k in r})
schema = StructType([
    StructField(k, StringType(), nullable=True) for k in all_keys
])
normalized = [{k: record.get(k) for k in all_keys} for record in records]
df = spark.createDataFrame(normalized, schema)

# 2b. Schema explicito: via --schema-json
schema = parse_schema_json('{"POSEX":"string","MENGE":"double"}')
df = spark.createDataFrame(records, schema)
```

### Normalizacao de Registros

Quando registros tem chaves diferentes (dados esparsos), a normalizacao garante que todos os dicionarios tenham as mesmas chaves:

```python
# Registro 1: {"name": "A", "stock_0": "100", "stock_1": "50"}
# Registro 2: {"name": "B", "stock_0": "200"}
# Registro 3: {"name": "C"}
# Apos normalizar: Registro 3 fica {"name": "C", "stock_0": None, "stock_1": None}
```

## Quick Reference

### Tipos Suportados pelo Schema JSON

| Tipo | Spark Type | Quando Usar |
|------|-----------|-------------|
| `string` | StringType | Padrao para tudo |
| `integer` / `int` | IntegerType | Contadores, quantidades inteiras |
| `long` / `bigint` | LongType | IDs grandes, timestamps epoch |
| `double` / `float` | DoubleType | Valores monetarios, medidas |

### Colunas de Metadados

O job adiciona automaticamente duas colunas apos a conversao:

| Coluna | Tipo | Conteudo |
|--------|------|----------|
| `_source_file` | string | Caminho GCS do arquivo XML de origem |
| `_ingestion_timestamp` | timestamp | Data/hora da ingestao |

### Schema Inferido vs Explicito

| Aspecto | Inferido (padrao) | Explicito (`--schema-json`) |
|---------|-------------------|----------------------------|
| Tipos | Tudo StringType | Tipos especificos |
| Colunas | Uniao de todas as chaves | Apenas colunas definidas |
| Dados esparsos | Preenchido com null | Preenchido com null |
| Performance | Calcula chaves | Schema pronto |
| Uso | Exploracao, schema desconhecido | Producao, schema estavel |

## Common Mistakes

| Erro | Consequencia | Solucao |
|------|-------------|---------|
| Nao normalizar chaves entre registros | `createDataFrame` falha com schema mismatch | Usar uniao de chaves com `record.get(k)` |
| Tipo errado no schema-json | RuntimeError ou dados truncados | Verificar tipos suportados no TYPE_MAP |
| Misturar schema explicito com colunas extras | Colunas extras ignoradas silenciosamente | Schema explicito filtra apenas as colunas definidas |
| Nao tratar arquivo sem registros | DataFrame nulo causa erro no write | `read_xml_file` retorna `None`, job faz `continue` |

## Related

- [XML Parsing com Python](xml-parsing-python.md)
- [Pipeline XML para Parquet](../patterns/xml-to-parquet.md)
- [Config de Ingestao](../specs/xml-ingestion-config.yaml)
