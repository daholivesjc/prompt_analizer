# XML Knowledge Base

> **Purpose**: Parsing e ingestao de arquivos XML para Parquet usando Python nativo (ElementTree) no Dataproc Serverless
> **MCP Validated**: 2026-03-18

## Quick Navigation

### Concepts (< 150 lines each)

| File | Purpose |
|------|---------|
| [concepts/xml-fundamentals.md](concepts/xml-fundamentals.md) | Estrutura XML, elementos, atributos, namespaces |
| [concepts/xml-parsing-python.md](concepts/xml-parsing-python.md) | ElementTree, lxml, SAX vs DOM — escolhas para PySpark |
| [concepts/xml-to-dataframe.md](concepts/xml-to-dataframe.md) | Conversao de XML para Spark DataFrame com schema |
| [concepts/xml-schemas.md](concepts/xml-schemas.md) | XSD, DTD e validacao de documentos XML |

### Patterns (< 200 lines each)

| File | Purpose |
|------|---------|
| [patterns/etree-parsing.md](patterns/etree-parsing.md) | Padrao de parsing com ElementTree usado no projeto |
| [patterns/xml-to-parquet.md](patterns/xml-to-parquet.md) | Pipeline completo XML -> Parquet (padrao do projeto) |
| [patterns/namespace-handling.md](patterns/namespace-handling.md) | Lidar com namespaces XML (NFe, SAP IDoc) |
| [patterns/large-xml-streaming.md](patterns/large-xml-streaming.md) | Parsing incremental para arquivos grandes com iterparse |

### Specs (Machine-Readable)

| File | Purpose |
|------|---------|
| [specs/xml-ingestion-config.yaml](specs/xml-ingestion-config.yaml) | Configuracao de ingestao XML do job do projeto |

---

## Key Concepts

| Concept | Description |
|---------|-------------|
| **ElementTree** | Parser XML nativo do Python, sem dependencia de JARs externos |
| **Row Tag** | Tag XML que identifica um registro/linha no DataFrame |
| **Flatten** | Achatamento recursivo de elementos aninhados em dicionario plano |
| **Namespace Stripping** | Remocao de prefixos de namespace para nomes de coluna limpos |

---

## Learning Path

| Level | Files |
|-------|-------|
| **Iniciante** | concepts/xml-fundamentals.md, concepts/xml-schemas.md |
| **Intermediario** | concepts/xml-parsing-python.md, patterns/etree-parsing.md |
| **Avancado** | patterns/xml-to-parquet.md, patterns/large-xml-streaming.md |

---

## Agent Usage

| Agent | Primary Files | Use Case |
|-------|---------------|----------|
| kb-architect | index.md, quick-reference.md | Navegacao e referencia rapida |
| spark-specialist | patterns/xml-to-parquet.md | Pipeline de ingestao XML |
| data-engineer | concepts/xml-to-dataframe.md | Conversao XML -> DataFrame |

---

## Project Context

Esta KB suporta o job de ingestao XML do projeto FDM Dados:

| Componente | Caminho |
|------------|---------|
| Job PySpark | `jobs/raw/ingest_xml_to_parquet.py` |
| Testes | `tests/test_ingest_xml_to_parquet.py` |
| Workflow | `workflows/wf_ingest_xml.yaml` |
| Terraform | `terraform/envs/jobs/ingest-xml/` |
| Documentacao | `docs/jobs/guia-execucao-ingest-xml.md` |
