# Padrao de Parsing com ElementTree

> **Purpose**: Padrao de parsing XML usado no projeto FDM Dados com xml.etree.ElementTree
> **MCP Validated**: 2026-03-18

## When to Use

- Parsing de arquivos XML ate ~100 MB (NFe, SAP IDoc, catalogos)
- Ambientes sem JARs externos (Dataproc Serverless)
- XMLs com namespaces que precisam ser removidos
- Necessidade de achatamento recursivo de elementos aninhados

## Implementation

### Funcao Principal: `parse_xml_records()`

```python
import xml.etree.ElementTree as ET


def strip_namespace(tag: str) -> str:
    """Remove prefixo de namespace: '{http://...}det' -> 'det'"""
    if tag.startswith("{"):
        return tag.split("}", 1)[1]
    return tag


def flatten_element(element: ET.Element, prefix: str = "") -> dict[str, str]:
    """Achata elemento XML recursivamente em dicionario plano.

    Convencoes:
    - Elementos aninhados: chaves separadas por underscore (prod_cProd)
    - Atributos: prefixo _attr_ (_attr_nItem)
    - Elementos repetidos: sufixo indexado (stock_0, stock_1)
    - Todos os valores sao strings
    """
    result = {}

    # Processar atributos do elemento
    for attr_name, attr_value in element.attrib.items():
        attr_key = strip_namespace(attr_name)
        key = f"{prefix}_attr_{attr_key}" if prefix else f"_attr_{attr_key}"
        result[key] = attr_value

    children = list(element)
    if not children:
        # Elemento folha: capturar texto
        if element.text and element.text.strip():
            key = prefix if prefix else strip_namespace(element.tag)
            result[key] = element.text.strip()
    else:
        # Contar ocorrencias de cada tag filha
        tag_counts: dict[str, int] = {}
        for child in children:
            tag = strip_namespace(child.tag)
            tag_counts[tag] = tag_counts.get(tag, 0) + 1

        # Processar filhos, indexando repetidos
        tag_seen: dict[str, int] = {}
        for child in children:
            child_tag = strip_namespace(child.tag)
            if tag_counts[child_tag] > 1:
                idx = tag_seen.get(child_tag, 0)
                tag_seen[child_tag] = idx + 1
                indexed_tag = f"{child_tag}_{idx}"
            else:
                indexed_tag = child_tag

            child_prefix = f"{prefix}_{indexed_tag}" if prefix else indexed_tag
            child_data = flatten_element(child, child_prefix)
            result.update(child_data)

    return result


def parse_xml_records(xml_content: str, row_tag: str) -> list[dict[str, str]]:
    """Extrai registros de XML que correspondem ao row_tag."""
    root = ET.fromstring(xml_content)
    records = []
    for element in root.iter():
        if strip_namespace(element.tag) == row_tag:
            record = flatten_element(element)
            records.append(record)
    return records
```

## Configuration

| Parametro | Descricao | Exemplo |
|-----------|-----------|---------|
| `row_tag` | Tag XML que identifica um registro | `det`, `E1EDP01`, `product` |
| `prefix` | Prefixo para chaves (usado na recursao) | `""`, `"prod"`, `"imposto_ICMS"` |

## Example Usage

### NFe com Namespaces

```python
# Input XML (com namespace)
xml = """<nfeProc xmlns="http://www.portalfiscal.inf.br/nfe">
  <NFe><infNFe>
    <det nItem="1">
      <prod><cProd>001</cProd><xProd>Parafuso</xProd></prod>
    </det>
  </infNFe></NFe>
</nfeProc>"""

records = parse_xml_records(xml, "det")
# [{"_attr_nItem": "1", "prod_cProd": "001", "prod_xProd": "Parafuso"}]
```

### SAP IDoc com Elementos Repetidos

```python
xml = """<ORDERS05><IDOC>
  <E1EDP01 SEGMENT="1">
    <POSEX>00010</POSEX>
    <E1EDP20 SEGMENT="1"><WMENG>250</WMENG></E1EDP20>
    <E1EDP20 SEGMENT="1"><WMENG>250</WMENG></E1EDP20>
  </E1EDP01>
</IDOC></ORDERS05>"""

records = parse_xml_records(xml, "E1EDP01")
# [{"_attr_SEGMENT": "1", "POSEX": "00010",
#   "E1EDP20_0_attr_SEGMENT": "1", "E1EDP20_0_WMENG": "250",
#   "E1EDP20_1_attr_SEGMENT": "1", "E1EDP20_1_WMENG": "250"}]
```

### Dados Esparsos

```python
# Produto 1 tem 2 stocks, Produto 2 tem 1, Produto 3 nenhum
# Resultado: colunas stock_0, stock_1 existem em todos
# Produto 3 tera null para stock_0 e stock_1 apos normalizacao
```

## See Also

- [XML Parsing com Python](../concepts/xml-parsing-python.md)
- [Pipeline XML para Parquet](xml-to-parquet.md)
- [Tratamento de Namespaces](namespace-handling.md)
