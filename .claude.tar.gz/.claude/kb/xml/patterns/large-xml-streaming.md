# Streaming de XML Grande com iterparse

> **Purpose**: Parsing incremental de arquivos XML grandes para evitar estouro de memoria
> **MCP Validated**: 2026-03-18

## When to Use

- Arquivos XML maiores que 100 MB
- Memoria limitada no executor Spark
- Milhares de registros em um unico arquivo XML
- Necessidade de processar sem carregar o documento inteiro na memoria

## Implementation

### Problema: DOM Carrega Tudo na Memoria

O padrao atual do projeto usa `ET.fromstring()` que carrega o XML inteiro na memoria:

```python
# Padrao atual — funciona bem para arquivos < 100 MB
xml_content = read_gcs_file_content(spark, file_path)  # string inteira
root = ET.fromstring(xml_content)  # arvore completa na memoria
for element in root.iter():
    if strip_namespace(element.tag) == row_tag:
        records.append(flatten_element(element))
```

### Solucao: iterparse com Limpeza de Memoria

```python
import xml.etree.ElementTree as ET
from io import BytesIO


def parse_xml_records_streaming(
    xml_content: str,
    row_tag: str,
    batch_size: int = 1000,
) -> list[list[dict[str, str]]]:
    """Parse XML em lotes usando iterparse para economia de memoria.

    Retorna lista de batches, cada um com ate batch_size registros.
    """
    batches = []
    current_batch = []

    # iterparse processa o XML incrementalmente
    stream = BytesIO(xml_content.encode("utf-8"))
    context = ET.iterparse(stream, events=("end",))

    for event, elem in context:
        if strip_namespace(elem.tag) == row_tag:
            record = flatten_element(elem)
            current_batch.append(record)

            if len(current_batch) >= batch_size:
                batches.append(current_batch)
                current_batch = []

            # CRITICO: liberar memoria do elemento processado
            elem.clear()

    if current_batch:
        batches.append(current_batch)

    return batches


def parse_large_xml_with_ancestor_clear(
    xml_content: str,
    row_tag: str,
) -> list[dict[str, str]]:
    """Parse com limpeza agressiva incluindo ancestrais.

    Para XMLs muito grandes onde mesmo os nos pais acumulam memoria.
    """
    records = []
    stream = BytesIO(xml_content.encode("utf-8"))

    # Manter referencia ao elemento pai para limpeza
    context = ET.iterparse(stream, events=("start", "end"))
    _, root = next(context)  # capturar o elemento raiz

    for event, elem in context:
        if event == "end" and strip_namespace(elem.tag) == row_tag:
            records.append(flatten_element(elem))
            elem.clear()

    # Limpar o root no final
    root.clear()
    return records
```

## Configuration

| Parametro | Default | Descricao |
|-----------|---------|-----------|
| `batch_size` | 1000 | Registros por lote antes de criar DataFrame |
| `events` | `("end",)` | Eventos iterparse: `start`, `end`, `start-ns`, `end-ns` |

### Comparacao de Memoria

| Metodo | Memoria | Velocidade | Quando Usar |
|--------|---------|------------|-------------|
| `ET.fromstring()` | O(tamanho XML) | Rapido | Arquivos < 100 MB |
| `ET.iterparse()` | O(tamanho registro) | Moderado | Arquivos 100 MB - 1 GB |
| `iterparse` + ancestor clear | O(1) constante | Mais lento | Arquivos > 1 GB |

## Example Usage

### Integracao com o Job Existente

```python
def read_xml_file_streaming(
    spark: SparkSession,
    file_path: str,
    row_tag: str,
    schema: StructType | None = None,
    batch_size: int = 1000,
) -> DataFrame | None:
    """Versao streaming do read_xml_file para arquivos grandes."""
    xml_content = read_gcs_file_content(spark, file_path)
    batches = parse_xml_records_streaming(xml_content, row_tag, batch_size)

    if not batches:
        return None

    # Criar DataFrame por lote e unir
    all_dfs = []
    for batch in batches:
        all_keys = sorted({k for r in batch for k in r})
        batch_schema = StructType([
            StructField(k, StringType(), nullable=True)
            for k in all_keys
        ])
        normalized = [{k: r.get(k) for k in all_keys} for r in batch]
        df = spark.createDataFrame(normalized, batch_schema)
        all_dfs.append(df)

    # Union de todos os batches
    result = all_dfs[0]
    for df in all_dfs[1:]:
        # Alinhar schemas antes do union
        for col in result.columns:
            if col not in df.columns:
                df = df.withColumn(col, F.lit(None).cast(StringType()))
        for col in df.columns:
            if col not in result.columns:
                result = result.withColumn(col, F.lit(None).cast(StringType()))
        result = result.unionByName(df)

    return result
```

### Quando Migrar para Streaming

```text
Decisao:
  Arquivo < 100 MB?
    -> Usar padrao atual (ET.fromstring)
  Arquivo 100 MB - 1 GB?
    -> iterparse com elem.clear()
  Arquivo > 1 GB?
    -> iterparse com ancestor clear
    -> Ou considerar pre-processar/split do XML
```

### Nota sobre GCS e wholeTextFiles

O metodo `read_gcs_file_content()` usa `wholeTextFiles` que carrega o arquivo inteiro como string. Para XMLs realmente grandes (> 1 GB), considerar:

1. Download temporario para disco local
2. Streaming direto via GCS client library
3. Pre-processamento para split do XML em arquivos menores

## See Also

- [XML Parsing com Python](../concepts/xml-parsing-python.md)
- [Padrao de Parsing ElementTree](etree-parsing.md)
- [Pipeline XML para Parquet](xml-to-parquet.md)
