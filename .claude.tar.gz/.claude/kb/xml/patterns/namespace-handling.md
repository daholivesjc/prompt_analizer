# Tratamento de Namespaces XML

> **Purpose**: Estrategias para lidar com namespaces XML em parsing para ingestao de dados
> **MCP Validated**: 2026-03-18

## When to Use

- XMLs com declaracao `xmlns` (NFe, SAP, SOAP)
- Tags que aparecem como `{http://...}tagname` no ElementTree
- Necessidade de nomes de coluna limpos no DataFrame

## Implementation

### O Problema

Quando XML tem namespace, o ElementTree prefixa cada tag com a URI do namespace:

```python
import xml.etree.ElementTree as ET

xml = '<nfeProc xmlns="http://www.portalfiscal.inf.br/nfe"><det/></nfeProc>'
root = ET.fromstring(xml)

# Tag real que o parser ve:
print(root[0].tag)
# '{http://www.portalfiscal.inf.br/nfe}det'

# Isso NAO funciona:
root.find("det")      # None
root.find("nfe:det")  # None (sem registro de prefixo)
```

### Solucao do Projeto: strip_namespace()

```python
def strip_namespace(tag: str) -> str:
    """Remove prefixo de namespace de uma tag XML.

    '{http://www.portalfiscal.inf.br/nfe}det' -> 'det'
    'item' -> 'item'  (sem namespace, retorna como esta)
    '{}tag' -> 'tag'   (namespace vazio)
    """
    if tag.startswith("{"):
        return tag.split("}", 1)[1]
    return tag
```

### Aplicacao no Parsing

A funcao e usada em dois pontos do fluxo:

```python
# 1. Encontrar registros pelo row_tag
def parse_xml_records(xml_content: str, row_tag: str) -> list[dict]:
    root = ET.fromstring(xml_content)
    records = []
    for element in root.iter():  # itera TODOS os elementos
        if strip_namespace(element.tag) == row_tag:  # compara sem namespace
            record = flatten_element(element)
            records.append(record)
    return records

# 2. Gerar chaves limpas no dicionario achatado
def flatten_element(element, prefix=""):
    # Atributos: strip namespace do nome
    for attr_name, attr_value in element.attrib.items():
        attr_key = strip_namespace(attr_name)
        key = f"{prefix}_attr_{attr_key}" if prefix else f"_attr_{attr_key}"
        result[key] = attr_value

    # Filhos: strip namespace da tag
    for child in children:
        child_tag = strip_namespace(child.tag)
        # ... logica de indexacao e recursao
```

## Configuration

Nao ha configuracao especifica. O tratamento de namespaces e automatico e transparente para o usuario do job.

| Tipo de Namespace | Exemplo XML | Comportamento |
|-------------------|-------------|---------------|
| Default namespace | `xmlns="http://..."` | Stripped automaticamente |
| Prefixed namespace | `xmlns:nfe="http://..."` | Stripped automaticamente |
| Namespace em atributo | `nfe:attr="value"` | Stripped automaticamente |
| Sem namespace | `<item>` | Retornado sem alteracao |

## Example Usage

### NFe (Nota Fiscal Eletronica)

```python
nfe_xml = """
<nfeProc xmlns="http://www.portalfiscal.inf.br/nfe">
  <NFe xmlns="http://www.portalfiscal.inf.br/nfe">
    <infNFe>
      <det nItem="1">
        <prod><cProd>001</cProd></prod>
        <imposto><ICMS><ICMS00><vBC>250.00</vBC></ICMS00></ICMS></imposto>
      </det>
    </infNFe>
  </NFe>
</nfeProc>
"""

records = parse_xml_records(nfe_xml, "det")
# Resultado (sem namespace nas chaves):
# [{"_attr_nItem": "1",
#   "prod_cProd": "001",
#   "imposto_ICMS_ICMS00_vBC": "250.00"}]
```

### Alternativa: Busca com Namespace Explicito

Para casos onde voce NAO quer remover namespaces (fora do escopo do job):

```python
# Abordagem com namespace explicito (ElementTree puro)
ns = {"nfe": "http://www.portalfiscal.inf.br/nfe"}
root.findall(".//nfe:det", ns)

# Abordagem com wildcard (Python 3.8+)
root.findall(".//{*}det")  # encontra 'det' em qualquer namespace
```

### Atributos com Namespace

```xml
<item xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:type="product">
  <name>Parafuso</name>
</item>
```

```python
# strip_namespace tambem funciona em nomes de atributos
# '{http://www.w3.org/2001/XMLSchema-instance}type' -> 'type'
# Chave no dict: '_attr_type'
```

## See Also

- [XML Fundamentals](../concepts/xml-fundamentals.md)
- [Padrao de Parsing ElementTree](etree-parsing.md)
- [Pipeline XML para Parquet](xml-to-parquet.md)
