# Pipeline XML para Parquet

> **Purpose**: Pipeline completo de ingestao XML -> Parquet usado no projeto FDM Dados
> **MCP Validated**: 2026-03-18

## When to Use

- Ingestao de arquivos XML da camada landing para raw no lakehouse Medallion
- Processamento batch via Dataproc Serverless
- Conversao de NFe, SAP IDoc ou XMLs genericos para Parquet

## Implementation

### Fluxo Completo do Job

```text
1. parse_args()           -> Argumentos CLI (source, destination, row-tag, etc.)
2. create_spark_session() -> SparkSession com AQE e Kryo
3. list_xml_files()       -> Descoberta via Hadoop FileSystem (recursivo)
4. filter_files_by_list() -> Filtro opcional por --files
5. Para cada arquivo:
   a. read_gcs_file_content()  -> String XML via wholeTextFiles
   b. parse_xml_records()      -> list[dict] pelo row_tag
   c. spark.createDataFrame()  -> DataFrame com schema inferido/explicito
   d. add_metadata_columns()   -> _source_file + _ingestion_timestamp
   e. build_output_path()      -> Caminho de saida (com/sem historic)
   f. write_parquet()           -> Escrita Parquet (snappy, overwrite/append)
6. Return JobMetrics      -> input_rows, output_rows, duration_seconds
```

### Submissao no Dataproc Serverless

```bash
# Basico
gcloud dataproc batches submit pyspark \
    gs://BUCKET/landing/scripts_pyspark/ingest_xml_to_parquet.py \
    --region=us-central1 \
    --version=2.2 \
    --service-account=SA@PROJECT.iam.gserviceaccount.com \
    -- \
    --source gs://BUCKET/landing/xml/ \
    --destination gs://BUCKET/raw/xml/ \
    --row-tag det

# Com schema explicito (SAP)
gcloud dataproc batches submit pyspark \
    gs://BUCKET/landing/scripts_pyspark/ingest_xml_to_parquet.py \
    --region=us-central1 --version=2.2 \
    --service-account=SA@PROJECT.iam.gserviceaccount.com \
    -- \
    --source gs://BUCKET/landing/xml/sap/ \
    --destination gs://BUCKET/raw/xml/sap/ \
    --row-tag E1EDP01 \
    --schema-json '{"POSEX":"string","MENGE":"double","MEINS":"string"}'

# Arquivos especificos com historico
gcloud dataproc batches submit pyspark \
    gs://BUCKET/landing/scripts_pyspark/ingest_xml_to_parquet.py \
    --region=us-central1 --version=2.2 \
    --service-account=SA@PROJECT.iam.gserviceaccount.com \
    -- \
    --source gs://BUCKET/landing/xml/nfe/ \
    --destination gs://BUCKET/raw/xml/nfe/ \
    --row-tag det \
    --has-historic true \
    --files nfe_001.xml nfe_002.xml
```

## Configuration

| Parametro | Tipo | Descricao |
|-----------|------|-----------|
| `--source` | string | Caminho GCS dos XMLs (busca recursiva) |
| `--destination` | string | Caminho GCS para Parquet de saida |
| `--row-tag` | string | Tag XML = 1 registro no DataFrame |
| `--schema-json` | JSON | Schema explicito de tipos |
| `--encoding` | string | Encoding do XML (default: UTF-8) |
| `--write-mode` | enum | `overwrite` (default) ou `append` |
| `--has-historic` | bool | Cria estrutura year/month/day |
| `--files` | list | Filtra arquivos por nome |

### Estrutura de Saida

```text
# Sem historic (--has-historic false)
gs://BUCKET/raw/xml/nfe_001/
  part-00000.snappy.parquet

# Com historic (--has-historic true)
gs://BUCKET/raw/xml/2026/3/18/nfe_001/
  part-00000.snappy.parquet
```

## Example Usage

### Teste Local com pytest

```python
def test_run_nfe(spark, tmp_path):
    source = str(tmp_path / "source")
    os.makedirs(source)
    (tmp_path / "source" / "nfe.xml").write_text(NESTED_XML)

    output = str(tmp_path / "output")
    args = parse_args([
        "--source", source,
        "--destination", output,
        "--row-tag", "det",
    ])
    with patch("...create_spark_session", return_value=spark):
        with patch.object(spark, "stop"):
            metrics = run(args)

    assert metrics.input_rows == 2
    result = spark.read.parquet(f"{output}/nfe")
    assert "prod_cProd" in result.columns
```

### Google Cloud Workflow

O job e orquestrado via Workflow YAML em `workflows/wf_ingest_xml.yaml` que:
1. Submete o batch no Dataproc Serverless
2. Faz polling ate conclusao
3. Pode ser agendado via Cloud Scheduler

## See Also

- [Padrao de Parsing ElementTree](etree-parsing.md)
- [Tratamento de Namespaces](namespace-handling.md)
- [XML para DataFrame](../concepts/xml-to-dataframe.md)
- [Config de Ingestao](../specs/xml-ingestion-config.yaml)
