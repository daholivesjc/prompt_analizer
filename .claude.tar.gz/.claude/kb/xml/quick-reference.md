# XML Quick Reference

> Fast lookup tables. Para exemplos de codigo, veja os arquivos linkados.
> **MCP Validated**: 2026-03-18

## Argumentos do Job XML

| Argumento | Obrigatorio | Default | Descricao |
|-----------|-------------|---------|-----------|
| `--source` | Sim | -- | Caminho GCS dos arquivos XML |
| `--destination` | Sim | -- | Caminho GCS para saida Parquet |
| `--row-tag` | Sim | -- | Tag XML que representa um registro |
| `--schema-json` | Nao | inferido | Schema explicito: `'{"col":"type"}'` |
| `--encoding` | Nao | UTF-8 | Encoding do arquivo XML |
| `--write-mode` | Nao | overwrite | Modo de escrita: overwrite ou append |
| `--has-historic` | Nao | false | Estrutura year/month/day no destino |
| `--files` | Nao | todos | Lista de arquivos especificos |

## Tipos de Schema Suportados

| Tipo JSON | Tipo Spark | Aliases |
|-----------|-----------|---------|
| `string` | StringType | -- |
| `integer` | IntegerType | `int` |
| `long` | LongType | `bigint` |
| `double` | DoubleType | `float` |

## Convencoes de Flatten

| XML Input | Chave no Dict | Exemplo |
|-----------|---------------|---------|
| Elemento simples | `tag` | `<name>A</name>` -> `name` |
| Aninhado | `pai_filho` | `<prod><cProd>1</cProd></prod>` -> `prod_cProd` |
| Atributo | `_attr_nome` | `<det nItem="1">` -> `_attr_nItem` |
| Repetido | `tag_N` | `<stock>100</stock><stock>50</stock>` -> `stock_0`, `stock_1` |
| Atributo de repetido | `tag_N_attr_nome` | `stock_0_attr_warehouse` |

## Formatos XML Comuns no Projeto

| Formato | Row Tag | Exemplo |
|---------|---------|---------|
| NFe (Nota Fiscal) | `det` | Itens de nota fiscal com namespace |
| SAP IDoc (ORDERS05) | `E1EDP01` | Pedidos SAP com segmentos aninhados |
| Catalogo de produtos | `product` | Produtos com elementos repetidos |
| Generico | configuravel | Qualquer XML com tag de registro |

## Decision Matrix

| Cenario | Abordagem |
|---------|-----------|
| XML < 100 MB | ElementTree (padrao do projeto) |
| XML > 100 MB | iterparse com limpeza de memoria |
| XML com namespace | strip_namespace automatico |
| Schema variavel entre arquivos | Inferencia automatica (default) |
| Schema fixo obrigatorio | `--schema-json` explicito |
| Elementos repetidos | Indexacao automatica (`tag_0`, `tag_1`) |

## Common Pitfalls

| Evite | Faca Assim |
|-------|------------|
| Usar spark-xml JAR | ElementTree nativo (sem classpath issues) |
| Ignorar namespaces | strip_namespace() remove automaticamente |
| Assumir tipos numericos | Tudo e string por padrao, use `--schema-json` |
| Processar XML gigante de uma vez | Use iterparse para streaming |
| Esquecer `--row-tag` | Argumento obrigatorio, define o registro |

## Related Documentation

| Topico | Caminho |
|--------|---------|
| Job de ingestao | `jobs/raw/ingest_xml_to_parquet.py` |
| Testes do job | `tests/test_ingest_xml_to_parquet.py` |
| Guia de execucao | `docs/jobs/guia-execucao-ingest-xml.md` |
| Conceitos XML | `concepts/xml-fundamentals.md` |
| Full Index | `index.md` |
